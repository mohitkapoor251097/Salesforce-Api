import { LightningElement } from "lwc";
import { ShowToastEvent } from "lightning/platformShowToastEvent";

export default class ZgrandParent extends LightningElement {
  handleChange() {}
  validate() {
    let isSelfValidated = true;
    isSelfValidated = [
      ...this.template.querySelectorAll("lightning-input")
    ].reduce((validSoFar, inputField) => {
      inputField.reportValidity();
      return validSoFar && inputField.checkValidity();
    }, true);

    let isChildValidated = true;
    [...this.template.querySelectorAll("c-zparent")].forEach((element) => {
      if (element.checkValidity() === false) {
        isChildValidated = false;
      }
    });
    if (isChildValidated && isSelfValidated) {
      this.dispatchEvent(
        new ShowToastEvent({
          title: "Success.",
          message: "Validated Successfully.",
          variant: "success"
        })
      );
    } else {
      this.dispatchEvent(
        new ShowToastEvent({
          title: "Error.",
          message: "Input values are not correct !",
          variant: "error"
        })
      );
    }
  }
}