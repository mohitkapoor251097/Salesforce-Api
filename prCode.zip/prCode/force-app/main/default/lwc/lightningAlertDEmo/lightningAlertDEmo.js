import { LightningElement } from 'lwc';
import LightningAlert from 'lightning/alert'
export default class LightningAlertDEmo extends LightningElement {

    async alertHandler(event){
        const {name}=event.target
        await LightningAlert.open({
            message:"this is alert",
            label:`I am ${name} alert Header`,
            theme:name,
            variant:'headerless'
         })
    }
}