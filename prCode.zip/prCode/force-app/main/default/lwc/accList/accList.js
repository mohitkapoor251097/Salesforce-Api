import { LightningElement,track,wire } from 'lwc';
import setDismissed from '@salesforce/apex/AccController.setDismissedAccount';
import getAccountList from '@salesforce/apex/AccController.showAccountDetails';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';

export default class AccList extends LightningElement {

 @track data;
connectedCallback(){
    getAccountList().
    then(result=>{
        this.data=result;
       console.log('Data is'+JSON.stringify(this.data));
    })
    .catch(error=>{
        console.log('Errorured:- ' +error.body.message);
    });

    }

    handleDismissClick(event){
        let accId = event.target.dataset.id;
        console.log('accId'+accId);
        setDismissed({accId:accId})
            .then(result => {
               console.log('data'+result);
               this.data=result;
               //refreshApex(this.data);
               this.showErrororSuccessMessage('Account is Dismissed Successfully !','success');
            })
            .catch(error => {
                console.log(error);
                this.showErrororSuccessMessage('something went wrong  !','error');
            });
        }
        showErrororSuccessMessage(message,msg) {
            const event = new ShowToastEvent({
                title: msg,
                message: message,
                variant: msg,
            });
            this.dispatchEvent(event);
        }

    }