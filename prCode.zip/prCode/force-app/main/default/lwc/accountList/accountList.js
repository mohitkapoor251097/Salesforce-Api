import { LightningElement,track,wire} from 'lwc';
import setDismissed from '@salesforce/apex/AccountController1.setDismissedAccount';
import getAccountList from '@salesforce/apex/AccountController1.getAccountList';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import getAccountList1 from '@salesforce/apex/AccountRelatedDataController.getAccounts';
export default class AccountList extends NavigationMixin(LightningElement) {
    @track data=[];
   check;
   contacts;
    spinnerStatus=false;
    ActiveOppName;
    @track ActiveContactName;
    ActiveCaseNumber;
    @track accounts = [];
    @track error;
    
    
    connectedCallback()
    {
     getAccountList()
     .then(result=>{
       this.data=result;
       //console.log(JSON.stringify(result.Opportunities));
     })
     .catch(error=>{
         console.log("error occured"+error);
     })
    }
    handleClick(event) {
        event.preventDefault();
        const receiveId = event.target.dataset.accountid;
        console.log('Clicked account Id:', receiveId);
        const idString = String(receiveId); // Use String() instead of toString()
        
        switch (true) { // Use a switch statemen
          case idString.startsWith('003'):
            this.Navigation('Contact', receiveId);
            break;
          case idString.startsWith('500'):
            this.Navigation('Case', receiveId);
            break;
          case idString.startsWith('006'):
            this.Navigation('Opportunity', receiveId);
            break;
          default: // Add a default case to handle unexpected input
            console.log('Invalid account ID');
            break;
        }
      }
    Navigation(object,Id){
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                "recordId":Id,
                "objectApiName": object,
                "actionName": "view"
            },
        });
    }
    handleDismissClick(event){
        const recieveId = event.target.dataset.accountid;
        console.log('accId'+recieveId);
        setTimeout(()=>{      
            this.spinnerStatus=true;
            setDismissed({accId:recieveId})
                .then(result => {
                   console.log('data'+result);
                   this.data=this.data.filter(acc => acc.Id !== recieveId);
                   this.spinnerStatus=false;
                  this.showErrororSuccessMessage('Account is Dismissed Successfully !','success');
                })
                .catch(error => {
                    console.log(error);
                    this.spinnerStatus=false;
                    this.showErrororSuccessMessage('something went wrong  !','error');
                });
        },3000);
       
        }
        showErrororSuccessMessage(message,msg) {
            const event = new ShowToastEvent({
                title: msg,
                message: message,
                variant: msg,
            });
            this.dispatchEvent(event);
        }

}










// handleClick1(event){
//     event.preventDefault();   
//     const accountId = event.target.dataset.accountid;
//     console.log('Clicked account Id:', accountId);
//     getOpportunityId({accountId:accountId})
//         .then(result => {
//             console.log('Opportunity details:', result);
//             this.Navigation('Opportunity',result.Id);
//             }
//         )
//         .catch(error => {
//             console.error('Error fetching Opportunity details:', error);
//             this.handlerrror(error.body.exceptionType);

//             // Handle the error here
//         });
  
// }
// handleClick2(event){
//     event.preventDefault();   
//     const accountId = event.target.dataset.accountid;
//     console.log('Clicked account Id:', accountId);
//     getCaseId({accountId:accountId})
//         .then(result => {
//             console.log('Case details:', result);
//             console.log('id => ' + event.target.dataset.contact);
//             this.Navigation('Case',result.Id);
//             }
//         )
//         .catch(error => {
//             console.error('Error fetching Case details:', JSON.stringify(error));
//             console.log(error.body.exceptionType);
//             this.handlerrror(error.body.exceptionType);
//             // Handle the error here
//         });
  
// }
// handlerrror(error){
//        if(error=='System.QueryException'){
//      this.showErrororSuccessMessage('Sorry,No Active Record is Found ','error');
//        }
// }


// Define a class-level variable to store the account list data
// Note: You can use whatever property name you want, depending on your component requirements
// let _accountListData = null;

// // Define a getter/setter pair to retrieve/store the data in the class-level variable
// get accountListData() {
//   return _accountListData;
// }
// set accountListData(data) {
//   _accountListData = data;
// }

// // Call the method to get the account list when the component is created or rendered
// constructor() {
//   super();
//   this.getAccountList();
// }

// renderedCallback() {
//   this.getAccountList();
// }

// // Define the method to get the account list and store it using the setter
// getAccountList() {
//   getAccountList()
//     .then(result => {
//       this.accountListData = result;
//       //console.log(JSON.stringify(result.Opportunities));
//     })
//     .catch(error => {
//       console.log("error occurred: " + error);
//     });
// }