import { LightningElement,wire ,api, track} from 'lwc';
import getDetails from '@salesforce/apex/AccountDetails.getDetails';
import { updateRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';

const COLUMNS = [
    { label: 'Account Name', fieldName: 'Name', type: 'text' },
    { label: 'Account Number', fieldName: 'AccountNumber', type: 'text' },
    { label: 'Email', fieldName: 'Email__c', type: 'email' },
    { label: 'Phone', fieldName: 'Phone', type: 'phone' },
    { label: 'Fax', fieldName: 'Fax', type: 'phone' },
    { label: 'Website', fieldName: 'Website', type: 'url' },
    { label: 'Industry', fieldName: 'Industry', type: 'text' },
    { label: 'Rating', fieldName: 'Rating', type: 'text' },
    {label:'Active',fieldName: 'Account.Contacts'},
    {
        type : 'button', typeAttributes: {
            label: 'Dismiss',
            name: 'dismiss',
            title: 'Click to Dismiss',
            variant: 'destructive'
        }
    }
];

export default class Details extends LightningElement {
    columns = COLUMNS;
    accountData = [];
    accResult;

    @wire(getDetails)
    wiredResult(result){
        if(result.data){
            this.accountData = result.data;
            console.log(result);
        }
        if(result.error){
            console.log('Error occured while fetching Account Data- ', result.error);
        }
    }

    get noRecordsFound() {
        return this.accountData.length == 0;
    }

    handleRowAction(event) {
        const action = event.detail.action;
        const row = event.detail.row;

        switch (action.name) {
            case 'dismiss':
                this.dismissAccount(row);
                break;
            default:
                break;
        }
    }

    dismissAccount(account) {
        const fields = {};
        // storing the accId in fields id
        fields.Id = account.Id;
        fields.Dismiss__c = true;

        console.log('Values are - ', fields.Id);
        console.log('Values of dismiss are - ', fields.Dismiss__c);
        const recordInput = { fields };
        
        updateRecord(recordInput)
            .then(() => {
                this.showToast('Success', 'Account Dismissed', 'success');
                this.accountData = this.accountData.filter(acc => acc.Id !== account.Id);
                refreshApex(this.accountData);
            })
            .catch((error) => {
                this.showToast('Error', 'Error Dismissing Account', 'error');
                console.error(error);
            });
    }

    showToast(title, message, variant) {
        const toastEvent = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant
        });
        this.dispatchEvent(toastEvent);
    }
}