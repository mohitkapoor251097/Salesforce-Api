import { LightningElement, api, wire } from 'lwc';
// Import Apex Methods
import getAccounts from '@salesforce/apex/AccountController1.getAccountList';
import dismissAccount from '@salesforce/apex/AccountController1.dismissAccount';

export default class AccountTable extends LightningElement {
    @api recordId;
    accountList = [];
  
    // Fetch Account List
    @wire(getAccounts)
    wiredAccounts({ error, data }) {
        if (data) {
            this.accountList = data;
        }
    }

    // Active Contact Click Function
    handleContactClick(event){
        let contactId = this.accountList[event.target.dataset.index].Active__c;
        if(contactId){
            // Navigate to Contact Record Page
            this[NavigationMixin.Navigate]({
              type: 'standard__recordPage',
              attributes: {
                  recordId: contactId,
                  objectApiName: 'Contact',
                  actionName: 'view'
              },
            });
        }
    }

    // Case Click Function
    handleCaseClick(event){
        let caseId = this.accountList[event.target.dataset.index].Case__c;
        if(caseId){
            // Navigate to Case Record Page
            this[NavigationMixin.Navigate]({
              type: 'standard__recordPage',
              attributes: {
                  recordId: caseId,
                  objectApiName: 'Case',
                  actionName: 'view'
              }
            });
        }
    }

    // Opportunity Click Function
    handleOppClick(event){
        let oppId = this.accountList[event.target.dataset.index].Opportunity__c;
        if(oppId){
            // Navigate to Opportunity Record Page
            this[NavigationMixin.Navigate]({
              type: 'standard__recordPage',
              attributes: {
                  recordId: oppId,
                  objectApiName: 'Opportunity',
                  actionName: 'view'
              }
            });
        }
    }

    // Dismiss Function
    handleDismissClick(event){
        let accId = event.target.dataset.id;
        dismissAccount({accountId: accId})
            .then(result => {
                this.accountList = this.accountList.filter(acc => acc.Id !== accId);
            })
            .catch(error => {
                console.log(error);
            });
    }
}