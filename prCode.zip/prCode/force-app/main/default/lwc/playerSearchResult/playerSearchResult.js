import { LightningElement,api,wire } from 'lwc';
import getCricketerList from '@salesforce/apex/CrickerterController.getCricketerList';
import { publish,MessageContext } from 'lightning/messageService';
import SELECTED_PLAYER_CHANNEL from '@salesforce/messageChannel/SelectedPlayer__c';
export default class PlayerSearchResult extends LightningElement {

    cricketerNationality='';
    cricketersData;
    selectedPlayerId;
    selectedPlayerName;

    @wire(getCricketerList,{nationality:'$cricketerNationality'})
    wireCricketers({error,data}){
          if(error){
             console.error(error);
          }
          else if(data){
               this.cricketersData=data;
               console.log(JSON.stringify(this.cricketersData));
          }
    }

    @wire(MessageContext)
    messageContext;


    handleClickPlayerCard(event){
        this.selectedPlayerId=event.currentTarget.dataset.id;
        this.selectedPlayerName=event.currentTarget.dataset.name;
        console.log('selectedPlayerId'+JSON.stringify(this.selectedPlayerId));

        publish(this.messageContext,SELECTED_PLAYER_CHANNEL,{cricketerId:this.selectedPlayerId});

        let boxClass=this.template.querySelectorAll('.selected');

        if(boxClass.length>0){
            this.removeClass();
        }
       let playerBox=this.template.querySelector(`[data-id="${this.selectedPlayerId}"]`);
       if(playerBox){
        playerBox.className='title_wrapper selected';
       }
       this.dispatchEvent(new CustomEvent('select',{
        detail:{
            playerId:this.selectedPlayerId,
            playerName:this.selectedPlayerName
        }
       }))

    }
    removeClass(){
         this.template.querySelectorAll('.selected')[0].classList.remove('selected');
    }

    @api
    searchCricketer(nationalityOfCrickter){
        console.log('value in child'+JSON.stringify(nationalityOfCrickter));
        this.cricketerNationality=nationalityOfCrickter;
    }

}