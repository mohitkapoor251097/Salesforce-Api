/*({ clickCreateItem : function(component, event, helper) {
    let validCamping = component.find('CampingItemform').reduce(function (validSoFar, inputCmp) { 
        inputCmp.showHelpMessageIfInvalid(); 
        return validSoFar && inputCmp.get('v.validity').valid; }, true);
    if(validCamping){ 
        var newItem = component.get("v.newItem"); 
       var campings = component.get("v.items"); 
        var item = JSON.parse(JSON.stringify(newCampingItem)); 
        campings.push(item); component.set("v.items",campings);
        component.set("v.newItem",{ 'sobjectType': 'Camping_Item__c','Name': '','Quantity__c': 0, 'Price__c': 0,'Packed__c': false }); } } })*/


({

    doInit:function(component, event, helper) {
        let action = component.get("c.getItems");
        action.setcallback(this,function(response){
            let state = response.getState();
            if (state === "SUCCESS") {
                let items = component.get("v.items");
                items.push(response.getReturnValue());
                component.set("v.items", items);
            }
            else
            {
                console.log("Failed with State" + state);
            }
        });
        $A.enqueueAction(action);
    },
    clickCreateItem : function(component, event, helper) {
    let validCamping = component.find('CampingItemform').reduce(function (validSoFar, inputCmp) {
            // Displays error messages for invalid fields
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;
        }, true);
        // If we pass error checking, do some real work
        if(validCamping){
            // Create the new expense
            var newItem = component.get("v.newItem");
                   var campings = component.get("v.items");
        var item = JSON.parse(JSON.stringify(newCampingItem));

        campings.push(item);

        component.set("v.items",campings);

         component.set("v.newItem",{ 'sobjectType': 'Camping_Item__c','Name': '','Quantity__c': 0,
        'Price__c': 0,'Packed__c': false });
            helper.createItem(component,item);
    }
    }
})