import { LightningElement } from 'lwc';
import getAccountList from '@salesforce/apex/AccountDataController.getAccount';
export default class FetchAccount extends LightningElement {

   accountId;
   accountList=[];
    connectedCallback(){
        getAccountList().then((result)=>{
             this.accountList=result.map((currItem)=>({
                label:currItem.Name,
                value:currItem.Id
             }))

        }).catch((error)=>{
            console.log('OUTPUT : ',JSON.stringify(error));
        })
    }

    handleChange(event) {
        this.accountId = event.detail.value;
        // const childComponent = this.template.querySelector('c-display-contact');
        // if (childComponent) {
        //     childComponent.fetchAccountId(this.accountId);  // Call method in child component
        // }
        const childComponent = this.refs.childComp;  // Correctly access via lwc:ref
        if (childComponent) {
            childComponent.fetchAccountId(this.accountId);  // Call method in child component
        } else {
            console.error('Child component not found');
        }

        console.log('OUTPUT : ', this.accountId);
    }
}