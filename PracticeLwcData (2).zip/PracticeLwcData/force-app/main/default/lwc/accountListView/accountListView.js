import { LightningElement, wire, track } from "lwc";
import { getListUi } from "lightning/uiListApi";
import ACCOUNT_OBJECT from "@salesforce/schema/Account";

export default class AccountListView extends LightningElement {
    @track listViewOptions = [];
    @track selectedListViewId;
    @track records;
    @track error;
   isLoading = true;
    pageToken = null;
    nextPageToken = null;
    previousPageToken = null;

    columns = [
        { label: "Name", fieldName: "Name" },
        { label: "Phone", fieldName: "Phone" },
        { label: "Industry", fieldName: "Industry" }
    ];

    // Fetch all list views for the Account object
    @wire(getListUi, { objectApiName: ACCOUNT_OBJECT })
    handleListUiResponse({ data, error }) {
        this.isLoading = false; // Stop loading
        if (data) {
        console.log("Full Data:", JSON.stringify(data.lists[0].label)); // Logs the full data structure
        console.log("Full Data:", JSON.stringify(data)); 
            // Check if listViewInfos exists
            if (data.lists) {
                this.listViewOptions =data.lists.map((listView) => ({
                    label: listView.label,
                    value: listView.id
                }));
                console.log("List View Options:", JSON.stringify(this.listViewOptions));
            } else {
                console.error("No list views found in data.");
                this.listViewOptions = [];
            }
        } else if (error) {
            console.error("Error fetching list views:", error);
            this.listViewOptions = [];
        }
    }
    
    
    // Fetch records for the selected list view dynamically
    @wire(getListUi, { objectApiName: ACCOUNT_OBJECT, listViewId: "$selectedListViewId", pageSize: 10,
        pageToken: "$pageToken", })
    fetchListViewRecords({ data, error }) {
        this.isLoading = false; // Stop loading
        if (data && data.records) {
            this.nextPageToken = data.records.nextPageToken;
            this.previousPageToken = data.records.previousPageToken;
            this.records = data.records.records.map((record) => {
                const { fields } = record;
                return {
                    id: record.id,
                    Name: fields?.Name?.value || "N/A", // Default to "N/A" if undefined
                    Phone: fields?.Phone?.value || "N/A", // Default to "N/A" if undefined
                    Industry: fields?.Industry?.value || "N/A" // Default to "N/A" if undefined
                };
            });
            this.error = undefined;
        } else if (error) {
            console.error("Error fetching records:", error);
            this.error = "Failed to fetch list view records.";
            this.records = undefined;
        }
    }
    

    // Handle list view selection
    handleListViewChange(event) {
        this.isLoading = true;
        this.selectedListViewId = event.detail.value;
        console.log('SelectedValue'+  this.selectedListViewId );
        
    }

    handleNextPage(e) {
        this.pageToken = this.nextPageToken;
      }
    
      handlePreviousPage(e) {
        this.pageToken = this.previousPageToken;
      }
    
}
