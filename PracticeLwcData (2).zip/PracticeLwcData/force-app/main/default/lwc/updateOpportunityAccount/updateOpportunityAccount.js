import { LightningElement,api, wire} from 'lwc';
import getAccounts from '@salesforce/apex/OpportunityListController.getAccounts';
import OPP_Name from '@salesforce/schema/Opportunity.Name';
import OPP_Id from '@salesforce/schema/Opportunity.Id';
import OPP_ACCOUNT from '@salesforce/schema/Opportunity.AccountId';
import OPP_ACCOUNTName from '@salesforce/schema/Opportunity.Account.Name';
import { getFieldValue, getRecord, updateRecord } from 'lightning/uiRecordApi';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
export default class UpdateOpportunityAccount extends LightningElement {

    @api recordId;
    accName;
    oppName;
    accountName;
accountList=[];
    connectedCallback(){
        getAccounts().then((result)=>{
          this.accountList=result.map((acc)=>({
            label:acc.Name,
            value:acc.Id
          }))
        }).catch((error)=>{
              console.log('OUTPUT : ',error);
        })
    }

    @wire(getRecord,{recordId:'$recordId',fields:[OPP_ACCOUNT,OPP_Name,OPP_ACCOUNTName]})
    oppAccount({data,error}){
        if(data){
            console.log('OUTPUT : ',data);
            this.accName=getFieldValue(data,OPP_ACCOUNT);
            this.oppName=getFieldValue(data,OPP_Name);
            this.accountName=getFieldValue(data,OPP_ACCOUNTName);
            console.log('accName'+this.accName);
        }
        else if(error){
            console.log('OUTPUT : ',error);
        }
    }

    changeHandler(event){
        this.accName=event.target.value;
        console.log('select value'+this.accName);
    }
    updateAccount(){
      let inputFields={};
      inputFields[OPP_Id.fieldApiName]=this.recordId;
      inputFields[OPP_ACCOUNT.fieldApiName]=this.accName;


      let recordInput={
        fields:inputFields
      }
      updateRecord(recordInput).then((result)=>{
          console.log('Updated Successfully');
         this.showMessage('success','success','Opportunity Account is Updated Succesfully !');

      }).catch((error)=>{
          console.log('OUTPUT : ',error);
          this.showMessage('error','error','something went wrong');
      })
    }

    showMessage(variant,title,message){
        const event=new ShowToastEvent({
                title:title,
                message:message,
                variant:variant
        })
        this.dispatchEvent(event);
    }

    get Title(){
        return `Update ${this.accountName} Account`;
    }
}