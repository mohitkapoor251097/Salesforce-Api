import { LightningElement,api,track } from 'lwc';

export default class Checkcall extends LightningElement {
    @track name='sfram'
    constructor(){
        super();
      console.log(' ----nmae OUTPUT : ',this.name);
    }

    connectedCallback(){
        console.log('---cono nmae OUTPUT : ',this.name);
    }
}