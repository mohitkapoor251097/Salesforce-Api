// wireGetRelatedListRecordsBatch.js
import { api, LightningElement, wire } from "lwc";
import { getRelatedListRecordsBatch } from "lightning/uiRelatedListApi";
export default class WireGetRelatedListRecordsBatch extends LightningElement {
  error;
  results;
  @api recordId;
  @wire(getRelatedListRecordsBatch, {
    parentRecordId: "$recordId",
    relatedListParameters: [
      {
        relatedListId: "Contacts",
        fields: ["Contact.Name", "Contact.Id"],
        sortBy: ["Contact.Name"],
      },
      {
        relatedListId: "Opportunities",
        fields: ["Opportunity.Name", "Opportunity.Amount"],
        sortBy: ["Opportunity.Amount"],
      },
    ],
  })
  listInfo({ error, data }) {
    if (data) {
      this.results = data.results;
      this.error = undefined;
    } else if (error) {
      this.error = error;
      this.results = undefined;
    }
  }
}

// // wireGetRelatedListRecordsBatch.js
// import { api, LightningElement, wire } from "lwc";
// import { getRelatedListRecordsBatch } from "lightning/uiRelatedListApi";

// export default class WireGetRelatedListRecordsBatch extends LightningElement {
//   error;
//   contactsData = [];
//   opportunitiesData = [];

//   @api recordId;

//   // Define columns for Contacts datatable
//   contactsColumns = [
//     { label: "Contact Name", fieldName: "Name" },
//     { label: "Contact ID", fieldName: "Id" },
//   ];

//   // Define columns for Opportunities datatable
//   opportunitiesColumns = [
//     { label: "Opportunity Name", fieldName: "Name" },
//     { label: "Amount", fieldName: "Amount", type: "currency" },
//   ];

//   @wire(getRelatedListRecordsBatch, {
//     parentRecordId: "$recordId",
//     relatedListParameters: [
//       {
//         relatedListId: "Contacts",
//         fields: ["Contact.Name", "Contact.Id"],
//         sortBy: ["Contact.Name"],
//       },
//       {
//         relatedListId: "Opportunities",
//         fields: ["Opportunity.Name", "Opportunity.Amount"],
//         sortBy: ["Opportunity.Amount"],
//       },
//     ],
//   })
//   listInfo({ error, data }) {
//     if (data) {
//       console.log("Data received:", JSON.stringify(data));

//       // Ensure data.results exists and is an array
//       if (Array.isArray(data.results)) {
//         // Process each related list in the results
//         data.results.forEach((result) => {
//           // Check if listReference and relatedListId are defined
//           const listId = result?.listReference?.relatedListId;
//           console.log("Processing related list:", listId);

//           if (listId === "Contacts" && Array.isArray(result.records)) {
//             // Map contact records if list is Contacts
//             this.contactsData = result.records.map((record) => ({
//               Id: record.fields.Id.value,
//               Name: record.fields.Name.value,
//             }));
//           } else if (listId === "Opportunities" && Array.isArray(result.records)) {
//             // Map opportunity records if list is Opportunities
//             this.opportunitiesData = result.records.map((record) => ({
//               Id: record.fields.Id.value,
//               Name: record.fields.Name.value,
//               Amount: record.fields.Amount.value,
//             }));
//           }
//         });
//       }

//       this.error = undefined;
//     } else if (error) {
//       console.error("Error retrieving data:", error);
//       this.error = error;
//       this.contactsData = [];
//       this.opportunitiesData = [];
//     }
//   }
// }

