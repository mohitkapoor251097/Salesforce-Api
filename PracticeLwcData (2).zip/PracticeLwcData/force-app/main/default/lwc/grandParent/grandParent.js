import { LightningElement } from 'lwc';

export default class GrandParent extends LightningElement{
    name;
    boundHandleData;
    
    connectedCallback() {
        console.log('--------------s');
        this.boundHandleData = this.recieveDate.bind(this); 
        console.log('OUTPUT : ',this.boundHandleData);
        this.template.addEventListener('senddata', this.boundHandleData); // Add listener
       }
       
       disconnectedCallback() {
        this.template.removeEventListener('senddata', this.boundHandleData); // Remove listener using the stored reference
       }
    recieveDate(event){
       this.name=event.detail.name;
    }
}