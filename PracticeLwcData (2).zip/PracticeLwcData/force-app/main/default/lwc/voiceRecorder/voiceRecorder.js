// import { LightningElement, track } from 'lwc';

// export default class voiceRecorder extends LightningElement {
//     @track isRecording = false; // Indicates recording status
//     @track videoAvailable = false; // Indicates if video is available for playback
//     @track statusMessage = 'Ready to record your screen!';
//     mediaRecorder;
//     videoChunks = [];
//     videoBlob;

//     // Computed properties for button states
//     get isNotRecording() {
//         return !this.isRecording;
//     }

//     get isVideoNotAvailable() {
//         return !this.videoAvailable;
//     }

//     async startRecording() {
//         try {
//             // Get screen and audio streams
//             const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
//             const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });

//             // Combine streams into one
//             const combinedStream = new MediaStream([
//                 ...screenStream.getTracks(),
//                 ...audioStream.getTracks(),
//             ]);

//             // Initialize MediaRecorder
//             this.mediaRecorder = new MediaRecorder(combinedStream);

//             // Start recording
//             this.mediaRecorder.onstart = () => {
//                 this.isRecording = true;
//                 this.statusMessage = 'Recording in progress...';
//                 this.videoChunks = []; // Clear previous chunks
//             };

//             // Capture video chunks
//             this.mediaRecorder.ondataavailable = (event) => {
//                 if (event.data.size > 0) {
//                     this.videoChunks.push(event.data);
//                 }
//             };

//             // Handle recording stop
//             this.mediaRecorder.onstop = () => {
//                 this.isRecording = false;
//                 this.videoAvailable = true;
//                 this.videoBlob = new Blob(this.videoChunks, { type: 'video/webm' });
//                 this.updateVideoElement();
//                 this.statusMessage = 'Recording stopped. You can Download the video now.';
//             };

//             this.mediaRecorder.start();
//         } catch (error) {
//             this.statusMessage = `Error: ${error.message}`;
//             console.error('Error starting recording:', error);
//         }
//     }

//     // stopRecording() {
//     //     if (this.mediaRecorder) {
//     //         this.mediaRecorder.stop();
//     //     }
//     // }
//     stopRecording() {
//         if (this.mediaRecorder) {
//             this.mediaRecorder.stop();
//         }

//         // Stop the screen stream
//         if (this.screenStream) {
//             this.screenStream.getTracks().forEach(track => track.stop());
//             this.screenStream = null; // Clear reference
//         }

//         // Stop the audio stream
//         if (this.audioStream) {
//             this.audioStream.getTracks().forEach(track => track.stop());
//             this.audioStream = null; // Clear reference
//         }
//     }
    

//     updateVideoElement() {
//         const videoElement = this.template.querySelector('video');
//         if (videoElement) {
//             // Clean up any existing video URL
//             if (videoElement.src) {
//                 URL.revokeObjectURL(videoElement.src);
//             }

//             // Set new video URL
//             const videoURL = URL.createObjectURL(this.videoBlob);
//             videoElement.src = videoURL;
//             videoElement.controls = true;
//             videoElement.autoplay = true;

//             // Play video
//             videoElement.play().catch((error) => {
//                 console.error('Error playing video:', error);
//             });
//         } else {
//             console.error('Video element not found.');
//         }
//     }

//     downloadRecording() {
//         if (this.videoBlob) {
//             const link = document.createElement('a');
//             link.href = URL.createObjectURL(this.videoBlob);
//             link.download = 'screen-recording.webm';
//             link.click();
//         } else {
//             console.error('No video blob available for download.');
//         }
//     }
// }

import { LightningElement, track } from 'lwc';

export default class VoiceRecorder extends LightningElement {
    @track isRecording = false; // Indicates recording status
    @track videoAvailable = false; // Indicates if video is available for playback
    @track statusMessage = 'Ready to record your screen!';
    mediaRecorder;
    screenStream; // Store screen stream
    audioStream; // Store audio stream
    videoChunks = [];
    videoBlob;

    // Computed properties for button states
    get isNotRecording() {
        return !this.isRecording;
    }

    get isVideoNotAvailable() {
        return !this.videoAvailable;
    }

    async startRecording() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
            alert('Screen recording is not supported on mobile browsers.');
            return;
        }
        try {
            // Get screen and audio streams
            this.screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
            this.audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });

            // Combine streams into one
            const combinedStream = new MediaStream([
                ...this.screenStream.getTracks(),
                ...this.audioStream.getTracks(),
            ]);

            // Initialize MediaRecorder
            this.mediaRecorder = new MediaRecorder(combinedStream);

            // Start recording
            this.mediaRecorder.onstart = () => {
                this.isRecording = true;
                this.statusMessage = 'Recording in progress...';
                this.videoChunks = []; // Clear previous chunks
            };

            // Capture video chunks
            this.mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    this.videoChunks.push(event.data);
                }
            };

            // Handle recording stop
            this.mediaRecorder.onstop = () => {
                this.isRecording = false;
                this.videoAvailable = true;
                this.videoBlob = new Blob(this.videoChunks, { type: 'video/webm' });
                this.updateVideoElement();
                this.statusMessage = 'Recording stopped. You can Download the video now.';
            };

            this.mediaRecorder.start();
        } catch (error) {
            this.statusMessage = `Error: ${error.message}`;
            console.error('Error starting recording:', error);
        }
    }

    stopRecording() {
        if (this.mediaRecorder) {
            this.mediaRecorder.stop();
        }

        // Stop the screen stream
        if (this.screenStream) {
            this.screenStream.getTracks().forEach(track => track.stop());
            this.screenStream = null; // Clear reference
        }

        // Stop the audio stream
        if (this.audioStream) {
            this.audioStream.getTracks().forEach(track => track.stop());
            this.audioStream = null; // Clear reference
        }
    }

    updateVideoElement() {
        const videoElement = this.template.querySelector('video');
        if (videoElement) {
            // Clean up any existing video URL
            if (videoElement.src) {
                URL.revokeObjectURL(videoElement.src);
            }

            // Set new video URL
            const videoURL = URL.createObjectURL(this.videoBlob);
            videoElement.src = videoURL;
            videoElement.controls = true;
            videoElement.autoplay = true;

            // Play video
            videoElement.play().catch((error) => {
                console.error('Error playing video:', error);
            });
        } else {
            console.error('Video element not found.');
        }
    }

    downloadRecording() {
        if (this.videoBlob) {
            const link = document.createElement('a');
            link.href = URL.createObjectURL(this.videoBlob);
            link.download = 'screen-recording.webm';
            link.click();
        } else {
            console.error('No video blob available for download.');
        }
    }
}

