import { getRelatedListCount } from 'lightning/uiRelatedListApi';
import { LightningElement, api, wire } from 'lwc';
import { refreshApex } from "@salesforce/apex";
export default class CountNoofContacts extends LightningElement {

    @api recordId;
    totalContacts;

    @wire(getRelatedListCount,{
        parentRecordId:'$recordId',
        relatedListId:'Contacts'
    })
    relatedcontacts({data,error}){
        if(data){

          this.totalContacts=data.count > 0 ? 'Total Contacts :'+ data.count :'There are not Related Contacts';
            console.log('related contacts'+JSON.stringify(data)); 
            refreshApex(data);
        }
        else if(error){
            console.log('error'+JSON.stringify(error));
    }

}
}