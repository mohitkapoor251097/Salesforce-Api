// import { LightningElement, track } from 'lwc';

// export default class ProductsApi extends LightningElement {





//     @track products = [];
//     @track error;
// @track productCategory=[];
//     // productCategory=[
//     //     {label:'fragrances', value:'fragrances'},
//     //     {label:'beauty',     value:'beauty'},
//     //     {label:'furniture', value:'furniture'},
//     //     {label:'groceries', value:'groceries'}
//     // ]

//     endPoint = 'https://dummyjson.com/products'; // Base endpoint
//     connectedCallback() {

//         this.fetchProducts();
//         this.showCategory();
//     }
//     async showCategory(){
//         const categoryURl=`${this.endPoint}/category-list`;
//         try {
//             const response = await fetch(categoryURl, {
//                 method: 'GET',
//                 headers: {
//                     'Content-Type': 'application/json',
//                 },
//             });
//             if (!response.ok) {
//                 throw new Error(`HTTP error! Status: ${response.status}`);
//             }
//             const data = await response.json();
//             console.log('OUTPUT data:---------', data);
//              this.productCategory=data.map((result=>({
//                 label:result,
//                 value:result
//              })))
//         } catch (error) {
//             this.error = error.message;
//             console.error('Error fetching products:', JSON.stringify(error));
//         }
//     }
//     async fetchProducts(endpoint = this.endPoint) {
//         try {
//             const response = await fetch(endpoint, {
//                 method: 'GET',
//                 headers: {
//                     'Content-Type': 'application/json',
//                 },
//             });
//             if (!response.ok) {
//                 throw new Error(`HTTP error! Status: ${response.status}`);
//             }
//             const data = await response.json();
//             console.log('OUTPUT data:', data);
//             this.products = data.products; // Assuming API response has a 'products' array
//         } catch (error) {
//             this.error = error.message;
//             console.error('Error fetching products:', JSON.stringify(error));
//         }
//     }
    
//     handleChange(event) {
//         const selectedCategory = event.target.value;
//         console.log('selectedCategory:', selectedCategory);
    
//         // Construct the endpoint for the selected category
//         const categoryEndpoint = `${this.endPoint}/category/${selectedCategory}`;
        
//         // Fetch products based on the selected category
//         this.fetchProducts(categoryEndpoint);
//     }


// }


import { LightningElement, track } from 'lwc';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
export default class ProductsApi extends LightningElement {
    @track products = [];
    @track productCategory = [];
    @track error = null;
    modalContainer = false;
    @track selectedData=[]
    endPoint = 'https://dummyjson.com/products'; // Base endpoint

    isPopupVisible = false; // Controls popup visibility
    recordId;
    connectedCallback() {
        this.initializeData();
    }

    async initializeData() {
        try {
            await Promise.all([this.fetchProducts(), this.fetchCategories()]);
        } catch (error) {
            console.error('Error during initialization:', error);
            this.error = error.message;
        }
    }

    async fetchCategories() {
        const categoryUrl = `${this.endPoint}/category-list`;
        const data = await this.fetchData(categoryUrl);
        if (data) {
            this.productCategory = data.map(category => ({
                label: category,
                value: category
            }));
        }
    }

    async fetchProducts(endpoint = this.endPoint) {
        const data = await this.fetchData(endpoint,'GET');
        if (data) {
            this.products = data.products || [];
        }
    }

    async fetchData(url,methodType) {
        try {
            const response = await fetch(url, {
                method: methodType,
                headers: { 'Content-Type': 'application/json' },
            });
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return await response.json();
        } catch (error) {
            console.error(`Error fetching data from ${url}:`, error);
            this.error = error.message;
            return null;
        }
    }

    handleChange(event) {
        const selectedCategory = event.target.value;
        console.log('Selected Category:', selectedCategory);
        const categoryEndpoint = `${this.endPoint}/category/${selectedCategory}`;
        this.fetchProducts(categoryEndpoint);
    }
    handleCloseModal(){
        this.modalContainer=false;
    }
   async  detailHandler(event){
        this.modalContainer=true;
        console.log('id'+event.target.dataset.id);
        const id = event.target.dataset.id;
        const productEndpoint = `${this.endPoint}/${id}`;
       this.selectedData= await this.fetchData(productEndpoint,'GET');
       console.log('data'+JSON.stringify(this. selectedData));
       
        
    }

    async deleteHandler(fetchId){
        const id = fetchId;
      //  this.recordId= event.target.dataset.id;
        console.log('Id---'+id);
        
        const productEndpoint = `${this.endPoint}/${id}`;
        this.selectedData= await this.fetchData(productEndpoint,'DELETE');
        console.log('data'+JSON.stringify(this. selectedData));
        this.products=this.products.filter((item)=> item.id!=id);
        this.isPopupVisible = false;
        this.showMessage('Product Deleted Sucessfully !','success','success');
    }

    showPopup(event) {
        this.isPopupVisible = true;
        this.recordId= event.target.dataset.id;
    }
    handleCancelDelete() {
        this.isPopupVisible = false; // Close the popup
    }
    handleConfirmDelete(event) {
        const recordId = event.detail.recordId;
        console.log('Record to delete:', recordId);
        this.deleteHandler(recordId);
    }

    showMessage(meessage,title,variant){
        this.dispatchEvent(new ShowToastEvent({
            message:meessage,
            title:title,
            variant:variant
        }))
    }
}
