import { LightningElement, api, wire } from 'lwc';
import { getRelatedListRecords } from 'lightning/uiRelatedListApi';

const columns=[
    { label: 'Contat Name', fieldName: 'name' },
    { label: 'Contat Email', fieldName: 'email' },
    { label: 'Contat Phone', fieldName: 'phone' }
]
export default class FetchRelatedRecord extends LightningElement {
    @api recordId;
    records;
    errors;
    columns=columns;
    @wire(getRelatedListRecords, {
        parentRecordId: '$recordId',
        relatedListId: 'Contacts',
        fields: ['Contact.Name', 'Contact.Id','Contact.Email', 'Contact.Phone'], // Use API names as strings
        sortBy: ['Contact.Name'] // Sort by API name as a string
    })
    relatedRecords({ data, error }) {
        if (data) {
          //  this.records = data.records;
          //  console.log('Fetched Related Records:', JSON.stringify(data.records));
          this.records=data.records.map(record => ({
            id: record.id,
            name: record.fields.Name.value,
            email: record.fields.Email?.value || 'test@gmail.com',
            phone: record.fields.Phone?.value || '13456780' // Use default if Phone is undefined
        }));
          this.errors = undefined;
        } else if (error) {
            this.errors = error;
            this.records = undefined;
        }
    }
}
