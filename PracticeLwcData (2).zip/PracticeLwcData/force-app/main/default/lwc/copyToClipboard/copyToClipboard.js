import { LightningElement, track } from 'lwc';

export default class CopyToClipboard extends LightningElement {
    textToCopy = 'This is the text to copy!';
    @track showMessage = false;

    async copyToClipboard() {
        try {
            // Use the Clipboard API to copy text
            await navigator.clipboard.writeText(this.textToCopy);

            // Show success message
            this.showMessage = true;

            // Hide the message after 2 seconds
            setTimeout(() => {
                this.showMessage = false;
            }, 2000);
        } catch (error) {
            console.error('Failed to copy text: ', error);
        }
    }
}
