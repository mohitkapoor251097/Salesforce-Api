import { LightningElement,api } from 'lwc';

export default class ModalProduct extends LightningElement {
    @api product;
    @api isVisible = false;

    get leftColumnFields() {
        return [
            { key: 'title', label: 'Title', value: this.product?.title },
            { key: 'category', label: 'Category', value: this.product?.category },
            { key: 'price', label: 'Price', value: this.product?.price },
            { key: 'rating', label: 'Rating', value: this.product?.rating },
        ];
    }

    get rightColumnFields() {
        return [
            { key: 'brand', label: 'Brand', value: this.product?.brand },
            { key: 'warrantyInfo', label: 'Warranty Info', value: this.product?.warrantyInformation },
            { key: 'shippingInfo', label: 'Shipping Info', value: this.product?.shippingInformation },
            { key: 'returnPolicy', label: 'Return Policy', value: this.product?.returnPolicy },
        ];
    }
    _hideModal() {
        this.isVisible = false;
        const closeEvent = new CustomEvent('close');
        this.dispatchEvent(closeEvent);
    }

    // Method to close modal
    closeModalAction() {
        this._hideModal();
    }

   
}