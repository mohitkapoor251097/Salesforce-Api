import { LightningElement } from 'lwc';

export default class VoiceRecorderSample extends LightningElement {
    isRecording = false;
    audioChunks = [];
    mediaRecorder;
    audioURL;
    audioAvailable = false;
    statusMessage = 'Click Start to Begin Recording';
    recordingLabel = 'Start Recording';
    isPlayDisabled = true;
    isDownloadDisabled = true;

    // Toggle recording state
    handleRecordingToggle() {
        if (this.isRecording) {
            this.stopRecording();
        } else {
            this.startRecording();
        }
    }

    // Start recording process
    startRecording() {
        this.isRecording = true;
        this.recordingLabel = 'Stop Recording';
        this.statusMessage = 'Recording in progress...';
        this.audioChunks = [];
        this.isPlayDisabled = true;
        this.isDownloadDisabled = true;

        navigator.mediaDevices.getUserMedia({ audio: true })
            .then((stream) => {
                this.mediaRecorder = new MediaRecorder(stream);
                this.mediaRecorder.ondataavailable = (event) => this.audioChunks.push(event.data);
                this.mediaRecorder.onstop = () => this.onRecordingStop();
                this.mediaRecorder.start();
            })
            .catch((err) => {
                console.error("Error accessing media devices: ", err);
                this.statusMessage = "Error: Unable to access microphone.";
            });
    }

    // Stop recording and process audio
    stopRecording() {
        this.isRecording = false;
        this.recordingLabel = 'Start Recording';
        this.statusMessage = 'Recording stopped.';
        this.mediaRecorder.stop();
    }

    // Handle stop recording event
    onRecordingStop() {
        const audioBlob = new Blob(this.audioChunks, { type: 'audio/wav' });
        this.audioURL = URL.createObjectURL(audioBlob);
        this.audioAvailable = true;
        this.isPlayDisabled = false;
        this.isDownloadDisabled = false;
    }

    // Play the recorded audio
    handlePlayRecording() {
        const audioPlayer = this.template.querySelector('audio');
        audioPlayer.play();
    }

    // Download the recorded audio
    handleDownloadRecording() {
        const link = document.createElement('a');
        link.href = this.audioURL;
        link.download = 'recording.wav';
        link.click();
    }
}
