import { LightningElement } from 'lwc';

export default class ChatGPT extends LightningElement {
    userInput = '';
    messages = [];

    handleInputChange(event) {
        this.userInput = event.target.value;
    }

    sendMessage() {
        if (this.userInput.trim()) {
            this.addMessage('user', this.userInput);
            this.getChatGPTResponse(this.userInput);
            this.userInput = ''; // Clear input field
        }
    }

    addMessage(sender, text) {
        this.messages = [...this.messages, {
            id: this.messages.length + 1,
            text,
            class: sender === 'user' ? 'slds-text-align_right' : 'slds-text-align_left'
        }];
    }

    async getChatGPTResponse(userMessage) {
        const apiKey = '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';  // Replace with your OpenAI API key
        const endpoint = 'https://chatgpt.com/';
    
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
        };
    
        const body = JSON.stringify({
            model: 'gpt-3.5-turbo',  // Updated to a correct model name
            messages: [{ role: 'user', content: userMessage }]
        });
    
        try {
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: headers,
                body: body
            });
    
            if (response.ok) {
                const data = await response.json();
                const message = data.choices[0].message.content;
                this.addMessage('gpt', message);
            } else {
                const errorData = await response.json();
                throw new Error(`API Error: ${errorData.error.message}`);
            }
        } catch (error) {
            console.error('Error fetching GPT response:', error);
            this.addMessage('gpt', `Sorry, something went wrong. Error: ${error.message}`);
        }
    }
    
}
