// catImages.js
import { LightningElement, track } from 'lwc';

export default class CatImages extends LightningElement {
    @track images = [];
    @track error;
   
    connectedCallback() {
        this.fetchCatImages();
    }

    async fetchCatImages() {
        const value=20;
        const endpoint = 'https://api.thecatapi.com/v1/images/search?limit='+value;
        const apiKey = 'live_PfF1JKD7ByCsnEbh1EOLZRy0TftKQj2vU5kTWHR9NgYoonWNNjGhsgosBo8dIhml';

        try {
            const response = await fetch(endpoint,{
                method: 'GET',
                // headers: {
                //     'x-api-key': apiKey,
                //     'Content-Type': 'application/json',
                // },
            });
            

            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const data = await response.json();
            this.images = data;
            console.log('Fetched Images:', this.images);
        } catch (error) {
            this.error = error.message;
            console.error('Error fetching cat images:', this.error);
        }
    }
}
