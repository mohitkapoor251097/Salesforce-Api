import { LightningElement,api} from 'lwc';
import OPP_NAME from '@salesforce/schema/Opportunity.Name';
import OPP_CLOSEDATE from '@salesforce/schema/Opportunity.CloseDate';
import OPP_STAGE from '@salesforce/schema/Opportunity.StageName';
import OPPORTUNITY_OBJECT from '@salesforce/schema/Opportunity';
import {CloseActionScreenEvent} from 'lightning/actions';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
export default class CreateOppUsingQuickAction extends LightningElement {

    @api recordId;
    objectApiName=OPPORTUNITY_OBJECT
    fieldList={
        opportunityName:OPP_NAME,
        closeDate:OPP_CLOSEDATE,
        stageName:OPP_STAGE
    }

    closeModel(){
        console.log("------------");
        this.dispatchEvent(new CloseActionScreenEvent());
    }
    sucessHandler(){
           this.showToastMessage('Success','success','Opportunity is Created Successfully !');
           this.dispatchEvent(new CloseActionScreenEvent());
          
    }
    errorHandler(event){
        console.log('OUTPUT : ',event.detail.message);
        this.showToastMessage('error','error',event.detail.message);
    }
    submitHandler(event){
          event.preventDefault();
          const fields=event.detail.fields;
          if(!fields.AccountId){
             fields.AccountId=this.recordId;
          }
          this.template.querySelector('lightning-record-edit-form').submit(fields);
    }
    resetHandler(){
     let inputFields=this.template.querySelectorAll('lightning-input-field');
     inputFields.forEach((currItem)=> currItem.reset());
    }

    showToastMessage(title,variant,message){
        const event=new ShowToastEvent({
            title:title,
            variant:variant,
            message:message
         })
         this.dispatchEvent(event);
    }
}