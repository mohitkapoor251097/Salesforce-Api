import { LightningElement, wire } from 'lwc';
import getOpportunityList from '@salesforce/apex/OpportunityListController.getOpportunityList';
import getOpportunityFilterList from '@salesforce/apex/OpportunityListController.getOpportunityFilterList';
import { getObjectInfo, getPicklistValues } from 'lightning/uiObjectInfoApi';
import OPP_OBJECT from '@salesforce/schema/Opportunity';
import STAGE_NAME from '@salesforce/schema/Opportunity.StageName';
const columns = [
    { label: 'Name', fieldName: 'Name' },
    { label: 'Account Name', fieldName: 'AccountName' },
    { label: 'Stage Name', fieldName: 'StageName' },
    { label: 'Close Date', fieldName: 'CloseDate', type: 'date' }
]
export default class OpportunnityList extends LightningElement {
    columns = columns;
    opportunityList = [];
    value;
    connectedCallback() {
        getOpportunityList().then((result) => {
            this.opportunityList = result.map((opp) => ({
                ...opp, AccountName: opp.Account?.Name
            }))
        })
    }

    @wire(getObjectInfo, { objectApiName: OPP_OBJECT })
    opportunityObjectInfo;


    @wire(getPicklistValues, {
        recordTypeId: '$opportunityObjectInfo.data.defaultRecordTypeId',
        fieldApiName: STAGE_NAME
    }) picklistValues;

    changeHandler(event) {
        this.value = event.target.value;
        console.log('select value' + this.value);
    }
    @wire(getOpportunityFilterList, {
        selectedStageName: '$value'
    })
    opportunityFilterList({ data, error }) {
        if (data) {
            this.opportunityList = data.map((opp) => ({
                ...opp, AccountName: opp.Account?.Name
            }))
        }
        else if (error) {
            console.log('OUTPUT : ', error);
        }
    }



}