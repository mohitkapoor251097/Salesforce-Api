import { LightningElement } from 'lwc';

export default class ChildSlotComponent extends LightningElement {}