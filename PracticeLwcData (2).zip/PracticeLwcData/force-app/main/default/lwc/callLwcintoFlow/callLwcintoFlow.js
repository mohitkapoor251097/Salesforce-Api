import { LightningElement, api } from 'lwc';
import {FlowAttributeChangeEvent} from 'lightning/flowSupport';
export default class CallLwcintoFlow extends LightningElement {

   @api fName;
   @api lName;

   handleChange(event) {
    this[event.target.name] = event.target.value;

    const attributeChangeEvent = new FlowAttributeChangeEvent(event.target.name, event.target.value);
    this.dispatchEvent(attributeChangeEvent);
}
}