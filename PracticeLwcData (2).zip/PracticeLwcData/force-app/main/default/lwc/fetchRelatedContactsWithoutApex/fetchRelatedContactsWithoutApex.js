import { LightningElement,api, wire } from 'lwc';
import { getRecord } from 'lightning/uiRecordApi';
import CONTACT_OBJECT from '@salesforce/schema/Contact';
import CONTACT_NAME from '@salesforce/schema/Contact.Name';
import CONTACT_PHONE from '@salesforce/schema/Contact.Phone';
import CONTACT_EMAIL from '@salesforce/schema/Contact.Email';
const COLUMNS = [
    { label: 'Name', fieldName: 'Name', type: 'text' },
    { label: 'Phone', fieldName: 'Phone', type: 'phone' },
    { label: 'Email', fieldName: 'Email', type: 'email' }
];

export default class FetchRelatedContactsWithoutApex extends LightningElement {


   @api recordId;

    contacts;
    error;
    columns = COLUMNS;

    @wire(getRecord, { 
        recordId: '$recordId', 
        fields: [CONTACT_OBJECT, CONTACT_NAME, CONTACT_PHONE, CONTACT_EMAIL]
    })
    accountHandler({ error, data }) {
        if (data) {
            // Assuming Contacts field is available in record
            this.contacts = data.fields.Contacts.records.map(contact => {
                return {
                    Id: contact.id,
                    Name: contact.fields.FirstName.value + ' ' + contact.fields.LastName.value,
                    Phone: contact.fields.Phone.value,
                    Email: contact.fields.Email.value
                };
            });
        } else if (error) {
            this.error = error;
            this.contacts = undefined;
        }
    }
}

   