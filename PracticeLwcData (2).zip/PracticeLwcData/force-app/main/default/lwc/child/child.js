import { LightningElement } from 'lwc';

export default class Child extends LightningElement {

    handleChange(event){
        const Cusevent=new CustomEvent('senddata',{
            detail:{
                 name:event.target.value
             },
             bubbles:true,
             composed:true
        })
        this.dispatchEvent(Cusevent);
    }
}