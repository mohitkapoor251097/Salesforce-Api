import { LightningElement } from 'lwc';

export default class ParentSlotComponent extends LightningElement {

}