import { LightningElement } from 'lwc';
export default class DisplayAccountData extends LightningElement {
    accountId;
    handleChange(event){
      this.accountId=event.detail.recordId;
      console.log('OUTPUT : ',this.accountId);
    }

}