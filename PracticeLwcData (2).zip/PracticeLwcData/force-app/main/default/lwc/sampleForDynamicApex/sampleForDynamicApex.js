import { LightningElement, wire } from 'lwc';
import getAllObject from '@salesforce/apex/SObjectApexClass.getAllObject';
export default class SampleForDynamicApex extends LightningElement {

   sObjectOptions=[];
   selectedObject;
    @wire(getAllObject)
    wiredObjectNames({data,error}){
        if(data){
          this.sObjectOptions=data.map(sObjectName=>{
             return {label:sObjectName,value:sObjectName}
          })
        }else if(error){
            console.log(error);
        }   
    }
    handleSobjectChange(event){
        this.selectedObject=event.target.value;
        console.log('Selected'+  this.selectedObject);
    }
}