import { LightningElement, wire, api } from 'lwc';
import ACCOUNT_RATING from '@salesforce/schema/Account.Rating';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import ACCOUNT_NAME from '@salesforce/schema/Account.Name';
import ACCOUNT_ID from '@salesforce/schema/Account.Id';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { getFieldValue, getRecord, updateRecord } from 'lightning/uiRecordApi';
import { getObjectInfo, getPicklistValuesByRecordType } from 'lightning/uiObjectInfoApi';
export default class UpdateAccount extends LightningElement {

    @api recordId;
    accountName;
    accountRating;

    accountRatingOptions;
    @wire(getObjectInfo, { objectApiName: ACCOUNT_OBJECT })
    accountObjectInfo;

    @wire(getPicklistValuesByRecordType, {
        objectApiName: ACCOUNT_OBJECT,
        recordTypeId: '$accountObjectInfo.data.defaultRecordTypeId'
    })
    accountPickListValues({ data, error }) {
        if (data) {
            this.accountRatingOptions = data.picklistFieldValues.Rating.values;
            console.log('OUTPUT ----: ', this.accountRatingOptions);
        } else if (error) {
            console.log(error);
        }
    }
    @wire(getRecord, {
        recordId: '$recordId',
        fields: [ACCOUNT_NAME, ACCOUNT_RATING]
    })
    accountInfo({ data, error }) {
        if (data) {
            this.accountName = getFieldValue(data, ACCOUNT_NAME);
            this.accountRating = getFieldValue(data, ACCOUNT_RATING);
            console.log('rating OUTPUT : ', this.accountRating);
        } else if (error) {
            console.log('OUTPUT : ', JSON.stringify(error));
        }
    }
    handleChange(event) {
        this.accountRating = event.target.value;
        console.log('changing' + this.accountRating);
    }

    handleUpdate() {
        let inputFields = {};
        inputFields[ACCOUNT_ID.fieldApiName] = this.recordId;
        inputFields[ACCOUNT_RATING.fieldApiName] = this.accountRating;

        let recordInput = {
            fields: inputFields
        }

        updateRecord(recordInput).then((result) => {
            console.log('Suceessfully Update');
            this.showToastMessage('success', 'Account Updated Successfully', 'success');
        }).catch((error) => {
            console.log('error in update : ', error);
            this.showToastMessage('error', 'something went wrong', 'error');
        })

    }

    showToastMessage(title, message, variant) {
        const toastEvent = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant
        })
        this.dispatchEvent(toastEvent);
    }

    get Title(){
        return `Update ${this.accountName} Account`;
    }
}