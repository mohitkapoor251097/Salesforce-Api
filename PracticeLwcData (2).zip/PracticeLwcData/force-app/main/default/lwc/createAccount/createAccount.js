import { LightningElement, track } from 'lwc';
import accountInsertion from '@salesforce/apex/AccountLwcController.accountInsertion';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class CreateAccount extends LightningElement {
    @track accountDetails = {
        accName: '',
        accNumber: ''
    }
    // accName;
    // accNumber;
    changeHandler(event) {
        this.accountDetails[event.target.name] = event.target.value;
        //     console.log('accName' + this.accountDetails.accName);
        //     console.log('accNumber' + this.accountDetails.accNumber);
    }

    createAccountHandler() {
            accountInsertion({ acc: this.accountDetails }).then((result) => {
                this.messageShow('success', 'Account Created Successfully !', 'success');
            }).catch((error) => {
                this.messageShow('error', error.body.message, 'error');
            })
    }

    messageShow(message, title, variant) {
        const CuEvent = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant
        })
        this.dispatchEvent(CuEvent);
    }
    resetHandler() {
        let inputFields = this.template.querySelectorAll('lightning-input');
        inputFields.forEach((currItem) => {
            currItem.value = ''
        })
    }
   
}
