import { LightningElement } from 'lwc';

export default class ParentData extends LightningElement {}