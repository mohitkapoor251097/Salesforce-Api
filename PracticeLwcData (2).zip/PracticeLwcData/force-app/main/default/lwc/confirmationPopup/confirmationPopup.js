import { LightningElement, api } from 'lwc';

export default class ConfirmationPopup extends LightningElement {
    @api recordId; // Record ID passed from the parent

    // Handle cancel action
    handleCancel() {
        this.dispatchEvent(new CustomEvent('cancel')); // Notify parent to close popup
    }

    // Handle confirm action
    handleConfirm() {
        console.log('recordId==='+this.recordId);
        this.dispatchEvent(
            new CustomEvent('confirm', {
                detail: { recordId: this.recordId},
                bubbles:true,
                composed:true
            })
        );
    }
}
