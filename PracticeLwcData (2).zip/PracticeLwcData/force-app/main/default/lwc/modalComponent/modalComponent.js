import { LightningElement, api, track } from 'lwc';
export default class ModalComponent extends LightningElement {
    @api contact;
    @api isVisible = false;
    @api defineMode;

    _hideModal() {
        this.isVisible = false;
        const closeEvent = new CustomEvent('close');
        this.dispatchEvent(closeEvent);
    }

    // Method to close modal
    closeModalAction() {
        this._hideModal();
    }

    // Method for success handling
    successHandler() {
        console.log('OUTPUT dis');
        this.dispatchEvent(new CustomEvent('contactupdated'));
    }
}
