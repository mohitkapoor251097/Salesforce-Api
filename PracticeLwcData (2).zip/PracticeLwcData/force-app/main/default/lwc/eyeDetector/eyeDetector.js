import { LightningElement } from 'lwc';

export default class EyeDetector extends LightningElement {
    videoElement;
    isVideoInitialized = false;

    renderedCallback() {
        if (!this.isVideoInitialized) {
            // Use a timeout to wait for the DOM to fully render
            window.requestAnimationFrame(() => {
                this.videoElement = this.template.querySelector('#video');
                if (this.videoElement) {
                    console.log('Video element found.');
                    this.initializeVideoStream();
                    this.isVideoInitialized = true;
                } else {
                    console.error('Video element still not found after DOM rendering.');
                }
            });
        }
    }

    initializeVideoStream() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            alert('Your browser does not support camera access.');
            console.error('getUserMedia not supported.');
            return;
        }

        navigator.mediaDevices
            .getUserMedia({ video: true })
            .then((stream) => {
                console.log('Stream obtained:', stream);
                this.videoElement.srcObject = stream;
                this.videoElement.onloadedmetadata = () => {
                    console.log('Metadata loaded, starting video...');
                    this.videoElement.play()
                        .then(() => console.log('Video playback started'))
                        .catch((playError) => console.error('Error starting playback:', playError));
                };
            })
            .catch((error) => {
                console.error('Error accessing webcam:', error);
                if (error.name === 'NotAllowedError') {
                    alert('Camera access was denied. Please allow camera access in your browser settings.');
                } else if (error.name === 'NotFoundError') {
                    alert('No camera was found. Please connect a camera and try again.');
                } else {
                    alert('Error accessing the camera. Check the console for details.');
                }
            });
    }
}
