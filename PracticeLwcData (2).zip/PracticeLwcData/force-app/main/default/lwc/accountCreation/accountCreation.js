import { LightningElement,api } from 'lwc';
import ACCOUNT_NAME from '@salesforce/schema/Account.Name';
export default class AccountCreation extends LightningElement {
objectApiName='Account';
fieldList=[ACCOUNT_NAME];
}