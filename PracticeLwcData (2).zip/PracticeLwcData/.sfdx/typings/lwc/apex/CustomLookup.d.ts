declare module "@salesforce/apex/CustomLookup.returnAllRelatedObjFields" {
  export default function returnAllRelatedObjFields(param: {ObjectName: any}): Promise<any>;
}
declare module "@salesforce/apex/CustomLookup.queryObjectData" {
  export default function queryObjectData(param: {objectName: any, fields: any, RelatedField: any, CurrentObjectId: any}): Promise<any>;
}
