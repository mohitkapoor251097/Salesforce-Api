declare module "@salesforce/apex/SpeechToTextSearch.searchResults" {
  export default function searchResults(param: {searchStr: any}): Promise<any>;
}
