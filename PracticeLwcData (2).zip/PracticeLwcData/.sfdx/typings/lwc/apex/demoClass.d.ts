declare module "@salesforce/apex/demoClass.getAllAccounts" {
  export default function getAllAccounts(): Promise<any>;
}
declare module "@salesforce/apex/demoClass.getAllContacts" {
  export default function getAllContacts(): Promise<any>;
}
declare module "@salesforce/apex/demoClass.getContactList" {
  export default function getContactList(): Promise<any>;
}
declare module "@salesforce/apex/demoClass.findContacts" {
  export default function findContacts(param: {searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/demoClass.getAllAccountsForDataTable" {
  export default function getAllAccountsForDataTable(): Promise<any>;
}
