declare module "@salesforce/apex/OpportunityListController.getOpportunityList" {
  export default function getOpportunityList(): Promise<any>;
}
declare module "@salesforce/apex/OpportunityListController.getOpportunityFilterList" {
  export default function getOpportunityFilterList(param: {selectedStageName: any}): Promise<any>;
}
declare module "@salesforce/apex/OpportunityListController.getAccounts" {
  export default function getAccounts(): Promise<any>;
}
