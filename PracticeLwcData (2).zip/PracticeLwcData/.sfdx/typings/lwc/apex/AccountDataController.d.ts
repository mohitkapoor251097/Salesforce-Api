declare module "@salesforce/apex/AccountDataController.getAccount" {
  export default function getAccount(): Promise<any>;
}
declare module "@salesforce/apex/AccountDataController.getContacts" {
  export default function getContacts(param: {accId: any}): Promise<any>;
}
