declare module "@salesforce/apex/AccountLwcController.accountInsertion" {
  export default function accountInsertion(param: {acc: any}): Promise<any>;
}
