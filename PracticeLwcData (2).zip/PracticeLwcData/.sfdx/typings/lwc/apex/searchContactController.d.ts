declare module "@salesforce/apex/searchContactController.getContactList" {
  export default function getContactList(): Promise<any>;
}
declare module "@salesforce/apex/searchContactController.searchKeyList" {
  export default function searchKeyList(param: {searchkey: any}): Promise<any>;
}
