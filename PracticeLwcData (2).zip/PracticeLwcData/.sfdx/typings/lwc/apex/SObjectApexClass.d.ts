declare module "@salesforce/apex/SObjectApexClass.getAllObject" {
  export default function getAllObject(): Promise<any>;
}
declare module "@salesforce/apex/SObjectApexClass.CreateSOQL" {
  export default function CreateSOQL(param: {objName: any}): Promise<any>;
}
