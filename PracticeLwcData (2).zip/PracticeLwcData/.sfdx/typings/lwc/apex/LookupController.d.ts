declare module "@salesforce/apex/LookupController.searchLookupRecords" {
  export default function searchLookupRecords(param: {searchTerm: any, selectedIds: any, sObjectName: any, field: any, subField: any, maxResults: any}): Promise<any>;
}
declare module "@salesforce/apex/LookupController.getRecentlyCreatedRecord" {
  export default function getRecentlyCreatedRecord(param: {sObjectName: any, recordId: any, field: any, subField: any}): Promise<any>;
}
