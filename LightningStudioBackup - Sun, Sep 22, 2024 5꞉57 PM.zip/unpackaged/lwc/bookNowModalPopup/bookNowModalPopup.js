import { LightningElement,api} from 'lwc';
import Service_Name from '@salesforce/schema/Service__c.Service_Name__c';
import Time_field from '@salesforce/schema/Service__c.When_do_you_want_service__c';
import User_Name from '@salesforce/schema/Service__c.Your_Name__c';
import Phone_field from '@salesforce/schema/Service__c.Your_Phone_No__c';
import Address_field from '@salesforce/schema/Service__c.Your_Address__c';
import State_field from '@salesforce/schema/Service__c.Your_State__c';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import createService from '@salesforce/apex/Service.createService';
export default class BookNowModalPopup extends LightningElement {
    @api isShowBookNowModalPopup; 

    objServiceDetails={
     Service_Name__c:Service_Name,
    When_do_you_want_service__c:Time_field,
    Your_Name__c:User_Name,
    Your_Phone_No__c: Phone_field,
    Your_Address__c:Address_field,
    Your_State__c:State_field
    }

    handleServiceName(event){
            this.objServiceDetails.Service_Name__c=event.target.value;
            this.validateInputField();
    }
    handleTime(event){
        this.objServiceDetails.When_do_you_want_service__c=event.target.value;
        this.validateInputField();
    }
    handleName(event){
        this.objServiceDetails.Your_Name__c=event.target.value;
        this.validateInputField();
    }
    handlePhone(event){
        this.objServiceDetails.Your_Phone_No__c=event.target.value;
        this.validateInputField();
    }
    handleAddress(event){
        this.objServiceDetails.Your_Address__c=event.target.value;
        this.validateInputField();
    }
    handleState(event){
        this.objServiceDetails.Your_State__c=event.target.value;
        this.validateInputField();
    }
serviceId;
serviceRecord;
error;
validateInputField(){

    return[...this.template.querySelectorAll("lightning-input-field")].reduce((validSoFar,field)=>{
        return(validSoFar && field.reportValidity());
    },true);
    // let inputFields = this.template.querySelectorAll('.validate');
    // inputFields.forEach(inputField => {
    //     if(!inputField.checkValidity()) {
    //         inputField.reportValidity();
    //         this.isValid = false;
    //     }
    // });
}
    handleBookClick(){
      
        createService({serviceDetails:this.objServiceDetails})
        .then(result=>{
            this.serviceRecord={};
            this.serviceId=result.Id;
            console.log('SericeId'+this.serviceId);
                   const toastEvent=new ShowToastEvent({
                    title:'Success!',
                    message:'Service record is created Successfully !',
                    variant:'success'
                   })
                   this.dispatchEvent(toastEvent);
                   const closePopupEvent=new CustomEvent('closepopup',{
                    detail:false
                   });
                   this.dispatchEvent(closePopupEvent);
        })
        .catch(error=>{
            this.error=error.message;
        })

    }

    handleCancelClick(){
        const closePopupEvent=new CustomEvent('closepopup',{
            detail:false
           });
           this.dispatchEvent(closePopupEvent);
    }
}