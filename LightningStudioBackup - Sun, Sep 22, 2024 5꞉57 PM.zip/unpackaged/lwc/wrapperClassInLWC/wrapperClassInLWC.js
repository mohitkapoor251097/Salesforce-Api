import { LightningElement, wire,track } from 'lwc';
import AccAndCons from '@salesforce/apex/LWCExampleController.fetchAccAndCons';
import setDismissed1 from '@salesforce/apex/LWCExampleController.handleDismissClick';
import getAccountList from '@salesforce/apex/AccountController1.getAccountList';
import getContactId from '@salesforce/apex/AccountController1.getContactiD';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getOpportunityId from '@salesforce/apex/AccountController1.getOpportunityiD';
import getCaseId from '@salesforce/apex/AccountController1.getCaseiD';
import { NavigationMixin } from 'lightning/navigation';
import setDismissed from '@salesforce/apex/AccountController1.setDismissedAccount';
import { refreshApex } from '@salesforce/apex';
export default class WrapperClassInLWC extends NavigationMixin(LightningElement) {
   @track data=[];
    error;
    //when page load fetch list of Accoun
    connectedCallback() {
        AccAndCons()
            .then(data => {
                this.data = data;
                console.log(JSON.stringify(this.data));
            })
            .catch(error => {
                console.log("error occured" + error);
            })
    }
    //Dismiss the Accounts
    handleDismissClick(event) {
        // this.spinnerStatus=true;
        let accId = event.target.dataset.id;
        console.log('accId' + accId);
        setDismissed1({ accId: accId })
            .then(result => {
                console.log('data' + result);
                this.data = result;
                // this.spinnerStatus=false;
                // refreshApex(this.data);
              
                //this.data=this.data.filter(acc => acc.Id !== accId);
                this.showErrororSuccessMessage('Account is Dismissed Successfully !', 'success');
            
            })
            .catch(error => {
                console.log(error);
                // this.spinnerStatus=false;
                this.showErrororSuccessMessage('something went wrong  !', 'error');
            });


    }
    handleClick(event) {
        event.preventDefault();
        const accountId = event.target.dataset.id;
        console.log('Clicked account Id:', accountId);
        getContactId({ accountId: accountId })
            .then(result => {
                this.ActiveContactName = result.Name;
                console.log('Contact details:', result);
                console.log('Name' + this.ActiveContactName);
                // this.check=true;
                this.Navigation('Contact', result.Id);
            }
            )
            .catch(error => {
                console.error('Error fetching account details:', error);
                this.handlerrror(error.body.exceptionType);

            });
    }

    handleClick1(event) {
        event.preventDefault();
        const accountId = event.target.dataset.id;
        console.log('Clicked account Id:', accountId);
        getOpportunityId({ accountId: accountId })
            .then(result => {
                console.log('Opportunity details:', result);
                this.Navigation('Opportunity', result.Id);
            }
            )
            .catch(error => {
                console.error('Error fetching Opportunity details:', error);
                this.handlerrror(error.body.exceptionType);

                // Handle the error here
            });

    }
    handleClick2(event) {
        event.preventDefault();
        const accountId = event.target.dataset.id;
        console.log('Clicked account Id:', accountId);
        getCaseId({ accountId: accountId })
            .then(result => {
                console.log('Case details:', result);
                // console.log('id => ' + event.target.dataset.contact);
                this.Navigation('Case', result.Id);
            }
            )
            .catch(error => {
                console.error('Error fetching Case details:', JSON.stringify(error));
                console.log(error.body.exceptionType);
                this.handlerrror(error.body.exceptionType);
                // Handle the error here
            });

    }
    handlerrror(error) {
        if (error == 'System.QueryException') {
            this.showErrororSuccessMessage('Sorry,No Active Record is Found ', 'error');
        }
    }
    Navigation(object, Id) {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                "recordId": Id,
                "objectApiName": object,
                "actionName": "view"
            },
        });
    }

    showErrororSuccessMessage(message, msg) {
        const event = new ShowToastEvent({
            title: msg,
            message: message,
            variant: msg,
        });
        this.dispatchEvent(event);
    }
}



// @wire(AccAndCons)
// accs({error, data}) {
//     if(data) {
//         this.data = data;
//         window.console.log('data ==> '+JSON.stringify(data));
//     }
//     else if(error) {
//         this.error = error;
//     }
// }