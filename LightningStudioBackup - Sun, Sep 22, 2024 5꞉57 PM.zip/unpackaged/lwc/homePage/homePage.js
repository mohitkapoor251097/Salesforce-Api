import { LightningElement } from 'lwc';
import ServiceImages from '@salesforce/resourceUrl/ServiceImages';
import LightningModal from 'lightning/modal';
export default class HomePage extends LightningElement {
    objServiceImages={
        cleaning:ServiceImages + '/Images/cleaning1.jpg',
        painting:ServiceImages + '/Images/painting.jpg',
        cooking:ServiceImages + '/Images/cooking.jpg',
        plumbing:ServiceImages + '/Images/plumbing.png',
        salon:ServiceImages + '/Images/salon.jpg',
        gardening:ServiceImages + '/Images/gardening.png',
    }
isShowBookNowModalPopup=false;
    handleBookNowClick(event){
      this.isShowBookNowModalPopup=true;
    }

    handleClosePopupEvent(event){
        this.isShowBookNowModalPopup= event.detail;
       
    }
}