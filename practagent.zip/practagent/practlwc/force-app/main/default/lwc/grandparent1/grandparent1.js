import { LightningElement } from 'lwc';

export default class Grandparent1 extends LightningElement {
    showData;
    recieveDate(event){
       this.showData=event.detail;
    }
}