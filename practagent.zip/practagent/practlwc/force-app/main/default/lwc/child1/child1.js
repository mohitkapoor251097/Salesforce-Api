import { LightningElement } from 'lwc';

export default class Child1 extends LightningElement {


    changeHandler(event){
        this.dispatchEvent(new CustomEvent('senddata',{
            detail:event.target.value,
            bubbles:true,
            composed:true
        }));
    }
}