import { LightningElement, wire } from 'lwc';
import getAccounts from '@salesforce/apex/AccountData.getAccounts';
import { updateRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';
export default class InlineEditingAccount extends LightningElement {

    accountRefreshData;
    accountDEtails;
    draftValues = [];
    @wire(getAccounts)
    accountData(result) {
        this.accountRefreshData = result;
        if (result.data) {
            this.accountDEtails = result.data;
        }
        else if (result.error) {
            console.error(result.error);
        }
    }

    get columns() {
        return [
            { label: 'Account Name', fieldName: 'Name', editable: 'true' },
            { label: 'Phone', fieldName: 'Phone', editable: 'true' },

        ]
    }

    async handleSave(event) {
        let records = event.detail.draftValues;
        let updatedREcordArray = records.map((currItem) => {
            let inputFields = { ...currItem }
            return {
                fields: inputFields
            }
        });
        this.draftValues = [];
        let updatedRecordArrayPromise = updatedREcordArray.map((currItem) => updateRecord(currItem));
        await Promise.all(updatedRecordArrayPromise);
        this.showMessage('success', 'success', 'Account Updated Successfully !');
        refreshApex(this.accountRefreshData);
    }

    showMessage(title, variant, message) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            variant: variant,
            message: message
        }))
    }
}


// <!--<apex:page standardController="Account" extensions="DeleteEntitlementsController">
//     <apex:form >
//         <apex:commandButton value="Delete All Entitlements" 
//                             action="{!deleteEntitlements}" 
//                             onclick="if(!confirm('Are you sure you want to delete all related entitlements?')) return false;" 
//                             oncomplete="window.location.reload();" />
//     </apex:form>
// </apex:page>-->

// <apex:page showHeader="false" sidebar="false">
//     <html>
//         <head>
//             <apex:includeLightning />
//         </head>
//         <body class="slds-scope">
//             <!-- Flow container div -->
//             <div id="flowContainer"></div>

//             <script>
//                 const recordId = '{!$CurrentPage.parameters.id}';
//                 let flowStarted = false;

//                 function statusChange(event) {
//                     if (event.getParam("status") === "FINISHED") {
//                         // Clean up and redirect
//                         document.getElementById('flowContainer').innerHTML = ''; // remove flow
//                         window.location.href = '/' + recordId;
//                     }
//                 }

//                 // Use DOMContentLoaded to make sure the page is fully loaded before running script
//                 document.addEventListener("DOMContentLoaded", function () {
//                     if (flowStarted) return; // prevent double execution
//                     flowStarted = true;

//                     $Lightning.use("c:lightningOutApp", function() {
//                         $Lightning.createComponent("lightning:flow", 
//                             { "onstatuschange": statusChange },
//                             "flowContainer",
//                             function(component) {
//                                 component.startFlow("Delete_entitlement_using_data_table", [
//                                     { name: "recordId", type: "String", value: recordId }
//                                 ]);
//                             }
//                         );
//                     });
//                 });
//             </script>
//         </body>
//     </html>
// </apex:page>


{/* <apex:page showHeader="false" sidebar="false">
    <html>
        <head>
            <apex:includeLightning />
        </head>
        <body class="slds-scope">
            <!-- Flow container div -->
            <div id="flowContainer"></div>

            <script>
                const recordId = '{!$CurrentPage.parameters.id}';
                let flowStarted = false;

                function statusChange(event) {
                    if (event.getParam("status") === "FINISHED") {
                        // Clean up and redirect
                        document.getElementById('flowContainer').innerHTML = ''; // remove flow
                        window.location.href = '/' + recordId;
                    }
                }

                // Use DOMContentLoaded to make sure the page is fully loaded before running script
                document.addEventListener("DOMContentLoaded", function () {
                    if (flowStarted) return; // prevent double execution
                    flowStarted = true;

                    $Lightning.use("c:lightningOutApp", function() {
                        $Lightning.createComponent("lightning:flow", 
                            { "onstatuschange": statusChange },
                            "flowContainer",
                            function(component) {
                                component.startFlow("Delete_entitlement_using_data_table", [
                                    { name: "recordId", type: "String", value: recordId }
                                ]);
                            }
                        );
                    });
                });
            </script>
        </body>
    </html>
</apex:page> */}

// <aura:application extends="ltng:outApp" access="GLOBAL">
//     <aura:dependency resource="lightning:flow"/>
// </aura:application>

/*
###########################################################################
# File.........................: ContactusMediaOfficeWebFormControllerTst
# Version......................: 1.0
# Created by...................: Coforge Ltd.
# Created Date.................: 30/11/2023
# Last Modified by.............: Coforge
# Last Modified Date...........: 21/12/2023
# Description..................: Controller class for ContactusMediawebform used to submit the 'Media Contact' cases.
# VF Page......................: ContactusMediawebform
# Test Class…..................: ContactusMediaOfficeWebFormControllerTest
# V1-							 Modified for User Story 18025 Reset Functionality to send Welsh Email on resetting webform
# V1.1- 21-12-2023			   : ADO 22590 Fixing QA defects
#############################################################################
*/
// public without sharing class ContactusMediaOfficeWebFormController {
    
    
//     public Case caseObject{get ;set;}
//     public String deadline{get; set;}
//     public string reCaptchaResponse{get; set;}
//     public Boolean reCaptchaError{get; set;}
//     public string languageSwitch{get; set;}
//     public String[] splitDateValue = new String[]{};
//     public String caseEmail {get;set;}
//         public Integer transmissionDay {get;set;}
//     public Integer transmissionMonth {get;set;}
//     public Integer transmissionYear {get;set;}
//     public String formErrorkeys {get;set;}
//     public Boolean apexPageMessageSize{get{return (ApexPages.getMessages().size() > 0 || (reCaptchaError != null && reCaptchaError));}}
     
//      /**
//     * @author      : Coforge Ltd.
//     * @date        : 03/11/2023
//     * @description : Constuctor used to intiliazation.
//     * @param1      : 
//     * @param2      : 
//     * @return      : void
//     */      
//     public ContactusMediaOfficeWebFormController(){
//         try{
//             caseObject = new Case();
//                         if(ApexPages.currentPage().getParameters().get(LicensingComConstants.CURRENT_LANG) != null){       
//                 languageSwitch = ApexPages.currentPage().getParameters().get(LicensingComConstants.CURRENT_LANG);
//                 caseObject.Language__c = languageSwitch;
//             }
//         }
//         catch( Exception ex){
//         }
          
//     }
    
//     /**
//     * @author      : Coforge Ltd.
//     * @date        : 03/11/2023
//     * @description : To submit Media Contact cases & Check all validations on Cases.
//     * @param1      : 
//     * @param2      : 
//     * @return      : Pagereference
//     */  
//     public Pagereference submit(){
//         try{
            
//         formErrorkeys =LicensingComConstants.NULL_VALUE;
//              validateFields();
//             Component.Apex.OutputText output = new Component.Apex.OutputText();
//             Boolean reCaptchatrue = utl_ReCaptcha.verifyReCaptchaResponse(reCaptchaResponse);
//             if(!Test.isRunningTest() && reCaptchatrue==false){
//                 formErrorkeys += 'recaptchaError';
//                 reCaptchaError = true;
//                 output.expressions.value = '{!$Label.WebFormsCaptchaValidation' + (languageSwitch == null ? '}' : ('_' + languageSwitch + '}'));
//                 ApexPages.addMessage(new ApexPages.Message(ApexPages.Severity.ERROR,String.ValueOf(output.value)));            
//             }else{
//                  reCaptchaError = false;
//             }      
            
            
//             //checking if date is blank or not
//             if(deadline != null && !(String.isBlank(deadline))){
//                 splitDateValue   =  utl_SitesFormController.splitDate(deadline);
//                 transmissionDay = Integer.valueof(splitDateValue.get(LicensingComConstants.NUM_ZERO));
//                 transmissionMonth = Integer.valueof(splitDateValue.get(LicensingComConstants.NUM_ONE));         
//                 transmissionYear = Integer.valueof(splitDateValue.get(LicensingComConstants.NUM_TWO)); 
//             }
//             Set<String> emailList=new Set<String>{'calgavfehim@hotmail.com'};
//                 if(emailList.contains(caseEmail)){
//                      ApexPages.addMessage(new ApexPages.Message(ApexPages.Severity.ERROR,'This webform is for queries from the media only.')); 
//                 }

//             caseObject.Deadline__c = Date.newInstance(transmissionYear, transmissionMonth, transmissionDay);//START W-002422
//              caseObject.SuppliedEmail = caseEmail;
//             caseobject.RecordTypeId = Schema.getGlobalDescribe().get('Case').getDescribe().getRecordTypeInfosByName().get(LicensingComConstants.MEDIA_CONTACT_RECORD_TYPE).getRecordTypeId();
//             caseObject.AccountId = assignMediaEnquiriesAcocunt().Id;
//           /*** Adding active rule functionality and creating case based on record types and queue assignment */                         
//             Database.DMLOptions dmlOpts = new Database.DMLOptions();
//             List<String> fieldList = new List<String>();
//             fieldList.add(LicensingComConstants.THE_FIELDS);
//             Set<Id> ids = new Set<Id>();
//             List<AssignmentRule> lstAssignmentRule= MIDReturn_Utility.queryObjects(LicensingComConstants.CASE_ASSIGNMENT_RULE,fieldList,LicensingComConstants.THE_FILTER,'','',ids);
//             //Creating the DMLOptions for "Assign using active assignment rules" checkbox
//             if(lstAssignmentRule.size()>0){                  
//                 dmlOpts.assignmentRuleHeader.assignmentRuleId= lstAssignmentRule[0].id;      
//                            }
//             caseobject.setOptions(dmlOpts);            
//             String langs = (languageSwitch == null ? LicensingComConstants.NULL_VALUE : LicensingComConstants.LANG_SWITCH + languageSwitch);
//             if(apexPageMessageSize){
//                 return null;
//             }else{
//                 insert caseObject; 
//                 return new PageReference('/apex/ContactusMediaOfficeThankYouWebForm'+langs);
//             }
            
//         }
//         catch(Exception ex){
//             return null;
//         }
//     }
    
//     /**
//     * @author      : Coforge Ltd.
//     * @date        : 03/11/2023
//     * @description : Method to reset values entered by user.
//     * @param1      : 
//     * @param2      : 
//     * @return      : Pagereference
//     */  
//     public Pagereference reset(){
//         //ADO 22590 Start: Fixing QA defects
//     	String langs = (languageSwitch == null ? LicensingComConstants.NULL_VALUE : LicensingComConstants.LANG_SWITCH + languageSwitch);
//         PageReference pr = new PageReference('/apex/ContactusMediaOfficeWebForm'+langs);
//         pr.setRedirect(true);
//         return pr;
//         //ADO 22590 End: Fixing QA defects
        
//     }
    
//     /**
//     * @author      : Coforge Ltd.
//     * @date        : 03/11/2023
//     * @description : Method to get Recaptcha Response.
//     * @param1      : 
//     * @param2      : 
//     * @return      : Pagereference
//     */  
//     public PageReference actionButtonFieldBinder() {
//         return null;
//     } 
    
//     /**
//     * @author      : Coforge Ltd.
//     * @date        : 03/11/2023
//     * @description : Method to validate case, called in submit method.
//     * @param1      : 
//     * @param2      : 
//     * @return      : null
//     */  
//     public void validateFields(){
//         Component.Apex.OutputText output = new Component.Apex.OutputText();
//         if(caseObject.SuppliedName == null && String.isEmpty(caseObject.SuppliedName)){ 
//             formErrorkeys += 'SuppliedName';
//             output.expressions.value = '{!$Label.Contact_usEnterName' + (languageSwitch == null ? '}' : ('_' + languageSwitch + '}'));
//             ApexPages.addMessage(new ApexPages.Message(ApexPages.Severity.ERROR,String.ValueOf(output.value)));
//         }
        
//         if(caseObject.Media_Outlet__c == null && String.isEmpty(caseObject.Media_Outlet__c)){    
//             formErrorkeys += 'MediaOutlet';
//             output.expressions.value = '{!$Label.Contact_usEnterMediaOutlet' + (languageSwitch == null ? '}' : ('_' + languageSwitch + '}'));
//             ApexPages.addMessage(new ApexPages.Message(ApexPages.Severity.ERROR,String.ValueOf(output.value)));
//         }
        
//         if(caseObject.SuppliedPhone == null && String.isEmpty(caseObject.SuppliedPhone)){    
//             system.debug('null');
//              formErrorkeys += 'SuppliedPhone';
//             output.expressions.value = '{!$Label.Contact_usEnterTelephone' + (languageSwitch == null ? '}' : ('_' + languageSwitch + '}'));
//             ApexPages.addMessage(new ApexPages.Message(ApexPages.Severity.ERROR,String.ValueOf(output.value)));
//         }else if( caseObject.SuppliedPhone.isNumeric()  == false ){    
//             system.debug('numeric');
//             formErrorkeys += 'SuppliedPhone';
//              output.expressions.value = '{!$Label.WebFormsMobileValidation' + (languageSwitch == null ? '}' : ('_' + languageSwitch + '}'));
//             ApexPages.addMessage(new ApexPages.Message(ApexPages.Severity.ERROR,String.ValueOf(output.value)));
//         }
        
//         if( String.isBlank(caseEmail)){    
//             formErrorkeys += 'caseEmail';
//             output.expressions.value = '{!$Label.Contact_usEnterEmail' + (languageSwitch == null ? '}' : ('_' + languageSwitch + '}'));
//             ApexPages.addMessage(new ApexPages.Message(ApexPages.Severity.ERROR,String.ValueOf(output.value)));
//         }else if(!utl_SitesFormController.validateEmail(caseEmail)){    
//             formErrorkeys += 'caseEmail';
//             output.expressions.value = '{!$Label.Contact_usEmailFormat' + (languageSwitch == null ? '}' : ('_' + languageSwitch + '}'));
//             ApexPages.addMessage(new ApexPages.Message(ApexPages.Severity.ERROR,String.ValueOf(output.value)));
//         }
//         if(caseObject.Subject == null && String.isEmpty(caseObject.Subject)){    
//             formErrorkeys += 'Subject';
//             output.expressions.value = '{!$Label.Contact_usEnterSubject' + (languageSwitch == null ? '}' : ('_' + languageSwitch + '}'));
//             ApexPages.addMessage(new ApexPages.Message(ApexPages.Severity.ERROR,String.ValueOf(output.value)));
//         }
        
//         if(String.isBlank(caseObject.Description )){    
//             formErrorkeys += 'Description';
//             output.expressions.value = '{!$Label.Contact_usEnterEnquiry' + (languageSwitch == null ? '}' : ('_' + languageSwitch + '}'));
//             ApexPages.addMessage(new ApexPages.Message(ApexPages.Severity.ERROR,String.ValueOf(output.value)));
//         }
        
//         if( String.isBlank(deadline)){    
//             formErrorkeys += 'deadline';  
//             output.expressions.value = '{!$Label.Contact_us_EnterDeadline' + (languageSwitch == null ? '}' : ('_' + languageSwitch + '}'));
//             ApexPages.addMessage(new ApexPages.Message(ApexPages.Severity.ERROR,String.ValueOf(output.value)));
//         }
        
        
//     }
    
//     /**
//     * @author      : Coforge Ltd.
//     * @date        : 03/11/2023
//     * @description : Method to Assign a dummy bussiness account for all Media Cases.
//     * @param1      : 
//     * @param2      : 
//     * @return      : Account
//     */  
//     public Account assignMediaEnquiriesAcocunt(){
//          try{
//         return [ SELECT Id, Name FROM Account WHERE Name =: LicensingComConstants.DUMMY_MEDIA_ENQUIRIES_ACCOUNT limit 1 ];
//             }
//             catch(Exception ex){
//                 Account accountObj = new Account();
//                 accountObj.Name = LicensingComConstants.DUMMY_MEDIA_ENQUIRIES_ACCOUNT;
//                 insert accountObj;
//                 return accountObj;
//             }   
//     }
    
// }

//  public static List<sObject> queryObjects(String theObject, List<String> theFields, String theFilter, String sortField, String sortOrder, Set<Id> Ids) {
//         String theQuery = 'SELECT ' + string.join(theFields, ',');
//         theQuery += ' FROM ' + theObject;
//         if(!String.isEmpty(theFilter)) {
//             theQuery += ' WHERE ' + theFilter;
//         }
//         if(Ids.size() > 0){
//             theQuery += ' IN: Ids';
//         }
//         if(!String.isEmpty(sortField)) {
//             theQuery += ' ORDER BY ' + sortField;
//             if(!String.isEmpty(sortOrder)) {
//                 theQuery += ' ' + sortOrder;
//             }
//         }
//         system.debug('Value of query ******** ' + theQuery);        
//         return database.query(theQuery);
//     }

// @AuraEnabled
//     public static String fetchChannelRecord(){
// 		Map<String, Channel_MasterList_EPG__c> mapOfChannelMasterList = new Map<String, Channel_MasterList_EPG__c>();
// 		try{
// 			String objectName = 'Channel_MasterList_EPG__c';
//            	List<String> theFields = new List<String>{'Id', 'Display_Name__c', 'EPG_Channel_ID__c', 'Is_Static__c', 'Target__c', 'Name', 'Internal_Name__c' }; // ADO44118 change  /////////addedd
//             String filter = 'Exclude_Channel__c = False';
//             // Call MIDReturn_Utility clas that will create a dynamic SOQL query with filter criteria & return the list of records for the object
//            	List<SObject> records = MIDReturn_Utility.queryObjects(objectName,theFields,filter,'Display_Name__c','DESC',new Set<Id>{});
//            	// Loop through the results and create SelectOption for each record
//            	for (SObject record : records) {
// 				Channel_MasterList_EPG__c channelRecords = (Channel_MasterList_EPG__c)record;
//                	Id recordId = (Id) record.get('Id');
//                	mapOfChannelMasterList.put(recordId,channelRecords);
//            	}
// 			return JSON.serialize(mapOfChannelMasterList);
//         }
// 		catch(Exception e){
// 			return e.getMessage();
//         }
// 	}

//  getChannels() {
// 	getChannelRecord()
// 		.then(result => {
//             let mapOfhannelMaster = JSON.parse(result);
//             this.searchResults = Object.entries(mapOfhannelMaster).map(([value, key]) => {
// 				return { label: key.Display_Name__c, value: key.Id, isStatic: key.Is_Static__c, EPG_ChannelId:key.EPG_Channel_ID__c, targetId: key.Target__c, internalName: key.Internal_Name__c, name:key.Name, className: 'slds-listbox__item' }; // ADO44094, ADO44118 change //// added
// 			}).concat([{ label: this.OTHER_VALUE, value: this.OTHER_VALUE, className: 'slds-listbox__item' }]);
//             this.pickListOrdered = this.searchResults;
// 		})
// 		.catch(error => {
// 			this.searchResults = [];
// 		});
//     }