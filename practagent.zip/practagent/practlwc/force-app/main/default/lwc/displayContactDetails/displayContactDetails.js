import { LightningElement } from 'lwc';
import getContacts from '@salesforce/apex/ContactController.getContacts';
export default class DisplayContactDetails extends LightningElement {
   
    contacts;
    selectedContact;
    recordSize=5;
    currentPage=1;
    totalPages=0;
    updatedContacts=[];
    get columns(){
        return [
            {label: 'Name', fieldName: 'LastName', type: 'text'},
            {label: 'Email', fieldName: 'Email', type: 'email'},
            {label: 'Account Name', fieldName: 'AccountName', type: 'text'},
        ]
    }
    connectedCallback(){
       this.callContactDetails();
    }

   async callContactDetails(){
        let data=await getContacts();
        this.contacts=data.map((item)=>({
          ...item,AccountName:item?.Account?.Name
        }));
        this.totalPages=Math.ceil(this.contacts.length/this.recordSize);
        this.updateData();
    }

    get rowOffSetData(){
         return (this.currentPage-1) * this.recordSize;
    }

    updateData(){
        console.log('OUTPUT : ',this.rowOffSetData);
       // const start=(this.currentPage-1) * this.recordSize;
        const end=this.rowOffSetData+this.recordSize;
        this.updatedContacts=this.contacts.slice(this.rowOffSetData,end);
    }

    handleRowSelection(event){
       if(event.detail.selectedRows.length>0){
        this.selectedContact=event.detail.selectedRows[0].Id;
        console.log('selectedContact : ',this.selectedContact);
       }
    }


    get prevDisabled(){
        return this.currentPage===1;
    }
    get nextDisabled(){
        return this.currentPage===this.totalPages;
    }
    handlePrevious(){
            this.currentPage-=1;
            this.updateData();
    }
    handleNext(){
        this.currentPage+=1;
        console.log('curremtPage'+this.currentPage);
        
         this.updateData();
    }
    handleFirst(){
        this.currentPage=1;
    }
    handleLast(){
        this.currentPage=this.totalPages;
    }

    get dishandleFirst(){
        return this.currentPage===1;
    }
    get dishandleLast(){
        return this.currentPage===this.totalPages;
    }
}