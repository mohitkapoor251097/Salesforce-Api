import { LightningElement, wire } from 'lwc';
import INDUSTEY_FIELD from '@salesforce/schema/Account.Industry';
import NAME_FIELD from '@salesforce/schema/Account.Name';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import CONTACT_OBJECT from '@salesforce/schema/Contact';
import CONTACT_LAST_NAME from '@salesforce/schema/Contact.LastName';
import CONTACT_EMAIL from '@salesforce/schema/Contact.Email';
import CONTACT_ACCOUNT_FIELD from '@salesforce/schema/Contact.AccountId';
import { getObjectInfo, getPicklistValues } from 'lightning/uiObjectInfoApi';
import { createRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class CreateAccountWithRelatedContact extends LightningElement {
    accountName;
    industry;
    lastName;
    email;
    isLoading = false;
    industryOptions = [];
    error;

    @wire(getObjectInfo, { objectApiName: ACCOUNT_OBJECT })
    accountInfo;

    @wire(getPicklistValues, {
        recordTypeId: '$accountInfo.data.defaultRecordTypeId',
        fieldApiName: INDUSTEY_FIELD
    })
    industryData({ data, error }) {
        if (data) {
            this.industryOptions = data.values;
            this.error = undefined;
        }
        else if (error) {
            this.error = error;
            this.industryOptions = undefined;
        }
    }

    handleInputChange(event) {
        const field = event.target.name;
        const value = event.target.value;
        this[field] = value;

        console.log('account Name' + this.accountName);
        console.log('industry' + this.industry);
        console.log('last Name' + this.lastName);
        console.log('email' + this.email);


    }

    submitHandler() {
        alert('submit');
        let isValid = this.validateUserInput();
        if (isValid) {
            console.log('validation success');
            this.createAccountWithContact();
        } else {
            console.log('validation failed');
            alert('validation failed');
        }
    }

    validateUserInput() {
        let isValid = true;

        this.template.querySelectorAll('lightning-input').forEach((currItem) => {
            if (!currItem.checkValidity()) {
                console.log(`Invalid input: ${currItem.label}`);
                isValid = false;
                currItem.reportValidity();
            }
        });

        let contactElement = this.template.querySelector('.contactLastName');
        if (this.lastName && this.accountName === this.lastName) {
            console.log('Account name and last name are same');
            contactElement.setCustomValidity('Account name should not be the same as contact last name');
            contactElement.reportValidity();
            isValid = false;
        } else {
            contactElement.setCustomValidity('');
            contactElement.reportValidity();
        }

        let contactEmailElement = this.template.querySelector('.contactEmail');
        if (!this.email.endsWith('@salesforce.com')) {
            console.log('Email does not end with @salesforce.com');
            contactEmailElement.setCustomValidity('Email should be a Salesforce email');
            contactEmailElement.reportValidity();
            isValid = false;
        } else {
            contactEmailElement.setCustomValidity('');
            contactEmailElement.reportValidity();
        }

        return isValid;
    }

    async createAccountWithContact() {
        this.isLoading=true;
        let inputFields = {};
        inputFields[NAME_FIELD.fieldApiName] = this.accountName;
        inputFields[INDUSTEY_FIELD.fieldApiName] = this.industry;

        let recordInput = {
            fields: inputFields,
            apiName: ACCOUNT_OBJECT.objectApiName
        }
        try {
            let accRecord = await createRecord(recordInput);

            let conFields = {};
            conFields[CONTACT_LAST_NAME.fieldApiName] = this.lastName;
            conFields[CONTACT_EMAIL.fieldApiName] = this.email;
            conFields[CONTACT_ACCOUNT_FIELD.fieldApiName] = accRecord.id;

            let conRecord = await createRecord({
                fields: conFields,
                apiName: CONTACT_OBJECT.objectApiName,
            })
            console.log('Account and Contact created successfully');
            this.showMessage('success', 'success', 'Account and Contact created successfully');
            this.resetForm();
        }
        catch (error) {
            console.error(error);
            this.showMessage('error', 'error', error.body.message);
        }
    }
    showMessage(title, variant, message) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            variant: variant,
            message: message
        }))
    }
    resetForm() {
        this.accountName = '';
        this.lastName = '';
        this.email = '';
        this.industryOptions = '';
        this.isLoading=false;
    }
}