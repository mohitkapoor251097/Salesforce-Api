import { LightningElement } from 'lwc';
import getAccounts from '@salesforce/apex/AccountDataWithlink.getAccounts';
export default class AccountDataWithlink extends LightningElement {

    accounts;

    get columns() {
        return [
            {
                label: 'Account Name', fieldName: 'nameUrl', type: 'url', typeAttributes: {
                    label: {
                        fieldName: 'accName'
                    },
                    target: '_blank'
                }
            },
            { label: 'Total Opportunities', fieldName: 'TotalOpp', type: 'text' },
            { label: 'Total Cases', fieldName: 'TotalCases', type: 'text' },
        ]
    }
    connectedCallback() {
        this.loadAccounts();
    }

    async loadAccounts() {
        this.accounts = await getAccounts();
    }
}