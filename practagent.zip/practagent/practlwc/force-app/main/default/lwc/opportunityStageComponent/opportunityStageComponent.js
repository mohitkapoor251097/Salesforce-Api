import { LightningElement, wire } from 'lwc';
import STAGE_NAME from '@salesforce/schema/Opportunity.StageName';
import OPP_OBJECT from '@salesforce/schema/Opportunity';
import { getObjectInfo, getPicklistValues } from 'lightning/uiObjectInfoApi';
import getOpportunityRecords from '@salesforce/apex/OpportunityStateController.getOpportunityRecords'
 const COUMNS=  [
            {label:'Name',fieldName:'Name',type:'text',sortable:true},
            {label:'Stage',fieldName:'StageName',type:'text',sortable:true,sortDirection:'desc'},
            {label:'Amount',fieldName:'Amount',type:'currency',sortable:true},
            {label:'Close Date',fieldName:'CloseDate',type:'date',sortable:true,typeAttributes:{
                year:'numeric',
                month:'short',
                day:'2-digit'
            }},
        ]
export default class OpportunityStageComponent extends LightningElement {

stageOptions=[];
selectedStage='';
showCloseDate=false;
sortBy='Amount';
sortDirection='desc';
columns=COUMNS.slice(0,3);
@wire(getOpportunityRecords,{stageName:'$selectedStage',sortBy:'$sortBy',sortDirection:'$sortDirection'})
opportunities;
    
@wire(getObjectInfo,{objectApiName:OPP_OBJECT})
    oppObjectInfo;

    @wire(getPicklistValues,{
        fieldApiName:STAGE_NAME,
        recordTypeId:'$oppObjectInfo.data.defaultRecordTypeId'
    })
    oppStageValues({data,error}){
        if(data){
            let stagesValues=data.values.map((currItem)=>({
                label:currItem.label,   
                value:currItem.value
            }))
         this.stageOptions=[
            {label:'All Stages', value:'All'},...stagesValues
        ]
        }else if(error){
           console.log('OUTPUT : ',JSON.stringify(error));
        }
    }

    handleStageChange(event){
        this.selectedStage=event.target.value;
        console.log('OUTPUT : ',this.selectedStage);
    }
    handleShowCloseDate(event){
    this.showCloseDate=event.target.checked;
    if(this.showCloseDate){
        this.columns=COUMNS;
    }
    else{
        this.columns=COUMNS.slice(0,3);
    }
    }


    // get columns(){
    //     return [
    //         {label:'Name',fieldName:'Name',type:'text',sortable:true},
    //         {label:'Stage',fieldName:'StageName',type:'text',sortable:true,sortDirection:'desc'},
    //         {label:'Amount',fieldName:'Amount',type:'currency',sortable:true},
    //         {label:'Close Date',fieldName:'CloseDate',type:'date',sortable:true,typeAttributes:{
    //             year:'numeric',
    //             month:'short',
    //             day:'2-digit'
    //         }},
    //     ]
    // }

    handleSort(event){
       this.sortBy=event.detail.fieldName;
       this.sortDirection=event.detail.sortDirection;
    }
}