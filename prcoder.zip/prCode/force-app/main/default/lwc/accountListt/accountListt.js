import { LightningElement, wire, track } from 'lwc';
import getAccountList from '@salesforce/apex/AccountRelatedDataController.getAccounts';

export default class accountListt extends LightningElement {
    @track accounts = [];
    @track error;
    
    @wire(getAccountList)
    wiredAccounts({ error, data }) {
        if (data) {
            this.accounts = data;
            this.error = undefined;
        } else if (error) {
            this.error = error;
            this.accounts = undefined;
        }
    }
}