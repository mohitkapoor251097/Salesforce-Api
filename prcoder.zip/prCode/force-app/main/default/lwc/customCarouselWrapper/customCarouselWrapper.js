import { LightningElement } from 'lwc';
import CAROUSEL_IMAGES from '@salesforce/resourceUrl/carousel';
export default class CustomCarouselWrapper extends LightningElement {

    slides=[
        {
            image:CAROUSEL_IMAGES + '/carousel/5star.JPG',
            heading:'Caption One',
            description:'First Slide'
        },
        {
            image:`${CAROUSEL_IMAGES}/carousel/datamodel.JPG`,
            heading:'Caption Two',
            description:'Second Slide'
        },
        {
            image:`${CAROUSEL_IMAGES}/carousel/diff.JPG`,
            heading:'Caption Three',
            description:'Third Slide'
        },
        {
            image:`${CAROUSEL_IMAGES}/carousel/sosl.JPG`,
            heading:'Caption Forth',
            description:'Forth Slide'
        },
        {
            image:`${CAROUSEL_IMAGES}/carousel/sosl1.JPG`,
            heading:'Caption Five',
            description:'Fifth Slide'
        }

    ]
}