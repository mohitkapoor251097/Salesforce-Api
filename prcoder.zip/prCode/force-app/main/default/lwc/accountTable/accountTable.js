import { LightningElement, wire } from 'lwc';
import getAccounts from '@salesforce/apex/AccountController.getAccounts';

export default class AccountTable extends LightningElement {
    @wire(getAccounts)
    accounts;

    get tableData() {
        if (this.accounts.data) {
            return this.accounts.data.map(account => {
                return {
                    accountName: account.Name,
                    contacts: account.Contacts.map(contact => contact.Name).join(', '),
                    opportunities: account.Opportunities.map(opportunity => opportunity.Name).join(', '),
                    cases: account.Cases.map(caseItem => caseItem.Subject).join(', ')
                };
            });
        }
        return [];
    }

    get tableColumns() {
        return [
            { label: 'Account Name', fieldName: 'accountName' },
            { label: 'Contacts', fieldName: 'contacts' },
            { label: 'Opportunities', fieldName: 'opportunities' },
            { label: 'Cases', fieldName: 'cases' }
        ];
    }
}
