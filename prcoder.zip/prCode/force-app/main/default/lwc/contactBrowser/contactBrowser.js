import { LightningElement,wire } from 'lwc';
import getContactsListByFilter from '@salesforce/apex/ContactBrowserController.getContactsListByFilter';
export default class ContactBrowser extends LightningElement {

    selectedAccountId='';
    selectedIndustry='';
    handleFilterChange(event){
         this.selectedAccountId=event.detail.accountId;
         this.selectedIndustry=event.detail.industry;

    }
    @wire(getContactsListByFilter,{
        accountId:'$selectedAccountId',
        Industry:'$selectedIndustry'
    })contactsFunction({data,error}){
            if(data){
                console.log('Selected Accounts'+JSON.stringify(data));
            }
            else if(error){
                console.log('error'+ error);
            }
        }


}