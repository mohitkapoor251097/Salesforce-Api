import { LightningElement,wire } from 'lwc';
import allAccountsWithContacts from '@salesforce/apex/AccountContact.allAccountsWithContacts';
export default class TreeGrridLwc extends LightningElement {
    gridData=[];
    @wire(allAccountsWithContacts)
    accountsWithContactsResult({data,error}){
          if(data){
           // this.gridData=data
           this.formatData(data);
            console.log(data);
          }
          else if(error){
              console.log(error);
          }
    }

    formatData(data){
       this.gridData= data.map(item=>{
            const {Contacts,...accounts} = item
            return {...accounts, "_children":Contacts}
        })
    }

    gridColumns=[
        {
            label:'Name',
            fieldName:'Name',
            type:'text'
        },
        {
            label:'Phone',
            fieldName:'Phone',
            type:'text'

        },
        {
            label:'Account Website',
            fieldName:'Website',
            type:'url',
            typeAttributes:{
                target:'_blank'
            }
        }
    ]

}