import { LightningElement, api } from 'lwc';

export default class DyanamicRecordAndObject extends LightningElement {
    @api recordId;
    @api objectApiName;
}