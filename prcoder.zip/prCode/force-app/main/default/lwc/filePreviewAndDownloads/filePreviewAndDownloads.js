import { LightningElement, api, wire } from 'lwc';
import {NavigationMixin} from 'lightning/navigation';
import getRelatedFilesByRecordId from '@salesforce/apex/filePreviewAndDownloadController.getRelatedFilesByRecordId';
export default class FilePreviewAndDownloads extends NavigationMixin(LightningElement) {
@api recordId;
filesList=[]
@wire(getRelatedFilesByRecordId,{recordId:'$recordId'})
wiredResult({data,error}){
    if(data){
         this.filesList= Object.keys(data).map(item=>({"label":data[item],"value":item,
       "url":`/sfc/servlet.shepherd/document/download/${item}`
        }))
        console.log('filesList'+JSON.stringify(this.filesList));
    }
    if(error){
         console.log(error);
    }
}
previewHandler(event){
 event.target.dataset.id;
        this[NavigationMixin.Navigate]({
         type:'standard__namedPage',
         attributes:{
          pageName:'filePreview'
         },
         state:{
            selectedRecordId:event.target.dataset.id
         }
        })
}
}