import { LightningElement } from 'lwc';

export default class MovieDetail extends LightningElement {}