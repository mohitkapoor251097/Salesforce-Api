import { LightningElement,wire } from 'lwc';
import {NavigationMixin} from 'lightning/navigation';
import { getPicklistValues,getObjectInfo } from "lightning/uiObjectInfoApi";
import Cricketer_Object from '@salesforce/schema/Cricketers__c';
import Nationality_Field from '@salesforce/schema/Cricketers__c.Nationality__c';
export default class PlayerSearchFilter extends NavigationMixin(LightningElement) {

    recordTypeId;
    picklistValues;
    optionsArray;
    selectCricketerNationality;
    selectedplayerId;
    selectedPlayerName;
    @wire(getObjectInfo,{objectApiName:'Cricketers__c'})
    objectInfos({data,error}){
        if(error){
            console.log('error'+JSON.stringify(error));
        }
        else if(data){
           this.recordTypeId=data.defaultRecordTypeId;
           console.log('recordTypeId'+JSON.stringify(this.recordTypeId));
        }
    }

    @wire(getPicklistValues,{recordTypeId:'$recordTypeId',fieldApiName:Nationality_Field})
    nationalityFieldValues({data,error}){
        if(error){
            console.log('error'+JSON.stringify(error));
        }
        else if(data){
            let arr=[];
            this.picklistValues=data.values;
            console.log('picklistdata'+JSON.stringify(this.picklistValues));

            this.picklistValues.forEach(element=>{
                arr.push({label:element.value,value:element.value})
            })
            this.optionsArray=arr;
            console.log('this.optionsArray'+JSON.stringify(this.optionsArray));
        }
    }

    createCrickters(){
        this[NavigationMixin.Navigate]({
              type: 'standard__objectPage',
              attributes:{
                objectApiName:'Cricketers__c',
                actionName:'new'
              }
        })}

       
        handleOptionChange(event){
            this.selectCricketerNationality=event.target.value;
            console.log('Selected value'+JSON.stringify(this.selectCricketerNationality));

            this.template.querySelector('c-player-search-result').searchCricketer(this.selectCricketerNationality);
        }
        handleCustomEvent(event){
            this.selectedplayerId=event.detail.playerId;
            this.selectedPlayerName=event.detail.playerName;
            console.log('this.selectedplayerId in parent lwc'+ JSON.stringify(this.selectedplayerId));
        }
}