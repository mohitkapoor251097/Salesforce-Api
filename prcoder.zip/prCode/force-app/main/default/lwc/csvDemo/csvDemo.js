import { exportCSVFile } from 'c/utils';
import { LightningElement } from 'lwc';

export default class CsvDemo extends LightningElement {

    userData=[
        {
            username:'Nikhil',
            age:45,
            title:'Developer'
        },
        {
            username:'Salesforce',
            age:45,
            title:'Developer'
        }
    ]

    headers={
        username:"User Name",
        age:"Age",
        title:"Title"
    }
    downloadUserDEtails(){
     console.log('download trigger');
       exportCSVFile(this.headers,this.userData,'user details')

    }
}