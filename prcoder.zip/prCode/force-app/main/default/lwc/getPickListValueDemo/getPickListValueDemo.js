import { getObjectInfo, getPicklistValues, getPicklistValuesByRecordType } from 'lightning/uiObjectInfoApi';
import { LightningElement ,wire} from 'lwc';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import ACCOUNT_INDUSTRY from '@salesforce/schema/Account.Industry';
export default class GetPickListValueDemo extends LightningElement {
   value;
    @wire(getObjectInfo,{
        objectApiName:ACCOUNT_OBJECT
    }) 
    accountprop;

    @wire(getPicklistValues,{
        recordTypeId:'$accountprop.data.defaultRecordTypeId',
        fieldApiName:ACCOUNT_INDUSTRY
    })
    industryPickList;
    // outputFunction({error,data}){
    //     if(data){
    //         console.log(data);
    //     }
    //     else if(error){
    //         console.log(error);
    //     }
    // }


    @wire(getPicklistValuesByRecordType,{
        objectApiName:ACCOUNT_OBJECT,
        recordTypeId:'$accountprop.data.defaultRecordTypeId'
    })
     accountInfoFunction;
    // accountInfoFunction({data,error}){
    //     if(d̥ata){
    //     console.log("🚀 ~ file: GetPickListValueDemo.js:33 ~ GetPickListValueDemo ~ accountInfoFunction ~ d̥ata:", d̥ata)

    //     }
    //     else if(error){

    //     }
    // }

    handleChange(event){
        this.value=event.target.value;

    }
}