import { LightningElement, wire } from 'lwc';
import { getRelatedListCount } from 'lightning/uiRelatedListApi';
export default class GetRelatedListCountDemo extends LightningElement 
{
  relatedData;
    @wire(getRelatedListCount,{
        parentRecordId:'0015i00000iZBV4AAO' ,  //the id of parent record you want to get related list
        relatedListId:'Contacts' //api name of a related list object

    })listCountHandler({data,error}){
        if(data){
        this.relatedData=data
        }else if(error){

        }
    }
}