import { LightningElement } from 'lwc';

export default class NewConditionDirective extends LightningElement {
    showText=false;

    get getLabel(){
        return this.showText ? 'Hide' : 'Show';
    }

    showTextHandler(){
        this.showText=true;
    }

    changleHandler(event){
        this.country=event.target.value;

    }
    country='India';

    get isCountryIndia(){
        return this.country==="India";
    }
}