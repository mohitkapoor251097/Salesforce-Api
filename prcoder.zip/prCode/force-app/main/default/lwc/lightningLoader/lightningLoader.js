import { LightningElement ,api} from 'lwc';

export default class LightningLoader extends LightningElement {

    @api spinnerText=''
    @api size='medium' //small medium large
    @api variant='base' //base brand inverse

    get helpText(){
        return this.spinnerText ? this.spinnerText : 'Loading spinner'
    }

    get className(){
        return `loader ${this.variant==='inverse'? 'inverse' :''} `
    }

}