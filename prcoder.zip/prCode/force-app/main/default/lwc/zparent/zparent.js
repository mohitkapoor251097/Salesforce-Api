import { LightningElement, api } from "lwc";

export default class Zparent extends LightningElement {
  @api
  checkValidity() {
    let isChildValidated = true;
    [...this.template.querySelectorAll("c-zchild")].forEach((element) => {
      if (element.checkValidity() === false) {
        isChildValidated = false;
      }
    });
    let isSelfValidated = true;
    isSelfValidated = [
      ...this.template.querySelectorAll("lightning-input")
    ].reduce((validSoFar, inputField) => {
      inputField.reportValidity();
      return validSoFar && inputField.checkValidity();
    }, true);
    if (isChildValidated && isSelfValidated) {
      return true;
    } else {
      return false;
    }
  }
  handleChange() {}
}