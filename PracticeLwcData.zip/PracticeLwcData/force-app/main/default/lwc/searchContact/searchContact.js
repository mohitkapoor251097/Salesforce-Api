import { LightningElement } from 'lwc';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import getContactList from '@salesforce/apex/searchContactController.getContactList';
import searchKeyList from '@salesforce/apex/searchContactController.searchKeyList';
import { deleteRecord } from 'lightning/uiRecordApi';
import LightningConfirm from 'lightning/confirm';
export default class SearchContact extends LightningElement{
    searchValue='';
    contactList=[];
    contactId='';
    modalContainer = false;
    mode;
    NOTFountContact;
    connectedCallback(){
       // super();
        this.fetchContactList();
      
    }
    fetchContactList(){
        getContactList().then((result)=>{
            this.contactList=result.map((contact)=>({
              ...contact,AccountName:contact.Account?.Name
            }))
            console.log('OUTPUT -------: ',JSON.stringify(result));
      }).catch((error)=>{
          console.log('OUTPUT : ',JSON.stringify(error));
      })
    }
      handleKeyChange(event){
        this.searchValue =event.target.value.trim();
        console.log(this.searchValue);
        console.log(this.searchValue.length);
        try{
        if(this.searchValue.length===0){
            this.fetchContactList();
        }
        else{
            searchKeyList({searchkey:this.searchValue}).then((result)=>{
                this.contactList=result;
                console.log('lrnfd'+result.length);
                if(result.length==0) {
                this.NOTFountContact='There are not Contact Found';
                this.contactList=[];
                }
                else{
                    this.NOTFountContact='';
                }
            });
        }
        }
        catch(error){
            console.log('Error Occured : ',error);
        }
    }
    
    EditViewHandler(event){
    const buttonLabel = event.target.label;
    const modeMapping = {
        'Edit': 'Edit',
        'View': 'readonly'
    };

    this.mode = modeMapping[buttonLabel];
        this.contactId = event.target.dataset.id;
        console.log('OUTPUT : ',this.contactId);
        this.modalContainer=true;
    }

    DeleteHandler(selectId){
        console.log('selctId'+selectId);
       // this.contactId = event.target.dataset.id;
            deleteRecord(selectId).then((result)=>{
                this.contactList = this.contactList.filter(currItem => currItem.Id !== selectId);
                    this.showToastMessage('success','Contact Deleted Successfully !','success');
                   // this.fetchContactList();
            }).catch((error)=>{
                    this.showToastMessage('error','Error Occured While Deleting Contact !','error');
            })


    }
    async confirmHandler(event){
        let id=event.target.dataset.id;
        console.log('Id is : ',event.target.dataset.id); 
    const result = await LightningConfirm.open({
        message: 'Are you sure you want to Delete this Contact? Please confirm your action.',
        variant: 'header', // or 'plain' if you prefer a simpler look
        label: 'Delete Contact Confirmation',
        theme: "success" // Add a success theme to make it visually attractive (though it may be subtle)
    }); 
    console.log(result);
    console.log('Id is : ',id); 
    result ? this.DeleteHandler(id) :'';
 
}
    handleCloseModal(){
        this.modalContainer=false;
    }
    handleContactUpdated(event) {
        console.log('Updated-----');
        this.NOTFountContact='';
        this.searchValue='';
        this.showToastMessage('success','Contact Updated Successfully !','success');
        // Call fetchContactList to refresh data after record update
        
         this.fetchContactList();
    }
    showToastMessage(title,message,variant){
        const event = new ShowToastEvent({
            title:title, 
            message: message,
            variant: variant
    })
    this.dispatchEvent(event);

}
}