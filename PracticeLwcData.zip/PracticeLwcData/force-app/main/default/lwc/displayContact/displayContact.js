import { LightningElement, api, wire } from 'lwc';
import getContactsList from '@salesforce/apex/AccountDataController.getContacts';
export default class DisplayContact extends LightningElement 
{
    columns=[
        {label:'Name',fieldName:'Name'},
        {label:'Account Name', fieldName:'AccountName'},
        {label:'Contact Email', fieldName:'Email',type:'email'}

    ]
    accountId;
    contactList=[];
    contactNotFound;
    @api
    fetchAccountId(value){
   this.accountId=value;
   console.log('in Child : ',this.accountId);
    }

    @wire(getContactsList ,{accId:'$accountId'})
    contactData({data,error}){
        if(data){
            
            // this.contactList=data.map((contact)=>({
            //     ...contact,
            //     AccountName:contact.Account?.Name
            // }))
            this.contactList=data.map((contact)=>{
            let updatedObject={};
            if(!contact.hasOwnProperty('Email')){
                updatedObject={...contact, AccountName:contact.Account?.Name,Email:'test@demo.com'};

            }
            else{
                updatedObject={...contact,AccountName:contact.Account?.Name};
            }
            
            this.contactNotFound = '';
           console.log('OUTPUT : ',JSON.stringify(this.contactList));
           return updatedObject;
        })
        }
        else{
            console.log('OUTPUT : ',JSON.stringify(error));
        }
        if (data && data.length === 0) {
            this.contactNotFound = 'There are no Related Contacts';
            this.contactList = [];
        }
    }

    get notFountCSS(){
        return  this.contactNotFound ? 'redError' : '';
    }
}