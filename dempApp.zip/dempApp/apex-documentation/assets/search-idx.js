export default [
    {
        "title": "Home",
        "fileName": "index.html",
        "text": "Home Project Home Use the apexdox.homePagePath  setting to point to an HTML file that contains details about your project. The body of the HTML will show up here instead of this default!"
    },
    {
        "title": "AccController",
        "fileName": "AccController.html",
        "text": "AccController Signature public class AccController AccController Methods getAccounts() getAccounts() Signature @AuraEnabled public static List<Account> getAccounts()"
    },
    {
        "title": "AccountCalculator",
        "fileName": "AccountCalculator.html",
        "text": "AccountCalculator Signature public class AccountCalculator AccountCalculator Methods countContacts(accIds) countContacts(accIds) Signature @future public static void countContacts(List<Id> accIds)"
    },
    {
        "title": "AccountCalculatorTest",
        "fileName": "AccountCalculatorTest.html",
        "text": "AccountCalculatorTest Signature @isTest public class AccountCalculatorTest AccountCalculatorTest Methods AccountContactTest() AccountContactTest() Signature @isTest public static void AccountContactTest()"
    },
    {
        "title": "Accountclls",
        "fileName": "Accountclls.html",
        "text": "Accountclls Signature public class Accountclls Accountclls Properties Name Signature actObj public Account actObj Accountclls Constructors Accountclls() Accountclls() Signature public Accountclls() Accountclls Methods saveAccount() saveAccount() Signature public pagereference saveAccount()"
    },
    {
        "title": "Accountcls",
        "fileName": "Accountcls.html",
        "text": "Accountcls Signature public with sharing class Accountcls Accountcls Properties Name Signature actObj public Account actObj Accountcls Constructors Accountcls() Accountcls() Signature public Accountcls() Accountcls Methods getAccountList() saveAccount() getAccountList() Signature @AuraEnabled(cacheable=true) public static List<Account> getAccountList() saveAccount() Signature public pagereference saveAccount()"
    },
    {
        "title": "AccountController",
        "fileName": "AccountController.html",
        "text": "AccountController Signature public class AccountController AccountController Properties Name Signature accountId public String accountId actObj public Account actObj AccountController Constructors AccountController() AccountController() Signature public AccountController() AccountController Methods getAccountRecordsList() getAccounts() getAccounts1() retrieveAccountDetail() getAccountRecordsList() Signature @AuraEnabled public static List<Account> getAccountRecordsList() getAccounts() Signature @auraEnabled public static List<Account> getAccounts() getAccounts1() Signature @AuraEnabled(cacheable=true) public static List<Account> getAccounts1() retrieveAccountDetail() Signature public pageReference retrieveAccountDetail()"
    },
    {
        "title": "AccountController1",
        "fileName": "AccountController1.html",
        "text": "AccountController1 Signature public class AccountController1"
    },
    {
        "title": "AccountControllerSearch",
        "fileName": "AccountControllerSearch.html",
        "text": "AccountControllerSearch Signature public with sharing class AccountControllerSearch AccountControllerSearch Constructors AccountControllerSearch() AccountControllerSearch() Signature public AccountControllerSearch() AccountControllerSearch Methods fetchAccounts() fetchAccounts() Signature @AuraEnabled(cacheable=true) public static List<Account> fetchAccounts()"
    },
    {
        "title": "AccountCreationController",
        "fileName": "AccountCreationController.html",
        "text": "AccountCreationController Signature public with sharing class AccountCreationController AccountCreationController Constructors AccountCreationController() AccountCreationController() Signature public AccountCreationController() AccountCreationController Methods createAccount(accountRecObj) createAccounts(accountList) createAccount(accountRecObj) Signature @AuraEnabled public static Account createAccount(Account accountRecObj) createAccounts(accountList) Signature @AuraEnabled public static List<Account> createAccounts(List<Account> accountList)"
    },
    {
        "title": "AccountHandlerDemo1",
        "fileName": "AccountHandlerDemo1.html",
        "text": "AccountHandlerDemo1 Signature public class AccountHandlerDemo1 AccountHandlerDemo1 Methods updateContact(accList) updateContact(accList) Signature public static void updateContact(List<Account> accList)"
    },
    {
        "title": "AccountHelper",
        "fileName": "AccountHelper.html",
        "text": "AccountHelper Signature public class AccountHelper AccountHelper Methods createContact(newaccList) createContact(newaccList) Signature public static void createContact(List<Account> newaccList)"
    },
    {
        "title": "AccountNewHandler",
        "fileName": "AccountNewHandler.html",
        "text": "AccountNewHandler Signature public class AccountNewHandler AccountNewHandler Methods checkContacts(accList) checkContacts(accList) Signature public static void checkContacts(List<Account> accList)"
    },
    {
        "title": "AccountRecordExtensionDemo",
        "fileName": "AccountRecordExtensionDemo.html",
        "text": "AccountRecordExtensionDemo Signature public class AccountRecordExtensionDemo AccountRecordExtensionDemo Properties Name Signature accountList public List<Account> accountList AccountRecordExtensionDemo Constructors AccountRecordExtensionDemo(stdcontroller) AccountRecordExtensionDemo(stdcontroller) Signature public AccountRecordExtensionDemo(ApexPages.StandardController stdcontroller)"
    },
    {
        "title": "AccountSavecls",
        "fileName": "AccountSavecls.html",
        "text": "AccountSavecls Signature public class AccountSavecls AccountSavecls Properties Name Signature actObj public Account  actObj AccountSavecls Constructors AccountSavecls() AccountSavecls() Signature public AccountSavecls() AccountSavecls Methods saveAccount() saveAccount() Signature public pagereference saveAccount()"
    },
    {
        "title": "AccountSearchController",
        "fileName": "AccountSearchController.html",
        "text": "AccountSearchController Signature public with sharing class AccountSearchController AccountSearchController Constructors AccountSearchController() AccountSearchController() Signature public AccountSearchController() AccountSearchController Methods getAccounts(actName) getAccounts(actName) Signature @AuraEnabled(cacheable=true) public static List<Account> getAccounts(String actName)"
    },
    {
        "title": "AccountTest",
        "fileName": "AccountTest.html",
        "text": "AccountTest Signature @isTest public class AccountTest AccountTest Methods copyBillingToShippingTest() createRelatedContactTest() PreventdeleteAccountTest() PreventUpdateAccountTest() testcopyBillingToShippingTest() testCreateContactOrOpp() testUpdateAccDesconPhoneUpdate() updateRatingInsertTest() updateRatingUpdateTest() UpdateRelatedContactMailingAddressTest1() UpdateRelatedContactTest() updateRelatedOppStageName() copyBillingToShippingTest() Signature @isTest public static void copyBillingToShippingTest() createRelatedContactTest() Signature @isTest public  static void createRelatedContactTest() PreventdeleteAccountTest() Signature @isTest private static void PreventdeleteAccountTest() PreventUpdateAccountTest() Signature @isTest private static void PreventUpdateAccountTest() testcopyBillingToShippingTest() Signature @isTest public static void testcopyBillingToShippingTest() testCreateContactOrOpp() Signature @isTest private static void  testCreateContactOrOpp() testUpdateAccDesconPhoneUpdate() Signature @isTest private static void testUpdateAccDesconPhoneUpdate() updateRatingInsertTest() Signature public static void updateRatingInsertTest() updateRatingUpdateTest() Signature @isTest public static void updateRatingUpdateTest() UpdateRelatedContactMailingAddressTest1() Signature @isTest public static void UpdateRelatedContactMailingAddressTest1() UpdateRelatedContactTest() Signature @isTest public static void UpdateRelatedContactTest() updateRelatedOppStageName() Signature @isTest private static void updateRelatedOppStageName()"
    },
    {
        "title": "AccountTrigg",
        "fileName": "AccountTrigg.html",
        "text": "AccountTrigg Signature public class AccountTrigg AccountTrigg Methods copyBillingToShipping(accList, oldMap) CreateContactOrOpp(accList) createRelatedContact(accList) preventDel(accList) preventUpdate(accList, oldMap) updateAccDesOnPhoneUpdate(accList, oldAccMap) updateContactsMailingAddress(accList, oldAccMap) updateRating(accList, oldMap) updateRelatedContacts(accList, oldAccMap) updateRelatedOppStage(accList, oldMap) copyBillingToShipping(accList, oldMap) Signature public static void copyBillingToShipping(List<Account> accList,Map<Id,Account> oldMap) CreateContactOrOpp(accList) Signature public static void CreateContactOrOpp(List<Account> accList) createRelatedContact(accList) Signature public static void createRelatedContact(List<Account> accList) preventDel(accList) Signature public static void preventDel(List<Account> accList) preventUpdate(accList, oldMap) Signature public static void preventUpdate(List<Account> accList,Map<Id,Account> oldMap) updateAccDesOnPhoneUpdate(accList, oldAccMap) Signature public static void updateAccDesOnPhoneUpdate(List<Account> accList,Map<id,Account> oldAccMap) updateContactsMailingAddress(accList, oldAccMap) Signature public static void updateContactsMailingAddress(List<Account>  accList,Map<Id,Account> oldAccMap) updateRating(accList, oldMap) Signature public static void updateRating(List<Account> accList,Map<Id,Account> oldMap) updateRelatedContacts(accList, oldAccMap) Signature public static void updateRelatedContacts(List<Account>  accList,Map<Id,Account> oldAccMap) updateRelatedOppStage(accList, oldMap) Signature public static void updateRelatedOppStage(List<Account>  accList,Map<Id,Account> oldMap)"
    },
    {
        "title": "AccountTriggerHandler",
        "fileName": "AccountTriggerHandler.html",
        "text": "AccountTriggerHandler Signature public class AccountTriggerHandler AccountTriggerHandler Methods applyValidation(oppList) applyValidationTest() checkAccountStatus(oldList) copyBillingToShipping(accList, oldMap) copyBillingToShippingTest() copyBillingToShippingUpdateTest() createRelatedContactTest() createRelatedOppTest() createTask(oppList, oldMap) createTaskTest() populateClosedLostReason(oppList, oldMap) populateClosedLostReasonTest() PreventdeleteAccountTest() preventUpdate(accList, oldMap) PreventUpdateAccountTest() testCreateContactOrOpp() testUpdateAccountDesconPhoneUpdate() updateAccPhonre(accList, oldAccMap) updateContactsMailingAddress(accList, oldAccMap) updateDescBasedOnStage(oppList, oldMap) updateDescBasedOnStageInsertTest() updateDescBasedOnStageUpdateTest() updateRating(accList) updateRating(accList, oldMap) updateRatingTest() updateRelatedContactMailingAdressTest() updateRelatedContacts(accList, oldAccMap) updateRelatedContacts(accList, oldAccMap) updateRelatedContactTest() UpdateRelatedOppStage(accList, oldMap) updateRelatedOppStageTest() applyValidation(oppList) Signature public static void applyValidation(List<Opoortunity> oppList) applyValidationTest() Signature @isTest private static void applyValidationTest() checkAccountStatus(oldList) Signature public static void checkAccountStatus(List<Account> oldList) copyBillingToShipping(accList, oldMap) Signature public static void copyBillingToShipping(List<Account> accList,Map<Id,Account> oldMap) copyBillingToShippingTest() Signature @isTest public static void copyBillingToShippingTest() copyBillingToShippingUpdateTest() Signature @isTest public static void copyBillingToShippingUpdateTest() createRelatedContactTest() Signature @isTest public  static void createRelatedContactTest() createRelatedOppTest() Signature public static void createRelatedOppTest() createTask(oppList, oldMap) Signature public static void createTask(List<Opportunity> oppList,Map<Id,Opportunity> oldMap) createTaskTest() Signature @isTest private static void createTaskTest() populateClosedLostReason(oppList, oldMap) Signature public static void populateClosedLostReason(List<Opportunity> oppList,Map<Id,Opportunity> oldMap) populateClosedLostReasonTest() Signature @isTest private static void populateClosedLostReasonTest() PreventdeleteAccountTest() Signature @isTest private static void PreventdeleteAccountTest() preventUpdate(accList, oldMap) Signature public static void preventUpdate(List<Account> accList,Map<Id,Account> oldMap) PreventUpdateAccountTest() Signature @isTest private static void PreventUpdateAccountTest() testCreateContactOrOpp() Signature @isTest private static void  testCreateContactOrOpp() testUpdateAccountDesconPhoneUpdate() Signature private static void testUpdateAccountDesconPhoneUpdate() updateAccPhonre(accList, oldAccMap) Signature public static void updateAccPhonre(List<Account> accList,Map<Id,Account> oldAccMap) updateContactsMailingAddress(accList, oldAccMap) Signature public static void updateContactsMailingAddress(List<Account>  accList,Map<Id,Account> oldAccMap) updateDescBasedOnStage(oppList, oldMap) Signature public static void updateDescBasedOnStage(List<Opportunity> oppList,Map<Id,Opportunity> oldMap) updateDescBasedOnStageInsertTest() Signature @isTest private static void updateDescBasedOnStageInsertTest() updateDescBasedOnStageUpdateTest() Signature @isTest private static void updateDescBasedOnStageUpdateTest() updateRating(accList) Signature public static void updateRating(List<Account> accList) updateRating(accList, oldMap) Signature public static void updateRating(List<Account> accList,Map<Id,Account> oldMap) updateRatingTest() Signature @isTest public static void updateRatingTest() updateRelatedContactMailingAdressTest() Signature @isTest public  static void updateRelatedContactMailingAdressTest() updateRelatedContacts(accList, oldAccMap) Signature public static void updateRelatedContacts(List<Account>  accList,Map<Id,Account> oldAccMap) updateRelatedContacts(accList, oldAccMap) Signature public static void updateRelatedContacts(List<Account>  accList,Map<Id,Account> oldAccMap) updateRelatedContactTest() Signature public static void updateRelatedContactTest() UpdateRelatedOppStage(accList, oldMap) Signature public static void UpdateRelatedOppStage(List<Account> accList,Map<Id,Account> oldMap) updateRelatedOppStageTest() Signature @isTest private static void updateRelatedOppStageTest() AccountTriggerHandler.AccountTriggerHandlewrTest Signature @isTest public class AccountTriggerHandlewrTest AccountTriggerHandler.AccountTriggerHandlewrTest Methods updateRatingTest() updateRatingTest() Signature @isTest public static void updateRatingTest() AccountTriggerHandler.OpportunityTriggerHandlerTest Signature @isTest public class OpportunityTriggerHandlerTest AccountTriggerHandler.OpportunityTriggerHandlerTest Methods updateDescTest() updateDescTest() Signature @isTest public static void updateDescTest()"
    },
    {
        "title": "AccountTriggerHandler1",
        "fileName": "AccountTriggerHandler1.html",
        "text": "AccountTriggerHandler1 Signature public class AccountTriggerHandler1 AccountTriggerHandler1 Methods checkAccountStatus(oldList) Phone(newList, oldMap) updateRelatedOpp(newList, oldMap) checkAccountStatus(oldList) Signature public static void checkAccountStatus(List<Account> oldList) Phone(newList, oldMap) Signature public static void Phone(List<Account> newList,Map<Id,Account> oldMap) updateRelatedOpp(newList, oldMap) Signature public static void updateRelatedOpp(List<Account> newList,Map<Id,Account> oldMap)"
    },
    {
        "title": "ApexHourDemo",
        "fileName": "ApexHourDemo.html",
        "text": "ApexHourDemo Signature public with sharing class ApexHourDemo ApexHourDemo Methods getAccountList() getContactList() getAccountList() Signature @AuraEnabled public static List<Account> getAccountList() getContactList() Signature @AuraEnabled(cacheable = true) public static List<Contact> getContactList()"
    },
    {
        "title": "ApxHourDataManipulation",
        "fileName": "ApxHourDataManipulation.html",
        "text": "ApxHourDataManipulation Signature public class ApxHourDataManipulation ApxHourDataManipulation Constructors ApxHourDataManipulation() ApxHourDataManipulation() Signature public ApxHourDataManipulation()"
    },
    {
        "title": "c7",
        "fileName": "c7.html",
        "text": "c7 Signature public class c7 c7 Methods getKeyword() getresults() search_now() setkeyword(input) getKeyword() Signature public String getKeyword() getresults() Signature public List<Account> getresults() search_now() Signature public PageReference search_now() setkeyword(input) Signature public void setkeyword(String input)"
    },
    {
        "title": "CalculateCaseOrigin",
        "fileName": "CalculateCaseOrigin.html",
        "text": "CalculateCaseOrigin Signature public with sharing class CalculateCaseOrigin CalculateCaseOrigin Methods countCasesBasedOnOrigin(accIds) countCasesBasedOnOrigin(accIds) Signature @future public static void countCasesBasedOnOrigin(List<Id> accIds)"
    },
    {
        "title": "CalculateCaseOriginTest",
        "fileName": "CalculateCaseOriginTest.html",
        "text": "CalculateCaseOriginTest Signature @isTest public with sharing class CalculateCaseOriginTest CalculateCaseOriginTest Methods testCountCases() testCountCases() Signature @isTest public  static void testCountCases()"
    },
    {
        "title": "Calculatorcontroller",
        "fileName": "Calculatorcontroller.html",
        "text": "Calculatorcontroller Signature public class Calculatorcontroller Calculatorcontroller Properties Name Signature firstNumber public Decimal firstNumber result public decimal result secondNumber public decimal secondNumber Calculatorcontroller Methods multi() sub() sum() multi() Signature public void multi() sub() Signature public void sub() sum() Signature public void sum()"
    },
    {
        "title": "CaseTriggerHandler",
        "fileName": "CaseTriggerHandler.html",
        "text": "CaseTriggerHandler Signature public class CaseTriggerHandler CaseTriggerHandler Methods populateLatestCaseNum(caseList) populateLatestCaseNum(caseList) Signature public static void populateLatestCaseNum(List<Case> caseList)"
    },
    {
        "title": "CaseTriggerHandlerTest",
        "fileName": "CaseTriggerHandlerTest.html",
        "text": "CaseTriggerHandlerTest Signature @isTest public class CaseTriggerHandlerTest CaseTriggerHandlerTest Methods testPopulateLatestCaseNum() testPopulateLatestCaseNum() Signature @isTest public static void testPopulateLatestCaseNum()"
    },
    {
        "title": "ChangePasswordController",
        "fileName": "ChangePasswordController.html",
        "text": "ChangePasswordController An apex page controller that exposes the change password functionality Signature public with sharing class ChangePasswordController ChangePasswordController Properties Name Signature newPassword public String newPassword oldPassword public String oldPassword verifyNewPassword public String verifyNewPassword ChangePasswordController Constructors ChangePasswordController() ChangePasswordController() Signature public ChangePasswordController() ChangePasswordController Methods changePassword() changePassword() Signature public PageReference changePassword()"
    },
    {
        "title": "ChangePasswordControllerTest",
        "fileName": "ChangePasswordControllerTest.html",
        "text": "ChangePasswordControllerTest An apex page controller that exposes the change password functionality Signature @IsTest public with sharing class ChangePasswordControllerTest"
    },
    {
        "title": "ComboboxwithDataTable",
        "fileName": "ComboboxwithDataTable.html",
        "text": "ComboboxwithDataTable Signature public with sharing class ComboboxwithDataTable ComboboxwithDataTable Constructors ComboboxwithDataTable() ComboboxwithDataTable() Signature public ComboboxwithDataTable() ComboboxwithDataTable Methods getAccounts() getContacts(selectedAccountId) getAccounts() Signature @AuraEnabled public static List<Account> getAccounts() getContacts(selectedAccountId) Signature @AuraEnabled public static List<Contact> getContacts(String selectedAccountId)"
    },
    {
        "title": "ComboDemo",
        "fileName": "ComboDemo.html",
        "text": "ComboDemo Signature public with sharing class ComboDemo ComboDemo Constructors ComboDemo() ComboDemo() Signature public ComboDemo() ComboDemo Methods getAccount() getAccount() Signature @AuraEnabled public static List<Account> getAccount()"
    },
    {
        "title": "ContactClone",
        "fileName": "ContactClone.html",
        "text": "ContactClone Signature public with sharing class ContactClone implements Queueable ContactClone Properties Name Signature con private Contact con industryValue private String industryValue ContactClone Constructors ContactClone(con, industryValue) ContactClone(con, industryValue) Signature public ContactClone(Contact con,String industryValue) ContactClone Methods execute(context) execute(context) Signature public void execute(QueueableContext context)"
    },
    {
        "title": "ContactCloneTest",
        "fileName": "ContactCloneTest.html",
        "text": "ContactCloneTest Signature @isTest public with sharing class ContactCloneTest ContactCloneTest Methods makeData() testContactClone() makeData() Signature @TestSetup static void makeData() testContactClone() Signature @isTest public static void testContactClone()"
    },
    {
        "title": "ContactController",
        "fileName": "ContactController.html",
        "text": "ContactController Signature public class ContactController ContactController Methods findContactByAccountId(accountId) getContacts(recordId) findContactByAccountId(accountId) Signature @AuraEnabled(cacheable=true) public static List<Contact> findContactByAccountId(String accountId) getContacts(recordId) Signature @auraEnabled public static List<Contact> getContacts(Id recordId)"
    },
    {
        "title": "ContactControllerWithApex",
        "fileName": "ContactControllerWithApex.html",
        "text": "ContactControllerWithApex Signature public with sharing class ContactControllerWithApex ContactControllerWithApex Constructors ContactControllerWithApex() ContactControllerWithApex() Signature public ContactControllerWithApex() ContactControllerWithApex Methods getContacts(accId) getContacts(accId) Signature @AuraEnabled(cacheable=true) public static List<Contact> getContacts(String accId)"
    },
    {
        "title": "contactPaginationLwcCtrl",
        "fileName": "contactPaginationLwcCtrl.html",
        "text": "contactPaginationLwcCtrl Signature public with sharing class contactPaginationLwcCtrl contactPaginationLwcCtrl Methods getContactList(pageSize, pageNumber) getContactList(pageSize, pageNumber) Signature @AuraEnabled public static String getContactList(Integer pageSize, Integer pageNumber) contactPaginationLwcCtrl.ContactItemWrapper Signature public class ContactItemWrapper contactPaginationLwcCtrl.ContactItemWrapper Properties Name Signature contacts public List<Contact> contacts pageNumber public Integer pageNumber pageSize public Integer pageSize recordEnd public Integer recordEnd recordStart public Integer recordStart totalRecords public Integer totalRecords"
    },
    {
        "title": "ContactsListWithController",
        "fileName": "ContactsListWithController.html",
        "text": "ContactsListWithController Signature public class ContactsListWithController ContactsListWithController Properties Name Signature sortOrder private String sortOrder ContactsListWithController Methods getContacts() sortByFirstName() sortByLastName() getContacts() Signature public List<Contact> getContacts() sortByFirstName() Signature public void sortByFirstName() sortByLastName() Signature public void sortByLastName()"
    },
    {
        "title": "ContactTriggerHandler",
        "fileName": "ContactTriggerHandler.html",
        "text": "ContactTriggerHandler Signature public class ContactTriggerHandler ContactTriggerHandler Methods sendEmail(conList) sendEmail(conList) Signature public static void sendEmail(List<Contact> conList)"
    },
    {
        "title": "CreateContact",
        "fileName": "CreateContact.html",
        "text": "CreateContact Signature public class CreateContact CreateContact Constructors createContact(firstName, lastName, email, bDate) createContact(firstName, lastName, email, bDate) Signature @AuraEnabled public static void createContact(String firstName,String lastName,String email,Date bDate)"
    },
    {
        "title": "CreateUpdateRecord",
        "fileName": "CreateUpdateRecord.html",
        "text": "CreateUpdateRecord Signature public with sharing class CreateUpdateRecord CreateUpdateRecord Constructors CreateUpdateRecord() CreateUpdateRecord() Signature public CreateUpdateRecord() CreateUpdateRecord Methods createRecord(accountNames, accountIndustries) updateRecord(accountId, accountNames, accountIndustries) createRecord(accountNames, accountIndustries) Signature @AuraEnabled public static List<Account> createRecord(String accountNames,String accountIndustries) updateRecord(accountId, accountNames, accountIndustries) Signature @AuraEnabled public static List<Account> updateRecord(String accountId,String accountNames,String accountIndustries)"
    },
    {
        "title": "DailyOppProcessor",
        "fileName": "DailyOppProcessor.html",
        "text": "DailyOppProcessor Signature public class DailyOppProcessor implements Schedulable DailyOppProcessor Methods execute(ctx) execute(ctx) Signature public void execute(SchedulableContext ctx)"
    },
    {
        "title": "DailyOppProcessorTest",
        "fileName": "DailyOppProcessorTest.html",
        "text": "DailyOppProcessorTest Signature @isTest public class DailyOppProcessorTest DailyOppProcessorTest Methods testScheduleApex() testScheduleApex() Signature @isTest private static void testScheduleApex()"
    },
    {
        "title": "DatabaseOperation",
        "fileName": "DatabaseOperation.html",
        "text": "DatabaseOperation Signature public class DatabaseOperation DatabaseOperation Constructors DatabaseOperation() DatabaseOperation() Signature public DatabaseOperation()"
    },
    {
        "title": "DataTY",
        "fileName": "DataTY.html",
        "text": "DataTY Signature public class DataTY DataTY Methods add(a, b) add(a, b) Signature public static void add(Integer a,Integer b)"
    },
    {
        "title": "DataTypeDemo",
        "fileName": "DataTypeDemo.html",
        "text": "DataTypeDemo Signature public class DataTypeDemo DataTypeDemo Methods methoDemo() methoDemo() Signature public void methoDemo()"
    },
    {
        "title": "Demo1",
        "fileName": "Demo1.html",
        "text": "Demo1 Signature public class Demo1 extends Demo2 Demo1 Methods sum() sum() Signature public void sum()"
    },
    {
        "title": "Demo2",
        "fileName": "Demo2.html",
        "text": "Demo2 Signature public virtual class Demo2 Demo2 Methods hell() hell() Signature public virtual void hell()"
    },
    {
        "title": "Demo3",
        "fileName": "Demo3.html",
        "text": "Demo3 Signature public class Demo3 Demo3 Methods display() display() Signature public static void display()"
    },
    {
        "title": "DMLOperation",
        "fileName": "DMLOperation.html",
        "text": "DMLOperation Signature public class DMLOperation DMLOperation Constructors DMLOperation() DMLOperation() Signature public DMLOperation()"
    },
    {
        "title": "ForgotPasswordController",
        "fileName": "ForgotPasswordController.html",
        "text": "ForgotPasswordController An apex page controller that exposes the site forgot password functionality Signature public with sharing class ForgotPasswordController ForgotPasswordController Properties Name Signature username public String username ForgotPasswordController Constructors ForgotPasswordController() ForgotPasswordController() Signature public ForgotPasswordController() ForgotPasswordController Methods forgotPassword() forgotPassword() Signature public PageReference forgotPassword()"
    },
    {
        "title": "ForgotPasswordControllerTest",
        "fileName": "ForgotPasswordControllerTest.html",
        "text": "ForgotPasswordControllerTest An apex page controller that exposes the site forgot password functionality Signature @IsTest public with sharing class ForgotPasswordControllerTest"
    },
    {
        "title": "GetChild",
        "fileName": "GetChild.html",
        "text": "GetChild Signature public with sharing class GetChild GetChild Constructors GetChild() GetChild() Signature public GetChild() GetChild Methods getContactDetails() getContactDetails() Signature @AuraEnabled public static List<Account> getContactDetails()"
    },
    {
        "title": "GetContactOpportunityDetails",
        "fileName": "GetContactOpportunityDetails.html",
        "text": "GetContactOpportunityDetails Signature public with sharing class GetContactOpportunityDetails GetContactOpportunityDetails Constructors GetContactOpportunityDetails() GetContactOpportunityDetails() Signature public GetContactOpportunityDetails() GetContactOpportunityDetails Methods getChildDetails(recId) getChildDetails(recId) Signature @AuraEnabled public static List<Account> getChildDetails(String recId)"
    },
    {
        "title": "GlobalRecursionHandle",
        "fileName": "GlobalRecursionHandle.html",
        "text": "GlobalRecursionHandle Signature public class GlobalRecursionHandle GlobalRecursionHandle Properties Name Signature updateCon public  static Boolean updateCon"
    },
    {
        "title": "LCDemoWrapper",
        "fileName": "LCDemoWrapper.html",
        "text": "LCDemoWrapper Signature public class LCDemoWrapper LCDemoWrapper.WrapperTest Signature public class WrapperTest LCDemoWrapper.WrapperTest Properties Name Signature Annotations myInteger1 public Integer myInteger1 @auraEnabled myString1 public String myString1 @auraEnabled"
    },
    {
        "title": "ListDemo",
        "fileName": "ListDemo.html",
        "text": "ListDemo Signature public class ListDemo"
    },
    {
        "title": "lwcApexController",
        "fileName": "lwcApexController.html",
        "text": "lwcApexController Signature public with sharing class lwcApexController lwcApexController Methods getCustomLookupAccount(actName) insertAccountMethod(accountObj) searchAccountNameMethod(accStrName, accStrPhone, accStrWebsite, accStrIndustry, accStrDescription) getCustomLookupAccount(actName) Signature @AuraEnabled(cacheable=true) public static List<Account> getCustomLookupAccount(String actName) insertAccountMethod(accountObj) Signature @AuraEnabled public static Account insertAccountMethod(Account accountObj) searchAccountNameMethod(accStrName, accStrPhone, accStrWebsite, accStrIndustry, accStrDescription) Signature @AuraEnabled(cacheable=true) public static List<Account> searchAccountNameMethod(String accStrName, String accStrPhone, String accStrWebsite, String accStrIndustry, String accStrDescription)"
    },
    {
        "title": "lwcAppExampleApex",
        "fileName": "lwcAppExampleApex.html",
        "text": "lwcAppExampleApex Signature public with sharing class lwcAppExampleApex lwcAppExampleApex Methods deleteMultipleContactRecord(conObj) displayContactRecord() fetchContactRecord() getAccountList() getAccountList1() getContactList() getDataFromContact() retrieveAccountRecords() retrieveContactData(keySearch) retrieveContactRecords(accId) deleteMultipleContactRecord(conObj) Signature @AuraEnabled public static List<Contact> deleteMultipleContactRecord(List<String> conObj) displayContactRecord() Signature @AuraEnabled(cacheable=true) public static List<Contact> displayContactRecord() fetchContactRecord() Signature @AuraEnabled(cacheable=true) public static List<Contact> fetchContactRecord() getAccountList() Signature @AuraEnabled(cacheable=true) public static List<Account> getAccountList() getAccountList1() Signature @AuraEnabled(cacheable=true) public static List<Account> getAccountList1() getContactList() Signature @AuraEnabled public static List<Contact> getContactList() getDataFromContact() Signature @AuraEnabled(cacheable=true) public static List<Contact> getDataFromContact() retrieveAccountRecords() Signature @AuraEnabled(cacheable=true) public static List<Account> retrieveAccountRecords() retrieveContactData(keySearch) Signature @AuraEnabled(cacheable=true) public static List<Contact> retrieveContactData(string keySearch) retrieveContactRecords(accId) Signature @AuraEnabled(cacheable=true) public static List<Contact> retrieveContactRecords(string accId)"
    },
    {
        "title": "lwcCustomMetaDataCtrl",
        "fileName": "lwcCustomMetaDataCtrl.html",
        "text": "lwcCustomMetaDataCtrl Signature public with sharing class lwcCustomMetaDataCtrl lwcCustomMetaDataCtrl Methods fetchMetaListLwc() fetchMetaListLwc() Signature @AuraEnabled( cacheable=true ) public static List < Student_Basic_Detail__mdt > fetchMetaListLwc()"
    },
    {
        "title": "lwcDateCmpCtrl",
        "fileName": "lwcDateCmpCtrl.html",
        "text": "lwcDateCmpCtrl Signature public with sharing class lwcDateCmpCtrl lwcDateCmpCtrl Methods searchRoItem(dateStr1, dateStr2) submitROAction(roAmount, roDate) searchRoItem(dateStr1, dateStr2) Signature @AuraEnabled public static List<RO_Published__c> searchRoItem(Date dateStr1, Date dateStr2) submitROAction(roAmount, roDate) Signature @AuraEnabled public static RO_Published__c submitROAction(Integer roAmount,Date roDate)"
    },
    {
        "title": "lwcEditSaveRowCtrl",
        "fileName": "lwcEditSaveRowCtrl.html",
        "text": "lwcEditSaveRowCtrl Signature public with sharing class lwcEditSaveRowCtrl lwcEditSaveRowCtrl Methods getAccounts() getAccounts() Signature @AuraEnabled(Cacheable = true) public static List<Account> getAccounts()"
    },
    {
        "title": "lwcSortingDataTableCtrl",
        "fileName": "lwcSortingDataTableCtrl.html",
        "text": "lwcSortingDataTableCtrl Signature public with sharing class lwcSortingDataTableCtrl lwcSortingDataTableCtrl Methods sortAccountList() sortAccountList() Signature @AuraEnabled(Cacheable = true) public static List<Account> sortAccountList()"
    },
    {
        "title": "MassDeleteContacts",
        "fileName": "MassDeleteContacts.html",
        "text": "MassDeleteContacts Signature public with sharing class MassDeleteContacts MassDeleteContacts Constructors MassDeleteContacts() MassDeleteContacts() Signature public MassDeleteContacts() MassDeleteContacts Methods deleteSelectedContacts(selContactIdList) getContactList() deleteSelectedContacts(selContactIdList) Signature @AuraEnabled public static Void  deleteSelectedContacts(List<Id> selContactIdList) getContactList() Signature @AuraEnabled(cacheable=true) public static List<Contact> getContactList()"
    },
    {
        "title": "MyDebugPrinter",
        "fileName": "MyDebugPrinter.html",
        "text": "MyDebugPrinter Signature public with sharing class MyDebugPrinter MyDebugPrinter Constructors MyDebugPrinter() MyDebugPrinter() Signature public MyDebugPrinter() MyDebugPrinter Methods doPrint() doPrint() Signature public static void doPrint()"
    },
    {
        "title": "MyDemoSosl",
        "fileName": "MyDemoSosl.html",
        "text": "MyDemoSosl Signature public class MyDemoSosl MyDemoSosl Methods createOpponAccount() createOpponAccount() Signature public static void createOpponAccount()"
    },
    {
        "title": "NewCaseListController",
        "fileName": "NewCaseListController.html",
        "text": "NewCaseListController Signature public class NewCaseListController"
    },
    {
        "title": "OpportunityControllerLwc",
        "fileName": "OpportunityControllerLwc.html",
        "text": "OpportunityControllerLwc Signature public with sharing class OpportunityControllerLwc OpportunityControllerLwc Methods createContact(firstName, lastName, emailValue, birthDate) getOppFilter(CloseDate) getOppoInLast20Days() oppListData() createContact(firstName, lastName, emailValue, birthDate) Signature @AuraEnabled public static void createContact(String firstName,String lastName,String emailValue,Date birthDate) getOppFilter(CloseDate) Signature @AuraEnabled(cacheable=true) public static List<Opportunity> getOppFilter(Date CloseDate) getOppoInLast20Days() Signature @AuraEnabled(cacheable=true) public static List<Opportunity> getOppoInLast20Days() oppListData() Signature @AuraEnabled(cacheable=true) public static List<Opportunity> oppListData()"
    },
    {
        "title": "OpportunityTriggerHandler",
        "fileName": "OpportunityTriggerHandler.html",
        "text": "OpportunityTriggerHandler Signature public class OpportunityTriggerHandler OpportunityTriggerHandler Methods createTask(oppList, oldMap) Phone(newList, oldMap) updateDescBasedOnStage(oppList, oldMap) createTask(oppList, oldMap) Signature public static void createTask(List<Opportunity> oppList,Map<Id,Opportunity> oldMap) Phone(newList, oldMap) Signature public static void Phone(List<Opportunity> newList,Map<Id,Opportunity> oldMap) updateDescBasedOnStage(oppList, oldMap) Signature public static void updateDescBasedOnStage(List<Opportunity> oppList,Map<Id,Opportunity> oldMap)"
    },
    {
        "title": "OpportunityTriggerHandlerExcercise",
        "fileName": "OpportunityTriggerHandlerExcercise.html",
        "text": "OpportunityTriggerHandlerExcercise Signature public class OpportunityTriggerHandlerExcercise OpportunityTriggerHandlerExcercise Methods changeDesc(oppList, oppMap) changeOppStage(oppList) changeDesc(oppList, oppMap) Signature public static void changeDesc(List<Opportunity> oppList,List<Opportunity> oppMap) changeOppStage(oppList) Signature public static void changeOppStage(List<Opportunity> oppList)"
    },
    {
        "title": "OpportunityTriggerHandlerExcerciseTest",
        "fileName": "OpportunityTriggerHandlerExcerciseTest.html",
        "text": "OpportunityTriggerHandlerExcerciseTest Signature @isTest public class OpportunityTriggerHandlerExcerciseTest OpportunityTriggerHandlerExcerciseTest Methods testchangeOppDesc() testchangeOppStage() testchangeOppDesc() Signature @isTest public static void testchangeOppDesc() testchangeOppStage() Signature @isTest public static void testchangeOppStage()"
    },
    {
        "title": "OpportunityTriggerHandlerTest",
        "fileName": "OpportunityTriggerHandlerTest.html",
        "text": "OpportunityTriggerHandlerTest Signature @isTest public class OpportunityTriggerHandlerTest OpportunityTriggerHandlerTest Methods applyValidationTest() createTaskTest() populateClosedLostReasonTest() updateDescBasedOnStageInsertTest() updateDescBasedOnStageUpdateTest() updateDescTest() applyValidationTest() Signature @isTest private static void applyValidationTest() createTaskTest() Signature @isTest private static void createTaskTest() populateClosedLostReasonTest() Signature @isTest private static void populateClosedLostReasonTest() updateDescBasedOnStageInsertTest() Signature @isTest private static void updateDescBasedOnStageInsertTest() updateDescBasedOnStageUpdateTest() Signature @isTest private static void updateDescBasedOnStageUpdateTest() updateDescTest() Signature @isTest public static void updateDescTest()"
    },
    {
        "title": "OpporTunityTriggerHelper",
        "fileName": "OpporTunityTriggerHelper.html",
        "text": "OpporTunityTriggerHelper Signature public class OpporTunityTriggerHelper OpporTunityTriggerHelper Methods changeStage(oppList) checkMaps(newList, oldList, newMap, oldMap) UpdateAccountPriority(newList, oldMap) changeStage(oppList) Signature public static void changeStage(List<Opportunity> oppList) checkMaps(newList, oldList, newMap, oldMap) Signature public static void checkMaps(List<Opportunity> newList,List<Opportunity> oldList,Map<Id,Opportunity> newMap,Map<Id,Opportunity> oldMap) UpdateAccountPriority(newList, oldMap) Signature public static void UpdateAccountPriority(List<Opportunity> newList,Map<Id,Opportunity> oldMap)"
    },
    {
        "title": "OppProcessor",
        "fileName": "OppProcessor.html",
        "text": "OppProcessor Signature public class OppProcessor implements Database.Batchable<sObject>,Database.stateful OppProcessor Properties Name Signature recordCount public integer recordCount OppProcessor Methods execute(bc, opps) finish(bc) start(bc) execute(bc, opps) Signature public void execute(Database.BatchableContext bc,List<Opportunity> opps) finish(bc) Signature public void finish(Database.BatchableContext bc) start(bc) Signature public Database.QueryLocator start(Database.BatchableContext bc)"
    },
    {
        "title": "OppProcessTest",
        "fileName": "OppProcessTest.html",
        "text": "OppProcessTest Signature @isTest public class OppProcessTest OppProcessTest Methods OppProcessTestBatch() OppProcessTestBatch() Signature @isTest public static void OppProcessTestBatch()"
    },
    {
        "title": "OppReminder",
        "fileName": "OppReminder.html",
        "text": "OppReminder Signature public with sharing class OppReminder implements Schedulable OppReminder Methods execute(ctx) execute(ctx) Signature public void execute(SchedulableContext ctx)"
    },
    {
        "title": "OppReminderTest",
        "fileName": "OppReminderTest.html",
        "text": "OppReminderTest Signature @isTest public with sharing class OppReminderTest OppReminderTest Properties Name Signature CRON_EXP public static String CRON_EXP OppReminderTest Methods testScheduleJob() testScheduleJob() Signature @isTest public static void testScheduleJob()"
    },
    {
        "title": "OppTriggerHandler",
        "fileName": "OppTriggerHandler.html",
        "text": "OppTriggerHandler Signature public class OppTriggerHandler OppTriggerHandler Methods applyValidation(oppList) populateClosedLostReason(oppList, oldMap) populateLatestOppAmt(oppList) updateDescription(oppList) applyValidation(oppList) Signature public static void applyValidation(List<Opportunity> oppList) populateClosedLostReason(oppList, oldMap) Signature public static void populateClosedLostReason(List<Opportunity> oppList,Map<Id,Opportunity> oldMap) populateLatestOppAmt(oppList) Signature public static void populateLatestOppAmt(List<Opportunity> oppList) updateDescription(oppList) Signature public static void updateDescription(List<Opportunity> oppList)"
    },
    {
        "title": "OppTriggerTotalAmount",
        "fileName": "OppTriggerTotalAmount.html",
        "text": "OppTriggerTotalAmount Signature public class OppTriggerTotalAmount OppTriggerTotalAmount Methods calculateAnuualRevenue(accIds) onAfterDelete(oldList) onAfterInsert(newList) onAfterUpdate(newList, oldMap) calculateAnuualRevenue(accIds) Signature public static List<Account> calculateAnuualRevenue(Set<Id> accIds) onAfterDelete(oldList) Signature public static void  onAfterDelete(List<Opportunity> oldList) onAfterInsert(newList) Signature public static void  onAfterInsert(List<Opportunity> newList) onAfterUpdate(newList, oldMap) Signature public static void  onAfterUpdate(List<Opportunity> newList,Map<Id,Opportunity> oldMap)"
    },
    {
        "title": "ParentToChildScanrio",
        "fileName": "ParentToChildScanrio.html",
        "text": "ParentToChildScanrio Signature public class ParentToChildScanrio ParentToChildScanrio Constructors ParentToChildScanrio() ParentToChildScanrio() Signature public ParentToChildScanrio()"
    },
    {
        "title": "PicklistHelper",
        "fileName": "PicklistHelper.html",
        "text": "PicklistHelper Signature public with sharing class PicklistHelper PicklistHelper Constructors PicklistHelper() PicklistHelper() Signature public PicklistHelper() PicklistHelper Methods getProfiles() getProfiles() Signature @AuraEnabled(cacheable=true) public static Map<String,String> getProfiles()"
    },
    {
        "title": "PokemonClass",
        "fileName": "PokemonClass.html",
        "text": "PokemonClass Signature public with sharing class PokemonClass PokemonClass Methods getPokemons(searchKey) getPokemons(searchKey) Signature @AuraEnabled public static List<Pokemon__c> getPokemons(String searchKey)"
    },
    {
        "title": "QuoteTriggerHandler",
        "fileName": "QuoteTriggerHandler.html",
        "text": "QuoteTriggerHandler Signature public class QuoteTriggerHandler QuoteTriggerHandler Methods SendingMail(newList) SendingMail(newList) Signature public static void SendingMail(List<Quote> newList)"
    },
    {
        "title": "ReminderOppOwners",
        "fileName": "ReminderOppOwners.html",
        "text": "ReminderOppOwners Signature global class ReminderOppOwners implements Schedulable ReminderOppOwners Methods execute(ctx) execute(ctx) Signature global void execute(SchedulableContext ctx)"
    },
    {
        "title": "RetrieveContacts",
        "fileName": "RetrieveContacts.html",
        "text": "RetrieveContacts Signature public class RetrieveContacts"
    },
    {
        "title": "SaveAccountwithProperties",
        "fileName": "SaveAccountwithProperties.html",
        "text": "SaveAccountwithProperties Signature public class SaveAccountwithProperties SaveAccountwithProperties Properties Name Signature accountName public String accountName accountType public String accountType SaveAccountwithProperties Methods saveAccount() saveAccount() Signature public pagereference saveAccount()"
    },
    {
        "title": "SetDemo",
        "fileName": "SetDemo.html",
        "text": "SetDemo Signature public class SetDemo"
    },
    {
        "title": "ShowRelatedContacts",
        "fileName": "ShowRelatedContacts.html",
        "text": "ShowRelatedContacts Signature public class ShowRelatedContacts ShowRelatedContacts Properties Name Signature accoutNames public List<SelectOption> accoutNames contactList public List<Contact> contactList selectedAccount public String selectedAccount ShowRelatedContacts Constructors ShowRelatedContacts() ShowRelatedContacts() Signature public ShowRelatedContacts() ShowRelatedContacts Methods retrieveContacts() retrieveContacts() Signature public pagereference retrieveContacts()"
    },
    {
        "title": "SiteLoginController",
        "fileName": "SiteLoginController.html",
        "text": "SiteLoginController An apex page controller that exposes the site login functionality Signature global with sharing class SiteLoginController SiteLoginController Properties Name Signature password global String password username global String username SiteLoginController Constructors SiteLoginController() SiteLoginController() Signature global SiteLoginController() SiteLoginController Methods login() login() Signature global PageReference login()"
    },
    {
        "title": "SiteLoginControllerTest",
        "fileName": "SiteLoginControllerTest.html",
        "text": "SiteLoginControllerTest An apex page controller that exposes the site login functionality Signature @IsTest global with sharing class SiteLoginControllerTest"
    },
    {
        "title": "sobjectDemo",
        "fileName": "sobjectDemo.html",
        "text": "sobjectDemo Signature public class sobjectDemo"
    },
    {
        "title": "SOQL",
        "fileName": "SOQL.html",
        "text": "SOQL Signature public class SOQL"
    },
    {
        "title": "SOQLSAnjay",
        "fileName": "SOQLSAnjay.html",
        "text": "SOQLSAnjay Signature public class SOQLSAnjay SOQLSAnjay Constructors SOQLSAnjay() SOQLSAnjay() Signature public SOQLSAnjay()"
    },
    {
        "title": "Sosl",
        "fileName": "Sosl.html",
        "text": "Sosl Signature public class Sosl Sosl Methods demo() demo() Signature public static void demo()"
    },
    {
        "title": "Temperature",
        "fileName": "Temperature.html",
        "text": "Temperature Signature public class Temperature Temperature Methods Ftoc(fh) Ftoc(fh) Signature public static Decimal Ftoc(Decimal fh)"
    },
    {
        "title": "TemperatureTest",
        "fileName": "TemperatureTest.html",
        "text": "TemperatureTest Signature @isTest public class TemperatureTest TemperatureTest Methods warmTempTest() warmTempTest() Signature @isTest private static void warmTempTest()"
    },
    {
        "title": "TransactionControl",
        "fileName": "TransactionControl.html",
        "text": "TransactionControl Signature public class TransactionControl TransactionControl Constructors TransactionControl() TransactionControl() Signature public TransactionControl()"
    },
    {
        "title": "UpdateContactMailingAddress",
        "fileName": "UpdateContactMailingAddress.html",
        "text": "UpdateContactMailingAddress Signature public with sharing class UpdateContactMailingAddress implements Database.Batchable<sObject>,Database.Stateful UpdateContactMailingAddress Properties Name Signature recordCount public Integer recordCount UpdateContactMailingAddress Methods execute(bc, accList) finish() start(bc) execute(bc, accList) Signature public void execute(Database.BatchableContext bc,List<Account> accList) finish() Signature public void finish() start(bc) Signature public Database.QueryLocator start(Database.BatchableContext bc)"
    },
    {
        "title": "UpdateContactMailingAddressTest",
        "fileName": "UpdateContactMailingAddressTest.html",
        "text": "UpdateContactMailingAddressTest Signature @isTest public with sharing class UpdateContactMailingAddressTest UpdateContactMailingAddressTest Methods testAddressCopy() testAddressCopy() Signature @isTest public static void testAddressCopy()"
    },
    {
        "title": "UpdateParentAccount",
        "fileName": "UpdateParentAccount.html",
        "text": "UpdateParentAccount Signature public class UpdateParentAccount  implements Queueable UpdateParentAccount Properties Name Signature accList private List<Account> accList parentAccId private Id parentAccId UpdateParentAccount Constructors UpdateParentAccount(accRecords, id) UpdateParentAccount(accRecords, id) Signature public UpdateParentAccount(List<Account> accRecords,Id id) UpdateParentAccount Methods execute(context) execute(context) Signature public void execute(QueueableContext context)"
    },
    {
        "title": "UpdateParentAccountTest",
        "fileName": "UpdateParentAccountTest.html",
        "text": "UpdateParentAccountTest Signature @isTest public class UpdateParentAccountTest UpdateParentAccountTest Methods setup() testQueueable() setup() Signature @testSetup static void setup() testQueueable() Signature @isTest private static void testQueueable()"
    },
    {
        "title": "User",
        "fileName": "User.html",
        "text": "User Signature public class User User Constructors User() User(name, batch) User() Signature public User() User(name, batch) Signature public User(String name, String batch) User Methods getBatch() getName() setBatch(batch) setName(name) getBatch() Signature public String getBatch() getName() Signature public String getName() setBatch(batch) Signature public void setBatch(String batch) setName(name) Signature public void setName(String name)"
    },
    {
        "title": "UserImpl",
        "fileName": "UserImpl.html",
        "text": "UserImpl Signature public class UserImpl UserImpl Methods demo() demo() Signature public static void demo()"
    },
    {
        "title": "wireDemoClass",
        "fileName": "wireDemoClass.html",
        "text": "wireDemoClass Signature public with sharing class wireDemoClass wireDemoClass Constructors wireDemoClass() wireDemoClass() Signature public wireDemoClass() wireDemoClass Methods getEmployeeList() getEmployeeList() Signature @AuraEnabled(cacheable=true) public static List<Employee__c> getEmployeeList()"
    },
    {
        "title": "WrapperExample",
        "fileName": "WrapperExample.html",
        "text": "WrapperExample Signature public class WrapperExample WrapperExample Properties Name Signature accountWrapperList public List<AccountWrapper> accountWrapperList selectedWrapperList public List<AccountWrapper> selectedWrapperList WrapperExample Constructors WrapperExample() WrapperExample() Signature public WrapperExample() WrapperExample Methods displaySelectedRecords() displaySelectedRecords() Signature public void displaySelectedRecords() WrapperExample.AccountWrapper Signature public class AccountWrapper WrapperExample.AccountWrapper Properties Name Signature accountName public String accountName accountType public String accountType isChecked public boolean isChecked"
    }
];
