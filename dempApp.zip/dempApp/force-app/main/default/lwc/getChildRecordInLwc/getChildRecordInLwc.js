import { LightningElement, api } from 'lwc';
import getChildDetails from '@salesforce/apex/GetContactOpportunityDetails.getChildDetails';

const column1=[
    {label:"Opportunity Id",fieldName:'Id'},
    {label:"Opportunity Name",fieldName:'Name'}
]

const column12=[
    {label:"Contact Id",fieldName:'Id'},
    {label:"Contact Name",fieldName:'Name'}
]

export default class GetChildRecordInLwc extends LightningElement {
    @api buttonLabel="Show";

    opportunityData=[];
    contactData=[];

   column1=column1;
   column2=column2;

    @api recordId;
    @api showDatatable=false;

    opportuniryTempArray=[];
    contactTempArray=[];

    handleShow(event)
    {
          if(event.target.label=="Show"){
            this.buttonLabel="Hide";
            this.showDatatable=true;
          }
          else if(event.target.label=="Hide")
          {
            this.buttonLabel="Show";
            this.showDatatable=false;
          }
    }

    connectedCallback(){
        getChildDetails({recId:this.recordId})
        .then(res=>{
            let tempRecords=res;
            console.log(JSON.stringify(tempRecords));

            //creste two objects for storing opp and contact details
            let temp=tempRecords.map(row=>{
                return Object.assign({OppName:row.Opportunities,ContactName:row.Contacts})
            })
            console.log("temp"+JSON.stringify(temp));

            //store contact and opp in different array
            temp.forEach(element=>{
                //opp array
                this.opportuniryTempArray=element.OppName;

                //contact array
                this.contactTempArray=element.ContactName;
            });

            //data for opp datatable
            this.opportunityData=this.opportuniryTempArray;
            //data for contact datatable
            this.contactData=this.contactTempArray;

        })
        .catch(error=>{
            console.log('error'+JSON.stringify(error));
        })
    }
}