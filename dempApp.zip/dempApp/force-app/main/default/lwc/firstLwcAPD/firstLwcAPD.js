import { LightningElement } from 'lwc';

export default class FirstLwcAPD extends LightningElement {}