import { LightningElement,api } from 'lwc';

export default class ChildComponentA extends LightningElement {

   @api getMessageDataFromParent;
}