import { LightningElement } from 'lwc';

export default class CssShareCmp extends LightningElement {
    
}