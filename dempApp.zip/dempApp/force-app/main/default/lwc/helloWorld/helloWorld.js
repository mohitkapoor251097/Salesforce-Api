import { LightningElement,track,wire } from 'lwc';
import getOppData from '@salesforce/apex/OpportunityControllerLwc.oppListData';
import setContactData from '@salesforce/apex/OpportunityControllerLwc.createContact';
export default class HelloWorld extends LightningElement {

    //Module :which is a Js file consisits of variable ,method,class+import or export statement
       /*variable which needs to be be used at class level not method level knows as PROPERTY*/ 
      @track opportunityList;
      @track  firstName;
      @track lastName;
      @track emailValue;
      @track birthDate;
      @track checktrueOrFalse=false;
handleChange(event){
        //this.firstName=event.target.value ;

        if(event.target.name=='fname'){
            this.firstName=event.target.value;
        }
        else if(event.target.name=='lname'){
            this.lastName=event.target.value;
        }
        else if(event.target.name=='bdate'){
            this.birthDate=event.target.value;
        }
        else if(event.target.name=='email'){
            this.emailValue=event.target.value;
        }


       }

       handleClick(event){
        checktrueOrFalse=true;
            setContactData({
                firstName:this.firstName,
                lastName:this.lastName,
                emailValue:this.emailValue,
                birthDate:this.birthDate
            })
            .then((result)=>{
                console.log('Result is success');
            })
            .catch((error)=>{
                console.log('Error encountered');
            });
       }









       @wire(getOppData)
       WiredOpps({error,data}){
        if(data){
            this.opportunityList=data;
        }
        else if(error){
            console.log('error'+error);
        }
       }

      





















// nameOfUser='Test User';
// emailUser;

    // processUserNames(){
    //     let nameOfUser='The user name is Mohit';
    //     let email='Mohit.@gmail.com';
    // }

    // processDetails(){

    // }

   
}