import { LightningElement } from 'lwc';
import { createRecord } from 'lightning/uiRecordApi';
import Account_Object from '@salesforce/schema/Account';
import NAME_FIELD from '@salesforce/schema/Account.Name';
export default class CreateRecordwithoutApex extends LightningElement {

    accountId;
    name='';
    handleNameChange(event)
    {
      this.name=event.target.value;
     // console.log(JSON.stringify(this.name));
    }
    handleCreateAccount()
    {
          const fields={};
          fields[NAME_FIELD.fieldApiName]=this.name;  
          console.log('fields'+JSON.stringify(fields));  

          const recordInput={apiName:Account_Object.objectApiName,fields};
          
          createRecord(recordInput)
          .then(account=>{
          console.log("Account"+JSON.stringify(account))
          this.accountId=account.id;
          })
          .catch(error=>{
            console.log("error"+JSON.stringify(error));
          })
        }

}