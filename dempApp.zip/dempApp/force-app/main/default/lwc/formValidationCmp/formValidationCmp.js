import { LightningElement } from 'lwc';

export default class FormValidationCmp extends LightningElement {}