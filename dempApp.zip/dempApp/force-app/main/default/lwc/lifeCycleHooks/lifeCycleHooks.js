import { LightningElement } from 'lwc';

export default class LifeCycleHooks extends LightningElement {

    //constructor
    //conntedCallback when all html element are loaded on page
    //renderedCallback : when all html elements of current component or child compoent are also intilaized
    //render : Update the UI
    //disconnectedCallback : when component are removed from DOM
    //errorCallback : error Details or StackTrace

    handleClick(event){

    }
    constructor(){
       super(); //calling constructor of extening LightningElement
       console.log("I am in Undia");
       var templateCheck=this.template;

       console.log('Template Intialized '+templateCheck.isConnected);
    }

    connectedCallback(){
        console.log('I am in conntedCall back');
        var templateCheck=this.template;

        console.log('Template Intialized in conntedcallback '+templateCheck.isConnected);
    }

    renderedCallback(){
        console.log('I am in renderedCallback');
    }
    // render(){
    //     console.log('I am in render');
    // }

    errorCallback(error,stack){
        console.log(' I am in error');
    }

    disconnectedCallback(){
        console.log('I am in out of memory');
    }

}