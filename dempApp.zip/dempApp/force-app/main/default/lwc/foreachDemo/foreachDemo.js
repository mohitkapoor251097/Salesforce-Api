import getEmployeeList from '@salesforce/apex/wireDemoClass.getEmployeeList';
import { LightningElement,track,wire} from 'lwc';

export default class ForeachDemo extends LightningElement {
     @track data=[];

    @wire(getEmployeeList)
    employees;
    
  
}