import { LightningElement } from 'lwc';
import SalesforeceImg from '@salesforce/resourceUrl/SalesforeceImg';
export default class CarasoalDemo extends LightningElement {

    players=[
        {
            id:"1",
            header:"Nature 1",
            name:"Nature1",
            src:SalesforeceImg +'/images/pic2.jpg',
            href:"#",
            description:"Nature First Image"
        },
        {
            id:"2",
            name:"Nature2",
            src:SalesforeceImg +'/images/pic3.jpg',
            href:"#",
            description:"Nature2"
        },
        {
            id:"3",
            name:"Nature3",
            src:SalesforeceImg +'/images/pic4.jpg',
            href:"#",
            description:"Nature3"
        }

    ]
}