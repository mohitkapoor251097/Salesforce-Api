import { LightningElement,api} from 'lwc';

export default class ChildSendA extends LightningElement {
 
   dataToSend;
    handleChange(event){
      this.dataToSend=event.target.value;

      const sendEvent=new CustomEvent("sendchilddata",
      {
       // detail:this.dataToSend
       detail:{
        data:this.dataToSend,
        color:"white",
        message:"Welcome"
       }
    });
      this.dispatchEvent(sendEvent);
    }
    
}