import { api, LightningElement } from 'lwc';

export default class ChildComponent extends LightningElement {
  @api  itemName="Dossa";

 @api handleChangeValue()
  {
    this.itemName="salesforce LWC Demo";
  }
}