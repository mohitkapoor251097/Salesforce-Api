import { LightningElement,api } from 'lwc';

export default class Child extends LightningElement {

    @api firstName='Mohit';

    // uppercaseItenName='default value';

    // @api 
    // get itemName(){
    //          return this.uppercaseItenName;
    // }
    // set itemName(value){
    //     this.uppercaseItenName=value.toUpperCase();
    // }

}