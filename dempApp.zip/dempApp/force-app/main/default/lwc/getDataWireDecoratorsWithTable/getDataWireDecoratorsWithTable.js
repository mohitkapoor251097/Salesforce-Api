import { api, LightningElement, track, wire } from 'lwc';
import getAccountList from '@salesforce/apex/lwcAppExampleApex.getAccountList';
 
import {NavigationMixin} from 'lightning/navigation';
 
export default class getDataWireDecoratorsWithTable extends NavigationMixin (LightningElement) {
  @api title;
  @api greetings;
  @track greeting;
   
    //Using @wire decorator for fatching the data from account 
      @track accData;
      @track errorData;
     @wire(getAccountList)
     dataRecord({data, error}){
       if(data){
           this.accData = data;
       }
       else if(error){
           this.errorData = error;
       }
     }
 
     
}