import { LightningElement, api } from 'lwc';
import NAME_FIELD from '@salesforce/schema/Account.Name';
import TYPE_FIELD from '@salesforce/schema/Account.Type';
import NumberOfEmployees_FIELD from '@salesforce/schema/Account.NumberOfEmployees';
export default class AccountCustomForm extends LightningElement {

    nameField = NAME_FIELD;
    type=TYPE_FIELD;
    empField=NumberOfEmployees_FIELD;

    @api objectApiName="Account";
    @api recordId;
}