import { LightningElement,track } from 'lwc';
import getAccountsForComboBox from '@salesforce/apex/ComboboxwithDataTable.getAccounts';
import getContacts from '@salesforce/apex/ComboboxwithDataTable.getContacts';
const columns=[
     {label:'Contacts Name', fieldName:'Name'},
     {label:'Contacts Email',fieldName:'Email'},
]
export default class ComboboxWithDataTable extends LightningElement {
    @track value='';
@track optionArray=[];
@track cardVisible=false;
@track data=[];
@track columns=columns;
get options()
{
    return this.optionArray;
}
    connectedCallback()
    {
        getAccountsForComboBox()
        .then(response=>{
             let arr=[];
             for(var i=0;i<response.length;i++)
             {
                arr.push({label:response[i].Name,value:response[i].Id})
             }

             this.optionArray=arr;
        })
    }

    handleChangedValue(event){
        this.cardVisible=true;
        this.value=event.detail.value;
       // window.alert(JSON.stringify(this.value));

       getContacts({selectedAccountId:this.value})
       .then(result=>{
        this.data=result;
       })
       .catch(error=>{
              window.alert("error"+ error);
       })
    }
}