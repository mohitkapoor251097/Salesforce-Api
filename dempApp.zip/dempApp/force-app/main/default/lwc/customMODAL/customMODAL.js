import { LightningElement } from 'lwc';

export default class CustomMODAL extends LightningElement {}