import { LightningElement } from 'lwc';
import createRecord from '@salesforce/apex/CreateUpdateRecord.createRecord';
export default class CreaterecordWithApex extends LightningElement {

    accountIds;
    accountName;
    accountIndustry;
    handleNameChange(event)
    {
      this.accountName=event.target.value;
    }
handleIndustryChange(event)
{
         this.accountIndustry=event.target.value;
}

onCreateRecord()
{
    createRecord({accountNames:this.accountName,accountIndustries:this.accountIndustry})
    .then(result=>{
        this.accountIds = result[0].Id;
        console.log("Result"+JSON.stringify(result));
    })
    .catch(error=>{
          console.log("error"+JSON.stringify(error));
    })
}

}