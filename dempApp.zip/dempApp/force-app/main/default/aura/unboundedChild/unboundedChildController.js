({
	updateChildVar : function(component, event, helper) {
		  component.set("v.childVar","Update child attribute");
	}
})