({
	throwError : function(component, event, helper) {
            throw new Error("I can not go on,This is the end ")		
	}
})