({
	doInit : function(component, event, helper) {
            //component.set("v.Var1","Demo Value From Component Controller")      
        var data={'name':'Test Name',
                  'email':'test@test.com'};
        component.set("v.jsObject",data);
        
        component.set("v.userData",
                      {
                          'myString1':'StringValue',
                          'myInteger1':234
                      })
	}
})