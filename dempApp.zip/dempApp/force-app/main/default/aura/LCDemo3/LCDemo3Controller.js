({
	handleClick : function(component, event, helper) {
		//component.set("v.Message1"," Button Click");
	     //var btn=event.getSource();
        //var msg=btn.get("v.label");
       // component.set("v.Message1",msg);
       // component.set("v.Message1",event.getSource().get("v.label"));
         var btn=event.getSource();
        var msg=btn.get("v.label");
        if(msg=="CLICKMe")
        {
            component.set("v.Message1",msg);
        }
        else
        {
            component.set("v.Message1",msg);
        }
	},
    anotherhandleClick: function(component, event, helper) {
		//component.set("v.Message2","Another Button Click");
		 component.set("v.Message2",event.getSource().get("v.label"));
	},
    doInit: function(component, event, helper) {
		
        component.set("v.Message1","Button  1 Initalize");
        component.set("v.Message2","Button 2 Initalize");
	}
})