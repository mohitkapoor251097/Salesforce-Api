({
	handleSubmit : function(component, event, helper) {
		var firstName = component.get("v.firstName");
        var lastName = component.get("v.lastName");
        var birthDate = component.get("v.birthDate");
        var userEmail = component.get("v.userEmail");
        helper.helperMethod(component);
	}
})