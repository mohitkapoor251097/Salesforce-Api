({
	helperMethod : function(component) {
		var action = component.get("c.createContact");
        action.setParams({
            firstName : component.get("v.firstName"),
            lastName : component.get("v.lastName"),
            email : component.get("v.userEmail"),
            bDate : component.get("v.birthDate")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                alert('Contact Created Successfully !');
            }else{
                alert('Contact Not Created. Please Debug !');
            }
        });
        $A.enqueueAction(action);
	}
})