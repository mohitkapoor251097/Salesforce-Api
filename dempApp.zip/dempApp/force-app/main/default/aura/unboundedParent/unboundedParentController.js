({
	updateParentVar : function(component, event, helper) {
		  component.set("v.parentVar","Update Parent Attribute");
	}
})