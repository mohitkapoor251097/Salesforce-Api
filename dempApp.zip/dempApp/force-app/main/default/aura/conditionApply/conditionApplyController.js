({
	doAction : function(component, event, helper) {
		var inputCmp=component.find("inputCmp");
        var value=inputCmp.get("v.value");
        
        if(value>=50)
        {
            component.set("v.flag",true);
            component.set("v.flagHeaer",true);
        }
        else
        {
            component.set("v.flag",false);
            component.set("v.flagHeader",true);
        }
	}
})