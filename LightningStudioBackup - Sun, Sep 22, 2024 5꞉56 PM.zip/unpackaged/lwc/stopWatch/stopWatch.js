import { LightningElement } from 'lwc';

export default class StopWatch extends LightningElement {
   counter=0;
   timer='0'
   timerRef;
   storeTime=window.localStorage.getItem("startTimer")
    actionHandler(event){
        const {label}=event.target;
        if(label==='start'){
            this.setTimer();
        }
        else if(label==='stop'){
              window.clearInterval(this.timerRef);
             
        }
        else if(label==='Reset'){
            this.counter=0;
            this.timer='0';
            window.clearInterval(this.timerRef);
            window.localStorage.removeItem('startTimer');
        }
      
    }

    StartTimerHandler(){
        const startTime=new Date();
        window.localStorage.setItem('startTimer',startTime)
        return startTime;
    }

    setTimer(){
        const startTime=new Date(this.storeTime ||  this.StartTimerHandler())
       this.timerRef= window.setInterval(()=>{
            //call this every second
        //  this.counter=this.counter+1;
        // this.timer=this.secondToHms(this.counter);
        const secsDiff=new Date().getTime()- startTime.getTime();
        this.timer=this.secondToHms(Math.floor(secsDiff/1000));
        },1000)
    }

    secondToHms(d){
   d=Number(d);
   const h=Math.floor(d/3600)
   const m=Math.floor(d % 3600 / 60)
   const s=Math.floor(d% 3600 % 60)
   const hDisplay= h > 0 ? h + (h==1 ? "hour, " : " hours, ") : "";
   const mDisplay= m > 0 ? m + (m==1 ? "minute, " : " minutes, ") : "";
   const sDisplay= s > 0 ? s + (s==1 ? "second " : " seconds") : "";
   return hDisplay + mDisplay + sDisplay;


    }

    connectedCallback(){
        if(this.storeTime){
            this.setTimer();
        }
    }
}