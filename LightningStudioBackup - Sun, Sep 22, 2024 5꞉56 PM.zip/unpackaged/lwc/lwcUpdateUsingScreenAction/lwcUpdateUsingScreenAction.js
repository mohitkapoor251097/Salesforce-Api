import { LightningElement,api } from 'lwc';
import {CloseActionScreenEvent} from 'lightning/actions';
import { updateRecord } from 'lightning/uiRecordApi';
import ID_field from '@salesforce/schema/Account.Id';
import Phone_field from '@salesforce/schema/Account.Phone';
export default class LwcUpdateUsingScreenAction extends LightningElement {
@api recordId;
userInput;

handleChange(event){
 this.userInput=event.target.value;
}
handleClick(){
    const fields={};
    fields[ID_field.fieldApiName]=this.recordId;
    fields[Phone_field.fieldApiName]=this.userInput;
    const recordInput ={
      fields:fields
    };
    updateRecord(recordInput)
    .then(result=>{
        console.log(result);
    })
    .catch(error=>{
     console.log(error);
    })
  this.dispatchEvent(new CloseActionScreenEvent());
}
}