import { LightningElement, wire } from 'lwc';
import {getRelatedListsInfo} from 'lightning/uiRelatedListApi';
export default class GetRElatedListInfoDemo extends LightningElement {

    relatedData;
    @wire(getRelatedListsInfo,{
        parentObjectApiName:'Account',
       // recordTypeId optional

    })ListInfoHandler({data,error}){
        if(data){
            this.relatedData=data.relatedLists;
console.log(JSON.stringify(data));
        }
        else if(error){
            console.log(JSON.stringify(error));
        }
    }
}