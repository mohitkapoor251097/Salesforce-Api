import { LightningElement } from 'lwc';
import LightningConfim from 'lightning/confirm';
export default class LightningConfirmDEmo extends LightningElement {
    
 async confimHandler(){
  const result= await LightningConfim.open({
      message:"would you like to refresh the page"  ,
      label:"Are you sure ?",
     // variant:"headerless",  //use for hiding header
      theme:"success" //success info warning error  
    })
    console.log(result);
//onclick of ok button will true
    if(result){
         location.reload()
    }
}

}