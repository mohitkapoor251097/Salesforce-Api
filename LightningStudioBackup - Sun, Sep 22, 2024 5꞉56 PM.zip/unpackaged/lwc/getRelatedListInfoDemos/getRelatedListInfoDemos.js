import { LightningElement, wire } from 'lwc';
import {getRelatedListInfo} from 'lightning/uiRelatedListApi';
export default class GetRelatedListInfoDemos extends LightningElement {

  relatedListData;
@wire(getRelatedListInfo,{
    parentObjectApiName:'Account',
    relatedListId:'Contacts'
  //  recordTypeId  optional
})listInfoHandler({data,error}){
    if(data){
 this.relatedListData=data.displayColumns;
    }
    else if(error){
        
    }
}
}