import { LightningElement, api } from 'lwc';
import getAccountRating from '@salesforce/apex/RefreshController.getAccountRating';
import {registerRefreshHandler,unregisterRefreshHandler} from 'lightning/refresh';
export default class RefreshCustomView extends LightningElement {
  ratingValue;
    @api recordId;
    refreshHandlerId;
    connectedCallback(){
        this.refreshHandlerId=registerRefreshHandler(this,this.refreshHandler) //{contextElement,providerMethod}
        this.fetchRating();
    }

    disconnectedCallback(){
        unregisterRefreshHandler(this.refreshHandlerId);
    }
    refreshHandler(){
       return new Promise(resolve=>{
        this.fetchRating();
        resolve(true)
       })
    }

    fetchRating(){
        getAccountRating({"accountId":this.recordId}).then(response=>{
             console.log('my data'+JSON.stringify(response));
             this.ratingValue=response[0].Rating;
        }).catch(error=>{
            console.log(error);
        })
    }
}