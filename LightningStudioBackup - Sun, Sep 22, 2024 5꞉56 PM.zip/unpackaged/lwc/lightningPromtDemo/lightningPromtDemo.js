import { LightningElement } from 'lwc';
import LightningPrompt from 'lightning/prompt';
import LightningAlert from 'lightning/alert'
export default class LightningPromtDemo extends LightningElement {
//   async promptHandler(){
//    const result= await LightningPrompt.open({
//     message:"Please Enter Your Age"
//    })
//    console.log(result);
//     }


 promptHandler(){
       LightningPrompt.open({
     message:"Please Enter Your Age",
     label:'Check your voting',
     theme:"success", //sucess warning error info
     defaultValue:30
    })
    .then(result=>{
        console.log(result);
        if(result && Number(result)>18){
          console.log('Hurray you are elibile');
          this.alertHandler("Hurray you are elibile","Sucess!!","success")
        }
        else{
            console.log("not elibilble");
            this.alertHandler(" sorry Hurray you are not  elibile","Error!!","error")
        }
    }).catch(error=>{
        console.log(error);
    })
   
     }

     alertHandler(message,label,theme){
        LightningAlert.open({
           message:message,
           label:label,
           theme:theme
        })
     }
}