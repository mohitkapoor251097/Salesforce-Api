import { LightningElement,api } from 'lwc';

export default class GenerateOTP extends LightningElement {
@api otpLength=5;
generatedOtpValue="";
@api timeDuration=30; //seconds
disableButton=false;
showTimer=false;
timerText="";
    clickHandler(){
        //Math.random -grterter than 0 less than 1
        //Math.floor -final integer value
        //what is lenghth
        let otpArray=[];
        for(let i=0;i<this.otpLength;i++){
              otpArray.push(Math.floor(Math.random() * 10));
        }
        //convert array into string
        this.generatedOtpValue=otpArray.join("");
        this.disableButton=true;
        this.showTimer=true;
        let secondsRemaining=this.timeDuration;
       let countDownInterval= setInterval(()=>{
          secondsRemaining--;
          this.timerText=`To Generate next otp  wait for ${secondsRemaining} seconds`;
          if(secondsRemaining<=0){
            clearInterval(countDownInterval);
            this.disableButton=false;
            this.showTimer=false;
          }
        },1000)
    }
}