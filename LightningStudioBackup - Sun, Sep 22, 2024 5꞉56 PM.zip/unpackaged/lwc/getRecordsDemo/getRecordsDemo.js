import { LightningElement, wire } from 'lwc';
import ACCOUNT_NAME_FIELD from '@salesforce/schema/Account.Name';
import CONTACT_NAME_FIELD from '@salesforce/schema/Contact.Name';
import { getRecords } from 'lightning/uiRecordApi';
export default class GetRecordsDemo extends LightningElement {

    outputs;
    errors;

    @wire(getRecords,{
        records:[
            {
            recordIds:['0015i00000m9cr8AAA','0015i00000m9cr8AAA'],
            fields:[ACCOUNT_NAME_FIELD]
            },
            {
                recordIds:['0035i00004q5679AAA'],
                fields:[CONTACT_NAME_FIELD]
            }
        ]
    })outputFunction({data,error}){
        if(data){
            this.outputs=data;
            this.errors=null;
            console.log('data',data);
        }
        else if(error){
            this.errors=error;
            this.outputs=null;
            console.log('error',error);
        }
    }
}