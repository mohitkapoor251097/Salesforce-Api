export function exportCSVFile(headers,totalData,filesTitle){
    if(!totalData || !totalData.length){
        return null
    }
   const jsonObject= JSON.stringify(totalData);
   const result=convertToCSV(jsonObject,headers);
   if(result===null) return 
   const blob=new Blob([result])
  // console.log('blob'+JSON.parse(blob));
   //console.log('blob'+JSON.stringify(blob));
   const exportedFilename=filesTitle ? filesTitle+'.csv' :  'export.csv';

   const link=document.createElement("a")
   if(link.download !== undefined){
    const url=URL.createObjectURL(blob);
    console.log('url'+url);
    link.setAttribute("href",url)
    link.setAttribute("download",exportedFilename)
    link.style.visibility='hidden'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
   }

}
function convertToCSV(objArray, headers) {
    const columDelimiter=','
    const lineDelimiter='\r\n'
    const actualHeaderKey=Object.keys(headers)
    const headerToShow=Object.values(headers)
      let str=''
      str+=headerToShow.join(columDelimiter)
      str+=lineDelimiter
      const data=typeof objArray !=='object' ? JSON.parse(objArray) : objArray;

      data.forEach(obj=>{
        let line=''
        actualHeaderKey.forEach(key=>{
            if(line!=''){
                line+=columDelimiter
            }
            line+=obj[key]
        })
        str+=line+lineDelimiter
      })
      console.log("str"+str);
      return str;

}