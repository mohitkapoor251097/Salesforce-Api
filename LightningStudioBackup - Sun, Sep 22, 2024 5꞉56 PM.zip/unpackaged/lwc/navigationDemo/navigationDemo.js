import { LightningElement } from 'lwc';
import {NavigationMixin} from 'lightning/navigation';
import {encodeDefaultFieldValues} from 'lightning/pageReferenceUtils';
export default class NavigationDemo extends NavigationMixin(LightningElement) {


    // handleClickNavigation(){
    //        //navigate to tab mean app page
    //        this[NavigationMixin.Navigate]({
    //         type:'standard__navItemPage',
    //         attributes:{
    //             apiName:'Bike_Card',
    //         }
    //        })
    // }


//     handleClickNavigation(){
//         //navigate to object Home page
//         this[NavigationMixin.Navigate]({
//          type:'standard__objectPage',
//          attributes:{
//             objectApiName:'Account',
//             actionName:'home'
//          },
//         })
//  }


// handleClickNavigation(){
//     //navigate to accountobject recently filter
//     this[NavigationMixin.Navigate]({
//      type:'standard__objectPage',
//      attributes:{
//         objectApiName:'Account',
//         actionName:'list'
//      },
//      state:{
//         filterName:'00B5h00000RJunUEAT',                //Recent bhi likh skte ha
//      }
//     })
// }


// handleClickNavigation(){
//     //navigate tocreate new record
//     this[NavigationMixin.Navigate]({
//      type:'standard__objectPage',
//      attributes:{
//         objectApiName:'Account',
//         actionName:'new'
//      },
    
//     })
// }



// handleClickNavigation(){
//     //navigate to view record
//     this[NavigationMixin.Navigate]({
//      type:'standard__recordPage',
//      attributes:{
//         recordId:'0015h00001AnfOnAAJ',
//         objectApiName:'Account',
//         actionName:'view'
//      },
    
//     })
// }



// handleClickNavigation(){
//     //navigate to show object record in edit mode
//     this[NavigationMixin.Navigate]({
//      type:'standard__recordPage',
//      attributes:{
//         recordId:'0015h00001AnfOnAAJ',
//         objectApiName:'Account',
//         actionName:'edit'
//      },
    
//     })
// }

// handleClickNavigation(){
//     //navigate to another site Url
//     this[NavigationMixin.Navigate]({
//      type:'standard__webPage',
//      attributes:{
//         url:'https://ewaybillgst.gov.in/'
//      },
    
//     })
// }


handleClickNavigation(){
    //navigate to more file record
    this[NavigationMixin.Navigate]({
     type:'standard__namedPage',
     attributes:{
        pageName:'filePreview',

     },
    state:{
        recordIds:'0695h00000HQyeAAAT,0695h00000GHrPyAAL,0695h00000GIf6iAAD',
        selectedRecordId:'0695h00000GIf6iAAD'
    }
    })
}

// let pageRef={
//     type:"standrad__namedPage",
//     attributes:{
//         pageName:"home"
//     }

// };
// this[NavigationMixin.Navigate](pageRef);


createNewDEault(){
    const defaultValues=encodeDefaultFieldValues({
        Industry:"Energy",
        Rating:'Hot'
    });

    let pageREf={
        type:'standard__objectPage',
             attributes:{
                objectApiName:'Account',
                actionName:'new'
             },
             state:{
                defaultFieldValues:defaultValues
             }
    }
    this[NavigationMixin.Navigate](pageREf);
}
}