import { LightningElement, api } from "lwc";

export default class Zchild extends LightningElement {
  @api
  checkValidity() {
    let isSelfValidated = false;
    isSelfValidated = [
      ...this.template.querySelectorAll("lightning-input")
    ].reduce((validSoFar, inputField) => {
      inputField.reportValidity();
      return validSoFar && inputField.checkValidity();
    }, true);
    return isSelfValidated;
  }
  handleChange() {}
}