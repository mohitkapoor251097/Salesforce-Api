/*********************************************************************
# File....................: osGscClassification
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............: 02/03/2025
# Last Modified by........: Coforge
# Last Modified Date......: 
# Description.............: Component is used to display the Government Security Classification
# VF Page.................: NA
# VF Component............: NA
# L Comp..................: NA
# Handler Class...........: NA
# Test Class..............: NA
# Change Log..............: NA
#Trigger Name ............: Case

**********************************************************************/
import { LightningElement, api, wire,track } from 'lwc';
import { getRecord, updateRecord } from 'lightning/uiRecordApi';
import currentUserId from '@salesforce/user/Id';
import getQueueId from '@salesforce/apex/OSRestrictedGscListController.getQueueId';
import {GSC_CONSTANTS} from './osGscClassificationConstants';

export default class CurrentRecordSuccessfull extends LightningElement {
    modalContainer = false;
    @api recordId;  // To pass curent record id where it placed.
    @api title; // title for GSC ribbion
    @api objectName; // To pass Object Api Name where it placed.
    @api fields; // To Pass Object fields Api Name.
    currentRecord = {}; // stroe current record 
    previousRecord = null; // store previous record
    dataRecord; // store current record
    gscClassificationIsNull=false; // check if GSC is none or null.
    gscClassificationIsNoGsc = false; // check if GSC value is No GSC marking.
    gscClassificationValue //  store GSC value.
    gscClassificationIsSelecected = false; // check for GSC value is selected or not.
    gscClassificationIsGsc = false; // check if GSC field have any GSC value.
    scClearedQueueId; // Store SC Cleared Queue Id.
    scAdditionalQueueId; //Store SC Additional Queue Id.
    errorMsg; // Store eeror if any
    lightningSpinner; // check for spinner
    gscConfirmationModalText = GSC_CONSTANTS.GSC_CONFIRMATION_MODAL_TEXT; // GSC confirmation modal text stored in utils.js
    gscAggregatedModaltext = GSC_CONSTANTS.GSC_AGGREGATE_MODAL_TEXT; // GSC aagregated modal text stored in utils.js
    @track fieldMappings = [];

    // get GSC flag for ribbon
    get gscClassificationFlag(){
        if(this.gscClassificationValue){
            return this.dataRecord.fields.Government_Security_Classification__c.value !== GSC_CONSTANTS.NO_GSC_VALUE? this.dataRecord.fields.Government_Security_Classification__c.value:'';
        }
        
    }
    
    // Method to close the modal
    confirmationModalForGSC(event) {
        const fields = {};
        // If user has selected "No GSC marking" or the value is null and then clicks on the "No" button
        if(event.target.outerText === GSC_CONSTANTS.AGGREGATE_CLOSE){

            this.modalContainer = false; // close modal
            this.lightningSpinner = false;// close spinner
        }else if ( event.target.outerText === GSC_CONSTANTS.AGGREGATE_NO ) {

            // Close the modal when "No GSC marking" is selected and save "No GSC marking" value.
            this.closeModalAndUpdateGSC();
        } 
        // Check if the GSC value is null or "No GSC marking" and the classification is also null
        else if ( (!this.dataRecord.fields.Government_Security_Classification__c.value && this.gscClassificationIsNull ) || 
            ( this.dataRecord.fields.Government_Security_Classification__c.value == GSC_CONSTANTS.NO_GSC_VALUE && this.gscClassificationIsNull )
        ) {
            // Set flag to indicate "No GSC marking" selection or GSC is null 
            this.gscClassificationIsNoGsc = true;
        } 
       
    }

    // close modal and save GSC as No GSC marking
    closeModalAndUpdateGSC(){
        const fields = {};
        fields[GSC_CONSTANTS.AGGRETAGED_FIELD_API_NAME] = '';
        
        if(this.gscClassificationValue){
            
            fields[GSC_CONSTANTS.GSC_FIELD_API_NAME] = this.gscClassificationValue;
            this.updateRecordWithGSC(fields);
        }else if(!this.gscClassificationValue){
            this.errorMsg = GSC_CONSTANTS.GSC_BLANK_ERROR_MSG;
        }
        
    }

    // Updates the Government Security Classification (GSC) with the selected value
    updateGovernmentSecurityClassification() {
        
        this.closeModalAndUpdateGSC();
    }

    // Closes the modal and saves the Aggregate value for GSC
    closeAggregatedGscModalAction(event) {
        // Ensure a GSC classification value is selected before proceeding
        if (this.gscClassificationValue) {
            const fields = {};

            // Set the selected GSC classification
            fields[GSC_CONSTANTS.GSC_FIELD_API_NAME] = this.gscClassificationValue;

            // Store the aggregate value based on the button text clicked
            fields[GSC_CONSTANTS.AGGRETAGED_FIELD_API_NAME] = event.target.outerText;

            // Update the record with the new GSC values
            this.updateRecordWithGSC(fields);
        }
    }

    // On chnage of GSC piclist get selected value
    changeGovernmentSecurityClassification(event){
        this.gscClassificationValue = event.target.value;
    }
    
    // Update and save the GSC (Government Security Classification) value
    updateRecordWithGSC(fields){
       
        const gscPopup = false;// Hide the GSC popup after selection

        // Assign required field values
        fields[GSC_CONSTANTS.GSC_SHOW_POPUP_FIELD_API_NAME] =gscPopup;
        fields[GSC_CONSTANTS.ID_FIELD_API_NAME] = this.recordId;
        
        // Assign owner as SC Cleared Queue based on the selected GSC classification, if GSC is selected as Official Senesitive.
        if(this.gscClassificationValue  === GSC_CONSTANTS.GSC_OFFICIAL_SENSITIVE){
            fields[GSC_CONSTANTS.OWNERID_FIELD_API_NAME] = this.scClearedQueueId;
        }
        // Assign owner as SC Additional Queue based on the selected GSC classification, if GSC is selected as Holding O or Holding OS.
        else if(this.gscClassificationValue  === GSC_CONSTANTS.GSC_HOLDING_O || this.gscClassificationValue  === GSC_CONSTANTS.GSC_HOLDING_OS){
            fields[GSC_CONSTANTS.OWNERID_FIELD_API_NAME] = this.scAdditionalQueueId;
        }
        // Otherwise, set owner as Current User 
        else{
            fields[GSC_CONSTANTS.OWNERID_FIELD_API_NAME] = currentUserId;
        }
       
        const recordInput = {
            fields:fields
        }
        this.lightningSpinner = true;// Show loading spinner while updating
        // update record 
        updateRecord(recordInput).then((record) => {
        
            this.modalContainer = false; // close modal
            this.lightningSpinner = false;// close spinner
        }).catch((error) => {
            this.modalContainer = true; // Keep modal open on error
            this.lightningSpinner = false; // close spinner if error occur.
            this.errorMsg = this.getErrorMessage(error); // parse error body and get error message through getErrorMessage
            
        });
        
    }

    // error method to parse error it will return error message 
    getErrorMessage(error) {
        if (error.body) {
            // Check if there are field validation errors
            if (error.body.output && error.body.output.errors && error.body.output.errors.length > 0) {
                return error.body.output.errors[0].message; // Get first error message
            }
            // Default error message
            return error.body.message || 'An unexpected error occurred.';
        }
        return 'An unknown error occurred.';
    }

    // connected callback to store the values from the meta file
    connectedCallback() {
        if (this.objectName && this.fields) {
            this.fieldMappings = this.fields.split(',').map(field => ({
                fieldApiName: field.trim(),
                objectApiName: this.objectName
            }));
        }

    }
    
    // wire method to get GSC, and show GSC confirmation modal and aggregated modal
    @wire(getRecord, { recordId: '$recordId', fields: '$fieldMappings' })
    wiredRecord({ error, data }) {
        if (data) {            
            this.modalContainer = false; // close modal
            this.errorMsg = null;
            this.dataRecord = data; // assign data to this global varible to get reuse.
            this.gscClassificationValue = this.dataRecord.fields.Government_Security_Classification__c.value; // assign Government Security Classification (GSC) to variable
            
            // check if record is getting edit and have previous version of record in previousRecord
            if (this.previousRecord) {
                // Check if record data has changed with fields (Aggregated_Sensitive_Material__c, GSC_show_popup__c, Government_Security_Classification__c)
                if (this.isRecordChanged(data.fields)&&data.fields.GSC_show_popup__c.value) {
                    this.modalContainer = true; 
                }
                // Otherwise close modal
                else{
                    this.modalContainer = false;
                }
            }

            // if GSC (Government Security Classification) is null or No GSC marking 
            if(data.fields.GSC_show_popup__c.value && ( data.fields.Government_Security_Classification__c?.value === GSC_CONSTANTS.NO_GSC_VALUE || 
                data.fields.Government_Security_Classification__c?.value == null ) ){

                this.modalContainer = true;
                this.gscClassificationIsNull = true; // Show GSC confirm modal
                this.gscClassificationIsGsc = false; // hide GSC Selection modal 
            } 
            // if user is updating GSC and it's changed & GSC value is not "No GSC marking"
            else if((this.fieldChange(data.fields,GSC_CONSTANTS.GSC_FIELD_API_NAME)   || 
                data.fields.Aggregated_Sensitive_Material__c?.value == null || data.fields.GSC_show_popup__c.value)  && 
                data.fields.Government_Security_Classification__c?.value !== GSC_CONSTANTS.NO_GSC_VALUE && 
                data.fields.Government_Security_Classification__c?.value !== null ){

                this.modalContainer = true;
                this.gscClassificationIsNull = false; // hide GSC confimation modal
                this.gscClassificationIsNoGsc = false; // hide GSC selection modal
                this.gscClassificationIsGsc = true;// show GSC modal and ask for aggregated "Yes" Or "No"
                            }
            else {
                this.modalContainer = false;            
            }
            // Update the current and previous record values
            this.previousRecord = { ...data.fields }; // Make a shallow copy
            this.currentRecord = data.fields;
        } else if (error) {
            console.error('Error fetching record:', error);
        }
    }

    // wire to get SC Cleared Queue id
    @wire(getQueueId, { queueName: GSC_CONSTANTS.QUEUE_SC_CLEARED })
    scClereadQueueName({ data, error }) {
        if (data) {
            this.scClearedQueueId = data; // SC Cleared Queue Id.
            
        } else if (error) {
            console.error('Error fetching Queue ID:', error);
        }
    }

    // wire to get SC Additional Queue id
    @wire(getQueueId, { queueName: GSC_CONSTANTS.QUEUE_SC_ADDITIONAL })
    scAdditionalQueueName({ data, error }) {
        if (data) {
            this.scAdditionalQueueId = data; // SC Additional Queue Id.
           
        } else if (error) {
            console.error('Error fetching Queue ID:', error);
        }
    }
 
    // Check of GSC field change based on previous and new value if field value is change will return true
    fieldChange(newFields,fieldApiName){
        const previous = this.previousRecord || {};
         
        return (
            previous[fieldApiName]?.value !== newFields[fieldApiName]?.value && previous[fieldApiName] && newFields[fieldApiName]
        );
    }


    // Check for field change based on previous and new value
    isRecordChanged(newFields) {
        const previous = this.previousRecord || {};
        return (
            previous.Aggregated_Sensitive_Material__c?.value !== newFields.Aggregated_Sensitive_Material__c?.value ||
            previous.GSC_show_popup__c?.value !== newFields.GSC_show_popup__c?.value || 
            previous.Government_Security_Classification__c?.value !== newFields.Government_Security_Classification__c?.value 
        );
    }

}