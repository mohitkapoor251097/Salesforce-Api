import {LightningElement,api} from 'lwc';
import getLicenceContactOrgRoles from '@salesforce/apex/Licensing_Utility.getLicenceContactOrgRoles';
//import getLicenceContactOrgRoles from '@salesforce/apex/LicenceUtil.getLicenceContactOrgRoles';// W-002904: Replacing Licensing_Utility with LicenceUtil
import LicensingComLabelIndividualLicensee from '@salesforce/label/c.LicensingComLabelIndividualLicensee';
import LicensingComLabelSoleTraderMe from '@salesforce/label/c.LicensingComLabelSoleTraderMe';
import LicensingComLabelSelectLicenceContact from '@salesforce/label/c.LicensingComLabelSelectLicenceContact';
import GenericLicensingWebFormUrl from '@salesforce/label/c.GenericLicensingWebFormUrl'; //< ADO15407>

export default class LicensingComLicenceContactScreen extends LightningElement {
    
    gridSelected; // Grid selected by user        
    selectGridValidation; // string variable to display validation error
    selectedLicensee; //W-002782 : It is the selected licensee(BA) from the Licensee Selection Screen for 'An organisation' and 'Another sole trader or partnership'
    @api licensee; // W-002782 : Fetches licensee data from Licensee Selection Screen
    licenseContactList; //W-002792 : It displayes Licence Contact list
    licenseContactCount=0; //W-002792 : It displays count of Licence Contacts
    @api licencefor;
    licenceContactCardsHeader; //W-002791 : It displays licence Contact Cards Header
    isEditDisabled = true;//W-002799
    @api flagforchangelicencecontact; //W-002839
    Webformlabelvalue=GenericLicensingWebFormUrl + 'SlepWebForm'; // ADO15407

    /*       
    * @author      : Coforge
    * @date        : 07/10/2022
    * @description : W-002792 : Method called when component is loaded to bring data for licence contact selection screen
    * @return      : None
    * @param       : None
    */   
    connectedCallback() {
    try{
        this.licenceContactCardsHeader = LicensingComLabelSelectLicenceContact; //W-002791 : This variable is used to display licence Contact Cards Header on UI
        if(this.licensee != null && this.licensee!=undefined){
            getLicenceContactOrgRoles({ selectedLicenseeId: this.licensee.Id })
                .then((result) => {
                        this.licenseContactList = result;
                        this.licenseContactCount = result.length;
                })
                .catch((error) => {
                    window.location.href='/apex/licensingcomerror';
                });
        }
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 10/10/2022
    * @description : Method called when select Licensee button is clicked for licensee selection screen - W-002774
    * @return      : None
    * @param       : event
    */
    selectedGrid(event){
    try{
        this.template.querySelector('[data-id="invalidRecordMessage"]').innerHTML =''; //W-002870 : Removing invalid record edit message if it exists
        var scrollOptions = {
            left: 0,
             top: document.body.scrollHeight, /* W-002883 : LPE Accessibility issue fixing here */ 
            behavior: 'smooth'
        }
        window.scrollTo(scrollOptions);
        var gridName = event.target.value;
        /*Selected card record id is fetched and styling class is added/removed to card */    
        for(let i=0; i<this.licenseContactList.length; i++){
            if(this.licenseContactList[i].Id == gridName){
                this.template.querySelector('[data-id="' +gridName+ '"]').classList.add('gridBackground');
                this.gridSelected = this.licenseContactList[i];
                this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
                this.selectGridValidation = "";
            }
            else{
                this.template.querySelector('[data-id="' +this.licenseContactList[i].Id+ '"]').classList.remove('gridBackground');
            }
        }    
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }
    
    /*       
    * @author      : Coforge
    * @date        : 10/10/2022
    * @description : Method called when next button is clicked
    * @return      : None
    * @param       : event
    */
    goToPaymentContactScreen(event){
    try{
        if(this.gridSelected==null){
            this.template.querySelector('[data-id="invalidRecordMessage"]').innerHTML =''; //W-002880 : Removing invalid record edit message if it exists
            /*On click of next without selecting card we are displaying error on top of grids  */ 
            this.template.querySelector('[data-id="errorMessage"]').classList.add('error');
            this.selectGridValidation = "Licence contact selection is required"; // W-002794 : Adding error message
            this.scrollToTop(); // W-002799 : To scroll to top 
        }
        else{
            //W-002839 Start
            if(this.flagforchangelicencecontact==true){
            this.dispatchEvent(new CustomEvent("openvalidationscreen",{ 
                detail:{
                    selectedContact : this.gridSelected 
                }
                }));
            }
            // W-002824 : Event created to open Payment contact screen 
            // START -W-002827 Sending Licence Contact on selection, to Payment COntact selection Screen 
            else{
            this.dispatchEvent(new CustomEvent("openpaymentcontactscreen",{ // START -W-002827 Sending Licence Contact on selection, to Payment COntact selection Screen 
            detail:{
                selectedContact : this.gridSelected 
            }// END W-002827
            }));
        }
        //W-002839 End
        }
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 27/10/2022
    * @description : W-002788/W-002787 : To go back to landing page for 'Me' and 'Sole trader in my name'  
    * @return      : None
    * @param       : event
    */
    goToPreviousScreen(event){
    try{
        if((this.licencefor == LicensingComLabelIndividualLicensee) || (this.licencefor == LicensingComLabelSoleTraderMe)){
            history.back();
        }
        else{
            // Dispatches the event, to navigate back to Licence Contact Screen
            this.dispatchEvent(new CustomEvent("openlicenseescreen"));
        }
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 02/11/2022
    * @description : W-002795 : Method called on click of 'Create new contact','Edit details' button
    * @return      : None
    * @param       : event
    */
    openLicenceContactPopup(event){
    try{
        this.template.querySelector('[data-id="invalidRecordMessage"]').innerHTML =''; //W-002870 : Removing invalid record edit message if it exists
        // W-002806 START Reset the existing grid value and remove error
        this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
        this.selectGridValidation = "";
        this.gridSelected = null;
        var isValidated = true; //W-002799 : if true it opens popup
        // W-002806 END
        // W-002798 : To de-select all grids on click of Create/Edit button and setting the selected grid data to 'gridSelected'
        var gridName = event.target.value;
        if(this.licenseContactList!= undefined){ // W-002823 START : Check if the list is undefined
        for(let i=0; i<this.licenseContactList.length; i++){
            if(this.licenseContactList[i].Id == gridName){
                this.gridSelected = this.licenseContactList[i];
            }
            // Defect Fix
            this.template.querySelector('[data-id="' +this.licenseContactList[i].Id+ '"]').classList.remove('gridBackground');
            
        }    
    }// W-2823 END
        // W-002799 Start : For edit case, validating the selected record
        if(event.target.name == 'Edit details' && this.gridSelected!=undefined && this.gridSelected!=null ){
            var orgRoleTypeList = (this.gridSelected.Types__c).split(';');
            // When user tries to edit licence contact org role that is linked with other application also (i.e. MID,VSP etc) as well apart from Licence contact or payment contact 
            if(!(
                ((this.gridSelected.Types__c == 'Licence Contact') && (orgRoleTypeList.length==1)) || 
                (orgRoleTypeList.includes('Licence Contact')  && orgRoleTypeList.includes('Licence Bill/Account Contact') && orgRoleTypeList.length==2)
                )){
                
                // To show the validation message on the UI
                this.setInvalidRecordMessage();    
                
                isValidated = false;

                this.gridSelected = null;
                this.scrollToTop(); // To scroll to top
                //this.template.querySelector('[data-id="' +gridName+ '"]').classList.add('gridBackground');
                //this.template.querySelector('[data-id="' +gridName+ '"]').disabled = true;
            }
        }
        // W-002799 End

        // W-002799 : Dispatching event to open popup only when valid record is selected for editing 
        if(isValidated){
            // W-002798 Start : Passing the Licence Contact data that is selected for edit
            // For create case, null data is passed
            this.dispatchEvent(new CustomEvent("openlicencecontactpopup",{
                // W-002828 Start
                detail:{
                    selectedContact : this.gridSelected,
                    contactType :'Licence Contact' // Passing the Contact's type
                }
                // W-002828 End
            }));
            // W-002798 End
            
            // Making grid selected as null, as now the grid selected will be the one whose popup has been open, and it will be handled
            // on VF side
            this.gridSelected = null;
        }
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 02/11/2022
    * @description : W-002799 : Method called to scroll tp the top of the page when any error occurs
    * @return      : None
    * @param       : None
    */
    scrollToTop(){
    try{
        var scrollOptions = {
            left: 0,
            top: 580,
            behavior: 'smooth'
        }
        window.scrollTo(scrollOptions);
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 29/11/2022
    * @description : W-002870: Method called when an invalid record is edited. It sets the error message on the UI
    * @return      : None
    * @param       : None
    */
    setInvalidRecordMessage(){
    try{    
        // Adding error message on UI
        this.template.querySelector('[data-id="errorMessage"]').classList.add('error');

        // Appending the error message on the UI section with data-id as invalidRecordMessage
        var pTagFirst = document.createElement('span');
        pTagFirst.innerHTML = "This contact record is possibly associated with other licensing products. Please contact ";
        this.template.querySelector('[data-id="invalidRecordMessage"]').appendChild(pTagFirst);        

        var aTag = document.createElement('a');
        aTag.setAttribute('href',"https://ofcomlive.my.salesforce-sites.com/formentry/SlepWebForm");
        aTag.setAttribute('target',"_blank");
        aTag.innerHTML = "spectrum licensing";
        this.template.querySelector('[data-id="invalidRecordMessage"]').appendChild(aTag);

        var pTagSecond = document.createElement('span');
        pTagSecond.innerHTML = " to update these details.";
        this.template.querySelector('[data-id="invalidRecordMessage"]').appendChild(pTagSecond);
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }
      /*       
    * @author      : Coforge
    * @date        : 11/01/2023
    * @description : W-002883 : LPE Accessibility issue fixing  here
    * @return      : None
    * @param       : None
    */
    cancellink(){
    try{
        window.location.href='/apex/LicensingComDashboard';   
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }      
        
    } 
}