/*********************************************************************
# File....................: picklistValue.js
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............: 20/11/2021
# Last Modified by........: Coforge
# Last Modified Date......: 
# Description.............: Used as a controller class of picklistValue component. It is used as sub-component of
                            multiSelectPicklist.
# Change Log..............: NA
**********************************************************************/

import { LightningElement, api } from 'lwc';

const SELECTED = 'Selected';

export default class OsPicklistValue extends LightningElement {

    @api selected = false;
    @api label;
    @api value;

    selectedLabel = SELECTED;

    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This method will execute on selection of any row in multiSelectPicklist.
     * @params      : NA
     * @return      : NA
     */
    handleSelect(event) {
        if(this.selected){
            this.selected = false;
        } else {
            this.selected = true;
        }
    }
}