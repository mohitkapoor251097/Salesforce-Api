/*       
    * @author      : Coforge
    * @date        : 16/04/2024
    * @lastModified  12 July 2024
    * @description : ADO-22355 : Visibility on IR Projects Contacts
                     ADO-34526 : Pagination Functionality for Specific IR Project Contact Section
    */
import { LightningElement,api, track } from 'lwc';
export default class IRProjectScreen extends LightningElement {
    @api title;
    @api irprojectlist;
    irProjects = [];
    casePrefix='500';
    orgRolePrefix='a21';
    irProjectOrgCount;
   /*ADO-34526 Sprint-8 Part*/
    @track isPagination = false;
    finalProjectlist;
    paginationprojectlist = [];
    
    /*       
    * @author      : Coforge
    * @date        : 19/04/2024
    * @description : ADO-22355 : Visibility on IR Projects Contacts
    */
    connectedCallback() {
        var projectList = JSON.parse(JSON.stringify(this.irprojectlist));
        for (var key in projectList) {
            let projectRec = { key: key};     // Initialize projectRec with the key as a third property
            projectList[key].forEach(sObjectRec => {
                if (sObjectRec.Id.startsWith(this.casePrefix)) {
                    projectRec["caseRec"] = sObjectRec;
                } else if (sObjectRec.Id.startsWith(this.orgRolePrefix)) {
                    projectRec["orgRole"] = sObjectRec;
                }
            });
            this.irProjects.push(projectRec); 
        }
        this.irProjectOrgCount = this.irProjects.length;
        this.paginationprojectlist=JSON.parse(JSON.stringify(this.irProjects));
        this.isPagination = true;   // ADO-34526 Sprint-8 part
    }
     /*       
    * @author      : Coforge
    * @date        : 12/07/2024
    * @description : ADO-34526 : Pagination Functionality for Specific IR Project Contact Section
    */
    currentProjectList(event) {
        this.finalProjectlist = [...event.detail.records];
    }
}