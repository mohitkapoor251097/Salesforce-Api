import {LightningElement,api, wire} from 'lwc'; // ADO20971 change
import LicensingComLabelAnotherSoleTrader from '@salesforce/label/c.LicensingComLabelAnotherSoleTrader';
import LicensingComLabelOrganisationOrSoleTrader from '@salesforce/label/c.LicensingComLabelOrganisationOrSoleTrader';
import getCommunityURL from '@salesforce/apex/Licensing_Utility.getCommunityURL';
import LicensingComLabelIndividualLicensee from '@salesforce/label/c.LicensingComLabelIndividualLicensee';
import LicensingComLabelSoleTraderMe from '@salesforce/label/c.LicensingComLabelSoleTraderMe';
import LicensingComLabelSelectLicensee from '@salesforce/label/c.LicensingComLabelSelectLicensee';
import GenericLicensingWebFormUrl from '@salesforce/label/c.GenericLicensingWebFormUrl'; //< ADO15407>
import licenseeOrgRoleListPagination from '@salesforce/apex/Licensing_UtilityExtension.getlicenseeOrgRolePagination'; // ADO20971 change

export default class LicensingComLicenseeSelectionScreen extends LightningElement {
    
        Webformlabelvalue=GenericLicensingWebFormUrl + 'SlepWebForm'; //< ADO15407>
    showSpinner=true; // To show spinner until data is fetched
	@api licenseeOrgRoleJSONList; // Its value is fetched from lightning out component
    gridSelected; // Grid selected by user        
    licenseeList; // Licensee org role list displayed on the UI
    licenseeCount; // Count of org role displayed on the UI
    selectGridValidation; // string variable to display validation error
    @api licenceFor; //W-002786 : Its value is fetched from lightning out component, it is the option selected for 'Who is the licence for'
    searchOrCreateLicensee; // W-002786 : It displays Search/Create licensee button name for 'An organisation' and 'Another sole trader or partnership' respectively
                            // based on 'Who is the licence for' selection
    openLicenseContactScreen; //W-002782 : It is used to show/hide the content of Licensee Selection and Licence Contact Selection screens
    selectedLicensee; //W-002782 : It is the selected licensee(BA) from the Licensee Selection Screen for 'An organisation' and 'Another sole trader or partnership'
    licenseeCardsHeader; //W-002791 : It displays licensee Cards Header
    openPaymentContactScreen; //W-002795 : It is used to show/hide the content of Payment Contact screen
    selectedLicenseContact; //W-002795 : It is the selected license contact from the License contact Selection Screen for 'An organisation' and 'Another sole trader or partnership'
    openLicenseeScreen; //W-002795 : It is used to show/hide the content of Licensee selection screen
    @api currentAeroScreen; //W-002829 : Current screen that is selected from breadcrumb
    @api selectedLicenseeRecord; //W-002829 : selected Licensee Id on Licensee selection screen which is used to display content based on Breadcrumb selection
    @api selectedLicenseContactRecord; //W-002829 : selected license contact record on Licence Contact selection screen which is used to display content based on Breadcrumb selection
    openContactValidationScreen; //W-002828 : It is used to show/hide the content of Contact Validation screen
    selectedPaymentContact; //W-002828 : It is the selected payment contact
    selectedLicenseeOrgRole;//W-002838
    flagforchangelicencecontact = false; //W-002839

    /* ADO20971 changes start */
    orgRoleList;

    /*       
    * @author      : Coforge
    * @date        : Jan 11, 2024
    * @description : Wire method called after the connectedcallback to fetch the list of org roles
    * @return      : None
    * @param       : None
    */
    @wire(licenseeOrgRoleListPagination, {licenseeOpt : "$licenceFor", lwcName : "licensingComLicenseeSelectionScreen", pageReferenceName: "Apply"})
    wiredOrgRoles({error, data}){
        if(data){
            if(this.licenceFor != LicensingComLabelIndividualLicensee && this.licenceFor != LicensingComLabelSoleTraderMe){
                this.orgRoleList = data;
                this.licenseeCount = data.length;
            }
            this.showSpinner = false; // To hide spinner
        }
        if(error){
            console.log('In wiredOrgRoles::'+ error);
            console.log(JSON.stringify(error));
            window.location.href='/apex/licensingcomerror';
            this.showSpinner = false; // To hide spinner
        }
    }

    /*       
    * @author      : Coforge
    * @date        : Jan 11, 2024
    * @description : Method called on onupdate event of paginationcmp to set the list of org role for current page
    * @return      : None
    * @param       : event
    */
    currentPageLicenseeList(event) {
        this.licenseeList = [...event.detail.records];
        this.gridSelected = null; // Reset the selected grid
    }
    /* ADO20971 changes end */
    /*       
    * @author      : Coforge
    * @date        : 07/10/2022
    * @description : Method called when component is loaded to bring data for licensee selection screen - W-002771
    * @return      : None
    * @param       : None
    */   
    connectedCallback() {
            try{    
        // W-002788/W-002787 : Adding condition to Show Licence Contact Selection Screen when 'Me'/ 'A sole trader in my name' is selected
        if((this.licenceFor == LicensingComLabelIndividualLicensee )|| (this.licenceFor == LicensingComLabelSoleTraderMe)){
            //W-002820 START Logged-in user will automatically be assigned the licence contact role for this licensee. Go straight to Licence contact selection screen for licensee = ‘Sole trader in my name'
            if(this.licenseeOrgRoleJSONList!=undefined && this.licenseeOrgRoleJSONList!=null && (JSON.parse(this.licenseeOrgRoleJSONList)).Licensee_or_Organisation__r != null){
                // W-002838 : Passing selected licensee org role to selectedLicenseeOrgRole
                this.selectedLicenseeOrgRole = this.licenseeOrgRoleJSONList;
                this.selectedLicensee = (JSON.parse(this.licenseeOrgRoleJSONList)).Licensee_or_Organisation__r; // parse the licensee org role JSON into licensee List
            }//W-002820 END Logged-in user will automatically be assigned the licence contact role for this licensee. Go straight to Licence contact selection screen for licensee = ‘Sole trader in my name'
            // W-002829 Start : If Payment Contact breadrumb link is clicked in case of "Me" or "Sole trader in my name"
            if(this.currentAeroScreen =='Payment Contact'){  
                // Setting the selected licence contact from vf to LWC variable so that it is passed when next screen is rendered
                this.selectedLicenseContact = this.selectedLicenseContactRecord;
                this.openPaymentContactScreen = true;     
            }
            // Otherwise, by default Licence Contact screen is shown
            else{
                this.openLicenseContactScreen = true;
            }
            // W-002829 End
        }
        // W-002829 Start : This block will be executed when breadrumb links are clicked in case of 'An organisation' or 'Another sole trader or partnership'
        else if((this.selectedLicenseeRecord!=null && this.selectedLicenseeRecord!=undefined && this.selectedLicenseeRecord!='')|| 
            (this.selectedLicenseContactRecord!=null && this.selectedLicenseContactRecord!=undefined && this.selectedLicenseContactRecord!='')){
            
                // If there is a selected Licensee record, then setting its value in LWC variables, so that they are passed to grid screens when
            // they are rendered
            if(this.selectedLicenseeRecord!=null && this.selectedLicenseeRecord!=undefined && this.selectedLicenseeRecord!='') {  
                this.selectedLicensee = (JSON.parse(this.selectedLicenseeRecord)).Licensee_or_Organisation__r;
                this.selectedLicenseeOrgRole = this.selectedLicenseeRecord;
            }
            // If there is a selected Licence contact record, then setting its value in LWC variables, so that they are passed to grid screens when
            // they are rendered
            if(this.selectedLicenseContactRecord!=null && this.selectedLicenseContactRecord!=undefined && this.selectedLicenseContactRecord!=''){
                this.selectedLicenseContact = this.selectedLicenseContactRecord;
            }
            // Rendering Licence Contact screen if its breadcrumb link is clicked
            if(this.currentAeroScreen =='Licence Contact'){
                this.openLicenseContactScreen = true;
            }
            // Rendering Payment Contact screen if its breadcrumb link is clicked
            else if(this.currentAeroScreen =='Payment Contact'){
                this.openPaymentContactScreen = true;
            }
        }
        // W-002829 End
        else{
            this.openLicenseeScreen = true; //W-002795 : To render licensee selection screen on the UI
            this.licenseeCardsHeader = LicensingComLabelSelectLicensee; // W-002791 : It displays licensee Cards Header on UI
            // W-002786 Start : It displays Search/Create licensee button name
            // If 'An organisation' is selected as 'Who is the licence for'
            if(this.licenceFor == LicensingComLabelOrganisationOrSoleTrader || this.licenceFor == 'An organisation or sole trader'){
                this.searchOrCreateLicensee = 'Create licensee';  //ADO15413 Change label "Search for licensee" to "Create Licensee"
            }
            // If 'Another sole trader or partnership' is selected as 'Who is the licence for'
            else if(this.licenceFor == LicensingComLabelAnotherSoleTrader){
                this.searchOrCreateLicensee = 'Create licensee';
                this.licenseeCardsHeader = 'Select from the list of associated licensees or create another.'; // W-002791 : It displays licensee Cards Header on UI
            }
            // W-002786 End
                        
        }
        // W-002795: Replacing the below method call with new method name ( No change in current functionality)
        //W-002823 :START Licence contact selection page functionality for "Me" and "Sole trader in my name" flow
        this.openSelectionScreenOnEventCapture(); //W-002782 : Opens Licence Contact Selection screen, when event is captured
        // W-002823 END
    //});
    }catch(e){
        window.location.href='/apex/licensingcomerror';
    }


    }

    /*       
    * @author      : Coforge
    * @date        : 10/10/2022
    * @description : Method called when select Licensee button is clicked for licensee selection screen - W-002774
    * @return      : None
    * @param       : event
    */
    selectedGrid(event){
    try{
				var scrollOptions = {
                left: 0,
                top: document.body.scrollHeight, /* W-002883 : LPE Accessibility issue fixing  here */ 
                behavior: 'smooth'
            }
            window.scrollTo(scrollOptions);
            
        var gridName = event.target.value;
		this.gridSelected=null; // Reset the existing grid value
        /*Selected card record id is fetched and styling class is added/removed to card */    
        for(let i=0; i<this.licenseeList.length; i++){
            if(this.licenseeList[i].Id == gridName){
                this.template.querySelector('[data-id="' +gridName+ '"]').classList.add('gridBackground');
                this.gridSelected = this.licenseeList[i];
				this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
            	this.selectGridValidation = "";
            }
            else{
                this.template.querySelector('[data-id="' +this.licenseeList[i].Id+ '"]').classList.remove('gridBackground');	
            }
        }    
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }
    
    /*       
    * @author      : Coforge
    * @date        : 10/10/2022
    * @description : Method called on next button click of licensee selection screen  - W-002774
    * @return      : None
    * @param       : event
    */
    goToLicenseContactScreen(event){
    try{
        if(this.gridSelected==null){
            /*On click of next without selecting card we are displaying error on top of grids  */ 
            this.template.querySelector('[data-id="errorMessage"]').classList.add('error');
            this.selectGridValidation = "Licensee selection is required";
            var scrollOptions = {
                left: 0,
                top: 580,
                behavior: 'smooth'
            }
            window.scrollTo(scrollOptions);
        }
        else{
            // W-002838 : Passing selected licensee org role to selectedLicenseeOrgRole
            this.selectedLicenseeOrgRole = JSON.stringify(this.gridSelected); // Adding JSON.stringify for Defect Fix
            // W-002782 : Start - Sets the selected business account record from UI to 'selectedLicensee'
            // W-002792 : Setting selectedLicensee to pass selected licensee to Licence Contact Selection Screen
            this.selectedLicensee = this.gridSelected.Licensee_or_Organisation__r;
            // W-002795 : To hide Licensee selection screen
            this.openLicenseeScreen = false;

            // It is used to show/hide the content on the current component and child component
            this.openLicenseContactScreen = true;
            // W-002782 : End  

            // W-002795 : To pass the selected licensee to the lightning out
            this.sendSelectedLicenseeToVF();
        }
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 12/10/2022
    * @description : Method called when Search for licensee is clicked, to open modal popup - W-002775
    *                W-002786 : Modified to open different popup for create & search Licensee
    * @return      : None
    * @param       : None
    */
    openLicenseePopup(event){
    try{
        // W-002806 START Reset the existing grid value and remove error
        this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
        this.selectGridValidation = "";
        // W-002806 END
        // If 'An organisation' is selected as 'Who is the licence for'
        if(event.target.value == 'searchOrCreateLicensee'){
            // W-002806 START Reset the existing grid value and remove background
            for(let i=0; i<this.licenseeList.length; i++){
                this.template.querySelector('[data-id="' +this.licenseeList[i].Id+ '"]').classList.remove('gridBackground');   
				this.gridSelected = null;
            } // W-002806 END
        }
        if(this.licenceFor == LicensingComLabelOrganisationOrSoleTrader){
            // Creating a custom event which is handled in LicensingComLightningOutComponent to open Search Licensee modal popup
            this.dispatchEvent(new CustomEvent('openLicenseeSearchPopup'));
        }
        // If 'Another sole trader or partnership' is selected as 'Who is the licence for'
        else if(this.licenceFor == LicensingComLabelAnotherSoleTrader){
            // Creating a custom event which is handled in LicensingComLightningOutComponent to open Create Licensee modal popup
            this.dispatchEvent(new CustomEvent('openLicenseeCreatePopup'));
        }
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 21/10/2022
    * @description : W-002782 : Handling the event and opening the Licence Contact selection screen if licensee data is recieved
    *                from the Visualforce popup, when the logged in user creates / selects an existing business account as licensee
    * @return      : None
    * @param       : None
    */
    openSelectionScreenOnEventCapture(){ // W-002795 : Changing the name fo the method, based on new functionality addition in the method
    try{
        // Adding event listener to handle the event
        window.addEventListener("message", (message) => {

            // Page origin
            getCommunityURL()
            .then(result => {
                var vfOrigin;
								vfOrigin =  result;
            
                if (!vfOrigin.includes(message.origin)) {
                    //Not the expected origin
                    return;
                }

                //handling the message named "LicenseeData"
                if (message.data.name === "LicenseeData") {

                    
                    
                    
                    // Pass the licensee data to selectedLicensee, which is send to the child component Licence Contact Screen
                    // W-002792 : Setting selectedLicensee to pass selected licensee to Licence Contact Selection Screen
                    // Setting to object type
                    
                    // W-002838 Start: Fetching Licensee_or_Organisation__r of selected licensee, as structure of recieved licensee is modified
                    if(typeof message.data.payload === 'object'){
                        this.selectedLicensee = (message.data.payload).Licensee_or_Organisation__r;
                        // W-002838 : Passing selected licensee org role to selectedLicenseeOrgRole
                        // W-002829 : Passing stringified value
                        this.selectedLicenseeOrgRole = JSON.stringify(message.data.payload);
                    }
                    else{
                        this.selectedLicensee = JSON.parse(message.data.payload).Licensee_or_Organisation__r;
                        // W-002838 : Passing selected licensee org role to selectedLicenseeOrgRole
                        // W-002829 : Passing parsed value
                        this.selectedLicenseeOrgRole = JSON.stringify(JSON.parse(message.data.payload));
                    }
                    // W-002838 End

                    // W-002795 : To hide Licensee selection screen
                    this.openLicenseeScreen = false; 

                    // W-002795 : To pass the selected licensee to the lightning out
                    this.sendSelectedLicenseeToVF();

                    // To render Licence Contact Screen on the UI
                    this.openLicenseContactScreen = true;
                }
                //W-002795 Start : Handling the event named "LicenseContactData"
                else if(message.data.name === "LicenseContactData"){

                    // Pass the license contact data to selectedLicenseContact, which is send to the child component Payment Contact Screen
                    this.selectedLicenseContact = message.data.payload;
                    // To hide Licensee selection screen
                    this.openLicenseeScreen = false; 
                    
                    // To hide the License Contact screen on UI
                    this.openLicenseContactScreen = false;

                    // To render Payment Contact Screen on the UI
                    //Start W-002839
                    if(!this.flagforchangelicencecontact){
                        // W-002829 : Dispatching event to update breadcrumb
                        this.updateBreadcrumb('Payment Contact','');
                        this.openPaymentContactScreen = true;
                    }
                    else{
                        // W-002829 : Dispatching event to update breadcrumb
                        this.updateBreadcrumb('Validation','');
                        this.openContactValidationScreen = true;
                    }//End W-002839
                }
                //W-002795 End
                //W-002828 Start : Handling the event named "PaymentContactData"
                else if(message.data.name === "PaymentContactData"){

                    // Setting the created payment contact as the selected contact
                    this.selectedPaymentContact = message.data.payload;

                    // To hide Licensee selection screen
                    this.openLicenseeScreen = false; 
                    
                    // To hide the License Contact screen on UI
                    this.openLicenseContactScreen = false;

                    // To render Payment Contact Screen on the UI
                    this.openPaymentContactScreen = false;

                    // To render contact validation screen on the UI
                    this.openContactValidationScreen = true;

                }
                //W-002828 End
            })
			.catch((error) => {
                    window.location.href='/apex/licensingcomerror';
                });
        });
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 27/10/2022
    * @description : W-002784 : Handling the event send from Licence Contact Selection Screen on click of Previous button, to show Licensee Selection
    *                Screen and hide Licence Contact Selection Screen.
    * @return      : None
    * @param       : event
    */
    openlicenseescreen(event) {
    try{
        // W-002829 Start : Displays Licensee screen and hides other screens
        location.reload();
        // W-002829 End
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 27/10/2022
    * @description : W-002795 : To open Licence Contact popup, when event for this is recieved from the child - Licence Contact Selection screen
    * @return      : None
    * @param       : None
    */
    opencontactpopup(event){ // W-002798 : Adding event as parameter
    try{
        // W-002828 Start :Modifying the event to pass two parameters, and renamed the event name
        this.dispatchEvent(new CustomEvent("openContactPopup",{
            detail:{
                selectedContact : event.detail.selectedContact,
                contactType :event.detail.contactType // Passing the Contact's type
            }
        // W-002828 End 
        }));
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
        
    }

    /*       
    * @author      : Coforge
    * @date        : 27/10/2022
    * @description : W-002795 :  To send the selected licensee to the lightning out vf component
    * @return      : None
    * @param       : None
    */
    sendSelectedLicenseeToVF(){
    try{
        this.dispatchEvent(new CustomEvent("sendSelectedLicensee",{
           // detail: this.selectedLicensee.Id
           // W-002829 Start : Passing licensee as well, as it will be stored at lightning out, and will be used to show content on breadcrumb click
           detail: {
             licenseeId : this.selectedLicensee.Id,
             licensee : this.selectedLicenseeOrgRole
           }
           // W-002829 End
        }));
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 21/11/2022
    * @description : W-002824 : Handles the event send from Licence Contact screen to open the Payment Contact screen
    * @return      : None
    * @param       : None
    */
    openpaymentcontactscreen(event){// W-002827 to hold the Licence Contact while moving to Payment Contact selection Screen 
    try{    
        // Selected contact converted to JSON
        this.selectedLicenseContact = JSON.stringify(event.detail.selectedContact);// W-002827 to hold the Licence Contact while moving to Payment Contact selection Screen 
        this.openLicenseeScreen = false
        this.openLicenseContactScreen = false;
        // W-002829 Start: Dispatching event which shows the new breadcrumb - Payment Contact
        this.updateBreadcrumb('Payment Contact', this.selectedLicenseContact);
        // W-002829 End
        this.openPaymentContactScreen = true;
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 24/11/2022
    * @description : W-002827 : Handles the event send from Payment Contact screen to open the Contact Validation screen
    * @return      : None
    * @param       : None
    */
    opencontactvalidationscreen(event){
    try{
        this.selectedPaymentContact = JSON.stringify(event.detail.selectedPaymentContact);
        this.openPaymentContactScreen = false;
        // W-002829 Start: Dispatching event which shows the new breadcrumb - Contact Validation
        this.updateBreadcrumb('Validation','');
        // W-002829 End
        this.openContactValidationScreen = true;
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 07/12/2022
    * @description : W-002839 : Handles the event send from  Contact Validation screen to open the Licence Contact screen
    * @return      : None
    * @param       : None
    */
    gotolicencecontact(){
    try{
        // W-002829 Start : Dispatching event to update breadcrumb, when Change Licence Contact is clicked on Contact validation screen
        this.updateBreadcrumb('Licence Contact','');
        // W-002829 End
        this.flagforchangelicencecontact = true;
        this.openLicenseeScreen = false
        this.openPaymentContactScreen = false;
        this.openContactValidationScreen = false;
        this.openLicenseContactScreen = true;
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 07/12/2022
    * @description : W-002839 : Handles the event send from  Licence Contact screen to open the Contact Validation screen
    * @return      : None
    * @param       : None
    */
    openvalidationscreen(event){
    try{
        // W-002829 Start: Dispatching event which shows the new breadcrumb - Contact Validation
        this.updateBreadcrumb('Validation',this.selectedLicenseContact);
        // W-002829 End
        this.selectedLicenseContact = JSON.stringify(event.detail.selectedContact);
        this.openLicenseeScreen = false
        this.openPaymentContactScreen = false;
        this.openContactValidationScreen = true;
        this.openLicenseContactScreen = false;
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 07/12/2022
    * @description : W-002840 : Handles the event send from  Contact Validation screen to open the Payment Contact screen
    * @return      : None
    * @param       : None
    */
    gotopaymentcontact(){
    try{
        this.flagforchangelicencecontact = false; // Setting this to false we are navigating using previous button
        this.openLicenseeScreen = false;
        // W-002829 Start : Dispatching event to update breadcrumb
        this.updateBreadcrumb('Payment Contact','');
        // W-002829 End
        this.openPaymentContactScreen = true;
        this.openContactValidationScreen = false;
        this.openLicenseContactScreen = false;
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 15/12/2022
    * @description : W-002829 : Handles the event send from  Payment Contact screen to open the Licence Contact screen
    * @return      : None
    * @param       : None
    */
    gotolicencecontactonprevious(){
    try{
        this.openLicenseeScreen = false
        this.openPaymentContactScreen = false;
        this.openContactValidationScreen = false;
        // Dispatching event to update breadcrumb
        this.updateBreadcrumb('Licence Contact','');
        this.openLicenseContactScreen = true;
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 15/12/2022
    * @description : W-002829 : Event that updates the breadcrumb when 'Next' or 'Previous' or 'Change contact' buttons are clicked
    * @return      : None
    * @param       : None
    */
    updateBreadcrumb(currentScreenName, selectedLicenseContactRecord){
    try{
        this.dispatchEvent(new CustomEvent('updatingBreadcrumb',{
            detail: {
                screenName : currentScreenName,
                selectedLicenseContact : selectedLicenseContactRecord
              }
        })); 
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 11/01/2023
    * @description : W-002883 : LPE Accessibility issue fixing  here
    * @return      : None
    * @param       : None
    */
    cancellink(){
    try{
        window.location.href='/apex/LicensingComDashboard';   
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }      
    } 

    /*       
    * @author      : Coforge
    * @date        : 11/01/2023
    * @description : W-002883 : LPE Accessibility issue fixing  here
    * @return      : None
    * @param       : None
    */
    previouslink(){
    try{
       window.location.href='/apex/licensingcomapplyforlicence?licence=Aeronautical Radio'; 
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }
    
    }