/*********************************************************************
# File....................: osDeleteConfirmationPopup.js
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............: 20/11/2021
# Last Modified by........: Coforge
# Last Modified Date......: 
# Description.............: Used as a controller class of osDeleteConfirmationPopup component.
# Change Log..............: NA
**********************************************************************/

import { LightningElement, api } from 'lwc';

const YES = 'Yes';
const NO = 'No';

export default class OsDeleteConfirmationPopup extends LightningElement {

    @api message = '';

    yesLabel = YES;
    noLabel = NO;
    
    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This method will execute on click of Yes button of delete confirmation model.
     * @params      : NA
     * @return      : NA
     */
    yes() {
        this.dispatchEvent(new CustomEvent('close', {detail: { value : 'yes'}}));
    }

    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This method will execute on click of No button of delete confirmation model.
     * @params      : NA
     * @return      : NA
     */
    no() {
        this.dispatchEvent(new CustomEvent('close', {detail: { value : 'no'}}));
    }
}