/**
* @description   Generic Pagination Component
* @author        Coforge
* @date          Jan 11, 2024
* @lastModified  06 May 2024
* @description : Jan 11, 2024 : ADO-20971: Licensee Selection (Initial Draft)
                 May 05, 2024 : ADO-26706: Pagination functionality for IR Regulatory Contact
                 May 05, 2024 : ADO-26707: Pagination functionality for General IR Contact
*/
import { LightningElement, api } from 'lwc';

export default class Paginationcmp extends LightningElement {

    wholeList; // will store the complete list of records passed from parent component
    displayBatchList; // will store the list of records that will be displayed on current page
    currentpageNumber = 1; // will store the current page number and display the same on UI
    totalPages = 1; // will store the total number of pages and display the same on UI
    hidePagination = false; // will be set to true will there is on only page, and will be used to show/ hide the pagination section
    disablePrevious = true; // will be used to disable the Previous button i.e., "<"
    disableNext = false; // will be used to disable the Next button i.e., ">"
    @api displayGrids = 50; // indicates how many grids will be displayed on page, default is set to 50

    /*
    * @author      : Coforge
    * @date        : Jan 11, 2024
    * @description : Getter method used for the list of sObject
    * @return      : None
    * @param       : None
    */
    get sobjectList() {
        return this.displayBatchList;
    }

    /*
    * @author      : Coforge
    * @date        : Jan 11, 2024
    * @description : Setter method used for the list of sObject
    * @return      : None
    * @param       : None
    */
    @api 
    set sobjectList(data) {
        try{
            if(data){
                this.wholeList = data;
                this.displayGrids = Number(this.displayGrids);
                this.totalPages = (this.wholeList.length/this.displayGrids) < 1 ? 1 : Math.ceil(this.wholeList.length/this.displayGrids);
                if(this.totalPages === 1) { this.hidePagination = true; }
                this.sendCurrentPageList();
            }
        }
        catch(e){
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*
    * @author      : Coforge
    * @date        : Jan 11, 2024
    * @description : Method used for sending the list of sObject for current page
    * @return      : None
    * @param       : None
    */
    sendCurrentPageList(){
        try{
            const startIndex = (this.currentpageNumber-1) * this.displayGrids;
            const endIndex = this.currentpageNumber * this.displayGrids;
            this.displayBatchList = this.wholeList.slice(startIndex, endIndex);
            this.dispatchEvent(new CustomEvent('update', {
                detail: {
                    records:this.displayBatchList
                }
            }));
            this.checkButtonCSS();
        }
        catch(e){
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*
    * @author      : Coforge
    * @date        : Jan 11, 2024
    * @description : Method used to handle the Previous button click
    * @return      : None
    * @param       : None
    */
    handlePrevious() {
        if(this.currentpageNumber != 1) {
            this.currentpageNumber -= 1;
            this.sendCurrentPageList();
        }
    }

    /*
    * @author      : Coforge
    * @date        : Jan 11, 2024
    * @description : Method used to handle the Next button click
    * @return      : None
    * @param       : None
    */
    handleNext() {
        if(this.currentpageNumber != this.totalPages) {
            this.currentpageNumber += 1;
            this.sendCurrentPageList();
        }
    }

    /*
    * @author      : Coforge
    * @date        : Jan 11, 2024
    * @description : Method used to handle the enabling/ disabling of Previous and Next button.
    * @return      : None
    * @param       : None
    */
    checkButtonCSS(){ 
        this.disablePrevious = (this.currentpageNumber === 1);
        this.disableNext = (this.currentpageNumber === this.totalPages);
        //ADO- 26706/26707 start
        /*if(this.disablePrevious) {
            this.template.querySelector('.previousBtn').classList.add('grayOutButton');
        }
        else{
            this.template.querySelector('.previousBtn').classList.remove('grayOutButton');
        }
        if(this.disableNext) {
            this.template.querySelector('.nextBtn').classList.add('grayOutButton');
        }
        else{
            this.template.querySelector('.nextBtn').classList.remove('grayOutButton');
        }*/
        //ADO- 26706/26707 End
    }
}