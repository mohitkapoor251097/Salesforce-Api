/**
* @description   Displays the IRMS cases files
* @author        Coforge
* @date          20 August 2024
* @lastModified  20 August 2024
* @description : ADO 22392/22396 Access to, viewing and download of Draft Notice document attachment
               : ADO-37261 Correspondence Detailed IR SRC Case View Pop-up Screen
*/
import { LightningElement, track, api } from 'lwc';
import getContentVersionsForIR from '@salesforce/apex/IRComCreatePortalUser.getContentVersionsForIR';

export default class IRComContentVersionList extends LightningElement {
    @track dataList;
    showSpinner = false;
    @api parentcaseids;
    @api metadatatypes;
    @api title;
    paginationfilelist = [];
    irfilecount;
    @track isPagination = false;
    finalfilelist;
    visibilityerrormessage = false;
    visibilitycontentversionList=false;

    @api isvisblebackbutton=false; //ADO-37261

    /*       
  * @author      : Coforge
  * @date        : 20/08/2024
  * @description : ADO 22392/22396  calls the getAllContentVersionData function
  */
    connectedCallback() {
        this.showSpinner = true;
        this.getAllContentVersionData();
    }
    
    /*       
  * @author      : Coforge
  * @date        : 20/08/2024
  * @description : ADO 22392/22396  return the content version data list with download URL, preview URL and contentVerObj as file record
  */
    getAllContentVersionData() {
        try {
            this.showSpinner = true;
            // Call the Apex method with the hardcoded recordId (ideally, make this dynamic)
            getContentVersionsForIR({
                recordId: this.parentcaseids,
                metadataType: this.metadatatypes
            })
                .then(result => {
                    let parsedData = [];

                    // Iterate through the result map
                    for (let recordId in result) {
                        let contentVersions = result[recordId];
                        // Filter content versions and add download and preview url parameter
                        contentVersions.forEach(file => {
                            let fileData = {
                                downloadUrl: window.location.origin + '/sfc/servlet.shepherd/document/download/'+ file.ContentDocumentId + '?operationContext=S1',
                                contentVerObj: file 
                            };
                            parsedData.push(fileData);
                        });
                    }

                    this.dataList = parsedData;
                    this.paginationfilelist = this.dataList;
                    this.isPagination = true;
                    this.irfilecount = (this.paginationfilelist).length;
                    this.showSpinner = false;
                    this.visibilityerrormessage = this.dataList.length === 0;
                    if(this.dataList!=null && this.dataList.length>0){
                        this.visibilitycontentversionList=true;
                    }
                })
                .catch(error => {
                    window.location.href = '/apex/licensingcomerror';
                })
        }
        catch (e) {
            this.showSpinner = false;
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
  * @author      : Coforge
  * @date        : 20/08/2024
  * @description : ADO 22392/22396  download the file
  */
    handleDownload(event) {
        try {
            const fileId = event.currentTarget.dataset.id;
            const file = this.dataList.find(file => file.contentVerObj.ContentDocumentId === fileId);
            window.location.href = file.downloadUrl;
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
  * @author      : Coforge
  * @date        : 20/08/2024
  * @description : ADO 22392/22396  return the user to IRComDetailRequestScreen
  */
    handleback() {
        try {
            const updatedValues = {
                isvisibleirdetailrequest: true,
                isvisibledraftfiles: false,
                isvisiblefinalnoticefiles: false
            };
            this.dispatchEvent(new CustomEvent('updatevalues', {
                detail: updatedValues
            }));
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
    /*       
   * @author      : Coforge
   * @date        : 21/08/2024
   * @description : ADO-22392/22396: method called to get the current record data from pagination
   */
    currentFileList(event) {
        this.finalfilelist = [...event.detail.records];
    }
}