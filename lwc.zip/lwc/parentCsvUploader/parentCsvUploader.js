/**
* @description   Used to reference child component sfMapsCsvUploader that allows inserting Custom Data Source object records through CSV
* @author        Coforge
* @date          19 Mar  2025
* @ChangeLog     Intitial Version 1.0 : 19-03-2025 : ADO 50844 : Inserting Custom Data Source object records through CSV                     
*/

import { LightningElement } from 'lwc';
export default class ParentCsvUploader extends LightningElement {
    objectName = 'Custom_Data_Sources__c';
    connectedCallback() {
        console.log('objectName in parent:', this.objectName); // Log to ensure it's defined
    }
}