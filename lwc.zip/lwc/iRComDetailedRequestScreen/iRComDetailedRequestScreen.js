/**
* @description   Displays the IR cases summary table
* @author        Coforge
* @date          23 May 2024
* @lastModified  26 Feb 2025
* @description : ADO-22358 Navigation to the 'All IR detailed viewscreen' screen
               : ADO 22376 Access to the Detailed IR Request Screen
               : ADO 22386 DRAFT NOTICE SECTION: ‘Submit Draft Notice Query’ Function
               : ADO 22383 Submission of Draft Notice comments
               : ADO 22393 Raising Final Notice Query
               : ADO 22390 Draft Notice Extension Request Function
               : ADO 22400 Submit Response Action on FRD rows
               : ADO 34555 Detailed Request Section Visibility linked to IRMS case status
               : ADO 22398 Final Notice Extension Request
               : ADO 22392/22396 Access to, viewing and download of Draft Notice document attachment
               : ADO-37261 Correspondence Detailed IR SRC Case View Pop-up Screen
               : ADO-37140 New Data Field - Related IR Contact
               : ADO-22373 'External Status' and 'Draft Notice' status automation for the 'Draft Notice Stage'
*/

import { LightningElement, track, api } from 'lwc';
import getIRCaseDetailsWithFRD from '@salesforce/apex/IRComCreatePortalUser.getIRCaseDetailsWithFRD';
import { loadScript } from 'lightning/platformResourceLoader';
import jsResourceUrl from '@salesforce/resourceUrl/IR_Templates';
import getIRCaseDataAccess from '@salesforce/apex/IR_Utility.getIRCaseDataAccess';
import getCasesOrgRole from "@salesforce/apex/IRComCreatePortalUser.getCasesOrgRole"; //ADO-37140

export default class IRComDetailedRequestScreen extends LightningElement {
    @track isPagination = false;
    irFRDCount;
    paginationfinalfrdlist = [];
    finalfrdlist;
    @api value;
    accountName;
    relatedProject;
    projectarea;
    returnScheduleNumber;
    @track selectedIds = [];
    @track casedetails = {};
    @track casewithallfrdRecords = [];
    casePrefix = '500';
    frdPrefix = 'a6F';
    showSpinner;
    isvisibleirdetailrequest = true;
    isCaseRecord = false;
    isDraftNoticeSection = false;
    isFinalNoticeSection = false;
    jsresource = jsResourceUrl + '/js/timeDateFormat.js';
    openpopupmodal = false;// ADO22400
    visibilityerrormessage = false; //ADO34555
    // This will hold the loaded library
    formatDateTimeLib;
    //ADO-22392/22396 start
    @api parentcaseid;
    metadatatype;
    isvisibledraftfiles = false;
    isvisiblefinalnoticefiles = false;
    title;
    //ADO-22392/22396 end

    isvisiblebackbutton = false;//ADO-37261 start
    //ADO-37140 start
    @track caseorgroles = [];
    targetaccountorgroles = [];
    orgrolecount;
    showaddcontactmodal = false;
    showremovecontactmodal = false;
    paginationOrgrolelist = [];
    @track isorgrolePagination = false;
    finalOrgrolelist;
    @api currentloggedorgrole = [];
    //ADO 37140 end
    isDisableSubmitDraft = false; //ADO 22373

    /*       
   * @author      : Coforge
   * @date        : 23/05/2024
   * @description : ADO-22358: method called on page load to get the IR related data 
   */
    connectedCallback() {
        try {
            this.showSpinner = true;
            this.setIRCaseDataAccessMatrix();
            this.populateCasesOrgRole(); //ADO- 37140
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
    /*       
   * @author      : Coforge
   * @date        : 23/05/2024
   * @description : ADO-22358/34555: method called from setIRCaseDataAccessMatrix 
   */
    loadDateTimeFormatter(callback) {
        loadScript(this, this.jsresource)
            .then(() => {
                if (typeof window.formatResponseReceivedDate !== 'function') {
                    this.showSpinner = false;
                    window.location.href = '/apex/licensingcomerror';
                }
                this.formatDateTimeLib = window.formatResponseReceivedDate;
                if (typeof callback === 'function') {
                    callback();
                }
            })
            .catch(error => {
                this.showSpinner = false;
                window.location.href = '/apex/licensingcomerror';
            });
    }
    /*       
     * @author      : Coforge
     * @date        : 23/05/2024
     * @description : ADO-22358: method called to get the current record data from pagination
     */
    currentNoticeList(event) {
        this.finalfrdlist = [...event.detail.records];
    }

    /*       
     * @author      : Coforge
     * @date        : 23/05/2024
     * @description : ADO-22358: method called on Back button to view thr iRComRequestScreen
     */
    handleback() {
        try {
            const updatedValues = {
                isExposed: true,
                isDetailedRequestScreen: false
            };
            this.dispatchEvent(new CustomEvent('updatevalues', {
                detail: updatedValues
            }));
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
    /*       
     * @author      : Coforge
     * @date        : 23/05/2024
     * @description : ADO-22358: ADO 22376 To do in future implementation
     */
    handleCheckboxChange(event) {
        try {
            const checkbox = event.target;
            const id = checkbox.dataset.id;
            if (checkbox.checked) {
                this.selectedIds.push(id);
            } else {
                this.selectedIds = this.selectedIds.filter(selectedId => selectedId !== id);
            }
        }
        catch (e) {
        }
    }

    /*       
      * @author      : Coforge
      * @date        : 23/05/2024
      * @description : ADO 22376 Access to the Detailed IR Request Screen
      */
    iRCaseDetailsWithFRDRecord() {
        try {
            getIRCaseDetailsWithFRD({ caseId: this.value.Id })
                .then(result => {
                    if (result != null && result != '') {
                        var caserecordlst = result;
                        for (var key in caserecordlst) {
                            let caseRec = {
                                caseRecord: null,
                                frdRecords: []
                            };
                            caserecordlst[key].forEach(sObjectRec => {
                                if (sObjectRec.Id.startsWith(this.casePrefix)) {
                                    if (sObjectRec.Draft_Comments_Due__c) {
                                        let formattedDateTime = this.formatDateTimeLib(sObjectRec.Draft_Comments_Due__c);
                                        sObjectRec.Draft_Comments_Due__c = formattedDateTime;
                                    }
                                    if (sObjectRec.Draft_Question_Sent__c) {
                                        sObjectRec.Draft_Question_Sent__c = this.formatDateTimeLib(sObjectRec.Draft_Question_Sent__c); // Bug 34629
                                    }
                                    caseRec["caseRecord"] = sObjectRec;
                                } else if (sObjectRec.Id.startsWith(this.frdPrefix)) {
                                    if (sObjectRec.Final_Response_Received__c) {
                                        let formattedDateTime = this.formatDateTimeLib(sObjectRec.Final_Response_Received__c);
                                        sObjectRec.Final_Response_Received__c = formattedDateTime;
                                    }
                                    if (sObjectRec.Final_Response_Due__c) {
                                        sObjectRec.Final_Response_Due__c = this.formatDateTimeLib(sObjectRec.Final_Response_Due__c);
                                    }
                                    if (sObjectRec.Final_Request_Sent__c) {
                                        sObjectRec.Final_Request_Sent__c = this.formatDateTimeLib(sObjectRec.Final_Request_Sent__c); // Bug 34629
                                    }
                                    caseRec["frdRecords"].push(sObjectRec);
                                }
                            });
                            this.casewithallfrdRecords.push(JSON.parse(JSON.stringify(caseRec)));
                        }
                    }
                    if (this.casewithallfrdRecords != null && this.casewithallfrdRecords.length > 0) {
                        this.casedetails = this.casewithallfrdRecords[0]["caseRecord"];
                        this.parentcaseid = this.casedetails.Id;
                        if (this.casedetails != null && this.casedetails.Account != null) {
                            this.accountName = this.casedetails.Account.Name;
                        }
                        if (this.casedetails != null && this.casedetails.IR_Project__c != null) {
                            this.relatedProject = this.casedetails.IR_Project__r.External_Name__c; //Bug 40065 Project Name is replaced with External Name
                            this.projectarea = this.casedetails.IR_Project__r.Area__c;
                        }
                        if (this.casedetails != null && this.casedetails.Return_Schedule_Number__c != null) {
                            this.returnScheduleNumber = this.casedetails.Return_Schedule_Number__r.Name;
                        }
                        //ADO 22373 Start
                        if (this.casedetails != null && this.isDraftNoticeSection && (this.casedetails.Draft_Notice_Status__c=='Comments window closed' || this.casedetails.External_Status__c == 'Draft comments window closed' || this.casedetails.External_Status__c == 'Pending final notice issue')){
                            this.isDisableSubmitDraft = true;  
                        }
                        //ADO 22373 End
                    }
                    if (this.casewithallfrdRecords != null && this.casewithallfrdRecords.length > 0 && this.casewithallfrdRecords[0]["frdRecords"] != null) {
                        this.paginationfinalfrdlist = this.casewithallfrdRecords[0]["frdRecords"];
                        this.irFRDCount = (this.paginationfinalfrdlist).length;
                        this.isPagination = true;
                    }
                    
                    this.showSpinner = false;
                })
                .catch((error) => {
                    this.showSpinner = false;
                    window.location.href = '/apex/licensingcomerror';
                })
        }
        catch (e) {
            this.showSpinner = false;
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 25/06/2024
    * @description : ADO-22386: DRAFT NOTICE SECTION: ‘Raise a query on draft notice’ Function
    */
    handleRaiseQueryDNClick() {
        try {
            window.location.href = '/apex/IRcomUploadDocumentPage?CaseId=' + this.casedetails.Id + '&DraftType=' + 'DNQRY';
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
    /*       
    * @author      : Coforge
    * @date        : 25/06/2024
    * @description : ADO-22383: Submission of Draft Notice comments
    */
    handleSubmitDNClick() {
        try {
            //BUG-52118 Fix
            if(this.isDisableSubmitDraft){
                window.location.href = '/apex/licensingcomerror';
            }else {
                window.location.href = '/apex/IRcomUploadDocumentPage?CaseId=' + this.casedetails.Id + '&DraftType=' + 'DNCMT';
            }
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
    /*       
    * @author      : Coforge
    * @date        : 15/07/2024
    * @description : ADO-22393: Raising Final Notice Query
    */
    handleRaiseFinalNoticeQueryClick() {
        try {
            window.location.href = '/apex/IRcomUploadDocumentPage?CaseId=' + this.casedetails.Id + '&DraftType=' + 'FNQRY';
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
    /*       
    * @author      : Coforge
    * @date        : 15/07/2024
    * @description : ADO 22390 Draft Notice Extension Request Function
    */
    handleRequestExtensionClick() {
        try {
            window.location.href = '/apex/IRcomUploadDocumentPage?CaseId=' + this.casedetails.Id + '&DraftType=' + 'DNEXT';
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
      * @author      : Coforge
      * @date        : 26/06/2024
      * @description : ADO 22400 Submit Response Action on FRD rows
      */
    closemodalaction(event) {
        try {
            this.openpopupmodal = event.detail.value;
            document.body.style.overflow = '';
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
    /*       
      * @author      : Coforge
      * @date        : 26/06/2024
      * @description : ADO 22400 Submit Response Action on FRD rows
      */
    handleSubmitclick() {
        this.openpopupmodal = true;
        document.body.style.overflow = 'hidden';
    }

    /*       
        * @author      : Coforge
        * @date        : 06/08/2024
        * @description : ADO-34555: This method will return IRCom_CaseDetailAccessMatrix__mdt record.
        * @return      : None
        * @param       : event
        */
    setIRCaseDataAccessMatrix() {
        try {
            getIRCaseDataAccess({ irExternalStatus: this.value.External_Status__c })
                .then((result) => {

                    if (result != null && result != '') {
                        this.isCaseRecord = result.Request_Main_Details__c;
                        this.isDraftNoticeSection = result.Draft_Notice_Section__c;
                        this.isFinalNoticeSection = result.Final_Notice_Section__c;
                        this.loadDateTimeFormatter(this.iRCaseDetailsWithFRDRecord.bind(this));

                        if (!this.isCaseRecord && !this.isDraftNoticeSection && !this.isFinalNoticeSection) {
                            this.visibilityerrormessage = true;
                            this.showSpinner = false;
                        }
                    } else {
                        this.visibilityerrormessage = true;
                        this.showSpinner = false;
                    }
                })
                .catch((error) => {
                    window.location.href = '/apex/licensingcomerror';
                });
        }
        catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
   * @author      : Coforge
   * @date        : 12/08/2024
   * @description : ADO-22398: method called on click of final notice's Request extension button.  
   */
    handleFinalExtensionClick() {
        try {
            this.showSpinner = true;
            window.location.href = '/apex/IRComFrdDetailPage?CaseId=' + this.casedetails.Id + '&draftType=' + 'FNEXT';
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
    /*       
  * @author      : Coforge
  * @date        : 20/08/2024
  * @description : ADO-22392/ 22396:  setup the parameter value to send it to child component
  */

    handleFileViewNotice(event) {

        try {
            const buttonName = event.target.name;
            if (buttonName != '' && buttonName === 'View draft notice') {
                this.metadatatype = 'Draft notice';
                this.title = 'Draft notice view';
                this.isvisibleirdetailrequest = false;
                this.isvisibledraftfiles = true;
                this.isvisiblebackbutton = true; //ADO-37261
            }
            else if (buttonName != '' && buttonName === 'View all notice documentation') {
                this.metadatatype = 'Final notice';
                this.title = 'Final notice view';
                this.isvisibleirdetailrequest = false;
                this.isvisiblefinalnoticefiles = true;
                this.isvisiblebackbutton = true; //ADO 37261
            }
        }
        catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
  * @author      : Coforge
  * @date        : 20/08/2024
  * @description : ADO-22392/22396: method used to open the iRComDetailRequestScreen 
  */
    exposedirdetailsscreen(event) {
        try {
            const { isvisibleirdetailrequest, isvisibledraftfiles, isvisiblefinalnoticefiles } = event.detail;
            this.isvisibleirdetailrequest = isvisibleirdetailrequest;
            this.isvisibledraftfiles = isvisibledraftfiles;
            this.isvisiblefinalnoticefiles = isvisiblefinalnoticefiles;
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
       * @author      : Coforge
       * @date        : 11 September  2024
       * @param       : None
       * @description : ADO-37140 This method rreturned the linked and unlinked orgrole list
       */
    populateCasesOrgRole() {
        try {
            getCasesOrgRole({ caseRecId: this.value.Id })
                .then((result) => {
                    if (result) {
                        this.showSpinner = true;
                        this.caseorgroles = [];
                        this.targetaccountorgroles = [];
                        for (var key in result) {
                            if (key == 'LinkedOrgRoles' && result[key] != null && result[key][0] != null) {
                                result[key].forEach(orgRole => {
                                    //craete object and add all fields which are using in datatable
                                    let orgRoleRec = {};
                                    orgRoleRec["Name"] = orgRole.Name;
                                    orgRoleRec["Id"] = orgRole.Id;
                                    orgRoleRec["FirstName"] = orgRole.Contact__r.FirstName;
                                    orgRoleRec["LastName"] = orgRole.Contact__r.LastName;
                                    orgRoleRec["Email"] = orgRole.Email__c;
                                    orgRoleRec["TargetAccountName"] = orgRole.Licensee_or_Organisation__r.Name;
                                    orgRoleRec["OrgTypes"] = orgRole.Types__c;          //Show & Tell Feedback ADO 33991
                                    this.caseorgroles.push(orgRoleRec);
                                });
                            }
                            if (key == 'UnlinkedOrgRoles' && result[key] != null && result[key][0] != null) {
                                result[key].forEach(orgRole => {
                                    //craete object and add all fields which are using in datatable
                                    let orgRoleRec = {};
                                    orgRoleRec["Name"] = orgRole.Name;
                                    orgRoleRec["Id"] = orgRole.Id;
                                    orgRoleRec["FirstName"] = orgRole.Contact__r.FirstName;
                                    orgRoleRec["LastName"] = orgRole.Contact__r.LastName;
                                    orgRoleRec["Email"] = orgRole.Email__c;
                                    orgRoleRec["TargetAccountName"] = orgRole.Licensee_or_Organisation__r.Name;
                                    orgRoleRec["OrgTypes"] = orgRole.Types__c;          //Show & Tell Feedback ADO 33991 
                                    this.targetaccountorgroles.push(orgRoleRec);
                                });
                            }
                        }
                        this.irsortingFirstName(this.caseorgroles);
                        this.irsortingFirstName(this.targetaccountorgroles);
                        this.paginationOrgrolelist = this.caseorgroles;
                        this.orgrolecount = this.caseorgroles.length;
                        this.isorgrolePagination = true;
                        this.showSpinner = false;

                    } else {
                        this.showSpinner = false;
                    }
                })
                .catch((error) => {
                    this.showSpinner = false;
                    window.location.href = '/apex/licensingcomerror';
                });
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
    /*       
        * @author      : Coforge
        * @date        : 11 September  2024
        * @param       : None
        * @description : ADO-37140 with this method popup will open for add contact
        */
    openaddcontactModal() {
        try {
            this.isorgrolePagination = false;
            this.showaddcontactmodal = true;
            document.body.style.overflow = 'hidden';
        } catch (e) {
            this.showSpinner = false;
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
         * @author      : Coforge
         * @date        : 11 September  2024
         * @param       : None
         * @description : ADO-37140 with this method popup will open for remove contact 
         */
    openremovecontactModal() {
        try {
            this.isorgrolePagination = false;
            this.showremovecontactmodal = true;
            document.body.style.overflow = 'hidden';
        } catch (e) {
            this.showSpinner = false;
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
         * @author      : Coforge
         * @date        : 11 September  2024
         * @param       : None
         * @description : ADO-37140 with this method popup will close
         */
    closemodalactions(event) {
        try {
            const { showaddremovecontactmodal, isVisibleIRRequestScreen } = event.detail;
            if (isVisibleIRRequestScreen) {
                this.handleback();
            } else {
                this.showaddcontactmodal = showaddremovecontactmodal;
                this.showremovecontactmodal = showaddremovecontactmodal;
                this.showSpinner = true;
                this.populateCasesOrgRole();
            }
            document.body.style.overflow = '';
        } catch (e) {
            this.showSpinner = false;
            window.location.href = '/apex/licensingcomerror';
        }
    }
    /*       
       * @author      : Coforge
       * @date        : 11 September  2024
       * @param       : None
       * @description : ADO-37140 This method return the current records list
       */
    currentPageOrgRoleList(event) {
        try {
            this.finalOrgrolelist = [...event.detail.records];
        } catch (e) {
            this.showSpinner = false;
            window.location.href = '/apex/licensingcomerror';
        }
    }
    /*       
       * @author      : Coforge
       * @date        : 11 September  2024
       * @param       : None
       * @description : ADO-37140 Sort the paginationOrgrolelist based on FirstName (case-insensitive)
       */
    irsortingFirstName(orgrole){
     // Sort the paginationOrgrolelist based on FirstName (case-insensitive)
                        orgrole.sort((a, b) => {
                            const nameA = a.FirstName ? a.FirstName.toUpperCase() : ''; // Handle null or undefined
                            const nameB = b.FirstName ? b.FirstName.toUpperCase() : ''; // Handle null or undefined
                            return nameA.localeCompare(nameB); // Locale compare for case-insensitive sorting
                        });
    }
}