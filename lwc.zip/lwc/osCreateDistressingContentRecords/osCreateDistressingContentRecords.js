import { LightningElement, api, track } from 'lwc';
import getCustomMetadataRecords from "@salesforce/apex/OsCreateDistressingContentRecordsCtrl.getCustomMetadataRecords";
import updateSharepointData from "@salesforce/apex/OsCreateDistressingContentRecordsCtrl.updateSharepointData";

import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import LightningModal from 'lightning/modal';
import COMMON_ERROR from '@salesforce/label/c.CommonError';
import OS_RECORD_LOCK_MESSAGE from '@salesforce/label/c.OS_Record_Lock_Message';

import LightningAlert from 'lightning/alert';

const DML_EXCEPTION = 'DMLException:';
const EXCEPTION_LABEL = '_EXCEPTION';
const RECORD__LOCKED_LABEL = 'Record Locked';
const EDIT_LABEL = 'edit';
const UPDATE_LABEL = 'update';
const SUCCESS_LABEL = 'success';
const ERROR_LABEL = 'Error';

export default class OsCreateDistressingContentRecords extends LightningModal {
    @api content;
    @api headerText;
    @api recordId;
    _flagIds = [];
    @api _fileName;
    @api _fileLink;
    @api _allSelectedflags = '';
    @track showLoadingSpinner = false;
    @api isEditMode;
    editMode;
    @api identifier;
    contentFlags; 

    /*
     * @author      : Coforge
     * @date        : 03/05/2024
     * @description : This connectedCallback method is call onload of LWC Component.
     * @params      : none
     * @return      : none
     */
    async connectedCallback() {
        try {
            this.handleOnLoadData();
        }
        catch (error) {
            console.error('Error parsing JSON value ', error)
        }
    }  

    /*
     * @author      : Coforge
     * @date        : 03/05/2024
     * @description : This handleOnLoadData method is used to load the configuration from custom metadata and display accordingly
     * @params      : none
     * @return      : none
     */
    async handleOnLoadData() {
        var result = await getCustomMetadataRecords({recordId :this.recordId});
        console.log('--->>result<<---'+ JSON.stringify(result));
        if( result != '' &&  result != undefined && result.Content_Flags__c != '' && result.Content_Flags__c != undefined ){
            this.contentFlags = result.Content_Flags__c.split(';');
        }
        this.editMode = this.isEditMode;
    }

    /*
     * @author      : Coforge
     * @date        : 03/05/2024
     * @description : This renderedCallback method is call after any render of LWC Component.
     * @params      : none
     * @return      : none
     */
    renderedCallback(){
        if(this.editMode && this.editMode == 'true' && this.contentFlags != '' && this.contentFlags != undefined && this._allSelectedflags != '' && this._allSelectedflags != undefined){
            this.selectedFlags(this.contentFlags,this._allSelectedflags);  
        }
        this.editMode = '';
    }

    /*
     * @author      : Coforge
     * @date        : 03/05/2024
     * @description : This selectedFlags method is used to set the flag and highlight the selected flag in edit mode.
     * @params      : none
     * @return      : none
     */
    async selectedFlags(contentFlagsArray, selectedFlagsValues){
        let selectedContentFlagArray = selectedFlagsValues.slice(0, -1).split(";");
        if(selectedContentFlagArray && selectedContentFlagArray.length > 0){
            for(let flag of selectedContentFlagArray){
                if(contentFlagsArray.includes(flag)){
                    if( this._flagIds.includes(flag)){
                        this._flagIds = this._flagIds.filter(item => item !== flag);
                        this.template.querySelector('[data-id="' + flag + '"]').className = 'slds-box slds-size_1-of-5 slds-p-around_small slds-m-around_small slds-align_absolute-center initialCardStyle'; 
                    }else{
                        this._flagIds.push(flag);
                        this.template.querySelector('[data-id="' + flag + '"]').className = 'slds-box slds-size_1-of-5 slds-p-around_small slds-m-around_small slds-align_absolute-center selectedCardStyle'; 
                    }
                }
            }
        }
    }  

    /*
     * @author      : Coforge
     * @date        : 03/05/2024
     * @description : To show the toast message for success and error 
     * @params      : title
     * @params      : variant
     * @params      : mode
     * @return      : NA
     */
    showNoRecordsToast(title,variant,mode) {
        const toastEvent = new ShowToastEvent({
            title: title,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(toastEvent);
    }

    /*
     * @author      : Coforge
     * @date        : 03/05/2024
     * @description : This getFlags method is used to set the flag.
     * @params      : none
     * @return      : none
     */
    getFlags(event){
        var flagID = event.currentTarget.dataset.id;
        if( this._flagIds.includes(flagID)){
            this._flagIds = this._flagIds.filter(item => item !== flagID);
            this.template.querySelector('[data-id="' + flagID + '"]').className = 'slds-box slds-size_1-of-5 slds-p-around_small slds-m-around_small slds-align_absolute-center initialCardStyle'; 
        }else{
           this._flagIds.push(flagID);
           this.template.querySelector('[data-id="' + flagID + '"]').className = 'slds-box slds-size_1-of-5 slds-p-around_small slds-m-around_small slds-align_absolute-center selectedCardStyle'; 
        }
    }

    /*
     * @author      : Coforge
     * @date        : 03/05/2024
     * @description : This handleFileName method is call after file name changes.
     * @params      : none
     * @return      : none
     */
    handleFileName(event){
        this._fileName = event.target.value;
        this.editMode = '';
    }

    /*
     * @author      : Coforge
     * @date        : 03/05/2024
     * @description : This handleFileLink method is call after file Link changes.
     * @params      : none
     * @return      : none
     */
    handleFileLink(event){
        this._fileLink = event.target.value;
        this.editMode = '';
    }

    /*
     * @author      : Coforge
     * @date        : 03/05/2024
     * @description : This handleSave method is used to create and edit the sharepoint records
     * @params      : none
     * @return      : none
     */
    async handleSave() {
        let validData = true;
        let nameCmp = this.template.querySelector(".nameCls").reportValidity();
        let urlCmp = this.template.querySelector(".urlCls").reportValidity();
        if (!nameCmp) { validData = false; }
        if (!urlCmp) { validData = false; }
        
        if(validData) {

            this.showLoadingSpinner = true;

            this._allSelectedflags = '';
            for (let i = 0; i < this._flagIds.length; i++) {
                 this._allSelectedflags+= this._flagIds[i]+';';
            }

            //Create the wrapper object and send to server side for insert or update case
            let wrapperData = {};
            wrapperData.identifier = this.identifier;
            wrapperData.contentFlags = this._allSelectedflags;
            wrapperData.fileName = this._fileName;
            wrapperData.fileLink = this._fileLink;
            wrapperData.recordId = this.recordId;
            if(this.isEditMode == 'true'){
                wrapperData.operation = EDIT_LABEL;
            }else{
                wrapperData.operation = UPDATE_LABEL;
            }
            
            //Calling the server method
            await updateSharepointData({wrapperDataString: JSON.stringify(wrapperData)})
            .then((result) => {
                if (result==SUCCESS_LABEL){
                    this.showLoadingSpinner = false;
                    window.location.reload();

                } // ADO 32796 - Add SharePoint URLs in Business / Person Account
                else if (result.includes(RECORD__LOCKED_LABEL)){
                    this.showLoadingSpinner = false;
                    this.close();
                    LightningAlert.open({
                        message: OS_RECORD_LOCK_MESSAGE,
                        theme: ERROR_LABEL, // a red theme intended for error states
                        label: ERROR_LABEL,
                    });
                    
                }
                this.close();
            })
            .catch((error) => {
                //W-002679
                 this.showLoadingSpinner = false;
                 let errMsg = error.body.message;
                console.log('errMsg==>',errMsg);
                if(error != undefined && errMsg != undefined && errMsg.includes(DML_EXCEPTION)){
                    //this.showNoRecordsToast(errMsg.message,ERROR_LABEL,DISMISSABLE_LABEL);
                    let errorMessage = errMsg.replace(DML_EXCEPTION, '');
                    LightningAlert.open({
                        message: errorMessage,
                        theme: ERROR_LABEL, // a red theme intended for error states
                        label: ERROR_LABEL, // this is the header text
                    });
                    this.close();
                }else{
                    //this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
                    LightningAlert.open({
                        message: COMMON_ERROR,
                        theme: ERROR_LABEL, // a red theme intended for error states
                        label: ERROR_LABEL, // this is the header text
                    });
                    this.close();
                }
            });          
        }
    }

    /*
     * @author      : Coforge
     * @date        : 03/05/2024
     * @description : This handleClose method is used to close the modal
     * @params      : none
     * @return      : none
     */
    handleClose() {
        this.close();
    }

}