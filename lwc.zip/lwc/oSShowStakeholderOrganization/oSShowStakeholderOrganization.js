import { LightningElement, api } from 'lwc';

export default class ChildComponent extends LightningElement {

    @api currentIndex;
    @api requiredIndex;
    @api label = '';
    @api required = false;
    @api options = [];
    selectedAccount ='';
    get data() {
        const accountOptions = [];
        for(const v of this.options) {
            if (v.StakeholderType__c == 'Stakeholder Organization'){
                //accountOptions.push({ label: v['Account__r.Name'], value: v.Account__r.Id });
                accountOptions.push({ label: v['Account__r.Name'], value: v['Account__c'] });
            }
        }
        return accountOptions;
    }

    get showAccounts() {
        return this.currentIndex == this.requiredIndex;
    }

    handleAccountSelection(event) {
        this.selectedAccount = event.detail.value;
        this.dispatchEvent(new CustomEvent('handleaccountselection', { detail : this.selectedAccount}));
    }
    //Bug-fix start
    @api
    checkValidity() {
      let isSelfValidated = false;
      isSelfValidated = [
        ...this.template.querySelectorAll("lightning-combobox")
      ].reduce((validSoFar, inputField) => {
        inputField.reportValidity();
        return validSoFar && inputField.checkValidity();
      }, true);
      return isSelfValidated;
    }
    //Bug- fix end
}