import { LightningElement } from 'lwc';
//import Images from '@salesforce/resourceUrl/IR_Templates';
import login from '@salesforce/apex/IR_LoginPageController.login';
import ForgotPasswordLabel from '@salesforce/label/c.LicensingComPageLinkForgotPassword';

export default class IRLoginScreen extends LightningElement {
    
    //irLoginPic = Images+'/image/IR_loginPic.png';
    username;
    password;
    ForgotPasswordUrl = '/IR_ForgotPassword';   // BUG-26252 || Defect Fix
    forgotPasswordText=ForgotPasswordLabel;
    irLoginPageHelpText = '<b>New user?</b> You <b>cannot</b> self-register to use IRP. Please contact the IR team via the relevant email address to request an IRP account.';
    guidanceText1 = '<b>Guidance and contact<b><br/>';
    guidanceText2 = 'Ofcom is the independent regulator for the communications sector. We regulate the TV, radio, online and video on demand sectors, mobile and fixed-line telecoms, postal services plus the airwaves over which wireless devices operate. We are an evidence-based regulator.<br/>';
    guidanceText3 = 'Ofcom requests information from individuals and businesses to inform all aspects of our work. We have formal powers to make these requests.<br/>'; 
    guidanceText4 = 'This portal is provided to enable you to gain access to and interact with any information requests that may have been issued by Ofcom that relate to you as an individual or in respect to representing a specific business.<br/>';
    guidanceText5 = 'For further information on information requests from Ofcom, please see:<br/>';
    guidanceText6 = 'https://www.ofcom.org.uk/about-ofcom/policies-and-guidelines/information-registry';
    guidanceText7 = 'To request access to the IRP, please contact the IR team at:<br/>';
    guidanceText8 = 'ir.enquiries@ofcom.org.uk'
    guidanceMailText = 'mailto:ir.enquiries@ofcom.org.uk';
    error;
    errorMessage;
    inputType = 'password';
    iconName = 'utility:hide';  // eye icon
    /*       
    * @author      : Coforge
    * @date        : 06/02/2024
    * @description : ADO-25224 : This method is used to call handleLogin method on enter press from keyboard
    * @return      : None
    * @param       : event
    */  
    handleKeypress(event){
        try{
            if(event.keyCode === 13){
                this.handleLogin();
            }
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }

        this.password = event.target.value;
    }
    
    /*       
    * @author      : Coforge
    * @date        : 06/02/2024
    * @description : ADO-25224 : This method is used to implement the Login functionality for IR
    * @return      : None
    * @param       : event
    */  
    handleLogin(event){
        
        try{
            this.template.querySelector('[data-id="invalidRecordMessage"]').innerHTML ='';      //Removing validation message from UI in the begining to remove existing errors if any
            this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');  //Removing error class from UI in the begining to remove existing errors if any
            this.username = this.template.querySelector('[data-id="email"]').value;
            this.password = this.template.querySelector('[data-id="pwd"]').value;
            
            var isMandatoryFieldAvailable = true;
            if(this.username == "" || this.username == null){           
                this.template.querySelector('[data-id="email"]').classList.add('highlightBorder');
                isMandatoryFieldAvailable=false;
            }  
            if(this.password == "" || this.password == null){           
                this.template.querySelector('[data-id="pwd"]').classList.add('highlightBorder');
                isMandatoryFieldAvailable=false;
            }  
            
            if(isMandatoryFieldAvailable){
                login({username: this.username, password: this.password })
                    .then((result) =>{
                        window.location.href = result;
                    })
                    .catch((error) => {
                        this.error = error;  
                        this.template.querySelector('[data-id="errorMessage"]').classList.add('error');
                        this.errorMessage = 'Invalid Credentials';
                    });
            }
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }
    }

     /*       
    * @author      : Coforge
    * @date        : 16/04/2025
    * @description : ADO-39242 : This method is used to show and hide icon in password input
    * @return      : None
    * @param       : event
    */  
    
    togglePasswordVisibility() {
        if (this.inputType === 'password') {
            this.inputType = 'text';
             this.iconName = 'utility:preview'; //eye icon
        } else {
            this.inputType = 'password';
            this.iconName = 'utility:hide';  // eye close
        }
    }
}