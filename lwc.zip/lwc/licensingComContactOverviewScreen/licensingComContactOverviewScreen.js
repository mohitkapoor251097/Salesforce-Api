/**
* @description   Displays Available Licencees list
* @author        Coforge
* @date          28 Dec 2022
* @lastModified  29 Dec  2022
* @ChangeLog     Intitial Version 1.0 : 29-12-2022 : W-002861 LPE Replace Contact: REP5.2] View details on the Contact overview page
*                       Version 1.1 : 29-12-2022 : W-002879 LPE Replace Contact: REP6.1] Expand licence contact section in the contact overview page
                        Version 1.2 : 05-01-2023 : W-002880 LPE Replace Contact: REP7.1] Create new licence contact from the Contact Overview
                        Version 1.3 : 05-01-2023 : W-002882 LPE Replace Contact: REP8.1] Edit licence contact from the Contact Overview
                        Version 1.4 : 13-01-2023 : W-002890 LPE Replace Contact: REP12.1] Create new payment contact from the Contact Overview
                        Version 1.5 : 13-01-2023 : W-002891 LPE Replace Contact: REP13.1] Edit payment contact from the Contact Overview
*/
import { LightningElement, api} from 'lwc';
import getLicenceContactOrgRoles from '@salesforce/apex/Licensing_Utility.getLicenceContactOrgRoles';
import getPaymentContactOrgRoles from '@salesforce/apex/Licensing_Utility.getPaymentContactOrgRoles';

export default class LicensingComContactOverviewScreen extends LightningElement {
    showSpinner = true;
    @api lisenseedetail;
    @api capturecontactevent;  //W-002880
    iconName = 'utility:add';
    contactOverviewScreen;
    licenseeData;
    openLicenceContactSection = false;//W-002880 
    openPaymentContactSection = false;
    licenceContactList=''; //W-002880
    paymentContactList=''; //W-002890
    contactType;
    selectedContact; //W-002880 
    isLicenceContactChanged;//W-002880 
    selectGridValidation;  //W-002882
    @api modalContainer = false;
    onkeypress = false;
    @api bindvar;

    /*       
    * @author      : Coforge
    * @date        : 29/12/2022
    * @description : Method called when component is loaded to bring data for licensee selection screen - W-002858
    * @return      : None
    * @param       : None
    */   
    connectedCallback() {
        try{
            this.contactOverviewScreen = true;
            this.showSpinner = false;
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }

    }

    /*       
    * @author      : Coforge
    * @date        : 29/12/2022
    * @description : W-002861/W-002879: Method called onclick event + icon button for Licence Contact section
    * @return      : None
    * @param       : None
    */  
    @api
    handleLicenceIconClick(event) {
        try{
            this.template.querySelector('[data-id="invalidRecordMessage"]').innerHTML ='';      //Removing validation message from UI
            this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');  //Removing error class from UI
            this.showSpinner=true;
            if(event==null){
                this.iconName='utility:add';
                this.template.querySelector('[data-id="licencebuttonIcon"]').iconName='utility:add';
                if(this.isLicenceContactChanged){
                    this.licenceContactList='';
                }
                this.openLicenceContactSection = false;
                this.showSpinner=false;
            }
            else if( event!=null && this.template.querySelector('[data-id="licencebuttonIcon"]').iconName=='utility:add'){
                this.template.querySelector('[data-id="licencebuttonIcon"]').iconName='utility:dash';
                //W-002879 start
                if(this.lisenseedetail != null && this.lisenseedetail!=undefined && this.licenceContactList==''){
                    getLicenceContactOrgRoles({ selectedLicenseeId: this.lisenseedetail.Licensee_or_Organisation__r.Id})
                        .then((result) => {
                                this.licenceContactList = result;
                                this.showSpinner=false;
                        })
                        .catch((error) => {
                            window.location.href='/apex/licensingcomerror';
                        });
                }else{
                    this.showSpinner=false;
                }
                //W-002879 End
                this.openLicenceContactSection=true;
            }else if(event!=null && this.template.querySelector('[data-id="licencebuttonIcon"]').iconName=='utility:dash'){
                this.showSpinner=false;
                this.template.querySelector('[data-id="licencebuttonIcon"]').iconName='utility:add';
                this.openLicenceContactSection = false;
            }
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        } 
    }

    /*       
    * @author      : Coforge
    * @date        : 29/12/2022
    * @description : W-002861/W-002890: Method called onclick event + icon button for payment Contact section
    * @return      : None
    * @param       : None
    */
    @api  
    handlePaymentIconClick(event) {
        try{
            this.template.querySelector('[data-id="invalidRecordMessage"]').innerHTML ='';      //Removing validation message from UI
            this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');  //Removing error class from UI
            this.showSpinner=true;
            if(event==null){
                this.iconName='utility:add';
                this.template.querySelector('[data-id="paymentbuttonIcon"]').iconName='utility:add';
                if(this.isLicenceContactChanged){
                    this.paymentContactList='';
                }
                this.openPaymentContactSection = false;
                this.showSpinner=false;
            }
            else if(event!=null && this.template.querySelector('[data-id="paymentbuttonIcon"]').iconName=='utility:add' ){
                this.template.querySelector('[data-id="paymentbuttonIcon"]').iconName='utility:dash';
                //W-002879 start
                if(this.lisenseedetail != null && this.lisenseedetail!=undefined && this.paymentContactList==''){
                    getPaymentContactOrgRoles({ selectedLicenseeId: this.lisenseedetail.Licensee_or_Organisation__r.Id})
                        .then((result) => {
                                this.paymentContactList = result;
                                this.showSpinner=false;
                        })
                        .catch((error) => {
                            window.location.href='/apex/licensingcomerror';                           
                        });
                }else{
                    this.showSpinner=false;
                }
                //W-002879 End
                this.openPaymentContactSection=true;
            }else if(event!=null && this.template.querySelector('[data-id="paymentbuttonIcon"]').iconName=='utility:dash'){
                this.showSpinner=false;
                this.template.querySelector('[data-id="paymentbuttonIcon"]').iconName='utility:add';
                this.openPaymentContactSection = false;
            }
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 02/01/2023
    * @description : W-002880 : Method called on click of 'Create new contact' button
    * @return      : None
    * @param       : None
    */
    openLicenceContactPopup(){
        try{
            this.template.querySelector('[data-id="invalidRecordMessage"]').innerHTML ='';      //Removing validation message from UI
            this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');  //Removing error class from UI
            this.dispatchEvent(new CustomEvent("openlicencecontactpopup",{
                detail:{
                    selectedContact : null,                 // Passing null to open create contact popup
                    selectedContactType :'Licence Contact', // Passing the Contact's type
                    selectedLicenseeId: this.lisenseedetail.Licensee_or_Organisation__c //Passing Licensee ID to create org role
                }
            }));
            this.isLicenceContactChanged = true;
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 02/01/2023
    * @description : W-002890 : Method called on click of 'Create new contact' button
    * @return      : None
    * @param       : None
    */
    openPaymentContactPopup(){
        try{
            this.template.querySelector('[data-id="invalidRecordMessage"]').innerHTML ='';      //Removing validation message from UI
            this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');  //Removing error class from UI
            this.dispatchEvent(new CustomEvent("openlicencecontactpopup",{
                detail:{
                    selectedContact : null,                 // Passing null to open create contact popup
                    selectedContactType :'Payment contact', // Passing the Contact's type
                    selectedLicenseeId: this.lisenseedetail.Licensee_or_Organisation__c //Passing Licensee ID to create org role
                }
            }));
            this.isLicenceContactChanged = true;
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 02/01/2023
    * @description : W-002882 : Method called on click of 'Edit details' button for Licence Contact
    * @return      : None
    * @param       : event
    */
    openEditLicenceContactPopup(event){
        try{
            this.template.querySelector('[data-id="invalidRecordMessage"]').innerHTML ='';          //Removing validation message from UI
            this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');      //Removing error class from UI
            this.selectGridValidation = "";
            this.gridSelected = null;
            var isValidated = true;
            var gridName = event.target.value;
            for(let i=0; i<this.licenceContactList.length; i++){
                if(this.licenceContactList[i].Id == gridName){
                    this.selectedContact = this.licenceContactList[i];
                }
            }
            var orgRoleTypeList = (this.selectedContact.Types__c).split(';');
            if(!(
                ((this.selectedContact.Types__c == 'Licence Contact') && (orgRoleTypeList.length==1)) || 
                (orgRoleTypeList.includes('Licence Contact')  && orgRoleTypeList.includes('Licence Bill/Account Contact') && orgRoleTypeList.length==2)
                )){
                    this.setInvalidRecordMessage();    // To show the validation message on the UI
                    isValidated = false;
                    this.gridSelected = null;
                    this.scrollToTop(); // To scroll to top
            }
            if(isValidated){
                this.dispatchEvent(new CustomEvent("openlicencecontactpopup",{
                detail:{
                    selectedContact : this.selectedContact,
                    selectedContactType :'Licence Contact' // Passing the Contact's type
                }
                }));
                this.isLicenceContactChanged = true;
            }
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 13/01/2023
    * @description : W-002891 : Method called on click of 'Edit details' button for Payment Contact
    * @return      : None
    * @param       : event
    */
    openEditPaymentContactPopup(event){
        try{
            this.template.querySelector('[data-id="invalidRecordMessage"]').innerHTML ='';      //Removing validation message from UI
            this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');  //Removing error class from UI
            this.selectGridValidation = "";
            this.gridSelected = null;
            var isValidateContact = true;
            var gridName = event.target.value;
            for(let i=0; i<this.paymentContactList.length; i++){
                if(this.paymentContactList[i].Id == gridName){
                    this.selectedContact = this.paymentContactList[i];
                }
            }
            var orgRoleTypeList = (this.selectedContact.Types__c).split(';');
            if(!(
                ((this.selectedContact.Types__c == 'Licence Bill/Account Contact') && (orgRoleTypeList.length==1)) || 
                (orgRoleTypeList.includes('Licence Contact') && orgRoleTypeList.includes('Licence Bill/Account Contact') && orgRoleTypeList.length==2)
                )){
                    this.setInvalidRecordMessage();    // To show the validation message on the UI
                    isValidateContact = false;
                    this.gridSelected = null;
                    this.scrollToTop(); // To scroll to top
            }
            if(isValidateContact){
                this.dispatchEvent(new CustomEvent("openlicencecontactpopup",{
                    detail:{
                        selectedContact : this.selectedContact, //Passing Payment Contact org role 
                        selectedContactType :'Payment contact' // Passing the Contact's type
                    }
                }));
                this.isLicenceContactChanged = true;
            }
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 05/01/2023
    * @description : W-002892 : Method called on click of 'Add Contact Role' button.
    * @return      : None
    * @param       : event
    */
    handleAddContactModal(event){
        try{
            this.template.querySelector('[data-id="invalidRecordMessage"]').innerHTML ='';      //Removing validation message from UI
            this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');  //Removing error class from UI
            this.contactType =  event.target.name;
            var gridName = event.target.value;
            if(this.contactType.includes('licence contact')){
                for(let i=0; i<this.licenceContactList.length; i++){
                    if(this.licenceContactList[i].Id == gridName){
                        this.selectedContact = this.licenceContactList[i];
                        this.modalContainer=true;
                    }
                }
            }else if(this.contactType.includes('payment contact')){
                for(let i=0; i<this.paymentContactList.length; i++){
                    if(this.paymentContactList[i].Id == gridName){
                        this.selectedContact = this.paymentContactList[i];
                        this.modalContainer=true;
                    }
                }            
            }
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }
    }

    closeModalAction(event){
        try{
            this.showSpinner = true;
            this.modalContainer=false;
            this.isLicenceContactChanged = event.detail.isContactUpdated;
            if((this.contactType.includes('licence contact') ||this.contactType.includes('payment contact')) && this.isLicenceContactChanged){
                this.handleLicenceIconClick(null);
                this.handlePaymentIconClick(null);
            }
            this.showSpinner = false;
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 05/01/2022
    * @description : W-002882: Method called when an invalid record is edited. It sets the error message on the UI
    * @return      : None
    * @param       : None
    */
    setInvalidRecordMessage(){
        try{
            // Adding error message on UI
            this.template.querySelector('[data-id="errorMessage"]').classList.add('error');
            // Appending the error message on the UI section with data-id as invalidRecordMessage
            var pTagFirst = document.createElement('span');
            pTagFirst.innerHTML = "This contact record is possibly associated with other licensing products. Please contact ";
            this.template.querySelector('[data-id="invalidRecordMessage"]').appendChild(pTagFirst);        
            var aTag = document.createElement('a');
            aTag.setAttribute('href',"https://ofcomlive.my.salesforce-sites.com/formentry/SlepWebForm");
            aTag.setAttribute('target',"_blank");
            aTag.innerHTML = "spectrum licensing";
            this.template.querySelector('[data-id="invalidRecordMessage"]').appendChild(aTag);
            var pTagSecond = document.createElement('span');
            pTagSecond.innerHTML = " to update these details.";
            this.template.querySelector('[data-id="invalidRecordMessage"]').appendChild(pTagSecond);
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 02/11/2022
    * @description : W-002882 : Method called to scroll tp the top of the page when any error occurs
    * @return      : None
    * @param       : None
    */
    scrollToTop(){
        try{
            var scrollOptions = {
                left: 0,
                top: 400,
                behavior: 'smooth'
            }
            window.scrollTo(scrollOptions);
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 02/11/2022
    * @description : W-002899 : Method called on press of space button
    * @return      : None
    * @param       : None
    */
    spacekeyevent(e){
       if (e.key == " " || e.code == "Space" ||  e.keyCode == 32 )
        {
            if(e.target.name=='licencebuttonIcon'){
                this.template.querySelector('[data-id="licencebuttonIcon"]').click();
            }else if(e.target.name=='paymentbuttonIcon'){
                this.template.querySelector('[data-id="paymentbuttonIcon"]').click();
            }
            
            //this.template.querySelector('[data-id="licencebuttonIcon"]').iconName='utility:add';
            //this.onkeypress = true;
            //e.key == " " || e.code == "Space" ||  e.keyCode == 32 ||
        }
    }

}