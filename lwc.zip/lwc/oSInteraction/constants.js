import REQUIRED_STAKEHOLDER_PARICPANT_LABEL from '@salesforce/label/c.Required_Interaction_Stakeholder_Participant';

import INTERACTION_SAVED_SUCCESS from '@salesforce/label/c.InteractionSavedSuccess';
const FIELD_CUSTOM_VALIDATION_EXCEPTION = 'FIELD_CUSTOM_VALIDATION_EXCEPTION';
const STAKEHOLDER_ORGANIZATION = 'Stakeholder Organization';
const STAKEHOLDER_PARTICIPANT = 'Stakeholder Participant';
import COMMON_ERROR from '@salesforce/label/c.CommonError';
/*33079-Auto-populate Stakeholder Organisation Name / Stakeholder Business Account*/
const SEARCH_ACCOUNT_METADATANAME = 'SearchAccount';
const InteractionObjectApiName = 'Interaction__c';
const OFCOM_PARTICIPANT = 'Ofcom Participant';
const CREATE_INTERACTION = 'Create Interaction';
const INTERACTION_ID_PREFIX = 'a8O';
const DISMISSABLE = 'dismissable';
const MEETING_ID_PREFIX = 'a8F';
const ACCOUNT_ID_PREFIX = '001';
const CASE_ID_PREFIX = '500';
const SEARCH_LABEL = 'Search';
const SUBMIT_LABEL = 'Submit';
const CANCEL_LABEL = 'Cancel';
const EXCEPTION = '_EXCEPTION';
const LOADING = 'Loading';
const SUCCESS = 'success';
const ERROR = 'error';

export {
    REQUIRED_STAKEHOLDER_PARICPANT_LABEL,
    FIELD_CUSTOM_VALIDATION_EXCEPTION,
    SEARCH_ACCOUNT_METADATANAME,
    INTERACTION_SAVED_SUCCESS,
    InteractionObjectApiName,
    STAKEHOLDER_ORGANIZATION,
    STAKEHOLDER_PARTICIPANT,
    INTERACTION_ID_PREFIX,
    ACCOUNT_ID_PREFIX,
    MEETING_ID_PREFIX,
    CREATE_INTERACTION,
    OFCOM_PARTICIPANT,
    CASE_ID_PREFIX,
    SEARCH_LABEL,
    SUBMIT_LABEL,
    CANCEL_LABEL,
    COMMON_ERROR,
    DISMISSABLE,
    EXCEPTION,
    SUCCESS,
    LOADING,
    ERROR
};