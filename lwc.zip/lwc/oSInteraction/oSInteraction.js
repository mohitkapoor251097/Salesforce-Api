import { LightningElement, api, wire } from 'lwc';
import submitInteraction from '@salesforce/apex/OS_InteractionController.submitInteraction';
import getRelatedListData from '@salesforce/apex/OS_InteractionController.getRelatedListData';
import getRelatedList from '@salesforce/apex/OS_InteractionController.getRelatedList';
import is_OS_Senior_Permission from '@salesforce/customPermission/OS_Senior_Permission';
import is_OS_Standard_Permission from '@salesforce/customPermission/OS_Standard_Permission';
import is_Senior_permission from '@salesforce/customPermission/Senior_permission';
import is_Standard_permission from '@salesforce/customPermission/Standard_permission';

import { getRecord, getFieldValue } from "lightning/uiRecordApi";
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';

import stakeholderParticipantsLimitError from '@salesforce/label/c.Stakeholder_Participants_Limit_error';
import stakeholderParticipantsLimit from '@salesforce/label/c.Stakeholder_Participants_Limit';
import ofcomParticipantsLimitError from '@salesforce/label/c.Ofcom_Participants_Limit_error';
import OS_Missing_Required_Field from '@salesforce/label/c.OS_Missing_Required_Field';
import ofcomParticipantsLimit from '@salesforce/label/c.Ofcom_Participants_Limit';

/* ADO 28374 Added Existing compliance field labels */
import OS_Compliance_Concern from '@salesforce/label/c.OS_Compliance_Concern';
import OS_Illegal_Harms from '@salesforce/label/c.OS_Illegal_Harms';
import OS_Legal_Harms from '@salesforce/label/c.OS_Legal_Harms';
import OS_Other from '@salesforce/label/c.OS_Other';

import { 
    REQUIRED_STAKEHOLDER_PARICPANT_LABEL,
    FIELD_CUSTOM_VALIDATION_EXCEPTION,
    SEARCH_ACCOUNT_METADATANAME,
    INTERACTION_SAVED_SUCCESS,
    InteractionObjectApiName,
    STAKEHOLDER_ORGANIZATION,
    STAKEHOLDER_PARTICIPANT,
    CREATE_INTERACTION,
    OFCOM_PARTICIPANT,
    INTERACTION_ID_PREFIX,
    ACCOUNT_ID_PREFIX,
    MEETING_ID_PREFIX,
    CASE_ID_PREFIX,
    CANCEL_LABEL,
    COMMON_ERROR,
    SUBMIT_LABEL,
    DISMISSABLE,
    EXCEPTION,
    LOADING,
    SUCCESS,
    ERROR
} from './constants';
/* ADO 28374 Added new compliance fields*/
const FIELDS = ["Interaction__c.Name", "Meeting__c.Compliance_Concern__c", "Meeting__c.Legal_Harm__c",
                 "Meeting__c.Illegal_Harm__c", "Meeting__c.Other_harm__c"];

export default class OSInteraction extends NavigationMixin(LightningElement) {

    @api recordId = '';
    shOrganizationCriteria = 'Interaction__c = \'@recordId@\' AND StakeholderType__c = \'Stakeholder Organization\'';
    shParticipantCriteria = 'Interaction__c = \'@recordId@\' AND StakeholderType__c = \'Stakeholder Participant\'';
    ofcomParticipantCriteria = 'Interaction__c = \'@recordId@\' AND StakeholderType__c = \'Ofcom Participant\'';
    
    interactionObjectApiName = InteractionObjectApiName;
    headerTitle = CREATE_INTERACTION;
    submitLabel = SUBMIT_LABEL;
    cancelLabel = CANCEL_LABEL;
    loadingLabel = LOADING;
    showLoading = false;
    refreshData = true;
    readOnly = false;
    stakeHolders = [];
    stakeholderorg;
    
    interactionRecordId;
    meetingRecordId;
    caseRecordId;
    _parentId;

    /* ADO 28374 Added new compliance fields start*/
    label = {
        OS_Compliance_Concern,
        OS_Illegal_Harms,
        OS_Legal_Harms,
        OS_Other
    };

    stakeholderOrganization = [];
    setOfStakeholderOrg = new Set();
    isPreventRecursion = false;

    isComplianceConcern = false;
    isLegalHarm = false;
    isIllegalHarm = false;
    isOtherHarm = false;

    other_Compliance_Concern__Field;
    violence_against_women__Field;
    child_Sexual_Abuse__Field;
    safety_Functions__Field;
    lH_SubCat__Field;
    iH_Other__Field;
    general__Field;
    other__Field;
    /* ADO 28374 Added new compliance fields end*/

    //Getter for parentId
    @api
    get parentId() {
        return this._parentId;
    }
    //Setter for parentId
    set parentId(value) {
        this._parentId = value;
        if(this._parentId && this._parentId.substring(0,3) === CASE_ID_PREFIX){
            this.caseRecordId = this._parentId;
        }else if(this._parentId && this._parentId.substring(0,3) === MEETING_ID_PREFIX){
            this.meetingRecordId = this._parentId;
        }else if(this._parentId && this._parentId.substring(0,3) === INTERACTION_ID_PREFIX){
            this.interactionRecordId = this._parentId;
        }
    }

        /*
    * @author      : Coforge
    * @date        : 11/04/2024
    * @description : This method is used to set field value on isComplianceConcern change.
    * @params      : none
    * @return      : none
    */
    handleComplianceConcernChange(event){
        this.isComplianceConcern = event.target.value;

        if(!this.isComplianceConcern){
            this.general__Field = '';
            this.safety_Functions__Field = '';
            this.other_Compliance_Concern__Field = '';
        }
        
    }
    
    /*
    * @author      : Coforge
    * @date        : 11/04/2024
    * @description : This method is used to set field value on isLegalHarm change.
    * @params      : none
    * @return      : none
    */
    handleLegalHarmChange(event){
        this.isLegalHarm = event.target.value;
        if(!this.isLegalHarm){
            this.lH_SubCat__Field = '';
        }
    }

    /*
    * @author      : Coforge
    * @date        : 11/04/2024
    * @description : This method is used to set field value on isIllegalHarm change.
    * @params      : none
    * @return      : none
    */
    handleIllegalHarmChange(event){
        this.isIllegalHarm = event.target.value;
        if(!this.isIllegalHarm){
            this.child_Sexual_Abuse__Field = '';
            this.violence_against_women__Field = '';
            this.iH_Other__Field = '';
        }
    }

    /*
    * @author      : Coforge
    * @date        : 11/04/2024
    * @description : This method is used to set field value on isOtherHarm change.
    * @params      : none
    * @return      : none
    */
    handleOtherHarmChange(event){
        this.isOtherHarm = event.target.value;
        if(!this.isOtherHarm){
            this.other__Field = '';
        }
    }

    /*
     * @author      : Coforge
     * @date        : 31/01/2024
     * @description : This @wire method is fetching the Interaction info
     * @params1      : interactionId
     * @params2      : FIELDS
     * @return      : Interaction
     */
    @wire(getRecord, {
        recordId: "$recordId",
        fields: FIELDS
      })
      getInteractionRecord( {data, error} ) {
        if( data && this.refreshData) {
            this.headerTitle = 'Edit ' + data.fields.Name.value;
            /* ADO 28374 Added new compliance fields*/
            this.isComplianceConcern =  data.fields.Compliance_Concern__c.value;
            this.isLegalHarm =  data.fields.Legal_Harm__c.value;
            this.isIllegalHarm =  data.fields.Illegal_Harm__c.value;
            this.isOtherHarm =  data.fields.Other_harm__c.value;
        }
    }

    /*
     * @author      : Coforge
     * @date        : 31/01/2024
     * @description : This @wire method is fetching the stakeholdlers or interaction child records
     * @params      : interactionId
     * @return      : stakeholders
     */
    @wire(getRelatedListData, { recordId: '$recordId' })
    getInteractionData( {data, error} ) {
        if( data && this.refreshData) {
            const temp = [];
            for(const obj of data.stakeholderData){
                this.addStakeholderData(obj,temp); //stakeholder type data mapping
            }
           this.stakeHolders = temp;
        }
    }

    /*
     * @author      : Coforge
     * @date        : 07/02/2024
     * @description : Method is checking whether current user has OS Senior/Standard custom permission.
     * @params      : none
     * @return      : Boolean
     */
    get isHasOSPermission() {
        if(is_OS_Senior_Permission || is_OS_Standard_Permission){
            return true;
        }
        else if( !is_OS_Senior_Permission && !is_OS_Standard_Permission && !is_Senior_permission && !is_Standard_permission){
            return true;
        }
        else{
            return false;
        }
        
    }

    /*
     * @author      : Coforge
     * @date        : 07/02/2024
     * @description : This method is checking whether current user has SM Senior/Standard custom permission.
     * @params      : none
     * @return      : Boolean
     */
    get isHasSMPermission() {
        if(is_Senior_permission || is_Standard_permission){
            return true;
        }
        else if( !is_OS_Senior_Permission && !is_OS_Standard_Permission && !is_Senior_permission && !is_Standard_permission){
            return true;
        }
        else{
            return false;
        }
    }

    /*
     * @author      : Coforge
     * @date        : 31/01/2024
     * @description : This @wire method is fetching the stakeholdlers related with Interaction
     * @params      : obj,temp1
     * @return      : none
     */
    addStakeholderData(obj,temp){
        let temporg = {'Id':'','Account__r.Name':'','Account__c':'','StakeholderType__c':'','Interaction__c':'','Contact__c':'','Account_PA__c':''};
        temporg['Account__r.Name'] = obj.Account__r.Name;
        temporg.Account__c = obj.Account__r.Id;
        temporg.StakeholderType__c = obj.StakeholderType__c;
        temporg.Contact__c = obj.Contact__c;
        temporg.Account_PA__c = obj.Account_PA__c;
        temporg.Interaction__c = obj.Interaction__c;
        temporg.Id = obj.Id;
        temp.push(temporg);
    }

    /*
     * @author      : Coforge
     * @date        : 31/07/2024
     * @description : ConnectedCallback
     * @params      : 
     * @return      : none
     */
    connectedCallback() {
        setTimeout(() => {
            if(this.readOnly == false && this._parentId != '' && this._parentId != undefined && 
            this.isPreventRecursion == false){
            this.addAutoStakeOrganization();
            this.isPreventRecursion = true;
            }
        }, 3000);
    }
    /*
     * @author      : Coforge
     * @date        : 31/01/2024
     * @description : handle onload method of lds
     * @params      : 
     * @return      : none
     */
    handleOnLoad(){
         /*33079-Auto-populate Stakeholder Organisation Name / Stakeholder Business Account*/
        /*try{
            /*33079-Auto-populate Stakeholder Organisation Name / Stakeholder Business Account*/
            /*if(this.readOnly == false &&  this._parentId != '' && this._parentId != undefined && 
               !this.setOfStakeholderOrg.has(this._parentId)){
                this.addAutoStakeOrganization();
            }
        } catch(e){
            console.log(e);
        }*/
    }

    /*
     * @author      : Coforge
     * @date        : 12/06/2024
     * @description : This method is used to auto add stakeholder organization if create meeting record from account record.
     * @params      : 
     * @return      : none
     */
    /*33079-Auto-populate Stakeholder Organisation Name / Stakeholder Business Account*/
    addAutoStakeOrganization(){
        if(this._parentId.substring(0,3) === ACCOUNT_ID_PREFIX ){
            let tempStakeOrganization = [];

            getRelatedList({
					metadataRecordName: SEARCH_ACCOUNT_METADATANAME,
					filterCriteria: 'Id = \''+ this._parentId +'\''
				}).then((result) => {
					try{
						if(result && result.length > 0 && !this.setOfStakeholderOrg.has(this._parentId)) {
                            //transform the data in required child component format
							let obj = this.mapStakeholderOrgData(result[0]);
                                
                                //Add the object and assign it to osRelatedList Child component
                                tempStakeOrganization.push(obj);
                                this.stakeholderOrganization = tempStakeOrganization;

                                this.stakeHolders.push(this.transformAccountObject(obj));
                                //Add parentId in set to avoid multiple run
                                this.setOfStakeholderOrg.add(this._parentId);
						}
					} catch(e){
						this.showNoRecordsToast(COMMON_ERROR,ERROR,DISMISSABLE);
					}
				})
				.catch((error) => {
					console.log(error);
					this.showNoRecordsToast(COMMON_ERROR,ERROR,DISMISSABLE);
				});
        }
    }

    /*
     * @author      : Coforge
     * @date        : 31/01/2024
     * @description : This method will execute on click of submit button of create meeting page when meeting is saved.
     * @params      : NA
     * @return      : NA
     */
    handleSuccess(event) {
        this.recordId = event.detail.id;
        
        //Validation Check
        if(this.validateData()){
            return;
        }
        this.submitInteractions(event.detail.id);
    }

    /*
     * @author      : Coforge
     * @date        : 31/01/2024
     * @description : This method will execute on click of submit button of create meeting page when meeting is saved.
     * @params      : NA
     * @return      : NA
     */    
    submitInteractions(recordId) {
        this.showLoading = true
        
        const rows = [];
        if (this.stakeHolders.length == 0 ){
            rows.push(this.stakeholderorg);
            this.stakeHolders = rows;
        }
        
        submitInteraction({ interactionId: this.recordId, wrapper : this.stakeHolders})
            .then((result) => {
                if (result==SUCCESS){
                    this.showNoRecordsToast(INTERACTION_SAVED_SUCCESS,SUCCESS,DISMISSABLE);   
                    window.location.assign(window.location.origin + '/'+recordId);
                    this.showLoading = false;
                }else{
                    this.showNoRecordsToast(COMMON_ERROR,ERROR,DISMISSABLE);
                    this.showLoading = false;
                }
            })
            .catch((error) => {
                this.showLoading = false;
                let errMsg = error.body.message;
                if(errMsg != undefined && errMsg.includes(FIELD_CUSTOM_VALIDATION_EXCEPTION)){
                    errMsg = errMsg.substr(errMsg.indexOf(EXCEPTION)+11);
                    errMsg = errMsg.slice(0, errMsg.indexOf(": ["));
                    this.showNoRecordsToast(errMsg,ERROR,DISMISSABLE);
                }else{
                    this.showNoRecordsToast(COMMON_ERROR,ERROR,DISMISSABLE);
                }
            });
    }

    /*
     * @author      : Coforge
     * @date        : 31/01/2024
     * @description : This method is showing toast when there is error on submit.
     * @params      : none
     * @return      : none
     */
    handleError(event) {
        if(event.detail.detail!=null){
            this.showNoRecordsToast(event.detail.detail,ERROR,DISMISSABLE);
        }
    }

    /*
    * @author      : Coforge
    * @date        : 29/02/2024
    * @description : This method is used to give validation
    * @params      : none
    * @return      : none
    */
    validateFields() {
        let isValid = false;
        let inputFields = this.template.querySelectorAll('lightning-input-field');
        inputFields.forEach(inputField => {
            if (!inputField.reportValidity() && isValid == false) {
                isValid = true;
                inputField.scrollIntoView();
                inputField.focus();
            }
        });
        if(isValid){
            this.showNoRecordsToast(OS_Missing_Required_Field,ERROR,DISMISSABLE);
            return;
        }
    }

    /*
     * @author      : Coforge
     * @date        : 15/04/2024
     * @description : This method is to handle Validation for compliance and harm field
     * @params      : none
     * @return      : Boolean
     */
    updateComplianceHarmsFields(inputFields){
        // ADO 28374 Blank related field if Compliance_Concern__c is false
        if(!this.isComplianceConcern){
            inputFields.General__c = '';
            inputFields.Safety_Functions__c = '';
            inputFields.Other_Compliance_Concern__c = '';
        }
        //ADO 28374 Blank related field if Illegal_Harm__c is false
        if(!this.isIllegalHarm){
            inputFields.Child_Sexual_Abuse__c = '';
            inputFields.Violence_against_women__c = '';
            inputFields.IH_Other__c = '';
        }
        //ADO 28374 Blank related field if Legal_Harm__c is false
        if(!this.isLegalHarm){
            inputFields.LH_SubCat__c = '';
        }
        //ADO 28374 Blank related field if Other_harm__c is false
        if(!this.isOtherHarm){
            inputFields.Other__c = '';
        }
    }

    /*
     * @author      : Coforge
     * @date        : 31/01/2024
     * @description : This method is to handle onSubmit
     * @params      : none
     * @return      : Boolean
     */
    handleSubmit(event){
        this.refreshData = false;


        if((this.recordId ==undefined || this.recordId =='') && this.stakeHolders.length !==0){
            
            event.stopPropagation();
            event.preventDefault();

            let ofcomParticipants=0;
            let stakeholderParticipants = 0;

            for(let i=0;i<this.stakeHolders.length; i++){
                if(this.stakeHolders[i].StakeholderType__c == STAKEHOLDER_PARTICIPANT){
                    stakeholderParticipants +=1;
                }
                else if(this.stakeHolders[i].StakeholderType__c == OFCOM_PARTICIPANT){
                    ofcomParticipants +=1;
                }
            }
            if(ofcomParticipants > Number(ofcomParticipantsLimit)){
                this.showNoRecordsToast(ofcomParticipantsLimitError,ERROR,DISMISSABLE);
                return;
            }
            else if(stakeholderParticipants > Number(stakeholderParticipantsLimit)){
                this.showNoRecordsToast(stakeholderParticipantsLimitError,ERROR,DISMISSABLE);
                return;
            }
            else{

                //Validation Check
                if(this.validateData()){
                    return;
                }
                const inputFields = event.detail.fields;
                this.updateComplianceHarmsFields(inputFields);

                this.template.querySelector('[data-id="createInteractionForm"]').submit(inputFields);
            }

        }else{

            //Validation Check
            if(this.validateData()){
                return;
            }
            
            const inputFields = event.detail.fields;
            this.updateComplianceHarmsFields(inputFields);

            this.template.querySelector('[data-id="createInteractionForm"]').submit(inputFields);
        }  
    }

    

    /*
     * @author      : Coforge
     * @date        : 31/01/2024
     * @description : This method is to handle Validation for stakeholder Participant
     * @params      : none
     * @return      : Boolean
     */
    validateData(){
        let isDisplayValidation = false;
        let stakeholderParicipant = [];

        if(this.stakeHolders){
            for(let stakeholer of this.stakeHolders){
                if(stakeholer && stakeholer.StakeholderType__c == STAKEHOLDER_PARTICIPANT){
                    stakeholderParicipant.push(stakeholer);
                }
            }
        }

        if(stakeholderParicipant.length == 0){
            isDisplayValidation = true;
            this.showNoRecordsToast(REQUIRED_STAKEHOLDER_PARICPANT_LABEL,ERROR,DISMISSABLE);
            return isDisplayValidation;
        }
        return isDisplayValidation;
    }

    /*
     * @author      : Coforge
     * @date        : 31/01/2024
     * @description : This method will execute when new stakeholder Organizations are added to the page.
     * @params      : event
     * @return      : NA
     */
    /*33079-Auto-populate Stakeholder Organisation Name / Stakeholder Business Account*/
    addStakeholderOrganizations(event) {
        
        try{
            let mapOfStakeHolders = new Map(); 
            const temp = [];

            for(const element of this.stakeHolders) {
                if(element.Contact__c != '' && element.Contact__c != undefined){
                    mapOfStakeHolders.set(element.Contact__c+element.StakeholderType__c,element);
                }
                if(element.Account_PA__c != '' && element.Account_PA__c != undefined){
                    mapOfStakeHolders.set(element.Account_PA__c+element.StakeholderType__c,element);
                }
                if((element.Account_PA__c == undefined || element.Account_PA__c == '') && (element.Contact__c == undefined || element.Contact__c == '') && 
                    !mapOfStakeHolders.has(element.Account__c)){
                    mapOfStakeHolders.set(element.Account__c+element.StakeholderType__c,element);
                }
            }

            if(event.detail.data) { 
                        
                for(const obj of event.detail.data) {
                    let temporg = {'Account__r.Name':'','Account__c':'','StakeholderType__c':'','Interaction__c':'','Contact__c':'','Account_PA__c':''};
                    temporg['Account__r.Name'] = obj["Account__r.Name"];
                    temporg.Account__c = obj["Account__r.Id"];
                    temporg.StakeholderType__c = STAKEHOLDER_ORGANIZATION;
                    temporg.Interaction__c = this.recordId;
                    mapOfStakeHolders.set(temporg.Account__c+temporg.StakeholderType__c,temporg);
                }
                
                //Fill list from map
                if(mapOfStakeHolders.size > 0){
                    for(let obj of mapOfStakeHolders.values()){
                        temp.push(obj)
                    }
                }
                //Assign templist to server list
                this.stakeHolders = temp;
            }
            
        }catch(e){
            this.showNoRecordsToast(COMMON_ERROR,ERROR,DISMISSABLE);
        }
    }

    /*
     * @author      : Coforge
     * @date        : 31/01/2024
     * @description : This method will execute when new stakeholder participants are added to the page.
     * @params      : event
     * @return      : NA
     */
    addStakeholderParticipants(event) {
        try{
            const temp = [];

            for(const obj of this.stakeHolders){
                temp.push(obj);
            }

            if(event.detail.data) {           
                for(const obj of event.detail.data) {
                    let temporg = {'Account__r.Name':'','Account__c':'','StakeholderType__c':'','Interaction__c':'','Contact__c':'','Account_PA__c':''};
                    temporg['Account__r.Name'] = obj["Account__r.Name"];
                    temporg.Account__c = obj["Account__r.Id"];
                    temporg.StakeholderType__c = STAKEHOLDER_PARTICIPANT;

                    //Checking if Contact__r.Id having contactId or accountIds and then assign to accordingly
                    if(obj["Contact__r.Id"] && obj["Contact__r.Id"].substring(0,3) === ACCOUNT_ID_PREFIX){
                        temporg.Account_PA__c = obj["Contact__r.Id"];
                        temporg.Contact__c = '';
                        temporg['Contact__r.Id'] = '';
                    }else{
                        temporg.Contact__c = obj["Contact__r.Id"];
                    }
                    temporg.Interaction__c = this.recordId;
                    temp.push(temporg);
                }
                this.stakeHolders = temp;
            }
        }catch(e){
            this.showNoRecordsToast(COMMON_ERROR,ERROR,DISMISSABLE);
        }
    }

    /*
     * @author      : Coforge
     * @date        : 31/01/2024
     * @description : This method will execute when new ofcom participants are added to the page.
     * @params      : NA
     * @return      : NA
     */
    addOfcomParticipants(event) {
        try{
            const temp = [];

            for(const obj of this.stakeHolders){
                temp.push(obj);
            }

            if(event.detail.data) {           
                for(const obj of event.detail.data) {
                    let temporg = {'Account__r.Name':'','Account__c':'','StakeholderType__c':'','Interaction__c':'','Contact__c':''};
                    temporg['Account__r.Name'] = obj["Account__r.Name"];
                    temporg.Account__c = obj["Account__r.Id"];
                    temporg.StakeholderType__c = OFCOM_PARTICIPANT;
                    temporg.Contact__c = obj["Contact__r.Id"];
                    temporg.Interaction__c = this.recordId;
                    temp.push(temporg);
                }
                this.stakeHolders = temp;
            }
        }catch(e){
            this.showNoRecordsToast(COMMON_ERROR,ERROR,DISMISSABLE);
        }
    }

    /*
     * @author      : Coforge
     * @date        : 31/01/2024
     * @description : This method will be used to soft delete the stakeholders
     * @params      : event
     * @return      : NA
     */
    deleterecords(event){
        try{
            const rows = [];
            
            for(const element of this.stakeHolders) {
                if(event.detail.data.StakeholderType__c == STAKEHOLDER_ORGANIZATION
                && element.Account__c !== event.detail.data.Account__c){
                    rows.push(element);
                }
                else if(event.detail.data.StakeholderType__c ==STAKEHOLDER_PARTICIPANT
                && (element.Contact__c !== event.detail.data.Contact__c 
                || element.Account_PA__c !== event.detail.data.Account_PA__c)){
                    rows.push(element);
                }
                else if(event.detail.data.StakeholderType__c == OFCOM_PARTICIPANT
                && element.Contact__c !== event.detail.data.Contact__c){
                    rows.push(element);
                }
                else if(event.detail.data.StakeholderType__c != element.StakeholderType__c){
                    rows.push(element);
                }
                else if(event.detail.data.StakeholderType__c != OFCOM_PARTICIPANT &&
                event.detail.data.StakeholderType__c != STAKEHOLDER_ORGANIZATION && 
                event.detail.data.StakeholderType__c != STAKEHOLDER_PARTICIPANT && 
                element.Id !== event.detail.data.Id)  {
                    rows.push(element);
                }
                
                this.stakeHolders = rows;
            }
        }catch(e){
            this.showNoRecordsToast(COMMON_ERROR,ERROR,DISMISSABLE);
        }
    } 

    /*
     * @author      : Coforge
     * @date        : 31/01/2024
     * @description : To show the toast message for success and error 
     * @params      : title
     * @params      : variant
     * @params      : mode
     * @return      : NA
     */
    showNoRecordsToast(title,variant,mode) {
        const event = new ShowToastEvent({
            title: title,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(event);
    }

    /*
     * @author      : Coforge
     * @date        : 31/01/2024
     * @description : This method will execute on click of Cancel button and will redirect back to the recent list view.
     * @params      : event
     * @return      : NA
     */
    handleCancel(event) {
        this.navigateToRecentListView();
    }

    /*
     * @author      : Coforge
     * @date        : 31/01/2024
     * @description : This method will navigate user to the recently viewed Object list view.
     * @params      : NA
     * @return      : NA
     */
    navigateToRecentListView() {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: this.interactionObjectApiName,
                actionName: 'list'
            },
            state: { 
                filterName: 'Recent' 
            }
        });
    }

    /*
     * @author      : Coforge
     * @date        : 16/04/2024
     * @description : This method used to create stakeholder account object and assign the value and return the object
     * @params      : result
     * @return      : tempdetail
     */
    /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
    mapStakeholderOrgData(obj){
        let tempdetail = { 'Account__c':'' ,'Account__r.Name':'','Account__r.Address__c':'','StakeholderType__c':'','URL':'', 'displayName':''};
        tempdetail['Account__c'] = obj.Id;
        tempdetail['Account__r.Id'] = obj.Id;
        tempdetail['Account__r.Name'] = obj.Name;
        tempdetail['Account__r.Address__c'] = obj.Address__c;
        tempdetail['StakeholderType__c'] = STAKEHOLDER_ORGANIZATION;
        tempdetail['displayName'] = obj.Name;
        tempdetail['Account__r.OS_Business_Owner__c'] = obj.OS_Business_Owner__c;
        return tempdetail;
    }

    /*
     * @author      : Coforge
     * @date        : 16/04/2024
     * @description : This method used to create the object and assign the value and return the object
     * @params      : result
     * @return      : tempdetail
     */
    /*33079-Auto-populate Stakeholder Organisation Name / Stakeholder Business Account*/
    transformAccountObject(obj){
        let temporg = {'Account__r.Name':'','Account__c':'','StakeholderType__c':'','Meeting__c':'','Contact__c':''};
            temporg['Account__r.Name'] = obj["Account__r.Name"];
            temporg.Account__c = obj["Account__r.Id"];
            temporg.StakeholderType__c = obj["StakeholderType__c"];
            temporg.Account_PA__c = obj["Contact__r.Id"];
            temporg.Meeting__c = this.recordId;
            return temporg;
    }
}