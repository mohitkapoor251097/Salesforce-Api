/*********************************************************************
# File....................: osMultiSelectPicklist.js
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............: 20/11/2021
# Last Modified by........: Coforge
# Last Modified Date......: 
# Description.............: Used as a controller class of osMultiSelectPicklist component.
# Change Log..............: NA
**********************************************************************/

import { LightningElement, api, track } from 'lwc';

const VALUES_ARE_SELECTED = 'values are selected'

export default class OsMultiSelectPicklist extends LightningElement {

    @api values = [];
    @api picklistlabel = '';

    @track selectedvalues = [];

    showdropdown;

    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This method will execute on onMouseLeave event of multi select picklist.
     * @params      : NA
     * @return      : NA
     */
    handleleave() {
        let sddcheck= this.showdropdown;
        if(sddcheck){
            this.showdropdown = false;
            this.fetchSelectedValues();
        }
    }

    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This method will execute on load of mutliSelectPicklist component
     * @params      : NA
     * @return      : NA
     */
    connectedCallback() {
        this.values.forEach(element => element.selected 
                            ? this.selectedvalues.push(element.value) : '');
    }

    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This method is fetching the selected values of the dropdown.
     * @params      : NA
     * @return      : NA
     */
    fetchSelectedValues() {
        
        this.selectedvalues = [];
        //get all the selected values
        this.template.querySelectorAll('c-os-picklist-value-component').forEach(
            element => {
                if(element.selected){
                    console.log(element.value);
                    this.selectedvalues.push(element.value);
                }
            }
        );

        //refresh original list
        this.refreshOrginalList();
    }

    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This method is updating original dataset with the updated dataset after selection.
     * @params      : NA
     * @return      : NA
     */
    refreshOrginalList() {
        //update the original value array to shown after close
        const picklistvalues = this.values.map(eachvalue => ({...eachvalue}));
        picklistvalues.forEach((element, index) => {
            if(this.selectedvalues.includes(element.value)){
                picklistvalues[index].selected = true;
            }else{
                picklistvalues[index].selected = false;
            }
        });
        this.values = picklistvalues;
    }

    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This method will execute on click of picklist component and will show the data under dropdown.
     * @params      : NA
     * @return      : NA
     */
    handleShowdropdown(){
        let sdd = this.showdropdown;
        if(sdd){
            this.showdropdown = false;
            this.fetchSelectedValues();
        }else{
            this.showdropdown = true;
        }
    }
    
    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This method is returning the message to show on the picklist component.
     * @params      : NA
     * @return      : NA
     */
    get selectedmessage() {
        if(this.selectedvalues.length === 0) {
            return 'All ' + VALUES_ARE_SELECTED;
        }
        return this.selectedvalues.length + ' ' + VALUES_ARE_SELECTED;
    }
}