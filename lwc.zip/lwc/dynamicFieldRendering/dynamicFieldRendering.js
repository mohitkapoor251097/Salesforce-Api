import {api,LightningElement} from 'lwc';
import dateType from './dateType.html';
import textType from './textType.html';
import numericalType from './numericalType.html';

export default class DynamicFieldRendering extends LightningElement {
    @api fieldValue;
    @api fieldLabel;
    @api fieldType;
    @api fieldName;
    @api isEditable;
    @api dateOutputValue;

    render(){
        if(this.fieldType){
            switch(this.fieldType){
                case 'currency':
                    return currencyType;
                case 'DATE':
                    return dateType;
                case 'email':
                    return emailType;
                case 'DOUBLE':
                    return numericalType;
                case 'phone':
                    return phoneType;
                case 'STRING':
                    return textType;
                case 'url':
                    return urlType;
                default:
                    return textType;
            }
        }
    }
    
    handleValueChange(event){
        const selectedEvent = new CustomEvent("valuechange", {
            detail:{
                    'fieldName': event.target.name,
                    'fieldValue': event.target.value
                    },
                    bubbles:true
            });
      this.dispatchEvent(selectedEvent);
    }

}