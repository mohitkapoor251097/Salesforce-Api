/*********************************************************************
# File....................: historyTracking.js
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............: 09/08/2022
# Last Modified by........: 
# Last Modified Date......: 
# Description.............: This is a JS Controller of 'historyTracking' Lightning component .   
# Lightning Component.....: historyTracking
# Change Log..............: v1.0 Initial Version 
**********************************************************************/
import { LightningElement, track, api } from 'lwc';
import getFilteredHistoryRecords from '@salesforce/apex/HistoryTrackingController.getFilteredHistoryRecords';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';


/*
* @author      : Coforge
* @date        : 09/08/2022
* @description : This constant shows all the columns for the datatable for the report page.
* @params      : NA
* @return      : NA
*/
const columns = [
    {
        label: 'Date', fieldName: 'CreatedDate', type: 'date', sortable: true , typeAttributes:{day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}
    }, {
        label: 'Field', fieldName: 'Field_API_Name__c', sortable: true ,type: 'text'
    }, {
        label: 'User', fieldName: 'CreatedBy.Name',  sortable: true ,type: 'text'        
    }, {
        label: 'Original Value', fieldName: 'Old_Value__c', sortable: false ,type: 'text'
    }, {
        label: 'New Value', fieldName: 'New_Value__c', sortable: false ,type: 'text'
    }, {
        label: 'Title', fieldName: 'TitleName', sortable: false , type: 'url',
        typeAttributes: {label: { fieldName: 'Title__c' }, target: '_blank'} 
    }, {
        label: 'Source (Case No)', fieldName: 'CaseUrl', type: 'url', sortable: false ,
        typeAttributes: {label: { fieldName: 'Case__r.CaseNumber' }, target: '_blank'} 
    }
]



/*
* @author      : Coforge
* @date        : 09/08/2022
* @description : This constant shows all the columns for the datatable for the record page.
* @params      : NA
* @return      : NA
*/
const columnss = [
    {
        label: 'Date', fieldName: 'CreatedDate', type: 'date', sortable: false, typeAttributes:{day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}
    }, {
        label: 'Field', fieldName: 'Field_API_Name__c', type: 'text'
    }, {
        label: 'User', fieldName: 'CreatedBy.Name', type: 'text', sortable: false
    }, {
        label: 'Original Value', fieldName: 'Old_Value__c', type: 'text', sortable: false
    }, {
        label: 'New Value', fieldName: 'New_Value__c', type: 'text', sortable: false
    }
]

/*
* @author      : Coforge
* @date        : 19/08/2022
* @description : This constant shows all the headers and related fields data for the datatable export to csv.
* @params      : NA
* @return      : NA
*/
const exportHeaderMap = new Map([
    ['CreatedDate', 'Date'],
    ['Field_API_Name__c', 'Field'],
    ['CreatedBy.Name', 'User'],
    ['Old_Value__c', 'Original Value'],
    ['New_Value__c', 'New Value'],
    ['Title__c', 'Title'],
    ['Case__r.CaseNumber', 'Source (Case No)']
  ]);
  

/*
* @author      : Coforge
* @date        : 09/08/2022
* @description : This is the main class component.
* @params      : NA
* @return      : NA
*/
export default class HistoryTracking extends LightningElement {

    contents;
    isDatatable = true;
    showSearch = false;
    dataLengthExceeded = false;
    isVisible;
    isNoDataFound ;
    handleFilterDisabled = true;
    handleExportDisabled = true;
    @track error;
    @track data;
    @api sortedDirection = 'desc';
    @api sortedBy = 'CreatedDate';
    @track searchKey = '';
    @api recordId;
    @api startDate;
    @api endDate;
    @api searchTitle;
    @track allSelectedRows = [];
    @track page = 1; 
    @track items = []; 
    @track initialData = [];
    @track data = []; 
    @track columns; 
    @track startingRecord = 1;
    @track endingRecord = 0; 
    @track pageSize = 10; 
    @track totalRecountCount = 0;
    @track totalPage = 0;
    disableExport = true;
    isFirstPage = true;
    isLastPage = false;
    isPageChanged = false;
    initialLoad = true;
    date;
    dataSpinner ;
    value = 10;
    maxDataLength = 10000;
    parentObject = 'ContentVersion';

    /*
	* @author      : Coforge
	* @date        : 09/08/2022
	* @description : This function shows all the option values in the combobox for displaying the records per page in data table.
	* @params      : NA
	* @return      : Labels with its values.
	*/
    get options() {
        return [
            { label: '5', value: 5 },
            { label: '10', value: 10},
            { label: '25', value: 25},
            { label: '50', value: 50 }
        ];
    }
    
    /*
	* @author      : Coforge
	* @date        : 09/08/2022
	* @description : This function is called when the combobox rows per page is changed and calls the displayRecordPerPage method.
	* @params      : event
	* @return      : displayRecordPerPage
	*/
    handleChange(event) {
        this.page = 1;
        this.value = event.detail.value;
        //alert('This value =='+ this.value);
        this.pageSize = this.value;
        //alert(' pg sz'+ this.pageSize);
        this.displayRecordPerPage(this.page);
        this.isFirstPage = true;
        this.isLastPage = false;
        if(this.totalPage == this.page){
            this.isLastPage = true;
            
        }
    }

    /*
	* @author      : Coforge
	* @date        : 09/08/2022
	* @description : This function give the init functionality to the component and all the data, functions declared here will run on the page load.
	* @params      : NA
	* @return      : loadData function
	*/
    connectedCallback(){
        console.log('con rec id'+this.recordId);        
        
        if(this.recordId != null || this.recordId != undefined){
            this.loadData();
            console.log('load data');
            this.isVisible = false;
        }
        else if(this.recordId != null || this.recordId != '' || this.recordId != undefined){
            this.isVisible = true;
            this.isDatatable = false;
        }        
    }

    /*
	* @author      : Coforge
	* @date        : 09/08/2022
	* @description : This function is used to load the initial data.
	* @params      : NA
	* @return      : NA
	*/
    loadData(){
        var parmData=
            {
                recordId:this.recordId,
                sortBy:this.sortedBy,
                sortDirection:this.sortedDirection,
                createdDateFrom: this.startDate,
                createdDateTo : this.endDate,
                searchedTitle : this.searchTitle,
                parentObject : this.parentObject
            }; 
        return getFilteredHistoryRecords({ wrapper:parmData })
        .then((data) => {
            this.flattenData(data);
            console.log('length'+data.length);
            //this.contents=data;
            this.error = undefined;
            console.log(this.recordId);
            
        })
        .catch(error => {
            this.error = error;
            
        });
    }

    /*
	* @author      : Coforge
	* @date        : 09/08/2022
	* @description : This function checks for the filter fields if properly entered, it fetches the records from the controller class based on the filters.
	* @params      : NA
	* @return      : NA
	*/
    handleFilter() {
        this.dataSpinner= true;
        var today = new Date();
            this.date=today.toISOString();
            console.log(today.toISOString())
            
        var parmData=
            {
                recordId:this.recordId,
                sortBy:this.sortedBy,
                sortDirection:this.sortedDirection,
                createdDateFrom: this.startDate,
                createdDateTo : this.endDate,
                searchedTitle : this.searchTitle,
                parentObject : this.parentObject
            };    

        if(this.startDate > this.date || this.endDate > this.date){
            this.error= 'Start/End date should be today or less than today';
            this.showErrorNotification();
            this.dataSpinner = false;
        }
        else if(this.startDate > this.endDate ){
            this.error= 'Start date should be less than End date';
            this.showErrorNotification();
            this.dataSpinner = false;
        }
        else{

                        
            //getFilteredHistoryRecords({ recordId: this.recordId, sortBy: this.sortedBy, sortDirection: this.sortedDirection, createdDateFrom : this.startDate, createdDateTo: this.endDate , searchedTitle : this.searchTitle})
            getFilteredHistoryRecords({ wrapper:parmData })
            .then((data) => { 
                console.log('data.length'+data.length);
                if(data.length >= this.maxDataLength ){
                    this.dataLengthExceeded = true;
                    this.dataSpinner=false;
                    this.isDatatable = false;            
                    this.disableExport = true;
                    this.showSearch = false;
                }
                else if (data.length < this.maxDataLength){
                    this.dataLengthExceeded = false;
                    this.searchKey = '';
                    let tempHistoryList = []; 
                    this.dataSpinner = false;
                    data.forEach((record) => {
                        
                        let tempHistoryRec = Object.assign({}, record);
                        if(tempHistoryRec.Parent_Record_Id__c != undefined){ 
                        tempHistoryRec.TitleName = '/' + tempHistoryRec.Parent_Record_Id__c;
                        }
                        console.log(tempHistoryRec.TitleName); 
                        if(tempHistoryRec.Case__c != undefined){
                        
                        tempHistoryRec.CaseUrl = '/' + tempHistoryRec.Case__c;
                        }
                        tempHistoryList.push(tempHistoryRec);
                        
                    });                
                    
                    this.initialData = tempHistoryList;
                    this.processSearchRecords(tempHistoryList);
                    this.isFirstPage = true;
                    this.isLastPage = false;  
                    this.page = 1;    
                    if(this.page == this.totalPage){            
                        this.isLastPage = true;
                    }         
                }                
            })
        }
                
    }

    /*
	* @author      : Coforge
	* @date        : 09/08/2022
	* @description : This function is used to flatten the recieved data.
	* @params      : data
	* @return      : NA
	*/
    flattenData(data){
        
        let contentArray = [];
        
       for (let row of data) {
            // this const stroes a single flattened row. 
            const flattenedRow = {}
            
            // get keys of a single row — Name, Phone, LeadSource and etc
            let rowKeys = Object.keys(row); 
           
            //iterate 
            rowKeys.forEach((rowKey) => {
                
                //get the value of each key of a single row. John, 999-999-999, Web and etc
                const singleNodeValue = row[rowKey];
                
                //check if the value is a node(object) or a string
                if(singleNodeValue.constructor === Object){
                    
                    //if it's an object flatten it
                    this._flatten(singleNodeValue, flattenedRow, rowKey)        
                }else{
                    
                    //if it’s a normal string push it to the flattenedRow array
                    flattenedRow[rowKey] = singleNodeValue;
                }
                
            });
           
            //push all the flattened rows to the final array 
            contentArray.push(flattenedRow);
        }
        console.log('flatened array');
        this.contents=contentArray;
        console.log(contentArray);
        this.processRecords(contentArray);       
    
}

    /*
    * @author      : Coforge
    * @date        : 09/08/2022
    * @description : This function is used in flattenData function to flatten the rows and the nodeValue.
    * @params      : nodeValue, flattenedRow, nodeName
    * @return      : NA
    */
    _flatten = (nodeValue, flattenedRow, nodeName) => {        
        let rowKeys = Object.keys(nodeValue);
        rowKeys.forEach((key) => {
            let finalKey = nodeName + '.'+ key;
            flattenedRow[finalKey] = nodeValue[key];
        })
    }

    /*
	* @author      : Coforge
	* @date        : 09/08/2022
	* @description : This function shows show the Error message in the form of a toast.
	* @params      : NA
	* @return      : NA
	*/
    showErrorNotification() {
        const evt = new ShowToastEvent({
            title: 'Error',
            message: this.error,
            duration: '20000',
            variant: 'error',
        });
        this.dispatchEvent(evt);
    }

    /*
	* @author      : Coforge
	* @date        : 09/08/2022
	* @description : This function captures the start date from the date input field.
	* @params      : event
	* @return      : NA
	*/
    handleStartDate = (event) => 
    {
        this.startDate = event.target.value;
        if(this.startDate != null && this.endDate!= null){
            this.handleFilterDisabled = false;
        }
        
    }

    /*
	* @author      : Coforge
	* @date        : 09/08/2022
	* @description : This function captures the end date from the date input field.
	* @params      : event
	* @return      : NA
	*/
    handleEndDate = (event) => 
    {
        this.endDate = event.target.value;
        if(this.startDate != null && this.endDate!= null){
            this.handleFilterDisabled = false;
        }
    }

    /*
	* @author      : Coforge
	* @date        : 09/08/2022
	* @description : This function captures the title field from the date input field.
	* @params      : event
	* @return      : NA
	*/
    handleSearchTitle = (event) => 
    {
        this.searchTitle = event.target.value;       
    }

    /*
	* @author      : Coforge
	* @date        : 09/08/2022
	* @description : This function process the searched records and adding conditions like no data found card visibility.
	* @params      : data
	* @return      : NA
	*/
    processSearchRecords(data){        
        console.log('data --' + data);
        if(data == null || data ==''){
            this.isDatatable = false;
            this.isNoDataFound = true;
            this.disableExport = true;
        }
        else if(data != null || data !=''){
            this.isDatatable = true;
            this.isNoDataFound = false;
            this.disableExport = false;    
            if(this.isVisible === true){
                this.showSearch = true;
            }        
        }    
        this.flattenData(data);    
    }
    
    /*
	* @author      : Coforge
	* @date        : 09/08/2022
	* @description : This function is used for pagination of the records retrieved.
	* @params      : data
	* @return      : NA
	*/
    processRecords(data){
        
        this.items = data;
        this.totalRecountCount = data.length; 
        this.totalPage = Math.ceil(this.totalRecountCount / this.pageSize); 
        
        this.data = this.items.slice(0,this.pageSize); 
        this.endingRecord = this.pageSize;
        if(this.recordId != null){ 
            this.columns = columnss;
        }
        else{
            this.columns = columns;
        }        
        this.isFirstPage = false;
        this.isLastPage = false;
        if(this.page == 1){
            this.isFirstPage = true;
        }
        if(this.page == this.totalPage){            
            this.isLastPage = true;
        }
    }

    /*
	* @author      : Coforge
	* @date        : 09/08/2022
	* @description : This function will be called after clicking on previous button.
	* @params      : NA
	* @return      : NA
	*/
    previousHandler() {
        this.isPageChanged = true;
        if (this.page > 1) {
            this.page = this.page - 1; //decrease page by 1
            this.displayRecordPerPage(this.page);
            this.isFirstPage = false;
        }
        if(this.page == 1){
            this.isFirstPage = true;            
        }
        this.isLastPage = false;
          var selectedIds = [];
          for(var i=0; i<this.allSelectedRows.length;i++){
            selectedIds.push(this.allSelectedRows[i].Id);
          }
        this.template.querySelector(
            '[data-id="table"]'
          ).selectedRows = selectedIds;
    }

    /*
	* @author      : Coforge
	* @date        : 09/08/2022
	* @description : This function will be called after clicking on next button.
	* @params      : NA
	* @return      : NA
	*/
    nextHandler() {
        this.isPageChanged = true;
        if((this.page<this.totalPage) && this.page !== this.totalPage){
            this.page = this.page + 1; //increase page by 1
            this.displayRecordPerPage(this.page);            
            this.isLastPage = false;
        }
        if(this.page == this.totalPage){
            this.isLastPage = true;            
        }
        this.isFirstPage = false;
        var selectedIds = [];
        for(var i=0; i<this.allSelectedRows.length;i++){
            selectedIds.push(this.allSelectedRows[i].Id);
        }
        this.template.querySelector(
            '[data-id="table"]'
          ).selectedRows = selectedIds;
    }

    /*
	* @author      : Coforge
	* @date        : 09/08/2022
	* @description : This function displays records page by page.
	* @params      : page
	* @return      : NA
	*/
    displayRecordPerPage(page){

        this.startingRecord = ((page -1) * this.pageSize) ;
        this.endingRecord = (this.pageSize * page);

        this.endingRecord = (this.endingRecord > this.totalRecountCount) 
                            ? this.totalRecountCount : this.endingRecord; 

        this.data = this.items.slice(this.startingRecord, this.endingRecord);
        this.startingRecord = this.startingRecord + 1;
        this.totalRecountCount = this.items.length ;
        this.totalPage = Math.ceil(this.totalRecountCount / this.pageSize);
    }    

    /*
	* @author      : Coforge
	* @date        : 09/08/2022
	* @description : This function is used to sort the records based on the field selected.
	* @params      : event
	* @return      : NA
	*/ 
    sortColumns( event ) {
        this.page = 1 ,
        this.sortedBy = event.detail.fieldName;
        this.sortedDirection = event.detail.sortDirection;
        
        //this.displayRecordPerPage(this.page);
        this.handleFilter();
        
    }

    /*
	* @author      : Coforge
	* @date        : 09/08/2022
	* @description : This function is used for the inline search functionality of the records in the datatable.
	* @params      : NA
	* @return      : NA
	*/ 
    handleKeyChange( event ) {
        this.searchKey = event.target.value;
        console.log('search key '+this.searchKey);
        var searchedData = [];
        console.log('item length'+this.initialData.length);
       
        for(var i=0;i<this.initialData.length;i++){
            console.log(i);
            console.log(this.initialData[i]);
            let oldValue;
            let newValue;
            let title;
            if(this.initialData[i].Title__c != undefined ){
                let titl = this.initialData[i].Title__c;
                title = titl.toLowerCase();
            }
            if(this.initialData[i].Old_Value__c != undefined){
                let oldVal = this.initialData[i].Old_Value__c;
                oldValue = oldVal.toLowerCase();
            }
            
            if(this.initialData[i].New_Value__c != undefined){
                let newVal = this.initialData[i].New_Value__c;
                newValue = newVal.toLowerCase();
            }


            if(this.initialData[i]!= null && title != undefined && title.includes(this.searchKey.toLowerCase())){
                
                searchedData.push(this.initialData[i]);
                
            }
            
            else if(this.initialData[i].Case__c != undefined && this.initialData[i].Case__c != null && this.initialData[i].Case__r.CaseNumber.includes(this.searchKey)){
                
                searchedData.push(this.initialData[i]);
            }
            else if(this.initialData[i]!= null && oldValue != undefined && oldValue.includes(this.searchKey.toLowerCase())){
                
                searchedData.push(this.initialData[i]);
            }
            else if(this.initialData[i]!= null && newValue != undefined && newValue.includes(this.searchKey.toLowerCase())){
                
                searchedData.push(this.initialData[i]);
            }
            console.log()            
        }
        //this.processRecords(searchedData);
        this.processSearchRecords(searchedData);
        console.log(this.searchedData);
    }

    /*
	* @author      : Coforge
	* @date        : 09/08/2022
	* @description : This function is used to download the records in csv format.
	* @params      : NA
	* @return      : NA
	*/  
    handleDownload = () =>
    {

        let rowEnd = '\n';
        let csvString = '';
        // this set elminates the duplicates if have any duplicate keys
        let rowData = new Set();
        // this set stores the api header values 
        let rowDataVal = new Set();

        // getting keys from data
        this.contents.forEach(function (record) {
            
            Object.keys(record).forEach(function (key) {
                // adding only those fields which are required in the export to csv 
                if(exportHeaderMap.has(key)){
                    rowData.add(key);
                    rowDataVal.add(exportHeaderMap.get(key));
                }
                
            });
        });
        console.log('rowData '+rowData);
        console.log(rowData);
        // Array.from() method returns an Array object from any object with a length property or an iterable object.
        rowData = Array.from(rowData);
        rowDataVal = Array.from(rowDataVal);
        
        // splitting using ','
        csvString += rowDataVal.join(',');
        csvString += rowEnd;
        console.log(' csvString '+csvString);
        // main for loop to get the data based on key value
        for(let i=0; i < this.contents.length; i++){
            let colValue = 0;

            // validating keys in data
            for(let key in rowData) {
                if(rowData.hasOwnProperty(key)) {
                    // Key value 
                    // Ex: Id, Name
                    let rowKey = rowData[key];
                    console.log('rowKey '+rowKey);
                    // add , after every value except the first.
                    if(colValue > 0){
                        csvString += ',';
                    }
                    // If the column is undefined, it as blank in the CSV file.
                    let value = this.contents[i][rowKey] === undefined ? '' : this.contents[i][rowKey];
                    console.log(value);
                    csvString += '"'+ value +'"';
                    colValue++;
                }
            }
            csvString += rowEnd;
        }

        // Creating anchor element to download
        let downloadElement = document.createElement('a');

        // This  encodeURI encodes special characters, except: , / ? : @ & = + $ # (Use encodeURIComponent() to encode these characters).
        downloadElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csvString);
        downloadElement.target = '_self';
        // CSV File Name
        downloadElement.download = 'HistoryTrackingExport.csv';
        // below statement is required if you are using firefox browser
        document.body.appendChild(downloadElement);
        // click() Javascript function to download CSV file
        downloadElement.click();    
    }
    
}