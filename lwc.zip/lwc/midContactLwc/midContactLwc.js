import { LightningElement,track,wire } from 'lwc';
import prepareLicenceDatatoFeed from '@salesforce/apex/LicenceMIDContactReportHelper.prepareLicenceDatatoFeed';
import getColumnInfo from '@salesforce/apex/LicenceMIDContactReportHelper.getColumnInfo';
import hasAccess from '@salesforce/apex/LicenceMIDContactReportHelper.hasAccess';
import getMIDPermissionDropdowns from '@salesforce/apex/LicenceMIDContactReportHelper.getMIDPermissionDropdowns';
import getErrorMessagesAndDisplayLimit from '@salesforce/apex/LicenceMIDContactReportHelper.getErrorMessagesAndDisplayLimit';

export default class MidLicenceReportTest1 extends LightningElement {

		//related to W-002410 , W-002411
		
    recId;
    columns = [];
    data = [];
    targetDatatable;
    recordsQueried = [];
    fixeddata = [];
    columnHeaders = []; 
    totalRows = 0;
    totalRowsDisplayed = 0;
    totalRowsQueried = 0;
    totalRowsDisplayLimit;
    recordLimitNote = false;
	noDataError = true;
    noRecordFoundMsg;
	progress = 2000;

    // For MID Permission dropdown list
    @track options=[];
    @track dataList;
    @track dropdown = 'slds-combobox slds-dropdown-trigger';
    @track dropdownList = 'slds-media slds-listbox__option slds-listbox__option_entity slds-listbox__option_has-meta';
    @track selectedValue = 'Select Permissions';
    @track selectedListOfValues='';

    // Filters on UI
    licenceNumber;
    accountName;
    contactName;
    midPermission;

    // current user access
    access = false;
    errorMessage;

    // reset button visibility
    showReset = false;
    someFilterSearch = false;
    emptyFilterSearch = false;

	/*
    * @author           : Coforge
    * @date             : 22/12/2021
    * @description      : To check if current user has access to the report
    */
    @wire (hasAccess)
    currentUserAccess({data,error}){
        if (data){
            this.access = data;
        }
        else if(error){
            console.log('Error '+error);
        }
    }

	/*
    * @author           : Coforge
    * @date             : 22/12/2021
    * @description      : To retrieve error messages and total number of rows to be display
    */
	@wire (getErrorMessagesAndDisplayLimit)
    errorMessageAndDisplayLimit({data,error}){
        if (data){
            this._interval = setInterval(() => {     
                this.errorMessage = (data[0] != undefined ? data[0]: '');
                clearInterval(this._interval);  
                  
            }, this.progress); 
            
            this.noRecordFoundMsg = (data[1] != undefined ? data[1]:'');
            this.totalRowsDisplayLimit = (data[2] != undefined ? parseInt(data[2]):'');
        }
        else if(error){
            console.log('Error '+error);
        }
    }

	/*
    * @author           : Coforge
    * @date             : 22/12/2021
    * @description      : Called everytime when page is loaded
    */
    connectedCallback(){
        
        // To set the values of MID Permission filter dropdown
        getMIDPermissionDropdowns()
        .then(response =>{
            this.dataList = response;
            for (let i = 0; i < this.dataList.length; i++) {
                //this.options = [...this.options, { value: this.dataList[i], label: this.dataList[i],isChecked:false,class:this.dropdownList }];
                this.options = [...this.options, { value: this.dataList[i], label: this.dataList[i],isChecked:false,class:this.dropdownList }];
            }
        });
        
        
		// To populate the value of total number of records at the top of report table
        this.showCount();
        // To set column headings of the report
        getColumnInfo().then(response => {
            this.columnHeaders = response;
            let columnsNames =[];
            Array.from(this.columnHeaders).forEach(function(headerName){
                if(headerName.URL__c!=undefined){
                    // for url
                    columnsNames.push({ 
                        label: headerName.Label, fieldName: headerName.Label+'Url',
                        initialWidth:150, 
                        type: 'url',
												sortable: 'true',
                        typeAttributes: {
                            label: { 
                                fieldName: headerName.API_Name__c
                            },
                            target : '_blank'
                        } 
                    });
                }
                else{
                    columnsNames.push({ label: headerName.Label, 
                        initialWidth:150, 
                        fieldName: headerName.API_Name__c, 
                        type: 'text' ,
												sortable: 'true'

                    });
                }
            });

            this.columns = columnsNames;
            console.log('columns '+this.columns);
            this.retrieveLicenceData();
            
        })
        .catch((error) => {
                console.log('Error: Fetching Columns from Metadata ' +error);
        });

    }

	/*
    * @author           : Coforge
    * @date             : 22/12/2021
    * @description      : To bring licence data from apex
    */ 
    retrieveLicenceData = () =>{

        if(this.recId != 'allDataFetched'){
            prepareLicenceDatatoFeed({licenceNumberFilter: this.licenceNumber,
                accNameFilter: this.accountName,
                midContactFilter: this.contactName,
                midPermissionFilter: this.midPermission,
                lastRecordId: this.recId,
                showCount: false,
                isExport: false})
                .then(result => {
                    if(this.recId != 'allDataFetched' && result !=undefined && result[0].recId != this.recId){
                        
                        this.totalRowsQueried+= result.length;
                        //alert('this.totalRowsDisplayed '+this.totalRowsDisplayed);
                        if(this.totalRowsQueried <= this.totalRowsDisplayLimit){
                            this.recordsQueried = result;
                        }
                        else{
                            this.recordsQueried = Array.from(result).splice(0,this.totalRowsDisplayLimit-this.totalRowsDisplayed);
                        }
                    
                        this.recId = result[0] !=undefined ?result[0].recId:'';
                        let listOfRecords = this.setFieldValues(this.recordsQueried,false);
                        this.data = [...this.data, ...listOfRecords];
                        
                        console.log('<<< this.recId >>> '+this.recId);
                        console.log('<<< this.data >>> '+this.data);
                        

                        //Disable a spinner to signal that data has been loaded
                        if (this.targetDatatable) this.targetDatatable.isLoading = false;
                    
                        
                        if(this.totalRowsQueried >= this.totalRowsDisplayLimit){  
                            this.recId = 'allDataFetched';
                            this.recordLimitNote = true;
                        }
                        this.totalRowsDisplayed += result.length;
                        
                          
                    }
                    
                })
                .catch((error) => {
                    console.log('Error in fetching records from database: ' +error);
                });
        
        }
    }

	/*
    * @author           : Coforge
    * @date             : 22/12/2021
    * @description      : To set values in the report table for export when isExport = true, and for display if isExport = false
    * @param1           : Object recordsQueried 
    * @param2           : Boolean isExport
    * @return           : csvString / fixeddata
    */ 
    setFieldValues = (recordsQueried,isExport) =>{
        console.log('<<< this.recordsQueried in setFieldValues() >>>'+ this.recordsQueried);
        
        let fixeddata = [];
        let rowEnd;
        let csvString;
        let rowDataLabels =[];
        let columnHeadersList=[];
        let value;
        let finalValue;
        let url;
        let mergeField =[];
        let mergeFieldUrl =[];
        let baseUrl = 'https://'+location.host+'/';
        // Retrieving column details from this.columnHeaders
        Array.from(this.columnHeaders).forEach(function(headerName){
            rowDataLabels.push(headerName.Label);
            columnHeadersList.push(headerName);
        });
        console.log('#columnHeadersList '+columnHeadersList);
        if(isExport == true){
            rowEnd = '\n';
            csvString = '';
            
            csvString += rowDataLabels.join(',');
            csvString += rowEnd;
        }
        
        // Looping all rows
        recordsQueried.forEach(function(record) {
            console.log('#outer loop reached for isExport '+isExport);
            console.log('<<< reached outer loop of setFieldValues >>>');
            let colValue;
            let dataline;
            if(isExport == true)
                colValue = 0;
            else{
                dataline = {};
            }
            
            // Setting values for each column
            columnHeadersList.forEach(function(header){
                
                console.log('#inner loop reached for isExport '+isExport);
                console.log('<<< reached inner loop of setFieldValues >>>');
                if(isExport == true){
                    if(colValue > 0){
                        csvString += ',';
                    }
                }
                url='';
                mergeField = header.API_Name__c.split('.');
                mergeFieldUrl = (header.URL__c != undefined ?header.URL__c.split('.'):[]);
                console.log('mergeField '+mergeField);
                console.log('mergeFieldUrl '+mergeField);
                if(mergeField.length == 4){
                    if(record[mergeField[0]][mergeField[1]][mergeField[2]]!=undefined){
                        value = record[mergeField[0]][mergeField[1]][mergeField[2]][mergeField[3]];
                        url = (record[mergeFieldUrl[0]][mergeFieldUrl[1]][mergeFieldUrl[2]]!=undefined?
                              record[mergeFieldUrl[0]][mergeFieldUrl[1]][mergeFieldUrl[2]][mergeFieldUrl[3]]:'');
                        
                    }
                    else{
                        value='';
                    }
                }
                else if(mergeField.length == 3){
                    if(record[mergeField[0]][mergeField[1]]!=undefined){
                        value = record[mergeField[0]][mergeField[1]][mergeField[2]];
                        url = (record[mergeFieldUrl[0]][mergeFieldUrl[1]] != undefined ? 
                              record[mergeFieldUrl[0]][mergeFieldUrl[1]][mergeFieldUrl[2]]:'');
                    }
                    else{
                        value='';
                    }
                }
                else if(mergeField.length == 2){
                    if(record[mergeField[0]]!=undefined){
                        value = record[mergeField[0]][mergeField[1]];
                        url = (record[mergeFieldUrl[0]] != undefined ? 
                              record[mergeFieldUrl[0]][mergeFieldUrl[1]]:'');
                    }
                    else{
                        value='';
                    }
                }
                
                finalValue = (value !==undefined ?  
                    value:'' );
                
                if(isExport == true){
                    csvString += '"'+finalValue+'"';
                }
                else{
                    if(mergeFieldUrl!=[] && url!='')
                    dataline[header.Label+'Url'] = baseUrl+url;

                    dataline[header.API_Name__c] = finalValue;
                }

                if(isExport == true)
                colValue++;
            });
            if(isExport == true){
                // For next row to be printed on next line
                csvString += rowEnd;
            }
            
            else{
                // Adding each row to fixeddata variable
                console.log('dataline before push '+JSON.stringify(dataline));
                fixeddata.push(dataline);
                console.log('dataline after push '+JSON.stringify(fixeddata));
            }
        });
        console.log('<<< reached end of setFieldValues and fixeddata is >>>'+fixeddata);
        if(isExport == true)
        return csvString;
        else{
            return fixeddata;
        }
    }

	/*
    * @author           : Coforge
    * @date             : 22/12/2021
    * @description      : Event to handle onloadmore on lightning datatable markup
    */ 
    handleLoadMore = (event) =>{
        if(this.recId != 'allDataFetched' && this.totalRowsDisplayed!=this.totalRows){
            //alert('<<< Control to handleLoadMore for loading more >>>');
            event.preventDefault();
            //Display a spinner to signal that data is being loaded
            event.target.isLoading = true;
            //Set the onloadmore event taraget to make it visible to imperative call response to apex.
            this.targetDatatable = event.target;
            // Get new set of records and append to this.data
            this.retrieveLicenceData();
        }
        else{
            //alert('<<< Control to handleLoadMore for stopping loading >>>');
            event.target.isLoading = false;
        }
    }

	/*
    * @author           : Coforge
    * @date             : 22/12/2021
    * @description      : This method is called when Search button is clicked
    */ 
    handleSearch = () => {

        // Hiding 2000 record limit note at the bottom
        this.recordLimitNote = false;

        // Setting current rows value to 0
        this.totalRowsDisplayed = 0;
        this.totalRowsQueried = 0;
        
        // Hiding Reset button when all records are searched without applying any filter
        if(this.licenceNumber =='' &&
        this.accountName =='' &&
        this.contactName =='' &&
        this.selectedListOfValues == ''){
            this.showReset = false;
            this.emptyFilterSearch = true;
        }
        else{
            // someFilterSearch value is set to true if search button is clicked with some filters applied,
            // emptyFilterSearch value is set to false if filters applied are not empty
            // reset button visibilty is handled on this basis in resetShow() method
            this.someFilterSearch = true;
            this.emptyFilterSearch = false;
            this.resetShow();
        }

        // Removing any existing data from the displayed table
        this.data =[];

        // recId is the last record's Id which is displayed in the table
        // it is set blank as no record list is fetched until now
        this.recId='';

        // Removing any existing queried data of the displayed table
        this.recordsQueried=[];

        // To show total count of records at the top 
        this.showCount();

        // This method invokes apex method to bring data of the table
        this.retrieveLicenceData();
    }

	/*
    * @author           : Coforge
    * @date             : 22/12/2021
    * @description      : This method is used to show the total count of records at the top of table
    */
    showCount = () =>{
        prepareLicenceDatatoFeed({licenceNumberFilter: this.licenceNumber,
            accNameFilter: this.accountName,
            midContactFilter:this.contactName,
            midPermissionFilter:this.midPermission,
            lastRecordId:'',
            showCount: true,
            isExport: false
        }).then(response => {
            console.log('response from count '+response);
            this.totalRows = (response != undefined ?response.length:0);
						if(this.totalRows == 0){
                this.noDataError = false;
            }else{
                this.noDataError = true;
            }
            console.log('this.totalRows '+this.totalRows);
        }).catch((error) => {
            console.log('Error: Record count ' +error);
        });
    }

	/*
    * @author           : Coforge
    * @date             : 22/12/2021
    * @description      : This method is called when export button is clicked
    */
    downloadCSVFile = () =>{ 
        prepareLicenceDatatoFeed({licenceNumberFilter: this.licenceNumber,
            accNameFilter: this.accountName,
            midContactFilter:this.contactName,
            midPermissionFilter:this.midPermission,
            lastRecordId:'',
            showCount: false,
            isExport: true
        }).then(response => {
            let csvString = '';
            // setFieldValues method sets merge field values in the table
            csvString = this.setFieldValues(response, true);
            console.log('response of downloadcsv '+csvString);

            let downloadElement = document.createElement('a');

            // This  encodeURI encodes special characters, except: , / ? : @ & = + $ # (Use encodeURIComponent() to encode these characters).
            downloadElement.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csvString);
            downloadElement.target = '_self';
            // CSV File Name
            downloadElement.download = 'MID Contacts.csv';
            // below statement is required if you are using firefox browser
            document.body.appendChild(downloadElement);
            // click() Javascript function to download CSV file
            downloadElement.click(); 
        }).catch((error) => {
            console.log('Error: Export to Excel ' +error);
        });
    }

	/*
    * @author           : Coforge
    * @date             : 22/12/2021
    * @description      : For opening of MID Permission filter dropdown on UI
    */
    openDropdown = () =>{
        this.dropdown =  'slds-combobox slds-dropdown-trigger  slds-is-open';  
    }
		
	/*
    * @author           : Coforge
    * @date             : 22/12/2021
    * @description      : For closing of MID Permission filter dropdown on UI
    */
    closeDropDown = () =>{
       this.dropdown =  'slds-combobox slds-dropdown-trigger';
    }

	/*
    * @author           : Coforge
    * @date             : 22/12/2021
    * @description      : For selecting and de-selecting MID Permissions filter from dropdown on UI
    */
    selectOption = (event) =>{
        
        var isCheck = event.currentTarget.dataset.id;
        var label = event.currentTarget.dataset.name;
        var selectedListData=[];
        var selectedOption='';
        var allOptions = this.options;
        var count=0;
        for(let i=0;i<allOptions.length;i++){ 
            if(allOptions[i].label===label)
            { 
                if(isCheck==='true')
                { 
                    allOptions[i].isChecked = false;
                    allOptions[i].class = this.dropdownList;
                }
                else
                { 
                    allOptions[i].isChecked = true; 
                    allOptions[i].class = 'slds-media slds-listbox__option slds-listbox__option_plain slds-media_small slds-media_center slds-is-selected';
                }
            } 
            if(allOptions[i].isChecked)
            { 
                selectedListData.push(allOptions[i].label); 
                count++; 
            } 
        }
        if(count === 1){
            selectedOption = count+' Permission Selected';
        }
        else if(count>1){
            selectedOption = count+' Permissions Selected';
        }
        
        this.options = allOptions;
        this.selectedValue = selectedOption;
        this.selectedListOfValues = selectedListData;
        let midPermissionSelected='';
        
        selectedListData.forEach(function(selectedValue){
            if(selectedListData.length===1)
                midPermissionSelected+="'"+selectedValue+"'";
            else{
                if(selectedListData[selectedListData.length-1]!==selectedValue)
                    midPermissionSelected+="'"+selectedValue+"',";
                else
                    midPermissionSelected+="'"+selectedValue+"'";
            }
        });
        // Setting MID Permission as comma separated single quoted values 
        this.midPermission = midPermissionSelected;
        this.resetShow();
    }

	/*
    * @author           : Coforge
    * @date             : 22/12/2021
    * @description      : This method is called when Reset button is clicked
    */
    allowReset = () =>{
        eval("$A.get('e.force:refreshView').fire();");
    }

	/*
    * @author           : Coforge
    * @date             : 22/12/2021
    * @description      : This method is run when there is change in values of licence report filters
    */
    resetShow = () =>{
        
        // Bringing all filter values from the UI
        this.licenceNumber = this.template.querySelector('lightning-input[data-id=LicenceNumber]').value;
        this.accountName = this.template.querySelector('lightning-input[data-id=AccountName]').value;
        this.contactName = this.template.querySelector('lightning-input[data-id=ContactName]').value;

        // Reset button shown on conditions-
        // 1. When at least one report filter is not blank
        // 2. When records displayed are on the basis of at least one filter applied, then on change of 
        //    filter values, reset button is shown
        if(!(this.licenceNumber =='' &&
        this.accountName =='' &&
        this.contactName =='' &&
        this.selectedListOfValues == '') || 
        (this.someFilterSearch && this.licenceNumber =='' &&
        this.accountName =='' &&
        this.contactName =='' &&
        this.selectedListOfValues == '' && !this.emptyFilterSearch)){
            this.showReset = true;
        }
            
        // Reset button hidden on conditions-
        // 1. Before Search button click (on Page Load), when all report filters are set as blank
        // 2. After Search button click with all blank report filters
        else if(!this.someFilterSearch && (this.licenceNumber =='' &&
        this.accountName =='' &&
        this.contactName =='' &&
        this.selectedListOfValues == '') 
        ||
        (this.emptyFilterSearch && (this.licenceNumber =='' &&
        this.accountName =='' &&
        this.contactName =='' &&
        this.selectedListOfValues == '' ))
        ){
            this.showReset = false;
        }

    }
		
	/*
    * @author           : Coforge
    * @date             : 22/12/2021
    * @description      : This method is called when sorting is applied on columns
    */
    doSorting(event) {
        this.sortBy = event.detail.fieldName;
        this.sortDirection = event.detail.sortDirection;
        this.sortData(this.sortBy, this.sortDirection);
    }

	/*
    * @author           : Coforge
    * @date             : 22/12/2021
    * @description      : This is called from doSorting method to sort data that has been loaded till now
    */
    sortData(fieldname, direction) {
        let parseData = JSON.parse(JSON.stringify(this.data));
        // Return the value stored in the field
        let keyValue = (a) => {
            return a[fieldname];
        };
        // cheking reverse direction
        let isReverse = direction === 'asc' ? 1: -1;
        // sorting data
        parseData.sort((x, y) => {
            x = keyValue(x) ? keyValue(x) : ''; // handling null values
            y = keyValue(y) ? keyValue(y) : '';
            // sorting values based on direction
            return isReverse * ((x > y) - (y > x));
        });
        this.data = parseData;
    }    
		
}