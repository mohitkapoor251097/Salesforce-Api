import { LightningElement, wire , api} from 'lwc';
import getCaseAddInfoFields from '@salesforce/apex/RFICaseAdditionalInfoController.getCaseAddInfoFields';
import Insufficient_access_rights_on_object_id from '@salesforce/label/c.Insufficient_access_rights_on_object_id';
import { CurrentPageReference } from 'lightning/navigation';
import COMMON_ERROR from '@salesforce/label/c.CommonError';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { loadStyle } from 'lightning/platformResourceLoader';
import CUSTOMCSS from '@salesforce/resourceUrl/MultilineToast';

const INSUFFICIENT_ACCESS_LABEL= 'insufficient access rights on object id';
const DISMISSABLE_LABEL= 'dismissable';
const SUCCESS_LABEL = 'success';
const ERROR_LABEL = 'error';

export default class RfiCaseAdditionalInfo extends LightningElement {
    @api execludePageLayoutSection;
    @api targetPagelayoutName;
    @api targetObjectApiName;
    @api filterFieldApiName;
    @api execludeFields;
    @api activeSections;
    @api successMessage;
    @api headerTitle;
    @api recordId;
    @api 
    get columnSize(){
        return '';
    }
    set columnSize(value){
        if(value == 2){
            this.layoutSize = 6;
            this.twoColumnClass = true;
        }else{
            this.layoutSize = 12;
            this.twoColumnClass = false;
        }
    }

    showEditField = false;
    layoutSections = [];
    isCssLoaded = false;
    showSpinner = true;
    caseAddRecordId;
    currentRecordId;
    twoColumnClass;
    isLoaded=false;
    
    layoutSize;

    /*
    * @author      : Coforge
    * @date        : 19/11/2024
    * @description : This method is used to get current recordId and calling the getPageLayoutFieldsData method
    * @params      : none
    * @return      : none
    */
    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        this.isLoading = true;
        if (currentPageReference && currentPageReference.attributes.recordId) {
            this.currentRecordId = currentPageReference.attributes.recordId;
            if(this.currentRecordId){
                this.getPageLayoutFieldsData();
            }  
        }
    }

    /*
    * @author      : Coforge
    * @date        : 19/11/2024
    * @description : This method is used to Load the Multiline Toast Style CSS
    * @params      : none
    * @return      : none
    */
    renderedCallback(){
        if(this.isCssLoaded) return
            this.isCssLoaded = true;
        loadStyle(this,CUSTOMCSS).then(()=>{
        })
        .catch(error=>{
        });
    }
    
    /*
    * @author      : Coforge
    * @date        : 19/11/2024
    * @description : This method is used to page layout information
    * @params      : none
    * @return      : none
    */
    getPageLayoutFieldsData(event){
            this.isLoading = true;
            let wrapperData = {};
            wrapperData.parentRecordId = this.currentRecordId;
            wrapperData.targetObjectApiName = this.targetObjectApiName;
            wrapperData.filterFieldApiName = this.filterFieldApiName;
            wrapperData.targetPagelayoutName = this.targetPagelayoutName;
            wrapperData.execludePageLayoutSection = this.execludePageLayoutSection;
            wrapperData.execludeFields = this.execludeFields;
            
        getCaseAddInfoFields({wrapperDataString : JSON.stringify(wrapperData)})
            .then((result) => {
                if (result){
                    
                    this.caseAddRecordId = result.caseAddRecordId;
                    this.layoutSections = result.layoutSection;
                    //Method is used to open given section
                    this.handleOpenAll();
                    this.isLoading = false;
                }
            })
            .catch((error) => {
                this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
                this.isLoading = false;
            });
    }

    /*
     * @author      : Coforge
     * @date        : 19/11/2024
     * @description : This handleSuccess method is display the success info
     * @params      : 
     * @return      : none
     */
    handleSuccess(event) {
        this.caseAddRecordId = event.detail.id;
        this.showEditField = false;
        this.showNoRecordsToast(this.successMessage,SUCCESS_LABEL,DISMISSABLE_LABEL);
    }

    /*
     * @author      : Coforge
     * @date        : 19/11/2024
     * @description : This handleEdit method is used to edit the record
     * @params      : 
     * @return      : none
     */
    handleEdit() {
        this.showEditField = !this.showEditField;
    }

    /*
     * @author      : Coforge
     * @date        : 19/11/2024
     * @description : This handleEdit method is used to submit the record
     * @params      : 
     * @return      : none
     */
    handleSubmit(event){
      try {
            this.isLoading = true;
            event.stopPropagation();
            event.preventDefault();
            const inputFields = event.detail.fields;

            Object.defineProperty(inputFields, this.filterFieldApiName, {
                                                value: this.currentRecordId,
                                                writable: true,
                                                enumerable: true,
                                                configurable: true
                                                });

            console.log('inputFields=>',JSON.stringify(inputFields));
            //console.log('Case__c=>',inputFields.Case__c);
            //inputFields.Case__c = this.currentRecordId;
            this.isLoading = false;
            this.template.querySelector('[data-id="rfiAdditionalInfo"]').submit(inputFields);
            
        } catch (error) {
            this.isLoading = false;
            this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
        }
    }

    /*
     * @author      : Coforge
     * @date        : 19/11/2024
     * @description : This handleEdit method is used to handle the record error
     * @params      : 
     * @return      : none
     */
    handleError(event){
        this.isLoading = true;

        console.log('event.detail.detail==>',JSON.stringify(event.detail));
        let errors = this.parseErrorMessage(event.detail);
        let errorMsg = errors.join('.');  
        
        if(errors && errors.length > 1){
            errorMsg = '';
            errors.forEach(function (item, index) {
                errorMsg += (index+1) +'-'+item+'. \n';
            });
        }else if(errorMsg == INSUFFICIENT_ACCESS_LABEL){
            errorMsg = Insufficient_access_rights_on_object_id;
        }
        
        this.isLoading = false;
        this.showNoRecordsToast(errorMsg,ERROR_LABEL,DISMISSABLE_LABEL);
    }
    
    /*
     * @author      : Coforge
     * @date        : 19/11/2024
     * @description : This handleToggleSection method is used to for active section
     * @params      : 
     * @return      : none
     */
    handleToggleSection(event) {
        this.activeSectionsInfo =  event.detail.openSections;
    }

    /*
     * @author      : Coforge
     * @date        : 19/11/2024
     * @description : This handleOpenAll method is used to open all active section
     * @params      : 
     * @return      : none
     */
    handleOpenAll(){
        if(this.activeSections){
            this.activeSectionsInfo = this.activeSections.split(',');
        }
    }

    /*
     * @author      : Coforge
     * @date        : 19/11/2024
     * @description : This handleCancel method is used to cancel 
     * @params      : 
     * @return      : none
     */
    handleCancel(){
        this.showEditField = false;
    }
    /*
     * @author      : Coforge
     * @date        : 19/11/2024
     * @description : To show the toast message for success and error 
     * @params      : title
     * @params      : variant
     * @params      : mode
     * @return      : NA
     */
    showNoRecordsToast(title,variant,mode) {
        const event = new ShowToastEvent({
            title: title,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(event);
    }

    /*
     * @author      : Coforge
     * @date        : 16/10/2024
     * @description : Method is used to parse the error
     * @params      : errors
     * @return      : String
     */
    parseErrorMessage(errors) {

        if (!Array.isArray(errors)) {
            errors = [errors];
        }
        return (
            errors
            // Remove null/undefined items
            .filter((error) => !!error)
            // Extract an error message
            .map((error) => {
                // UI API read errors
                if (Array.isArray(error.body)) {
                    return error.body.map((e) => e.message);
                }
                // Page level errors
                else if (
                    error?.body?.pageErrors &&
                    error.body.pageErrors.length > 0
                ) {
                    return error.body.pageErrors.map((e) => e.message);
                }
                // Field level errors
                else if (
                    error?.fieldErrors &&
                    Object.keys(error.fieldErrors).length > 0
                ) {
                    const fieldErrors = [];
                    Object.values(error.fieldErrors).forEach(
                        (errorArray) => {
                            fieldErrors.push(
                                ...errorArray.map((e) => e.message)
                            );
                        }
                    );
                    return fieldErrors;
                }
                // UI API DML page level errors
                else if (
                    error?.output?.errors &&
                    error.output.errors.length > 0
                ) {
                    return error.output.errors.map((e) => e.message);
                }
                // UI API DML field level errors
                else if (
                    error?.output?.fieldErrors &&
                    Object.keys(error.output.fieldErrors).length > 0
                ) {
                    const fieldErrors = [];
                    Object.values(error.output.fieldErrors).forEach(
                        (errorArray) => {
                            fieldErrors.push(
                                ...errorArray.map((e) => e.message)
                            );
                        }
                    );
                    return fieldErrors;
                }
                // UI API DML, Apex and network errors
                else if (error && typeof error.message === 'string') {
                    return error.message;
                }
                // JS errors
                else if (typeof error.message === 'string') {
                    return error.message;
                }
                // Unknown error shape so try HTTP status text
                return error.statusText;
            })
            // Flatten
            .reduce((prev, curr) => prev.concat(curr), [])
            // Remove empty strings
            .filter((message) => !!message)
    );
    }
}