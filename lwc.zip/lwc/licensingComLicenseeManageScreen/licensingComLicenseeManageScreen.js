/**
* @description   Displays Available Licencees list
* @author        Coforge
* @date          22 Nov 2022
* @lastModified  23 Nov 2022
* @ChangeLog     Intitial Version 1.0 : 22-11-2022 : W-002858 LPE Replace Contact: REP2.1] Select licensee (if multiple) from grid - TBC 
*                         Version 1.1 : 02-12-2022 : W-002859 LPE Replace Contact: REP3.1] Select type of ‘Manage’ transaction (manage licence or update contact)
*                         Version 1.2 : 29-12-2022 : W-002861 LPE Replace Contact: REP5.2] View details on the Contact overview page
                          Version 1.3 : 05-01-2023 : W-002880 LPE Replace Contact: REP7.1] Create new licence contact from the Contact Overview
                          Version 1.4 : 13-01-2023 : W-002890 LPE Replace Contact: REP12.1] Create new payment contact from the Contact Overview
                          Version 1.5 : 06-02-2023 : W-002860 LPE Replace Contact: REP5.1] View and navigate updated breadcrumb trail
                          Version 1.6 : Jan 08, 2025 : ADO20971: Licensee Selection
                          
*/
import {LightningElement,api, wire} from 'lwc'; // ADO20971 change
import getCommunityURL from '@salesforce/apex/Licensing_Utility.getCommunityURL';
import GenericLicensingWebFormUrl from '@salesforce/label/c.GenericLicensingWebFormUrl';//< ADO15407>
import licenseeOrgRoleListPagination from '@salesforce/apex/Licensing_UtilityExtension.getlicenseeOrgRolePagination'; // ADO20971 change

export default class LicensingComLicenseeManageScreen extends LightningElement {
    
    showSpinner=true; // To show spinner until data is fetched
    capturecontactevent = false;   //W-002880
    gridSelected; // Grid selected by user        
    licenseeList; // Licensee org role list displayed on the UI
    licenseeCount; // Count of org role displayed on the UI
    selectGridValidation; // string variable to display validation error
    licenseeCardsHeader; //W-002858 : It displays licensee Cards Header
    openLicenseeScreen; //W-002858 : It is used to show/hide the content of Licensee selection screen
    selectedLicensee; //W-002859 : It is used to store the selected Licensee
    selectedLicenseeOrg;
    openManageTransactionScreen; //W-002859 : It is used to show/hide the content of Manage Transaction screen
    Webformlabelvalue=GenericLicensingWebFormUrl + 'SlepWebForm';//ADO15407
    /* ADO20971 changes start */
    orgRoleList;

    /*       
    * @author      : Coforge
    * @date        : Jan 08, 2025
    * @description : Wire method called after the connectedcallback to fetch the list of org roles
    * @return      : None
    * @param       : None
    */
    @wire(licenseeOrgRoleListPagination, {licenseeOpt : "", lwcName : "licensingComLicenseeManageScreen", pageReferenceName: "Manage"})
    wiredOrgRoles({error, data}){
        if(data){
            this.orgRoleList = data;
            this.licenseeCount = data.length;
            this.showSpinner = false; // To hide spinner
        }
        if(error){
            console.log('In wiredOrgRoles::'+ error);
            console.log(JSON.stringify(error));
            window.location.href='/apex/licensingcomerror';
            this.showSpinner = false; // To hide spinner
        }
    }
    
    /*       
    * @author      : Coforge
    * @date        : Jan 08, 2025
    * @description : Method called on onupdate event of paginationcmp to set the list of org role for current page
    * @return      : None
    * @param       : event
    */
    currentPageLicenseeList(event) {
        this.licenseeList = [...event.detail.records];
        this.gridSelected = null; // Reset the selected grid
        //W-002859 added to show ManageTransactionScreen for one licensee.
        if(this.licenseeCount == 1){
            this.selectedLicensee = this.licenseeList[0].Licensee_or_Organisation__r;
            this.selectedLicenseeOrg = this.licenseeList[0];
            this.openLicenseeScreen = false;
            this.openManageTransactionScreen = true; 
        }
        this.openContactOverviewOnEventCapture();
        this.showSpinner = false; // To hide spinner
    }
    /* ADO20971 changes end */
    /*       
    * @author      : Coforge
    * @date        : 22/11/2022
    * @description : Method called when component is loaded to bring data for licensee selection screen - W-002858
    * @return      : None
    * @param       : None
    */   
    connectedCallback() {
        try{       
            this.openLicenseeScreen = true; //W-002858 : To render licensee selection screen on the UI
            this.licenseeCardsHeader = 'Select the licensee you want to manage licences for:'; // W-002858 : It displays licensee Cards Header on UI
            
            
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }        
    }

    /*       
    * @author      : Coforge
    * @date        : 22/11/2022
    * @description : Method called when select Licensee button is clicked for licensee selection screen - W-002858
    * @return      : None
    * @param       : event
    */
    selectedGrid(event){
        try{
            var scrollOptions = {
                left: 0,
                top: document.body.scrollHeight, /* W-002883 : LPE Accessibility issue fixing  here */ 
                behavior: 'smooth'
            }
            window.scrollTo(scrollOptions);
            var gridName = event.target.value;
            this.gridSelected=null; // Reset the existing grid value
            /*Selected card record id is fetched and styling class is added/removed to card */    
            for(let i=0; i<this.licenseeList.length; i++){
                if(this.licenseeList[i].Id == gridName){
                    this.template.querySelector('[data-id="' +gridName+ '"]').classList.add('gridBackground');
                    this.gridSelected = this.licenseeList[i];
                    this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
                    this.selectGridValidation = "";
                }
                else{
                    this.template.querySelector('[data-id="' +this.licenseeList[i].Id+ '"]').classList.remove('gridBackground');	
                }
            }
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }    
    }

    /*       
    * @author      : Coforge
    * @date        : 01/12/2022
    * @description : Method called on next button click of licensee selection screen
    * @return      : None
    * @param       : None
    */
    goToManageTransaction(){
        try{
            if(this.gridSelected==null){
                /*On click of next without selecting card we are displaying error on top of grids  */ 
                this.template.querySelector('[data-id="errorMessage"]').classList.add('error');
                this.selectGridValidation = "Licensee selection is required";
                var scrollOptions = {
                    left: 0,
                    top: 580,
                    behavior: 'smooth'
                }
                window.scrollTo(scrollOptions);
            }
            else{
                // W-002859 : Setting selectedLicensee to pass selected licensee to Licensee Manage Transaction Screen
                this.selectedLicensee = this.gridSelected.Licensee_or_Organisation__r;
                this.selectedLicenseeOrg = this.gridSelected;
                // W-002859 : To hide Licensee selection screen
                this.openLicenseeScreen = false;
                // It is used to show/hide the content on the current component and child component
                this.openManageTransactionScreen = true;
                // W-002859 : Hiding the heading on vf page
                this.dispatchEvent(new CustomEvent('hideLicensingforManageHeading')); 
            }
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 02/01/2023
    * @description : W-002880 : To open Licence Contact popup, when event for this is recieved from the child - Contact Overview Screen
    * @return      : None
    * @param       : None
    */
    opencontactpopup(event){
        try{ 
            this.dispatchEvent(new CustomEvent("openlicencecontactmodal",{
                detail:{
                    selectedContact: event.detail.selectedContact,
                    selectedContactType :event.detail.selectedContactType, // Passing the Contact's type
                    selectedLicenseeId: event.detail.selectedLicenseeId
                }
            }));
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }        
    }
    
    /*       
    * @author      : Coforge
    * @date        : 05/01/2023
    * @description : W-002880/W-002890 : Handling the event and opening the Licence Contact overview selection screen if licensee data is recieved
    *                from the Visualforce popup, when the logged in user creates
    * @return      : None
    * @param       : None
    */
    openContactOverviewOnEventCapture(){
        try{
            window.addEventListener("message", (message) => {
                // Page origin
                getCommunityURL()
                .then(result => {
                    var vfOrigin;
                    var contactType = message.data.name; //W-002890
                    vfOrigin =  result;
                    if (!vfOrigin.includes(message.origin)) {
                        return;//Not the expected origin
                    }
                    if(contactType === "LicenseContactData" || contactType === "PaymentContactData"){  //W-002890 Added filter for Payment contact
                        this.capturecontactevent = contactType;                                        //W-002890 Passing contact type data in capturecontactevent
                        this.template.querySelector('c-licensing-com-licensee-manage-transaction-screen').goToContactOverview(event, this.capturecontactevent);
                    }
                });
            });
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }
    }
    /*       
    * @author      : Coforge
    * @date        : 11/01/2023
    * @description : W-002883 : LPE Accessibility issue fixing  here
    * @return      : None
    * @param       : None
    */
    cancellink(){
        window.location.href='/apex/LicensingComDashboard';         
    }

        /*       
    * @author      : Coforge
    * @date        : 06/02/2023
    * @description : W-002860 : Event that updates the breadcrumb when 'Next' or 'Previous' buttons are clicked
    * @return      : None
    * @param       : None
    */
    updateBreadcrumb(event){
        try{
            this.dispatchEvent(new CustomEvent('updatingBreadcrumb',{
                detail: {
                    screenName : event.detail.screenName
                }
            })); 
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }
    }
}