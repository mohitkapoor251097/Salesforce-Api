import { LightningElement ,api } from 'lwc';
import updateSobjectData from '@salesforce/apex/OSUpdateMeetingStatusController.updateCancelMeetingData';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { getRecordNotifyChange } from 'lightning/uiRecordApi';
import COMMON_ERROR from '@salesforce/label/c.CommonError';
import { CloseActionScreenEvent } from 'lightning/actions';

import OSUpdateCancelstatusMsg from '@salesforce/label/c.oSUpdateCancelstatusMsg';

const SUCCESS_MESSAGE = 'Meeting status cancelled successfully!';
const DISMISSABLE_LABEL = 'dismissable';
const SUCESS_LABEL = 'success';
const ERROR_LABEL = 'error';

export default class OSUpdateCancelstatus extends LightningElement {

    modalContainer = true;
    
    @api recordId;
    @api cancellationReason;
    message;

    label = {
        OSUpdateCancelstatusMsg
    };

    connectedCallback() {
        this.closeScreeQuickAction();
    }


    /*
     * @author      : Coforge
     * @description : fetch the cancellation reason from input text area
     * @params event
     * @return N/A
     */
    handleCancellationReason(event) 
    {
        this.cancellationReason = event.target.value;
        console.log('cancellationReason==>',this.cancellationReason);
    }

    /*
     * @author      : Coforge
     * @description : fetch the record to display sensitive info
     * @params None
     * @return List of records
     */
    updateMeetingDataAction() {
        if(!this.cancellationReason){
            this.showNoRecordsToast('Please enter the cancellation reason.',ERROR_LABEL,DISMISSABLE_LABEL);
            return;
        }
         updateSobjectData({
            recordId : this.recordId,
            cancellationReason : this.cancellationReason
        }).then((result) => {
            try{
                if(result) {
                    let message = result;
                    if(message && message == SUCESS_LABEL){
                        this.showNoRecordsToast(SUCCESS_MESSAGE,SUCESS_LABEL,DISMISSABLE_LABEL);
                        this.refreshDetailPage();
                        this.closeModalAction();
                    }else if(message && message == ERROR_LABEL){
                        this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
                    }else {
                        this.showNoRecordsToast(message,ERROR_LABEL,DISMISSABLE_LABEL);
                    }      
                }
            } catch(e){
                this.message = JSON.stringify(e)
                console.log('error==>',JSON.stringify(e));
                this.closeModalAction();
                this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
                
            }
        })
        .catch((error) => {
            console.log('error==>',JSON.stringify(error));
            this.closeModalAction();
            this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
        });
    }

    /*
     * @author      : Coforge
     * @description : Close the modal 
     * @params      : event
     * @return      : NA
    */
    closeModalAction(){
        this.modalContainer=false;
        this.closeScreeQuickAction();
    }
    /*
     * @author      : Coforge
     * @description : Close the modal 
     * @params      : event
     * @return      : NA
    */
    closeScreeQuickAction(){
        this.dispatchEvent(new CloseActionScreenEvent());
    }

        /*
     * @author      : Coforge
     * @date        : 03/01/2024
     * @description : To show the toast message for success and error 
     * @params      : title
     * @params      : variant
     * @params      : mode
     * @return      : NA
     */
    showNoRecordsToast(title,variant,mode) {
        const event = new ShowToastEvent({
            title: title,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(event);
    }
    /*
     * @author      : Coforge
     * @date        : 11/01/2024
     * @description : Refresh/Reload the detail page
     * @return      : NA
     */
    refreshDetailPage(){
        getRecordNotifyChange([{recordId: this.recordId}]);
    }

}