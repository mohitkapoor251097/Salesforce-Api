import { LightningElement,api } from 'lwc';
//import getPaymentContactOrgRoles from '@salesforce/apex/LicenceUtil.getPaymentContactOrgRoles';// W-002904: Replacing Licensing_Utility with LicenceUtil
import getPaymentContactOrgRoles from '@salesforce/apex/Licensing_Utility.getPaymentContactOrgRoles';
import updateLicenceContactOrgRoleRecord from '@salesforce/apex/Licensing_Utility.updateLicenceContactOrgRoleRecord';
import GenericLicensingWebFormUrl from '@salesforce/label/c.GenericLicensingWebFormUrl'; //< ADO15407>

export default class LicensingComPaymentContactSelectionScreen extends LightningElement {
    @api licencecontact;
    paymentContactList; // W-002825 : payment Contact List displayed on the UI
    paymentContactCount = 0; // W-002825 : payment Contact Count displayed on the UI
    @api licensee; // W-002825 : selected licensee on Licensee selection screen
    gridSelected = null; //W-002828 : It will contain the value of the selected grid
    selectGridValidation; //W-002826 string variable to display validation error
    Webformlabelvalue=GenericLicensingWebFormUrl + 'SlepWebForm'; //< ADO15407>
		showSpinner;

    /*       
    * @author      : Coforge
    * @date        : 21/11/2022
    * @description : W-002825 : Method called when component is loaded to bring data for payment contact selection screen
    * @return      : None
    * @param       : selectedLicenseeId
    */   
    connectedCallback() {
    try{   

        // US-25154 Start : Escaping line breaks in JSON   
        this.licencecontact =  this.licencecontact.replace(/[\r\n]/gm, ' ');
        // US-25154 End

        if(this.licensee != null && this.licensee!=undefined){
            getPaymentContactOrgRoles({ selectedLicenseeId: this.licensee.Id })
                .then((result) => {
                        this.paymentContactList = result;
                        this.paymentContactCount = result.length;
                })
                .catch((error) => {
                     window.location.href='/apex/licensingcomerror';
                });
        }
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 03/11/2022
    * @description : W-002795 : Reloading on click of previous button
    * @return      : None
    * @param       : event
    */
    goToPreviousScreen(event){
    try{
        // W-002829 : Dispatching an event on previous click
        this.dispatchEvent(new CustomEvent('gotolicencecontactonprevious')); 
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 03/11/2022
    * @description : W-002795 : To go to contact validation screen on click of next button
    * @return      : None
    * @param       : event
    */
    goToContactValidationScreen(event){
    try{
        //W-002826 START Display Error Payment Contact selection screen 
        if(this.gridSelected==null){
            this.template.querySelector('[data-id="invalidRecordMessage"]').innerHTML =''; //W-002870 : Removing invalid record edit message if it exists
            /*On click of next without selecting card we are displaying error on top of grids  */ 
            this.template.querySelector('[data-id="errorMessage"]').classList.add('error');
            this.selectGridValidation = "Payment contact selection is required";
            var scrollOptions = {
                left: 0,
                top: 580,
                behavior: 'smooth'
            }
            window.scrollTo(scrollOptions);
        }//W-002826 END
        else{
            //W-002827 START Redirect to Contact Validation Screen 
            this.dispatchEvent(new CustomEvent("opencontactvalidationpopup",{
                detail:{
                    selectedPaymentContact : this.gridSelected
                }
            }));
            //W-002827 END
        }
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }    
    }

    /*       
    * @author      : Coforge
    * @date        : 22/11/2022
    * @description : W-002828 : Method called when Create new contact button is clicked
    * @return      : None
    * @param       : event
    */  
    openPaymentContactPopup(event){
    try{
        this.template.querySelector('[data-id="invalidRecordMessage"]').innerHTML =''; //W-002870 : Removing invalid record edit message if it exists

        // W-002830 Fetching the selected Grid id
        var gridId = event.target.value;

        // W-002870 START Reset the existing grid value and remove error
        this.gridSelected = null;
        var isValidated = true; // if true it opens popup
        // W-002870 END

        //W-002826 START Error removed on Payment Contact selection screen 
        this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
        this.selectGridValidation = "";
        // START Reset the existing grid value and remove background
        for(let i=0; i<this.paymentContactList.length; i++){
            // W-002830 Start : Setting the selected grid as gridSelected, by matching on the basis of Id
            if(this.paymentContactList[i].Id == gridId){
                this.gridSelected = this.paymentContactList[i];
            }
            // W-002830 End
            // Defect Fix
            this.template.querySelector('[data-id="' +this.paymentContactList[i].Id+ '"]').classList.remove('gridBackground');   
            
        }
        //W-002826 END

        // W-002870 Start: Showing Validation
        if(event.target.name == 'Edit details' && this.gridSelected!=undefined && this.gridSelected!=null ){
            var orgRoleTypeList = (this.gridSelected.Types__c).split(';');
            // When user tries to edit licence contact org role that is linked with other application also (i.e. MID,VSP etc) as well apart from Licence contact or payment contact 
            if(!(
                ((this.gridSelected.Types__c == 'Licence Bill/Account Contact') && (orgRoleTypeList.length==1)) || 
                (orgRoleTypeList.includes('Licence Contact')  && orgRoleTypeList.includes('Licence Bill/Account Contact') && orgRoleTypeList.length==2)
                )){

                // To show the validation message on the UI
                this.setInvalidRecordMessage();
                
                isValidated = false;

                this.gridSelected = null;
                this.scrollToTop(); // To scroll to top
            }
        }
        // W-002870 End

        if(isValidated){ // W-002870 : Opening popup only when record is valid
            // Dispatching an event to open payment contact popup
            this.dispatchEvent(new CustomEvent("openpaymentcontactpopup",{
                detail:{
                    selectedContact : this.gridSelected,
                    contactType :'Payment contact' // Passing the Contact's type // W-002870 : Modifying contact type
                }
            }));
            
            // Making grid selected as null, as now the grid selected will be the one whose popup has been open, and it will be handled
            // on VF side
            this.gridSelected = null;
        }
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 22/11/2022
    * @description : Method called when select Contact button is clicked for Payment Contact selection screen - W-002826
    * @return      : None
    * @param       : event
    */
    selectedGrid(event){
    try{
    this.template.querySelector('[data-id="invalidRecordMessage"]').innerHTML =''; //W-002870 : Removing invalid record edit message if it exists
        var scrollOptions = {
        left: 0,
        top: document.body.scrollHeight, /* W-002883 : LPE Accessibility issue fixing here */ 
        behavior: 'smooth'
    }
    window.scrollTo(scrollOptions);
    var gridName = event.target.value;
    this.gridSelected=null; // Reset the existing grid value
    /*Selected card record id is fetched and styling class is added/removed to card */    
    for(let i=0; i<this.paymentContactList.length; i++){
        if(this.paymentContactList[i].Id == gridName){
            this.template.querySelector('[data-id="' +gridName+ '"]').classList.add('gridBackground');
            this.gridSelected = this.paymentContactList[i];
            this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
            this.selectGridValidation = "";
        }
        else{
            this.template.querySelector('[data-id="' +this.paymentContactList[i].Id+ '"]').classList.remove('gridBackground');	
        }
    }
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }    
    }

    /*       
    * @author      : Coforge
    * @date        : 24/11/2022
    * @description : Method called when Use Licence Contact button is clicked on Payment Contact selection screen - W-002827
    * @return      : None
    * @param       : event
    */
    useLicenceContact(event){
    try{
       // this.licencecontact =  this.licencecontact.replace(/[\r\n]/gm, ' ');
       // console.log('licencecontact: ',JSON.stringify(this.licencecontact));
        this.showSpinner = true;
        if(this.licencecontact != null && this.licencecontact!=undefined){
            updateLicenceContactOrgRoleRecord({ orgRoleRecord: this.licencecontact })
                .then((result) => {
                        this.gridSelected = result;
                        this.goToContactValidationScreen();
												this.showSpinner = false;
                })
                .catch((error) => {
                     window.location.href='/apex/licensingcomerror';
                });
        }
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 29/11/2022
    * @description : W-002830 : Method called to scroll to the top of the page when any error occurs
    * @return      : None
    * @param       : None
    */
    scrollToTop(){
    try{
        var scrollOptions = {
            left: 0,
            top: 580,
            behavior: 'smooth'
        }
        window.scrollTo(scrollOptions);
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 29/11/2022
    * @description : W-002870: Method called when an invalid record is edited. It sets the error message on the UI
    * @return      : None
    * @param       : None
    */
    setInvalidRecordMessage(){
    try{
        // Adding error message on UI
        this.template.querySelector('[data-id="errorMessage"]').classList.add('error');

        // Appending the error message on the UI section with data-id as invalidRecordMessage
        var pTagFirst = document.createElement('span');
        pTagFirst.innerHTML = "This contact record is possibly associated with other licensing products. Please contact ";
        this.template.querySelector('[data-id="invalidRecordMessage"]').appendChild(pTagFirst);        

        var aTag = document.createElement('a');
        aTag.setAttribute('href',"https://ofcomlive.my.salesforce-sites.com/formentry/SlepWebForm");
        aTag.setAttribute('target',"_blank");
        aTag.innerHTML = "spectrum licensing";
        this.template.querySelector('[data-id="invalidRecordMessage"]').appendChild(aTag);

        var pTagSecond = document.createElement('span');
        pTagSecond.innerHTML = " to update these details.";
        this.template.querySelector('[data-id="invalidRecordMessage"]').appendChild(pTagSecond);
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }
      /*       
    * @author      : Coforge
    * @date        : 11/01/2023
    * @description : W-002883 : LPE Accessibility issue fixing  here
    * @return      : None
    * @param       : None
    */
    cancellink(){
    try{
        window.location.href='/apex/LicensingComDashboard';         
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }    
    } 
}