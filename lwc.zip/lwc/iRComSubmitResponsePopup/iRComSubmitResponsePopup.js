/**
* @description   Displays the IR cases summary table
* @author        Coforge
* @date          19 July 2024
* @lastModified  19 July 2024
* @description : ADO-22400 Submit Response Action on FRD rows             
*/
import { LightningElement,api } from 'lwc';

export default class IRComSubmitResponsePopup extends LightningElement {
    @api isshowmodal;
    @api casedetails={};
    showSpinner = false;

   /*       
   * @author      : Coforge
   * @date        : 19/07/2024
   * @description : ADO-22400: Submit Response Action on FRD rows
   */
    closeModalAction() {
        try {
            this.dispatchEvent(new CustomEvent('closemodalaction', { detail: false }));
            this.isshowmodal = false;
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

   /*       
   * @author      : Coforge
   * @date        : 19/07/2024
   * @description : ADO-22400: method called on page load to get the IR related data 
   */
    handlesubmitResponseClick(){
        try {
            this.showSpinner = true;
            window.location.href = '/apex/IRComFrdDetailPage?CaseId=' + this.casedetails.Id + '&DraftType='+ 'FNSUB';
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    } 
}