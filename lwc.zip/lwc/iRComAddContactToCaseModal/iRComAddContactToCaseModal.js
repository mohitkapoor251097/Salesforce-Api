/*       
* @author      : Coforge
* @date        : 23/04/2024
* @description : ADO-26354 Adding Contacts to the IRMS Case
*              : ADO-31497 : Organisational Role Relationship to Case Records
*              : ADO 39098 Feedback User Story - Sprint 9
*/
import { LightningElement, api } from 'lwc';
import addAndRemoveCaseContact from "@salesforce/apex/IRComCreatePortalUser.addAndRemoveCaseContact"; // ADO-31497
import { ShowToastEvent } from "lightning/platformShowToastEvent";

export default class MyModal extends LightningElement {
    @api buttonlabel;
    @api orgrolelist = [];
    @api title;
    @api caserecordid;
    selectedRows = [];
    spinnerFlag = false;
    availableContact;
    caseOrgRoleNoDataPreView = false;
    isAddRemoveContactDisabled=false;//Bug 31572

     /*       
    * @author      : Coforge
    * @date        : 23/04/2024
    * @description : org role data table coloumns
    */
    orgRoleColumns = [
        {
            label: 'Organisational Roles',
            fieldName: 'NameUrl',
            type: 'url',
            initialWidth : 200,
            typeAttributes: {
                label: { fieldName: 'Name' }, tooltip: { fieldName: 'Name' },
                target: '_blank'
            },
            sortable: true
        },
        { label: 'Types', fieldName: 'OrgTypes', sortable: true },       //Show & Tell Feedback ADO 33991
        { label: 'First Name', fieldName: 'FirstName', sortable: true },
        { label: 'Last Name', fieldName: 'LastName', sortable: true },
        { label: 'Email Address', fieldName: 'Email', sortable: true },
        { label: 'Associated Account', fieldName: 'TargetAccountName', sortable: true }
    ];

    /*       
    * @author      : Coforge
    * @date        : 23/04/2024
    * @description : ADO-26354 
    */
    connectedCallback() {
        // concate length of orgRoeList to show count of orgRoles
        this.availableContact = 'Available Contact (' + this.orgrolelist.length + ')';
        //flag to show no record found on component
        if (this.orgrolelist.length > 0) {
            this.caseOrgRoleNoDataPreView = true;
        }else if(this.orgrolelist.length == 0){ //Bug 31572 
            this.isAddRemoveContactDisabled=true;
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 23/04/2024
    * @description : ADO-26354 dispatch Event to close modal
    */
    closemodal() {
        this.dispatchEvent(new CustomEvent('closemodal', {
            detail: {
                closemodal: false
            }
        }));
    }

    /*       
    * @author      : Coforge
    * @date        : 23/04/2024
    * @description : ADO-26354 add and remove contact on selected records
    */
    addAndRemoveContact() {
        if (this.selectedRows.length == null || this.selectedRows.length == 0) {
            //Display warning if records not selected
            this.showNotification('Warning','Please select at least one record to proceed further','warning'); //ADO 39098 add space between "at least"
            return;
        } else {
            //true spinner flag to display spinner
            this.spinnerFlag = true;
            //call apex to update orgROle records
            addAndRemoveCaseContact({ action: this.buttonlabel, orgRoleList: this.selectedRows, caseId: this.caserecordid })
                .then((result) => {
                    if (result == null) {
                        // Check if button label and display toast accordingly
                        if (this.buttonlabel == 'Add contact') {
                            this.showNotification('Success','Contact added successfully','success');
                        } else {
                            this.showNotification('Success','Contact removed successfully','success');
                        }
                        // after update complete get the updated data                     
                        this.refreshData();
                        //hide spinner 
                        this.spinnerFlag = false;
                        //close modal
                        this.closemodal();
                    } else {
                        this.spinnerFlag = false;
                        this.closemodal();
                        this.showNotification('Error Message','Sorry – something went wrong. Please try again later.','error');
                    }
                })
                .catch((error) => {
                    this.spinnerFlag = false;
                    this.closemodal();
                    this.showNotification('Error Message','Sorry – something went wrong. Please try again later.','error');
                });
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 23/04/2024
    * @description : Display toast message
    */
    showNotification(title,message,variant) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
            mode: 'dismissable'
        });
        this.dispatchEvent(evt);
    }

    /*       
    * @author      : Coforge
    * @date        : 23/04/2024
    * @description : ADO-26354 selected records add in list.
    */
    selectRecords(event) {
        this.selectedRows = event.detail.selectedRows;
    }

    /*       
    * @author      : Coforge
    * @date        : 23/04/2024
    * @description : ADO-26354 fetch updated data after update records
    */
    refreshData() {
        //dispatch event to run method in parent component
        this.dispatchEvent(new CustomEvent('refreshdata', {
            detail: {
                refresh: true
            }
        }));
    }

    /*       
    * @author      : Coforge
    * @date        : 23/04/2024
    * @description : ADO-26354 Sorting in datatable
    */
    doSorting(event) {
        this.sortBy = event.detail.fieldName;
        this.sortDirection = event.detail.sortDirection;
        this.sortData(this.sortBy, this.sortDirection);
    }

    /*       
    * @author      : Coforge
    * @date        : 23/04/2024
    * @description : ADO-26354 Sorting in datatable
    */
    sortData(fieldname, direction) {
        let parseData = JSON.parse(JSON.stringify(this.orgrolelist));
        // Return the value stored in the field
        let keyValue = (a) => {
            return a[fieldname];
        };
        // cheking reverse direction
        let isReverse = direction === 'asc' ? 1 : -1;
        // sorting data
        parseData.sort((x, y) => {
            x = keyValue(x) ? keyValue(x) : '';
            y = keyValue(y) ? keyValue(y) : '';
            return isReverse * ((x > y) - (y > x));
        });
        this.orgrolelist = parseData;
    }

}