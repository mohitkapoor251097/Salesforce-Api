/**
    * @description   Displays CSLE reports in Lightning Reports tab.
    * @author        Coforge
    * @date          19 Feb  2025
    * @lastModified  04 April  2025
    * @ChangeLog     Intitial Version 1.0 
    */
import { LightningElement, track, wire } from 'lwc';
import fetchTriageRecords from '@salesforce/apex/CaseReportController.fetchTriageRecords';
import fetchCRMRecords from '@salesforce/apex/CaseReportController.fetchCRMRecords';
import fetchDecisionRecords from '@salesforce/apex/CaseReportController.fetchDecisionRecords';
import updateCaseRecords from '@salesforce/apex/CaseReportController.updateCaseRecords';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { getPicklistValues, getObjectInfo } from 'lightning/uiObjectInfoApi';
import CASE_OBJECT from '@salesforce/schema/Case';
import Refer_To_CRM__c from '@salesforce/schema/Case.Refer_To_CRM__c';
import Decision_Maker_Outcome__c from '@salesforce/schema/Case.Decision_Maker_Outcome__c';
import getPageSizeFromCS from '@salesforce/apex/CaseReportController.getPageSizeFromCS';
import csleHideRowNumber from '@salesforce/resourceUrl/csleHideRowNumber';
import { loadStyle } from 'lightning/platformResourceLoader';


/* ADO-54864 Add the initialWidth of columns and make the custom Text area field 'Triage_Assessment__c' */
const triageColumns = [
    { label: 'SN', fieldName: 'serialNumber', sortable: false, initialWidth: 58 }, //this is used for showing Serial number
    {
        label: 'Case Number',
        fieldName: 'caseLink',
        type: 'url',
        initialWidth: 125,
        typeAttributes: {
            label: { fieldName: 'CaseNumber' },
            target: '_blank'
        }

    },
    { label: 'Case Owner', fieldName: 'OwnerName', initialWidth: 160 },
    { label: 'Stage', fieldName: 'Stage__c', initialWidth: 170 },
    { label: 'Programme Name', fieldName: 'Programme__c', wrapText: true, initialWidth: 240 },
    { label: 'Service', fieldName: 'Service__c', wrapText: true, initialWidth: 240 },
    { label: 'Transmission Date', fieldName: 'Transmission_Date__c', type: 'date',
        typeAttributes: {
            day: '2-digit',
           month: '2-digit',
           year: 'numeric',
           }, initialWidth: 240 },/* ADO- 57776 as per obseavtion we made date as same as record page*/
    { label: 'Transmission Time', fieldName: 'Transmission_Time__c', type: 'text', initialWidth: 240 },
    { label: 'Description', fieldName: 'Description', type: 'text', wrapText: true, initialWidth: 240 },
    { label: 'Assessment Recommendation', fieldName: 'Assessment_Notes__c', wrapText: true, initialWidth: 240 },
    { label: 'Link to Material', fieldName: 'Link_to_Content__c', wrapText: true, initialWidth: 240 },
    { label: 'Additional Material', fieldName: 'Additional_Material__c', wrapText: true, initialWidth: 240 },
    {
        label: 'Triage Assessment',
        fieldName: 'Triage_Assessment__c',
        type: 'textAreaColumn',
        editable: true,
        wrapText: true,
        initialWidth: 240,
        typeAttributes: {
            label: 'Triage Assessment',
            value: { fieldName: 'Triage_Assessment__c' },
            context: { fieldName: 'Id' }
        },
    },
    {
        label: 'Refer to CRM',
        fieldName: 'Refer_To_CRM__c',
        type: 'picklistColumn',
        editable: true,
        initialWidth: 310,
        typeAttributes: {
            options: { fieldName: 'pickListOptions' },
            value: { fieldName: 'Refer_To_CRM__c' },
            context: { fieldName: 'Id' }
        }
    }
];

/* ADO-54864 Add the initialWidth of columns and make the custom Text area field 'CRM_Recommendation__c' */
const crmColumns = [
    { label: 'SN', fieldName: 'serialNumber', sortable: false, initialWidth: 58 }, //this is used for showing Serial number
    {
        label: 'Case Number',
        fieldName: 'caseLink',
        type: 'url',
        initialWidth: 125,
        typeAttributes: {
            label: { fieldName: 'CaseNumber' },
            target: '_blank'
        }
    },
    { label: 'Case Owner', fieldName: 'OwnerName', initialWidth: 160 },
    { label: 'Stage', fieldName: 'Stage__c', initialWidth: 170 },
    { label: 'Programme Name', fieldName: 'Programme__c', wrapText: true, initialWidth: 240 },
    { label: 'Service', fieldName: 'Service__c', wrapText: true, initialWidth: 240 },
    { label: 'Transmission Date', fieldName: 'Transmission_Date__c',type: 'date',
        typeAttributes: {
            day: '2-digit',
           month: '2-digit',
           year: 'numeric',
           }, initialWidth: 240 },/* ADO- 57776 as per obseavtion we made date as same as record page*/
    { label: 'Transmission Time', fieldName: 'Transmission_Time__c', type: 'text', initialWidth: 240 },
    { label: 'Description', fieldName: 'Description', type: 'text', wrapText: true, initialWidth: 240 },
    { label: 'Assessment Recommendation', fieldName: 'Assessment_Notes__c', wrapText: true, initialWidth: 240 },
    { label: 'Link to Material', fieldName: 'Link_to_Content__c', wrapText: true, initialWidth: 240 },
    { label: 'Additional Material', fieldName: 'Additional_Material__c', wrapText: true, initialWidth: 240 },
    {
        label: 'Triage Assessment',
        fieldName: 'Triage_Assessment__c',
        type: 'text',
        wrapText: true,
        initialWidth: 240
    },
    {
        label: 'CRM Recommendation',
        fieldName: 'CRM_Recommendation__c',
        type: 'textAreaColumn',
        editable: true,
        initialWidth: 320,
        typeAttributes: {
            label: 'CRM Recommendation',
            value: { fieldName: 'CRM_Recommendation__c' },
            context: { fieldName: 'Id' }
        }
    }
];

/* ADO-54864 Add the initialWidth of columns and make the custom Text area field 'Decision_Maker_Assessment__c' */
const decisionColumns = [
    { label: 'SN', fieldName: 'serialNumber', sortable: false, initialWidth: 58 }, //this is used for showing Serial number
    {
        label: 'Case Number',
        fieldName: 'caseLink',
        type: 'url',
        initialWidth: 125,
        typeAttributes: {
            label: { fieldName: 'CaseNumber' },
            target: '_blank'
        }
    },
    { label: 'Case Owner', fieldName: 'OwnerName', initialWidth: 160 },
    { label: 'Stage', fieldName: 'Stage__c', initialWidth: 170 },
    { label: 'Programme Name', fieldName: 'Programme__c', wrapText: true, initialWidth: 240 },
    { label: 'Service', fieldName: 'Service__c', wrapText: true, initialWidth: 240 },
    { label: 'Transmission Date', fieldName: 'Transmission_Date__c', type: 'date',
        typeAttributes: {
            day: '2-digit',
           month: '2-digit',
           year: 'numeric',
           }, initialWidth: 240 },/* ADO- 57776 as per obseavtion we made date as same as record page*/
    { label: 'Transmission Time', fieldName: 'Transmission_Time__c', type: 'text', initialWidth: 240 },
    { label: 'Description', fieldName: 'Description', type: 'text', wrapText: true, initialWidth: 240 },
    { label: 'Assessment Recommendation', fieldName: 'Assessment_Notes__c', wrapText: true, initialWidth: 240 },
    { label: 'Link to Material', fieldName: 'Link_to_Content__c', wrapText: true, initialWidth: 240 },
    { label: 'Additional Material', fieldName: 'Additional_Material__c', wrapText: true, initialWidth: 240 },
    {
        label: 'Triage Assessment',
        fieldName: 'Triage_Assessment__c',
        type: 'text',
        initialWidth: 240,
        wrapText: true,
    },
    {
        label: 'CRM Recommendation',
        fieldName: 'CRM_Recommendation__c',
        initialWidth: 240
    },
    {
        label: 'Decision Maker Assessment',
        fieldName: 'Decision_Maker_Assessment__c',
        type: 'textAreaColumn',
        editable: true,
        wrapText: true,
        initialWidth: 240,
        typeAttributes: {
            label: 'Decision Maker Assessment',
            value: { fieldName: 'Decision_Maker_Assessment__c' },
            context: { fieldName: 'Id' }
        }
    },
    {
        label: 'Decision Maker Outcome',
        fieldName: 'Decision_Maker_Outcome__c',
        type: 'picklistColumn',
        editable: true,
        initialWidth: 250,
        typeAttributes: {
            options: { fieldName: 'decisionMakerOutcomeOptions' },
            value: { fieldName: 'Decision_Maker_Outcome__c' },
            context: { fieldName: 'Id' }
        }

    },
    {
        label: 'Summary Required',
        type: 'boolean',
        fieldName: 'Summary_of_Complaint_Required__c',
        editable: true,
        initialWidth: 320

    }
];
export default class CsleReport extends LightningElement {
    @track PAGE_SIZE;
    @track columns = [];
    showSpinner = false;
    @track data = [];
    @track accountData;
    @track draftValues = [];
    lastSavedData = [];
    @track pickListOptions;
    @track decisionMakerOutcomeOptions;
    picklistLoaded = false;
    @track wiredCaseData;
    @track caseData = [];
    @track paginatedData = [];
    @track saveDraftValues = [];
    triageColumns = triageColumns;
    crmColumns = crmColumns;
    decisionColumns = decisionColumns;

    @track pageNumber = 1;
    @track totalPages = 0;
    @track totalRecords = 0;
    showPagination = false;


    reportOptions = [
        { label: 'Triage Stage Report', value: 'Triage Stage Report' },
        { label: 'CRM Stage Report', value: 'CRM Stage Report' },
        { label: 'Decision Maker Report', value: 'Decision Maker Report' },

    ];

    /*       
    * @author      : Coforge
    * @date        : 04/04/2025
    * @description : renderedCallback using for load css file from static resource
    * @return      : None
    * @param       : None
    */
    renderedCallback() {
        Promise.all([
            loadStyle(this, csleHideRowNumber),
        ])
            .then(() => {
                console.log('CSS loaded successfully');
            })
            .catch(error => {
                this.showToast('Error', 'An unexpected error occurred, please contact your Administrator', 'error');
            });
    }

    /*       
  * @author      : Coforge
  * @date        : 26/03/2025
  * @description : Method to return the page size
  * @return      : None
  * @param       : None
  */
    @wire(getPageSizeFromCS)
    pageSize({ error, data }) {
        try {
            if (data) {
                this.PAGE_SIZE = data;
            } else if (error) {
                console.log('Error-->', error);
            }
        } catch (e) {
            this.showToast('Error', 'An unexpected error occurred, please contact your Administrator', 'error');
        }
    }

    /*       
* @author      : Coforge
* @date        : 05/03/2025
* @description : W-002892 : Method to return the case info
* @return      : None
* @param       : None
*/

    @wire(getObjectInfo, { objectApiName: CASE_OBJECT })
    caseInfo;
    /*       
    * @author      : Coforge
    * @date        : 05/03/2025
    * @description : Method to get the picklist values
    * @return      : None
    * @param       : getPicklistValues
    */
    @wire(getPicklistValues, {
        recordTypeId: "$caseInfo.data.defaultRecordTypeId",
        fieldApiName: Refer_To_CRM__c
    })
    wirePickList({ error, data }) {
        try {
            if (data) {
                this.pickListOptions = data.values;
                this.picklistLoaded = true;
            } else if (error) {
                this.handlePicklistError(error);
            }
        } catch (e) {
            this.showToast('Error', 'An unexpected error occurred, please contact your Administrator', 'error');
        }
    }

    // Fetch the picklist values for "Decision Maker Outcome"
    @wire(getPicklistValues, {
        recordTypeId: "$caseInfo.data.defaultRecordTypeId",
        fieldApiName: Decision_Maker_Outcome__c
    })
    wireDecisionMakerOutcomePicklist({ error, data }) {
        try {

            if (data) {
                this.decisionMakerOutcomeOptions = data.values;
                this.picklistLoaded = true;
            } else if (error) {

                this.handlePicklistError(error);
            }
        } catch (e) {

            this.showToast('Error', 'An unexpected error occurred while fetching picklist values.', 'error');
        }
    }

    /*       
* @author      : Coforge
* @date        : 05/03/2025
* @description : Method to get the triage case data
* @return      : None
* @param       : None
*/

    fetchTriageCaseData() {
        this.showSpinner = true; // Show spinner while data is being fetched
        fetchTriageRecords({
            pageSize: this.PAGE_SIZE,
            pageNumber: this.pageNumber

        })
            .then(result => {
                if (result) {
                    this.caseData = result.caseRecords;
                    this.totalRecords = result.totalCount;
                    this.totalPages = Math.ceil(this.totalRecords / this.PAGE_SIZE);
                    this.pagination();
                }
            })
            .catch(error => {
                console.log('errror', error);
                this.showToast('Error', 'An unexpected error occurred while fetching case records.', 'error');
                this.data = undefined;
            })
            .finally(() => {
                this.showSpinner = false; // Hide the spinner when data fetch is complete
            });
    }
    /*       
* @author      : Coforge
* @date        : 05/03/2025
* @description : Method to get the CRM CaseData
* @return      : None
* @param       : None
*/

    fetchCrmCaseData() {
        this.showSpinner = true; // Show spinner while data is being fetched
        fetchCRMRecords({
            pageSize: this.PAGE_SIZE,
            pageNumber: this.pageNumber

        })
            .then(result => {

                if (result) {
                    this.caseData = result.caseRecords;
                    this.totalRecords = result.totalCount;
                    this.totalPages = Math.ceil(this.totalRecords / this.PAGE_SIZE);
                    this.pagination();

                }
            })
            .catch(error => {
                console.log('error', error);
                this.showToast('Error', 'An unexpected error occurred while fetching case records.', 'error');
                this.data = undefined;
            })
            .finally(() => {
                this.showSpinner = false; // Hide the spinner when data fetch is complete
            });
    }

    /* @author      : Coforge
* @date        : 05/03/2025
* @description : Method to get the CRM CaseData
* @return      : None
* @param       : None
*/

    fetchDecisionMakerCaseData() {
        this.showSpinner = true; // Show spinner while data is being fetched
        fetchDecisionRecords({
            pageSize: this.PAGE_SIZE,
            pageNumber: this.pageNumber

        })
            .then(result => {
                if (result) {
                    this.caseData = result.caseRecords;
                    this.totalRecords = result.totalCount;
                    this.totalPages = Math.ceil(this.totalRecords / this.PAGE_SIZE);
                    this.pagination();

                }
            })
            .catch(error => {
                console.log('error is', error);
                this.showToast('Error', 'An unexpected error occurred while fetching case records.', 'error');
                this.data = undefined;
                this.showSpinner = false;
            })
            .finally(() => {
                this.showSpinner = false; // Hide the spinner when data fetch is complete

            });
    }


    /* @author      : Coforge
    * @date        : 05/03/2025
    * @description : Method to handle the pagination
    * @return      : None
    * @param       : None
    */
    pagination() {
        this.data = [];
        let startIndex = (this.pageNumber - 1) * this.PAGE_SIZE;
        let endIndex = startIndex + this.PAGE_SIZE;
        endIndex = (endIndex > this.totalRecords) ? this.totalRecords : endIndex;
        const paginatedData = this.caseData.slice(startIndex, endIndex);
        const currentUrl = window.location.href;
        const afterforceCom = currentUrl.split('force.com/')[1];
        const trimmedUrl = afterforceCom.startsWith('com/') ? afterforceCom.substring('com/'.length) : afterforceCom;
        const orgUrl = currentUrl.replace(trimmedUrl, '');

        if (paginatedData) {
            this.data = JSON.parse(JSON.stringify(paginatedData));
            this.data.forEach((ele, index) => { // Added index to get the current row index
                ele.OwnerName = ele.Owner ? ele.Owner.Name : '';
                ele.pickListOptions = this.pickListOptions;
                ele.decisionMakerOutcomeOptions = this.decisionMakerOutcomeOptions;
                ele.caseLink = `${orgUrl}lightning/r/Case/${ele.Id}/view`;
                ele.serialNumber = startIndex + index + 1; // Calculate serial number
                const draftValue = this.draftValues.find(draft => draft.Id === ele.Id);
                if (draftValue) {
                    ele = { ...ele, ...draftValue };
                }
            });
            this.lastSavedData = JSON.parse(JSON.stringify(this.data)); // Save data to persist when canceled 

            //ADO-54864 handle the pagination for last record on last page
            if (this.totalPages < this.pageNumber) {
                this.pageNumber = this.pageNumber - 1;
                if (this.selectedReport === 'Triage Stage Report') {
                    this.fetchTriageCaseData(); // Fetch Triage data if we're on Triage report type
                } else if (this.selectedReport === 'CRM Stage Report') {
                    this.fetchCrmCaseData(); // Fetch CRM data if we're on CRM report type
                } else if (this.selectedReport === 'Decision Maker Report') {
                    this.fetchDecisionMakerCaseData();
                }
            }
        }
    }

    /* @author      : Coforge
    * @date        : 05/03/2025
    * @description : Method to handle the previous page
    * @return      : None
    * @param       : None
    */

    previousPage() {
        try {
            if (this.pageNumber > 1) {
                this.pageNumber--;
                this.pagination();

            }
        }
        catch (e) {
            this.showToast('Error', 'An unexpected error occurred, please contact your Administrator', 'error');

        }
    }

    /* @author      : Coforge
    * @date        : 05/03/2025
    * @description : Method to handle the next page
    * @return      : None
    * @param       : None
    */

    nextPage() {
        try {
            if (this.pageNumber < this.totalPages) {
                this.pageNumber++;
                this.pagination();


            }
        }
        catch (e) {
            this.showToast('Error', 'An unexpected error occurred, please contact your Administrator', 'error');

        }
    }
    /* @author      : Coforge
* @date        : 05/03/2025
* @description : Method to handle the first page
* @return      : None
* @param       : None
*/
    get isFirstPage() {
        try {
            if (this.pageNumber === 1 || this.pageNumber === 0)
                return true;
        }
        catch (e) {

            this.showToast('Error', 'An unexpected error occurred, please contact your Administrator', 'error');
            return this.pageNumber === 0;
        }
    }

    /* @author      : Coforge
    * @date        : 05/03/2025
    * @description : Method to handle the last page
    * @return      : None
    * @param       : None
    */

    get isLastPage() {
        try {
            return this.pageNumber === this.totalPages;
        }
        catch (error) {

            this.showToast('Error', 'An unexpected error occurred, please contact your Administrator', 'error');
            return this.pageNumber === 0;

        }

    }



    /* @author      : Coforge
    * @date        : 05/03/2025
    * @description : Method to update the draft values
    * @return      : None
    * @param       : updateItem
    */
    updateDraftValues(updateItem) {
        try {
            let copyDraftValues = [...this.draftValues];

            // Find the draft values for the updated item
            let existingDraft = copyDraftValues.find(item => item.Id === updateItem.Id);

            if (existingDraft) {
                // Update the existing draft value
                for (let field in updateItem) {
                    existingDraft[field] = updateItem[field];
                }
            } else {
                // Add the new draft value if it's a new item
                copyDraftValues.push(updateItem);
            }

            this.draftValues = [...copyDraftValues];
        } catch (e) {
            this.showToast('Error', 'An unexpected error occurred, please contact your Administrator', 'error');
        }
    }


    /* @author      : Coforge
    * @date        : 05/03/2025
    * @description : Method to handle save and update the records
    * @return      : None
    * @param       : NA
    */

    handleSave() {
        try {
            this.showSpinner = true;
            this.saveDraftValues = this.draftValues;
            const casesToUpdate = this.saveDraftValues.map(draft => {
                return { ...draft };
            });
            // Call the Apex method to update records
            updateCaseRecords({ casesToUpdate }).then((result, error) => {
                if (result == 'Success') {
                    this.showToast('Success', 'Records Updated Successfully!', 'success', 'dismissable');
                    this.showSpinner = false;
                    this.data = this.data.map(item => {
                        const updatedItem = this.draftValues.find(draft => draft.Id === item.Id);
                        return updatedItem ? { ...item, ...updatedItem } : item;
                    });
                    // Ensure the table is refreshed by reassigning 'this.data'
                    this.data = [...this.data]; // Trigger reactivity

                    // Clear  draft values after saving
                    this.draftValues = [];
                    this.saveDraftValues = [];
                    if (this.selectedReport === 'Triage Stage Report') {
                        this.fetchTriageCaseData(); // Fetch Triage data if we're on Triage report type
                    } else if (this.selectedReport === 'CRM Stage Report') {
                        this.fetchCrmCaseData(); // Fetch CRM data if we're on CRM report type
                    } else if (this.selectedReport === 'Decision Maker Report') { // Fetch CRM data if we're on Decision maker report type
                        this.fetchDecisionMakerCaseData(); 
                    }
                }
                else {
                    this.showSpinner = false;
                    this.showToast('Error', 'You do not have neccessary privieges to edit this/these records.Please contact your system adminstrator', 'error', 'dismissable');
                    this.draftValues = [];
                    this.saveDraftValues = [];
                }
            })
        } catch (error) {
            console.log('error is', error);
            this.showToast('Error', 'An unexpected error occurred, please contact your Administrator', 'error', 'dismissable');
        }
    }
    /* @author      : Coforge
    * @date        : 05/03/2025
    * @description : Method to do the cell change
    * @return      : None
    * @param       : event
    */

    handleCellChange(event) {
        try {
            let draftValues = event.detail.draftValues;
            draftValues.forEach(ele => {
                this.updateDraftValues(ele);
            })
        }
        catch (e) {
            this.showToast('Error', 'An unexpected error occurred, please contact your Administrator', 'error');

        }
    }

    /* @author      : Coforge
    * @date        : 05/03/2025
    * @description : Method to handle the cancel functionality
    * @return      : None
    * @param       : NA
    */
    handleCancel() {
        try {
            this.data = JSON.parse(JSON.stringify(this.lastSavedData));
            this.draftValues = [];
        } catch (e) {
            this.showToast(
                'Error',
                'An unexpected error occurred, please contact your Administrator',
                'error');
        }
    }
    /* @author      : Coforge
    * @date        : 05/03/2025
    * @description : Method to handle the report change
    * @return      : None
    * @param       : NA
    */
    handleReportChange(event) {
        try {
            /********************To reload/blank the draft value on change of report type****************************/
            this.draftValues = [];
            this.saveDraftValues = [];
            /*************************End************************************/
            this.selectedReport = event.detail.value;
            this.pageNumber = 1;
            if (this.selectedReport === 'Triage Stage Report') {
                this.columns = this.triageColumns;
                this.showPagination = true;
                this.fetchTriageCaseData();

            } else if (this.selectedReport === 'CRM Stage Report') {
                this.columns = this.crmColumns;
                this.showPagination = true;
                this.fetchCrmCaseData();
            } else {
                this.columns = this.decisionColumns;
                this.showPagination = true;
                this.fetchDecisionMakerCaseData();

            }
        }
        catch (error) {
            this.showToast('Error', 'An unexpected error occurred, please contact your Administrator', 'error');

        }
    }

    /* @author      : Coforge
* @date        : 05/03/2025
* @description : Method to handle the showtoast
* @return      : None
* @param       : title,message,variant,mode
*/

    showToast(title, message, variant, mode) {
        try {
            const evt = new ShowToastEvent({
                title: title,
                message: message,
                variant: variant,
                mode: mode
            });
            this.dispatchEvent(evt);
        }
        catch (e) {
            this.showToast('Error', 'An unexpected error occurred, please contact your Administrator', 'error');

        }
    }


}