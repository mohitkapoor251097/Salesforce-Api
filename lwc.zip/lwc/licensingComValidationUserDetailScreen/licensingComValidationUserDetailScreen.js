import { LightningElement, api } from 'lwc';
import LicensingComContactDetailsLastUpdated from '@salesforce/label/c.LicensingComContactDetailsLastUpdated';
import LicensingComContactDetailsRequireValidationMsg from '@salesforce/label/c.LicensingComContactDetailsRequireValidationMsg';
import getUserAccountRequireValidation from '@salesforce/apex/Licensing_Utility.getUserAccountRequireValidation';

export default class LicensingComValidationUserDetailScreen extends LightningElement {

    @api personAccountJSON;
    userAccount;
    lastVerifiedDateLabel = LicensingComContactDetailsLastUpdated;
    requiredValidationMsg = LicensingComContactDetailsRequireValidationMsg;
    isValidateUserDetailSectionReq = false; // This variable is used to display validate user detail section
    contactLastVerified; // It is used to store last verified date of the current logged in user
    isLastVerifiedDateSectionRequired = false; // This variable is used to display the last verified date section
    isTweleveHourFormatReq = false; // It is used to store which format is required i.e. 12 hour or 24 hour format

    /*       
    * @author      : Coforge
    * @date        : 02/08/2023
    * @description : Method called when component is loaded to bring data for licensing dashboard screen - ADO 12634
    * @return      : None
    * @param       : None
    */
    connectedCallback() {
        try {
            // Verify person account JSON record is blank or not
            if (this.personAccountJSON != undefined && this.personAccountJSON != null) {
                // Parsing account record JSON into object
                this.userAccount = (JSON.parse(this.personAccountJSON));
                this.contactLastVerified = this.userAccount.Contact_Details_Last_Verified__pc;

                // If contanct last verified date is not blank, make it visible on verified user section
                if (this.contactLastVerified != null && this.contactLastVerified != '') {
                    this.isLastVerifiedDateSectionRequired = true;
                }

                //Made server side calling to identify verify user detail section required or not
                getUserAccountRequireValidation({ accountJson: this.personAccountJSON })
                    .then((result) => {
                        this.isValidateUserDetailSectionReq = result;
                    });
            }
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 02/08/2023
    * @description : Method called when user clicks on the verify my detail button - ADO 12634
    * @return      : None
    * @param       : None
    */
    handleVerifyUserDetail() {
        window.location = '/LicensingComUserDetailsUpdate?RetURL=%2FLicensingComDashboard';
    }

}