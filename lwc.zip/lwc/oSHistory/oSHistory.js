import { LightningElement, api } from 'lwc';
import getHistoryRecords from '@salesforce/apex/OSHistoryController.getHistoryRecords';

import { subscribe } from 'lightning/empApi';

const columns = [{
    label: 'View',
    type: 'button-icon',
    initialWidth: 50,
        typeAttributes:{   
            iconName: 'action:preview',
            title: 'Open in New Tab',
            name: 'View',
            alternativeText: 'View'
        }
    },
    { label: 'Date', 
      fieldName: 'createdDate', 
      type: 'date', 
        typeAttributes: {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        }
    },
    { label: 'Field', fieldName: 'fieldName', type: 'text' },
    {
        label: 'User',
        fieldName: 'userIdLink',
        type: 'url',
        typeAttributes: { label: { fieldName: 'userName' }, target: '_blank' }
    },
    { label: 'Original Value', fieldName: 'oldValue', type: 'text' },
    { label: 'New Value', fieldName: 'newValue', type: 'text' },
    { label: 'Operation', fieldName: 'operation', type: 'text' }
];

const mapOfApiNameVsLabel = new Map([
            ['createdDate', 'Date'],
            ['fieldName', 'Field'],
            ['userName', 'User'],
            ['oldValue', 'Original Value'],
            ['newValue', 'New Value'],
            ['operation', 'Operation'],
        ]);
const mapOfApiNameVsDataType = new Map([
            ['createdDate', 'datetime'],
            ['fieldName', 'text'],
            ['userName', 'text'],
            ['oldValue', 'text'],
            ['newValue', 'text'],
            ['operation', 'text'],
        ]);

const NO_RECORD_TO_DISPLAY_LABEL = 'No records to display'
const RICHTEXTAREA_LABEL = 'RICHTEXTAREA';
const TEXTAREA_LABEL = 'TEXTAREA';
const OLDVALUE_LABEL ='oldValue';
const NEWVALUE_LABEL ='newValue';
const DATEONLY_LABEL ='DateOnly';
const DATETIME_LABEL = 'DATETIME';

export default class OSHistory extends LightningElement {
noRecordsPlaceHolder = NO_RECORD_TO_DISPLAY_LABEL;
@api
get recordId() {
    return this._recordId;
}

set recordId(value) {
  this._recordId = value;
}

@api metadataRecordApiName;
@api iconName;
@api title;

tempTitle;
tempRecords =[];

modalContainer = false;
columns = columns;
isLoaded = false;
records = [];
_recordId;
error;

subscription = null;

historyRowRichTextArea = [];
historyRowTextArea=[];
historyRow=[];

//Pagination 
pageSizeOptions = [5,10,20,50,100,200,500]; //Page size options
totalRecords = 0; //Total no.of records
pageSize; //No.of records to be displayed per page
totalPages; //Total no.of pages
pageNumber = 1; //Page number    
recordsToDisplay = []; //Records to be displayed on the page
displayPagination = false;

get bDisableFirst() {
    return this.pageNumber == 1;
}
get bDisableLast() {
    return this.pageNumber == this.totalPages;
}
get showRecords() {
    return this.recordsToDisplay.length > 0;
}


/*
* @author      : Coforge
* @date        : 19/02/2024
* @description : This method is calling the imperative method in connectedcallback
* @params      : none
* @return      : none
*/
connectedCallback() {
    if(this.tempTitle == '' || this.tempTitle == undefined){
        this.tempTitle = this.title;
    }
    this.getHistoryData();
    this.subscribeToEvent();
}

/*
* @author      : Coforge
* @date        : 26/02/2024
* @description : This method is used to subscribe the platform event
* @params      : none
* @return      : none
*/
subscribeToEvent() {
        const channel = '/event/FieldChangeEvent__e';
        const messageCallback = (response) => {

            // Handle event
            if(response.data.payload.RecordId__c){
                this.handleEvent(response);
            }
        };

        subscribe(channel, -1, messageCallback).then(response => {
            this.subscription = response;
        }).catch(error => {
            console.error('Error subscribing to channel:', JSON.stringify(error));
        });
    }
    
/*
* @author      : Coforge
* @date        : 26/02/2024
* @description : This method is used to handle the response of the platform event
* @params      : response
* @return      : none
*/
    handleEvent(response) {
        if(response.data.payload.RecordId__c == this._recordId){
            this.getHistoryData();
        }
        
    }


/*
* @author      : Coforge
* @date        : 19/02/2024
* @description : This method is used to fetched the data from the server
* @params      : none
* @return      : none
*/
getHistoryData(){
  this.isLoaded = true;
  getHistoryRecords({
      parentId: this._recordId,
      metadataRecordApiName: this.metadataRecordApiName
    })
  .then((result) => {
            try {
                if(result) {
                    result.forEach(res => {
                        res.userIdLink = '/' + res.userId;
                        // Bug 27358 updated filter for date field values
                        if( res.fieldType == DATEONLY_LABEL){
                            res.newValue = res.newValue.split(' ')[0];
                            res.oldValue = res.oldValue.split(' ')[0];
                        }
                        // Bug fix - 56172 converted the date time to local system time
                        if( res.fieldType == DATETIME_LABEL){
                            if(res.oldValue != ''){
                                res.oldValue = this.convertToLocalTime(res.oldValue);
                            }
                            if(res.newValue != ''){
                                res.newValue = this.convertToLocalTime(res.newValue);
                            }                            
                        }                        
                    });
                    this.records = result;
                    this.isLoaded = false;
                    this.title = this.tempTitle;

                    //Pagination logic
                    if(this.records){
                        this.totalRecords = this.records.length;// update total records count 
                        this.pageSize = this.pageSizeOptions[0]; //set pageSize with default value as first option
                        this.paginationHelper(); // call helper menthod to update pagination logic 
                        this.displayPagination = this.records.length > 5 ? true : false; //Display the pagination if records more than 10
                        this.title += ' ('+ this.records.length +')'; //Display the number of records in title
                    }
                }
                this.isLoaded = false;
            } catch(e){
                console.log('exeception ==>',JSON.stringify(e));
                this.isLoaded = false;
            }

        })
        .catch((error) => {
            console.log('exeception ==>',JSON.stringify(error));
            this.isLoaded = false;
        });
        this.isLoaded = false;
    }

    /*
    * @author      : Coforge
    * @date        : 24/04/2025
    * @description : Bug fix - 56172 converted the date time to local system time
    * @params      : utcString
    * @return      : String
    */
    convertToLocalTime(utcString) {
        try {
            const isoUtcString = utcString.replace(' ', 'T') + 'Z';
            const utcDate = new Date(isoUtcString); // Parses as UTC
            const pad = (n) => (n < 10 ? '0' + n : n);
            // Get local time values
            const localDateTime =
                utcDate.getFullYear() + '-' +
                pad(utcDate.getMonth() + 1) + '-' +
                pad(utcDate.getDate()) + ' ' +
                pad(utcDate.getHours()) + ':' +
                pad(utcDate.getMinutes()) + ':' +
                pad(utcDate.getSeconds());
            return localDateTime;
        } catch (error) {
            console.error('Conversion error:', error);
            return '';
        }
    }


    /*
    * @author      : Coforge
    * @date        : 19/02/2024
    * @description : Handle Row Action and open modal and display form 
    * @params      : none
    * @return      : none
    */
    handleRowAction( event ) {
        const keyToExeclude = new Set(["id","fieldType","userId","userIdLink"]);
        this.historyRowRichTextArea = [];
        this.historyRowTextArea = [];
        this.historyRow = [];

        this.modalContainer=true;
        const row = event.detail.row;

        if(row){
            for (let key in row) {
                if(key != 'undefined' && !keyToExeclude.has(key)){
                    //Set the values
                    if( row.fieldType == TEXTAREA_LABEL && (key == OLDVALUE_LABEL || key == NEWVALUE_LABEL) &&  mapOfApiNameVsDataType.has(key)){
                        this.historyRowTextArea.push({'key':mapOfApiNameVsLabel.get(key),'value':row[key],'type':'text'});
                    }else if(row.fieldType == RICHTEXTAREA_LABEL && (key == OLDVALUE_LABEL || key == NEWVALUE_LABEL) && mapOfApiNameVsDataType.has(key)){
                        this.historyRowRichTextArea.push({'key':mapOfApiNameVsLabel.get(key),'value':row[key],'type':'text'});
                    }else{
                        this.historyRow.push({'key':mapOfApiNameVsLabel.get(key),'value':row[key],'type':mapOfApiNameVsDataType.get(key)});
                    }
                }
            }
        }
    }

    /*
    * @author      : Coforge
    * @date        : 19/02/2024
    * @description : Manage records per page Function 
    * @params      : none
    * @return      : none
    */
    handleRecordsPerPage(event) {
        this.pageSize = event.target.value;
        this.paginationHelper();
    }

    /*
    * @author      : Coforge
    * @date        : 19/02/2024
    * @description : Previous Page Function
    * @params      : none
    * @return      : none
    */
    previousPage() {
        this.pageNumber = this.pageNumber - 1;
        this.paginationHelper();
    }

    /*
    * @author      : Coforge
    * @date        : 19/02/2024
    * @description : Next Page Function
    * @params      : none
    * @return      : none
    */
    nextPage() {
        this.pageNumber = this.pageNumber + 1;
        this.paginationHelper();
    }

    /*
    * @author      : Coforge
    * @date        : 19/02/2024
    * @description : First Page Function
    * @params      : none
    * @return      : none
    */
    firstPage() {
        this.pageNumber = 1;
        this.paginationHelper();
    }

    /*
    * @author      : Coforge
    * @date        : 19/02/2024
    * @description : Last Page Function
    * @params      : none
    * @return      : none
    */
    lastPage() {
        this.pageNumber = this.totalPages;
        this.paginationHelper();
    }

    /*
    * @author      : Coforge
    * @date        : 19/02/2024
    * @description : JS function to handel pagination logic 
    * @params      : none
    * @return      : none
    */
    paginationHelper() {
        this.recordsToDisplay = [];
        
        // calculate total pages
        this.totalPages = Math.ceil(this.totalRecords / this.pageSize);
        
        // set page number 
        if (this.pageNumber <= 1) {
            this.pageNumber = 1;
        } else if (this.pageNumber >= this.totalPages) {
            this.pageNumber = this.totalPages;
        }

        // set records to display on current page
        if(this.records.length > 0){ 
            for (let i = (this.pageNumber - 1) * this.pageSize; i < this.pageNumber * this.pageSize; i++) {
                if (i === this.totalRecords) {
                    break;
                }                
                this.recordsToDisplay.push(this.records[i]);
                
            }
        }
    }

    /*
    * @author      : Coforge
    * @date        : 19/02/2024
    * @description : Close Modal 
    * @params      : none
    * @return      : none
    */
   closeModalAction(){
    this.modalContainer=false;
   }
}