import { LightningElement ,api } from 'lwc';
import updateSobjectData from '@salesforce/apex/OSUpdateMeetingStatusController.updateMeetingData';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { getRecordNotifyChange } from 'lightning/uiRecordApi';
import COMMON_ERROR from '@salesforce/label/c.CommonError';
import { CloseActionScreenEvent } from 'lightning/actions';

const SUCCESS_MESSAGE = 'Meeting status finalised successfully!';
const DISMISSABLE_LABEL = 'dismissable';
const SUCESS_LABEL = 'success';
const ERROR_LABEL = 'error';

export default class OsUpdateMeetingStatus extends LightningElement {
    modalContainer = true;
    
    @api recordId;
    message;

    connectedCallback() {
        this.closeScreeQuickAction();
    }

    /*
     * @author      : Coforge
     * @description : fetch the record to display sensitive info
     * @params None
     * @return List of records
     */
    updateMeetingDataAction() {
         updateSobjectData({
            recordId : this.recordId
        }).then((result) => {
            try{
                if(result) {
                    let message = result;
                    if(message && message == SUCESS_LABEL){
                        this.showNoRecordsToast(SUCCESS_MESSAGE,SUCESS_LABEL,DISMISSABLE_LABEL);
                        this.refreshDetailPage();
                        this.closeModalAction();
                    }else if(message && message == ERROR_LABEL){
                        this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
                    }else {
                        this.showNoRecordsToast(message,ERROR_LABEL,DISMISSABLE_LABEL);
                    }      
                }
            } catch(e){
                this.message = JSON.stringify(e)
                console.log('error==>',JSON.stringify(e));
                this.closeModalAction();
                this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
                
            }
        })
        .catch((error) => {
            console.log('error==>',JSON.stringify(error));
            this.closeModalAction();
            this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
        });
    }

    /*
     * @author      : Coforge
     * @description : Close the modal 
     * @params      : event
     * @return      : NA
    */
    closeModalAction(){
        this.modalContainer=false;
        this.closeScreeQuickAction();
    }
    /*
     * @author      : Coforge
     * @description : Close the modal 
     * @params      : event
     * @return      : NA
    */
    closeScreeQuickAction(){
        this.dispatchEvent(new CloseActionScreenEvent());
    }

    /*
     * @author      : Coforge
     * @date        : 03/01/2024
     * @description : To show the toast message for success and error 
     * @params      : title
     * @params      : variant
     * @params      : mode
     * @return      : NA
     */
    showNoRecordsToast(title,variant,mode) {
        const event = new ShowToastEvent({
            title: title,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(event);
    }
    /*
     * @author      : Coforge
     * @date        : 11/01/2024
     * @description : Refresh/Reload the detail page
     * @return      : NA
     */
    refreshDetailPage(){
        getRecordNotifyChange([{recordId: this.recordId}]);
    }
}