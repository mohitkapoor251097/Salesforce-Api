import { LightningElement, api } from 'lwc';
import searchRecordsUsingMetadata from '@salesforce/apex/OS_MeetingController.searchRecordsUsingMetadata';
import getFieldsFromMetadata from '@salesforce/apex/OS_MeetingController.getFieldsFromMetadata';
import OFCOM_BUSINESS_ACCOUNT_ID from '@salesforce/label/c.OfcomBusinessAccountId';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

const DELETE_BUTTON_COLUMN = {
    type: 'button-icon',
    initialWidth: 50,
    typeAttributes:
    {
        iconName: 'utility:delete',
        name: 'delete',
        alternativeText: 'Delete'
    }
};
const PLEASE_SELECT_ROWS_MESSAGE = 'Please select at least one row.';

export default class SearchComp extends LightningElement {

    @api title = '';
    @api filterCriteria = '';
    @api metadataRecordApiName = '';
    @api recordIdsToExclude = [];
    @api filterAccountData = [];
    @api stakeholdertype =''; // its defines the type of stake holder

    get showAccountPicklist() {
        return this.accountOptions.length > 0;
    }

    stakeholderOrganizations = 'Stakeholder Organizations';
    searchTerm = '';
    cancelLabel = 'Cancel';
    addLabel = 'Add';
    //For search tile
    primaryField;
    secondaryField;
    tileUrl;

    accountOptions = [];
    columns = [];
    data = [];
    datatable = [];
    searchMap;
    showLoading = false; //for spinner
    
    /*
     * @author      : Coforge
     * @description : first getting the data from custom metedata and based on that doing the 
     * soql on particular object to fetch the data and mapp that with the datatable , also showing 
     * the stakeholder organization picklist in case on stakeholder Lead and stakeholder participants.
     * @params      : event
     * @return      : NA
     */
    connectedCallback() {
        this.setupColumns();  
        if(this.filterAccountData) {
            for(const element of this.filterAccountData) {
                if(element['StakeholderType__c'] === 'Stakeholder Organization'){
                    this.accountOptions.push({label: element['Account__r.Name'], value: element['Account__c'], selected: false})
                }
            }
        }
    }

    /*
     * @author      : Coforge
     * @description : This method is used to get the fields from the custom metadatatype
     * @params      : event
     * @return      : NA
     */
    
    urlClick(event){
        const currentId = event.target.name;
        //alert('id: '+currentId);
        window.open(currentId, '_blank');
    }

    /*
     * @author      : Coforge
     * @description : This method is used to set the Data table column
     * @params      : event
     * @return      : NA
     */
    setupColumns() {

        getFieldsFromMetadata({ metadataRecordName: this.metadataRecordApiName }).then((result) => {
            try{
                if(result) {
                    this.columns = this.sanitizeMetadata(result);
                }
            } catch(e){
                this.showNoRecordsToast('Something went wrong, kindly cordinate with admin','error','dismissable');
            }
        })
        .catch((error) => {
            this.showNoRecordsToast('Something went wrong, kindly cordinate with admin','error','dismissable');
        });
    }
    /*
     * @author      : Coforge
     * @description : This method is used to set the primary and secondary fields values for search in the tiles
     * @params      : result
     * @return      : NA
     */
    sanitizeMetadata(result) {
        try{
            const temp = [];
            const searchTileFields = result.SearchTileFields__c.split(',');
            this.primaryField = searchTileFields[0];
            this.secondaryField = searchTileFields[1];
          
            const fieldsMapping = result.FieldsMapping__c.split(",");
            for(const obj of fieldsMapping) {
                const val = obj.split("=");
                //start for W-002656 
                // Show stakeholder column only when stakeholdertype is equal to Stakeholder lead
                if(this.stakeholdertype!='Stakeholder Lead' && val[0]!='Account.Name'){
                    temp.push({fieldName: val[0], label: val[1], type: 'text'});
                }
                else if(this.stakeholdertype=='Stakeholder Lead'){
                    temp.push({fieldName: val[0], label: val[1], type: 'text'});
                }
                //end for W-002656
            }
            temp.push(DELETE_BUTTON_COLUMN);
          
            return temp;
        }catch(e){
            this.showNoRecordsToast(COMMON_ERROR,'error','dismissable');
        }
    }

    /*
     * @author      : Coforge
     * @description : Closed modal
     * @params      : event
     * @return      : NA
     */
    closeModel(event) {
        this.dispatchEvent(new CustomEvent('close', {}));
    }
    /*
     * @author      : Coforge
     * @description : This method is used to add all the selected values in datatable
     * @params      : event
     * @return      : NA
     */
    submitDetails(event) {
        if(this.datatable.length == 0) {
            const event = new ShowToastEvent({
                title: PLEASE_SELECT_ROWS_MESSAGE,
                variant: 'info',
                mode: 'dismissable'
            });
            this.dispatchEvent(event);
            return;
        } else {
            this.dispatchEvent(new CustomEvent('close', {detail: this.datatable}));
        }
    }

    /*
     * @author      : Coforge
     * @description : This method is used to add all the selected values in the below datatable 
     * @params      : event
     * @return      : NA
     */
    selectRecord(event) {
        try{
            const currentId = event.target.title;

            let tempData = [];
            let temptable = [];
            this.showSelected = true;
        
            let excludeIdsTemp = this.recordIdsToExclude.map(element => element);//fix
            for(const element of this.data) {
                const singleObjectData = {};
                if(element.Id === currentId) {
                    //Added if user search person account for Stakeholder Lead and Stakeholder Participant
                    if(element.Id && element.Id.substring(0,3)==='001' && (this.stakeholdertype =='Stakeholder Lead' || this.stakeholdertype =='Stakeholder Participant')){
                        let tempAccountObj = {'Id':'','Name':''};
                            if(element.Organisational_Roles_Contact__r){
                                for(let orgRole of element.Organisational_Roles_Contact__r){
                                    if(orgRole.Contact__c && orgRole.Licensee_or_Organisation__c && orgRole.Contact__c == element.Id){
                                        tempAccountObj['Id'] = orgRole.Licensee_or_Organisation__c;
                                        tempAccountObj['Name'] = orgRole.Licensee_or_Organisation__r.Name;
                                    }
                            }
                        }
                        element['Email'] = element.PersonEmail ? element.PersonEmail : '';
                        element['Account.Id'] = tempAccountObj.Id ? tempAccountObj.Id : '';
                        element['Account.Name'] = tempAccountObj.Name ? tempAccountObj.Name : '';
                    }

                    excludeIdsTemp.push(currentId);//fix
                    // start for W-002656
                    let rowKeys = Object.keys(element);
                    rowKeys.forEach((rowKey) => {
                    //getting value of each row
                        const valueD = element[rowKey];
                        //check whether the type of value is object
                        if(typeof(valueD) == 'object'){
                            singleObjectData[rowKey] = valueD;
                            let nestedObjRow = Object.keys(valueD);
                            nestedObjRow.forEach((key) =>{
                                let finalKey = rowKey + '.' + key;
                                singleObjectData[finalKey] = valueD[key];
                            })
                        }
                        else {
                            singleObjectData[rowKey] = valueD;
                        }
                    });
                    temptable.push(singleObjectData); 
                   //2656 end
                } else {
                    tempData.push(element);
                }
            }
            this.recordIdsToExclude = excludeIdsTemp;//fix
            this.data = tempData;

             for(const element of this.datatable) {         
                temptable.push(element); 
             }
         
           this.datatable = temptable; 
         
        } catch(e){
             this.showNoRecordsToast('Something went wrong, kindly cordinate with admin','error','dismissable');
        }
    }
   
   /*
     * @author      : Coforge
     * @description : This method is used to remove the row 
     * @params      : event
     * @return      : NA
     */
    removeRow(event) {
        try{
            const row = event.detail.row;
            let tempData = [];
            let temptable = [];

            for(const element of this.datatable) {
                if(element.Id === row.Id) {
                    tempData.push(element);
                } else {
                    temptable.push(element);
                }
            }
            this.datatable = temptable;

            if(this.datatable.length == 0) {
                this.showSelected = false;
            }

            for(const element of this.data) {
                tempData.push(element);
            }
            this.data = tempData;
        } catch(e){
            this.showNoRecordsToast('Something went wrong, kindly cordinate with admin','error','dismissable');
        }
    }

    /*
     * @author      : Coforge
     * @description : This method is used to search all the records based on the input text and other filters 
     * @params      : event
     * @return      : NA
     */
    handleKeyUp(event) {
        try{    
            this.showLoading = true; //show spinner
            const accountsToInclude = [];
            if('Ofcom Participant' == this.stakeholdertype) {
                accountsToInclude.push(OFCOM_BUSINESS_ACCOUNT_ID);

            } else if (this.stakeholdertype =='Stakeholder Participant' || this.stakeholdertype =='Stakeholder Lead') {
                
                let selection = this.template.querySelector('c-os-multi-select-picklist-component');
                if (selection != null){
                    for(const element of selection.values) {
                        if(element.selected == true) {
                            accountsToInclude.push(element.value);
                        }
                    }
                    if(accountsToInclude.length == 0) {
                        for(const element of this.accountOptions) {
                            accountsToInclude.push(element.value);
                        }
                    }
                }

            }
            this.searchMap = {"searchTerm":'',"metadataRecordName":'',"filterCriteria":''};
            this.searchMap["searchTerm"] = event.target.value;
            this.searchMap["metadataRecordName"]=this.metadataRecordApiName;
            this.searchMap["filterCriteria"] = this.filterCriteria;
            this.searchTerm = event.target.value;

            searchRecordsUsingMetadata({ 
                    searchMap:this.searchMap,
                    accountIds: accountsToInclude
                }).then((response) => {
                    this.data = [];
                    this.showLoading = false; //hide spinner
                    if(response.length > 0) {
                        this.data = this.sanitizeSearchResult(response);
                        
                    } else {
                        this.showNoRecordsToast('No Record Found.','info','dismissable');
                    }
                })
                .catch((error) => {
                    this.data = [];
                    this.showNoRecordsToast('Something went wrong, kindly cordinate with admin','error','dismissable');
            });
        } catch(e){
            this.showNoRecordsToast('Something went wrong, kindly cordinate with admin','error','dismissable');
        }

    }
    /*
     * @author      : Coforge
     * @description : This method is used to exculde recordids and add search result into tiles 
     * @params      : event
     * @return      : NA
     */
    sanitizeSearchResult(result) {
        try{
            const temp = [];
            for(let i=0; i<result.length ; i++) {
               
                let obj = result[i];
                if(this.recordIdsToExclude.indexOf(obj.Id) == -1) {
                    temp.push(obj);
                }
            }
            
            let accountIcon = 'standard:person_account';
            var objectName;
            if(this.stakeholdertype =='Stakeholder Organization'){
                objectName = 'Account';
                accountIcon = 'standard:account';
            }else{
                objectName = 'Contact';
            }
            return temp.map((item) => ({
               
               
                ...item,
                primaryField: item[this.primaryField],
                secondaryField: (this.stakeholdertype !='Stakeholder Organization' && item.Id.substring(0,3)==='001') ? item['PersonEmail'] : item[this.secondaryField],
                tileUrl: window.location.origin + '/lightning/r/'+objectName+'/' +item.Id+'/view',//Added by Shabana
                iconName: item.Id.substring(0,3)==='001' ? accountIcon :'standard:contact'
               
            }));
            
        }catch(e){
            this.showNoRecordsToast(COMMON_ERROR,'error','dismissable');
        }
    }

    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : To show the toast message for success and error 
     * @params      : title
     * @params      : variant
     * @params      : mode
     * @return      : NA
     */
    showNoRecordsToast(title,variant,mode) {
        const event = new ShowToastEvent({
            title: title,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(event);
    }

}