/*********************************************************************
# File....................: flowShowToastMessage.js
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............: 7/11/2024
# Last Modified by........: 
# Last Modified Date......: 
# Description.............: This is a JS Controller of 'flowShowToastMessage' Lightning component .   
# Lightning Component.....: flowShowToastMessage
# Change Log..............: v1.0 Initial Version 
**********************************************************************/
import { LightningElement, api } from 'lwc';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';

/*
* @author      : Coforge
* @date        : 07/11/2024
* @description : This is the main class component.
* @params      : NA
* @return      : NA
*/
export default class FlowShowToastMessage extends NavigationMixin(LightningElement) {
    @api mode;
    @api variant;
    @api toastMessage;
    @api title;
    @api recordId;

    /*
	* @author      : Coforge
	* @date        : 07/11/2024
	* @description : This function give the init functionality to the component and all the data, functions declared here will run on the page load.
	* @params      : NA
	* @return      : handleShowToast and navigateToRecord function
	*/
    connectedCallback() {
        this.handleShowToast();
        this.navigateToRecord();
    }
    
    /*
	* @author      : Coforge
	* @date        : 07/11/2024
	* @description : This function is used to show toast message.
	* @params      : NA
	* @return      : NA
	*/
    handleShowToast(){
        const event = new ShowToastEvent({
            title:this.title,
            mode:this.mode,
            variant:this.variant,
            message:this.toastMessage
        });
        this.dispatchEvent(event);
    }

    /*
	* @author      : Coforge
	* @date        : 07/11/2024
	* @description : This function is used to navigate to new created record.
	* @params      : NA
	* @return      : NA
	*/
    navigateToRecord(){        
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.recordId,
                actionName: 'view'
            }
        });
    }

}