/**
* @description   Displays Manage Transaction screen
* @author        Coforge
* @date          02 Dec 2022
* @lastModified  02 Dec 2022
* @ChangeLog     Intitial Version 1.0 : 02-12-2022 : W-002859 LPE Replace Contact: REP3.1] Select type of ‘Manage’ transaction (manage licence or update contact)
                          Version 1.1 : 08-12-2022 : W-002871 LPE Replace Contact: REP5.4] Select to ‘Manage licence’ to be taken to mySPECTRA (including SSO parameters)
                          Version 1.2 : 29-12-2022 : W-002861 LPE Replace Contact: REP5.2] View details on the Contact overview page
                          Version 1.3 : 05-01-2023 : W-002880 LPE Replace Contact: REP7.1] Create new licence contact from the Contact Overview
                          Version 1.4 : 13-01-2023 : W-002890 LPE Replace Contact: REP12.1] Create new payment contact from the Contact Overview
                          Version 1.5 : 06-02-2023 : W-002860 LPE Replace Contact: REP5.1] View and navigate updated breadcrumb trail

*/
import { api, LightningElement } from 'lwc';
import LicensingComManageTransactionLabel from '@salesforce/label/c.LicensingComManageTransactionLabel';
import prepareSSOData from '@salesforce/apex/Licensing_Utility.prepareSSOData';  //W-002871/W-002898
import AERO_MYSPECTRA_URL from '@salesforce/label/c.AERO_MYSPECTRA_URL';

export default class LicensingComLicenseeManageTransactionScreen extends LightningElement {
    showSpinner=true; // To show spinner until data is fetched
    @api licensee;
    @api licenseecount;
    @api capturecontactevent;   // W-002880
    isManageTransaction;
    manageTextLabel = LicensingComManageTransactionLabel;
    openContactOverviewScreen;
    managelicensee;

    /*       
    * @author      : Coforge
    * @date        : 24/11/2022
    * @description : Method called when component is loaded to bring data for licensee selection screen - W-002858
    * @return      : None
    * @param       : None
    */   
    connectedCallback() {
        try{
            if(this.licensee!=null){
                this.isManageTransaction = true;
            }
            this.showSpinner = false;
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 06/12/2022
    * @description : Method called on previous button click - W-002859
    * @return      : None
    * @param       : None
    */
    goToPreviousPage(){
        try{
            if(this.licenseecount==1){
                window.location = '/apex/LicensingComDashboard';
            }else{
                window.location = '/apex/licensingcomapplyforlicence?licence=Aeronautical+Radio&isAeroManage=true';
            }
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 05/12/2022
    * @description : W-002871/W-002898 : Method called when Manage Licence button is clicked
    * @return      : None
    * @param       : None
    */  
    redirectToMySpectra(){
        try{
            this.showSpinner = true;
            prepareSSOData({ selectedLicensee: JSON.stringify(this.licensee),
                selectedLicenceContact : null,
                selectedPaymentContact : null,
                caseCode : 'caseCode=03'
            }).then((result) => {
                    this.showSpinner = false;
                    if(result=='Success'){
                    window.location.href=AERO_MYSPECTRA_URL;
                    }
                })
                .catch((error) => {
					window.location.href='/apex/licensingcomerror';
                });
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 01/12/2022
    * @description : Method called on next button click of licensee selection screen
    * @return      : None
    * @param       : event
    * @param       : capturecontactevent   //W-002880 getting boolean value.
    */
    @api
    goToContactOverview(event, capturecontactevent){
        try{
            this.managelicensee = this.licensee; 
            // W-002861 : To hide Licensee selection screen
            this.isManageTransaction = false;
            // It is used to show/hide the content on the current component and child component
            this.openContactOverviewScreen= true;
            // START -W-002860 seting Update Contact breadcurm 
            this.dispatchEvent(new CustomEvent("updatebreadcrumb",{
                detail:{
                    screenName : 'Update contact' 
                }
            }));
            // END -W-002860 seting Update Contact breadcurm 
            this.openContactOverviewScreen= true;
            
            //W-002880 start
            if(capturecontactevent=== "LicenseContactData"){
                this.template.querySelector('c-licensing-com-contact-overview-screen').handleLicenceIconClick(event); 
            //W-002880 end
            //W-002890 start 
            }else if(capturecontactevent=== "PaymentContactData"){
                this.template.querySelector('c-licensing-com-contact-overview-screen').handlePaymentIconClick(event); 
            }
            //W-002890 end
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }     
    }
    /*       
    * @author      : Coforge
    * @date        : 06/12/2022
    * @description : Method called on previous button click - W-002859
    * @return      : None
    * @param       : None
    */
    goToPreviousManageScreen(){
        this.openContactOverviewScreen= false;
        // START -W-002860 setting Manage Licences breadcurmb 
        this.dispatchEvent(new CustomEvent("updatebreadcrumb",{ 
            detail:{
                screenName : 'Manage' 
            }
        }));
        // END -W-002860 setting Manage Licences breadcurmb 
        this.isManageTransaction = true;
    }

    /*       
    * @author      : Coforge
    * @date        : 02/01/2023
    * @description : W-002880 : To open Licence Contact popup, when event for this is recieved from the child - Contact Overview Screen
    * @return      : None
    * @param       : event
    */
    opencontactpopup(event){ 
        try{
            this.dispatchEvent(new CustomEvent("openlicencecontactpopup",{
                detail:{
                    selectedContact: event.detail.selectedContact,
                    selectedContactType :event.detail.selectedContactType, // Passing the Contact's type
                    selectedLicenseeId: event.detail.selectedLicenseeId
                }
            }));
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }      
    } 
}