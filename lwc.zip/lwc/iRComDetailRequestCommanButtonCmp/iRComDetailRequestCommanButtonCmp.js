/**
* @description   Displays the IR cases summary table
* @author        Coforge
* @date          26 June 2024
* @lastModified  26 June 2024
* @description : ADO 22376 Access to the Detailed IR Request Screen(Dummy component need to delete)
*/
import { LightningElement } from 'lwc';
export default class IRComDetailRequestCommanButtonCmp extends LightningElement {

    /*       
      * @author      : Coforge
      * @date        : 26/06/2024
      * @description : ADO 22376 Access to the Detailed IR Request Screen
      */
    handleback() {
        try {
            const updatedValues = {
                isvisibleirdetailrequest: true,
                isvisiblecommoanbuttoncmp: false
            };
            this.dispatchEvent(new CustomEvent('updatevalues', {
                detail: updatedValues
            }));
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
}