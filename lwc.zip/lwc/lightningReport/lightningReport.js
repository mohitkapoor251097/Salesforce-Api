/**
* @description   Display Lightning Reports tab section .
* @author        Coforge
* @date          19 Feb  2025
* @lastModified  27 Feb  2025
* @ChangeLog     Intitial Version 1.0 
*/
import { LightningElement } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class lightningReport extends NavigationMixin(LightningElement) {
    
 
    showToast(title, message, variant, mode) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(evt);
    }
    
    
    linkHandler(event) {
        try {
        var compDetails = {
            componentDef: "c:csleReport",
            
        };
        // Base64 encode the compDefinition JS object
        var encodedCompDetails = btoa(JSON.stringify(compDetails));
        console.log('encodedComp'+encodedCompDetails);
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: '/one/one.app#' + encodedCompDetails
            }
        });
        }
        catch(error) {
            this.showToast('Error', 'An unexpected error occurred, please contact your Administrator', 'error');
        }
    }
}