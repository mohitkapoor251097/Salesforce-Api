/**
* @description   Displays Available Licencees list
* @author        Coforge
* @date          18 Jan  2023
* @lastModified  25 Jan  2023
* @ChangeLog     Intitial Version 1.0 : 29-12-2022 : W-002892 LPE Replace Contact: REP9.1] Add contact type to licence contact from the Contact Overview
*/

import { LightningElement,api} from 'lwc';
import updateOrgRoleRecord from '@salesforce/apex/Licensing_Utility.updateOrgRoleRecord';
 
export default class AddContactTypeModal extends LightningElement {
    @api isshowmodal;
    @api contactorg;
    licenceContactCheckboxVal;
    paymentContactCheckboxVal;
    addLicenceContactType = false;
    addPaymentContactType = false;
    orgRoleTypeList;
    isContactUpdated = false;
    errormsg = false;
    updateContactValidation = '';
    showSpinner = false;

    /*       
    * @author      : Coforge
    * @date        : 05/01/2023
    * @description : W-002892 : Method called when component is loaded to bring data for chechbox value.
    * @return      : None
    * @param       : event
    */
    connectedCallback() {
        this.orgRoleTypeList = (this.contactorg.Types__c).split(';');
        if(this.contactorg.Types__c == 'Licence Contact' || this.orgRoleTypeList.includes('Licence Contact')){
           this.licenceContactCheckboxVal = true; 
        }
        if(this.contactorg.Types__c == 'Licence Bill/Account Contact' || this.orgRoleTypeList.includes('Licence Bill/Account Contact')){
            this.paymentContactCheckboxVal = true;
        }
        
        this.isshowmodal=true;
    }

    /*       
    * @author      : Coforge
    * @date        : 05/01/2023
    * @description : W-002892 : Method called on click of 'Cancel/close icon' button.
    * @return      : None
    * @param       : event
    */
    closeModalAction(event){
        event.stopPropagation();
        this.dispatchEvent(new CustomEvent("closemodalaction",{
            detail:{isContactUpdated: this.isContactUpdated}
        }));
        this.isshowmodal = false;
        
    }

    closeSectionAction(){
        this.dispatchEvent(new CustomEvent("closemodalaction",{
            detail:{isContactUpdated: this.isContactUpdated}
        }));
        this.isshowmodal = false;
    }

    /*       
    * @author      : Coforge
    * @date        : 05/01/2023
    * @description : W-002892 : Method called on click of 'Update Contact' button.
    * @return      : None
    * @param       : event
    */
    handleUpdateContact(){
        try{
            //var updateContactButton = document.getElementById("updateContactId");
            this.updateContactValidation = '';
            this.template.querySelector('[data-id="errorData"]').classList.remove('error');  //Removing error class from UI
            const newContactObj = { ...this.contactorg, prop: 'this.contactorg' };
            if(this.addLicenceContactType && !this.orgRoleTypeList.includes('Licence Contact')){
                newContactObj.Types__c += ';Licence Contact';
                this.errormsg = false;
            }else if(this.addPaymentContactType && !this.orgRoleTypeList.includes('Licence Bill/Account Contact')){
                newContactObj.Types__c += ';Licence Bill/Account Contact';
                this.errormsg = false;
            }else if(this.orgRoleTypeList.includes('Licence Contact') && this.orgRoleTypeList.includes('Licence Bill/Account Contact')){
                this.errormsg = true;
                this.template.querySelector('[data-id="errorData"]').classList.add('error');
                this.updateContactValidation = "This contact has all available types added. No further contact types can be added at this time";
            }
            if(!this.errormsg){
                //updateContactButton.disabled = false;
                updateOrgRoleRecord({orgRoleRecord : JSON.stringify(newContactObj)})
                .then((result) =>{
                    this.isContactUpdated = result;
                    this.dispatchEvent(new CustomEvent("closemodalaction",{
                        detail:{isContactUpdated: this.isContactUpdated}
                    }));
                })
                .catch((error) =>{
                    window.location.href='/apex/licensingcomerror';
                });
                this.isshowmodal = false;
                this.showSpinner= true;
            }/*else{
                updateContactButton.disabled = true;
            } */   
        }catch(error){
            window.location.href='/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 05/01/2023
    * @description : W-002892 : Method called on change of checkbox.
    * @return      : None
    * @param       : event
    */
    handleCheckboxChange(event){
        var contactType = event.target.name;
        if(contactType.includes('Licence contact') && event.target.checked){
            this.addLicenceContactType = true;
            this.addPaymentContactType = false;
        }else if(contactType.includes('Payment contact') && event.target.checked){
            this.addPaymentContactType = true;
            this.addLicenceContactType = false;
        }else{
            this.addLicenceContactType = false;
            this.addPaymentContactType = false;
        }
    }
}