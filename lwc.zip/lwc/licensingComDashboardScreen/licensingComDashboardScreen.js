import { LightningElement, api } from 'lwc';
import getLicenceTypeList from '@salesforce/apex/LicensingComLicensingTabController.getLicenceTypeList';// Added for ADO-12636
import getLicenceTypeMap from '@salesforce/apex/Licensing_UtilityExtension.getLicenceTypeMap'; // ADO25357 change
import verifyMandatoryUserDetail from '@salesforce/apex/Licensing_Utility.verifyMandatoryUserDetail';// Added for ADO-12639
import getUserOrgRoleListForManage from '@salesforce/apex/Licensing_UtilityExtension.getUserOrgRoleListForManage'; // Added for ADO-13508/13504
// Start for ADO-12637
import aeronauticalFAQ from '@salesforce/label/c.LicensingComAeronauticalFAQURL';
import amateurFAQ from '@salesforce/label/c.LicensingComAmateurRadioFAQURL';
import businessFAQ from '@salesforce/label/c.LicensingComBusinessRadioFAQURL';
import maritimeFAQ from '@salesforce/label/c.LicensingComMaritimeRadioFAQURL';
import shipFAQ from '@salesforce/label/c.LicensingComShipRadioFAQURL';
import aeronauticalRadioLabel from '@salesforce/label/c.LicensingComLicenceProductAeronauticalRadio'; // ADO15255 change
// End for ADO-12637
export default class LicensingComDashboardScreen extends LightningElement {

    @api customerRefNo;
    // Start for ADO-12637
    aeronauticalFAQLink = aeronauticalFAQ;
    amateurFAQLink = amateurFAQ;
    businessFAQLink = businessFAQ;
    maritimeFAQLink = maritimeFAQ;
    shipFAQLink = shipFAQ;
    // End for ADO-12637
    openMandatoryDetailPopUpFlag=false; //ADO-12639 Boolean flag to open the mandatory details popup on click of aero apply button 
    //Start ADO-12636
    licTypeMap = new Map();/* ADO25357 changes*/
    jsonObj = [];
    licenceList;
    personAccountRecord; //ADO-12639 Variable to hold person account details 
    UserOrgRoleListForManage; //ADO-13508/13504 Variable to hold User Org role list for Manage journey 

    /*       
    * @author      : Coforge
    * @date        : 08/08/2023
    * @description : ADO-12636 :  To get the product types from apex
    */
    connectedCallback() {
        try {
            /* ADO25357 changes start */
            getLicenceTypeMap()
            .then((result) => {
                if(result != null && result != undefined && result != '') {
                    for(let key in result){
                        this.licTypeMap.set(key, result[key]);
                    }
                }
            })
            .catch((error) => { 
                window.location.href = '/apex/licensingcomerror';
            });
            /* ADO25357 changes end */

            getLicenceTypeList()
                .then((result) => {
                    let temporaryList = result;
                    temporaryList.forEach((items) => {
                        let productType = {};
                        productType["Name"] = items;
                        productType["flag"] = (items === "Aeronautical Radio") || (items === "Business Radio Light") || (items === "Shared Access") ||(items === "Spectrum Access");// ADO15255, ADO15256, ADO15231, ADO15236, ADO15240, ADO15241 changes
                        productType["isDisabled"] = this.licTypeMap.get(items); // ADO25357 change
                        this.jsonObj.push(productType);
                    });
                    this.licenceList = JSON.parse(JSON.stringify(this.jsonObj));
                    
                })
                .catch((error) => { 
                    console.log('Print Error' +JSON.stringify(error)); // Intentionally kept to display client side error on console and remove PMD issue
                    window.location.href = '/apex/licensingcomerror';
                });
                //Start ADO-12639 method called to check if account has mandatory details or not 
                verifyMandatoryUserDetail()
                .then((result) => {
                    this.personAccountRecord = result;
                    if (this.personAccountRecord != null) {
                        this.openMandatoryDetailPopUpFlag = true;
                    }
                    else{
                        this.openMandatoryDetailPopUpFlag = false;
                    }
                })
                .catch((error) => { 
                    console.log('Print Error' +error); // Intentionally kept to display client side error on console and remove PMD issue
                    window.location.href = '/apex/licensingcomerror';
                });
                //End ADO-12639
        }
        catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 08/08/2023
    * @description : ADO-12636 :  To redirect to light licences page
    */
    redirectToLightLicences(event) {
        window.location.href = '/apex/licensingcomapplyforlicence?licence=' + event.target.name;
    }

    /*       
    * @author      : Coforge
    * @date        : 08/08/2023
    * @description : ADO-12636 :  To redirect to Aeronautical licences page
    */
    redirectToAeroLicences(event) {
        //START ADO-12639 dispaytching the event to lightning out component 
        if(this.openMandatoryDetailPopUpFlag){
            this.dispatchEvent(new CustomEvent('openUpdateMandatoryDetailsPopup',{
                detail:{personaccountdata: this.personAccountRecord}
            }));
        }
        else{
            window.location.href = '/apex/licensingcomapplyforlicence?licence=' + aeronauticalRadioLabel; // ADO15255 change
        }
        //END ADO-12639
    }

    /*       
    * @author      : Coforge
    * @date        : 08/08/2023
    * @description : ADO-12636 :  To redirect to manage Light licences page
    */
    redirectToLightManage() {
        window.location.href = '/apex/licensingcomdashboard?isNewHomePage=false';
    }

    /*       
    * @author      : Coforge
    * @date        : 08/08/2023
    * @description : ADO-12636 :  To redirect to manage Aeronautical licences page
    */
    redirectToAeroManage(event) {
    //Start ADO-13508/13504
        try {   
                let eventName = event.target.name
                getUserOrgRoleListForManage()
                .then((result) => {
                    this.UserOrgRoleListForManage = result;
                    if (this.UserOrgRoleListForManage != null && this.UserOrgRoleListForManage.length==0) {
                        window.location.href =  '/apex/licensingcomdashboard?MANAGE_ERROR_STATUS=true';
                    }
                    else{
                        window.location.href = '/apex/licensingcomapplyforlicence?licence=' + aeronauticalRadioLabel + '&isAeroManage=true'; // ADO15256, ADO15236 changes start
                    }
                })
                .catch((error) => { 
                    window.location.href = '/apex/licensingcomerror';
                });
                //End ADO-12639
        }
        catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    //End ADO-13508/13504       
    }
    //End ADO-12636
    /*
    * @author      : Coforge
    * @date        : Dec 07, 2023
    * @description : ADO15259: Contact Information - Update Your Details Button
    */
    redirectToEditDetailsPage() {
        window.location.href = '/apex/LicensingComUserDetailsUpdate?isNewHomePage=false';
    }

    /*
    * @author      : Coforge
    * @date        : Dec 07, 2023
    * @description : ADO15260: Contact Information - Authorise User Button
    */
    redirectToAddAssignContactPage() {
        window.location.href = '/apex/LicensingAddAssignContact';
    } 
}