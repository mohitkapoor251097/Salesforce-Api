/*
* @description   Add and Remove contact from IRM Case
* @author        Coforge
* @date          11 September  2024
* @lastModified  11 September  2024
* @ChangeLog    : ADO-37140 New Data Field - Related IR Contact
*/

import { LightningElement, api, track } from 'lwc';
import addAndRemoveCaseContact from "@salesforce/apex/IRComCreatePortalUser.addAndRemoveCaseContact";
export default class IRComContactViewModal extends LightningElement {

    @api isshowmodal;
    @api title;
    @api buttonlabel;
    @api value;
    @api orgrolelist = [];
    finalOrgrolelist;
    // Track the list of selected records
    @track selectedRecords = [];
    showSpinner;
    paginationOrgrolelist = [];
    @track isPagination = false;
    orgrolecount;
    cancelpopup = false;
    @api currentloggedorgrole = [];
    errorMessage;
    @track ishaserror = false;
    @track isGirError = false;
    istablevisible;
    @track isselectall = false;

    /*       
    * @author      : Coforge
    * @date        : 11 September  2024
    * @param       : None
    * @description : ADO-37140 calling this method on page load
    */
    connectedCallback() {
        try {
         
            this.paginationOrgrolelist = this.orgrolelist.map(orgroleItem => {
                const ischecked = false;
                return {
                    ...orgroleItem,
                    ischecked
                };
            });
          
            this.istablevisible = true;
            this.isGirError = false;
            this.orgrolecount = this.paginationOrgrolelist.length;
            this.isPagination = true;
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 11 September  2024
    * @param       : None
    * @description : ADO-37140 With this method we are closing the popup
    */
    closeModalAction() {
        try {
            // Check if any of the selectedRecords matches an orgrole.Id in currentloggedorgrole
            const matchingRecord = this.selectedRecords.find(contact => contact.Id === this.currentloggedorgrole);
            if (matchingRecord && matchingRecord != undefined && matchingRecord != null && !this.cancelpopup && matchingRecord.OrgTypes === "General IR Contact") { // This criteria is executed from add/remove button
                this.addRemoveDetailScreen(false, true);
            } else { // This criteria is executed from cancel button
                this.addRemoveDetailScreen(false, false);
            }
            this.isshowmodal = false;
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 16 September  2024
    * @param       : None
    * @description : ADO-37140 Hide and show the IR request screen and Add/Remove popup
    */
    addRemoveDetailScreen(showaddremovecontactmodal, isVisibleIRRequestScreen) {
        // Fire the custom event if a matching record is found
        const updatedValues = {
            showaddremovecontactmodal: showaddremovecontactmodal, // This will close the Add/Remove modal if value is false
            isVisibleIRRequestScreen: isVisibleIRRequestScreen // This will open the IR Request screen  if value is true
        };
        this.dispatchEvent(new CustomEvent('closemodalaction', {
            detail: updatedValues
        }));
    }

    /*       
    * @author      : Coforge
    * @date        : 11 September  2024
    * @param       : None
    * @description : ADO-37140 With this method we are closing the popup
    */
    closeModalActionpopup() {
        try {
            this.cancelpopup = true;
            this.closeModalAction();
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 11 September  2024
    * @param       : None
    * @description : ADO-37140 This method handles checkbox changes for individual rows
    */
    handleCheckboxChange(event) {
        try {
            this.isIRErrorClassListRemoval();
            const recordId = event.target.dataset.id;
            const isChecked = event.target.checked;
            const record = this.paginationOrgrolelist.find(record => record.Id === recordId);
            if (isChecked) {
                record.ischecked = isChecked;
                // Add the record to selectedRecords  if not already there
                if (!this.selectedRecords.find(rec => rec.Id === recordId)) {
                    this.selectedRecords.push(record);
                }
            } else {
                // Remove the record from selectedRecords if unchecked
                record.ischecked = false;
                this.selectedRecords = this.selectedRecords.filter(rec => rec.Id !== recordId);
            }
            if (this.selectedRecords.length === this.paginationOrgrolelist.length) {
                this.isselectall = true;
            }
            else {
                this.isselectall = false;
            }

        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 11 September  2024
    * @param       : None
    * @description : ADO-37140 add and remove contact on selected records
    */
    addAndRemoveContact() {
        try {
            // Check if selectedRecords is empty and show error
            if (this.selectedRecords.length === 0) {
                this.errorMessage = 'Please select at least one record to proceed further';
                this.addIRErrorClassList();
                return;
            }
            this.showSpinner = true

            //call apex to update orgROle records
            addAndRemoveCaseContact({ action: this.buttonlabel, orgRoleList: this.selectedRecords, caseId: this.value.Id })
                .then((result) => {
                    this.closeModalAction();
                    this.showSpinner = false;
                })

        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 11 September  2024
    * @param       : None
    * @description : ADO-37140 This method return the current records list
    */
    currentPageOrgRoleList(event) {
        try {
            this.finalOrgrolelist = [...event.detail.records];  // Initialize list of org roles to display in the table.
            // Check if all records on the current page are selected
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }

    }

    /*       
    * @author      : Coforge
    * @date        : 11 September  2024
    * @param       : None
    * @description : ADO-37140 This method runs for select all functionality
    */
    handleSelectAllChange(event) {
        try {
            this.isselectall = true;
            this.isIRErrorClassListRemoval();
            const isChecked = event.target.checked;
            // Set all records in paginationOrgrolelist to checked/unchecked
            this.paginationOrgrolelist.forEach(record => {
                record.ischecked = isChecked;
                // Add or remove from selectedRecords based on isChecked
                if (isChecked) {
                    if (!this.selectedRecords.find(rec => rec.Id === record.Id)) {
                        this.selectedRecords.push(record);
                    }
                } else {
                    // Remove  the records from the selectedRecords if unchecking
                    this.selectedRecords = this.selectedRecords.filter(rec => !this.paginationOrgrolelist.some(pagRec => pagRec.Id === rec.Id));
                     this.isselectall = false;
                }
                return record;
            });

            // Re-render the updated list in the UI
            this.paginationOrgrolelist = [...this.paginationOrgrolelist];
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 11 September  2024
    * @param       : None
    * @description : ADO-37140 This method return the boolean value if record exist or not
    */
    get isDataEmpty() {
        try {
            return this.orgrolecount === 0;
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 11 September  2024
    * @param       : None
    * @description : ADO-37140 This method return the class list value
    */
    get geterrorclasslist() {
        try {
            return this.ishaserror ? 'slds-form-element__control slds-has-error' : 'slds-form-element__control';
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 11 September  2024
    * @param       : None
    * @description : ADO-37140 This method remove the classlist when record is selected on UI
    */
    isIRErrorClassListRemoval() {
        try {
            this.errorMessage = '';
            this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
            this.template.querySelector('[data-id="checkboxError"]').classList.remove('slds-has-error');
            this.ishaserror = false;
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 11 September  2024
    * @param       : None
    * @description : ADO-37140 This method add the classlist when no record is selected on UI
    */
    addIRErrorClassList() {
        try {
            this.ishaserror = true;
            this.template.querySelector('[data-id="errorMessage"]').classList.add('error');
            this.template.querySelector('[data-id="checkboxError"]').classList.add('slds-has-error');
            this.scrollToTop();
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }

    }

    /*       
   * @author      : Coforge
   * @date        : 17/09/2024
   * @description : ADO-37140: this function is add the error message when all record is selected and open a confirmation message when current logged in orgrole contact is selected.
   */
    validateContactsOnRemove() {
        try {
            if (this.selectedRecords.length === this.paginationOrgrolelist.length && this.buttonlabel === "Remove contact") { // If user select all records to remove, wlill display below warning message

                this.errorMessage = 'Warning: You must ensure that you have at least one contact held against an information request record. Please retain at least one existing contact, or add a new contact prior to making any contact removal changes';
                this.addIRErrorClassList();
                return;
            }

            const matchingRecord = this.selectedRecords.find(contact => contact.Id === this.currentloggedorgrole);

            if (matchingRecord && matchingRecord != undefined && matchingRecord != null && matchingRecord.OrgTypes === "General IR Contact") { // We are displaying an popup screen to take the confirmation from external users before removing contact that is currently linked with the current logged in user
                this.istablevisible = false;
                this.isGirError = true;
            } else {
                this.addAndRemoveContact();
            }
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 17/09/2024
    * @description : ADO-37140: this function is used to open the table section
    */
    backtotable() {
        try {
            this.istablevisible = true;
            this.isGirError = false;
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
    
    /*       
     * @author      : Coforge
     * @date        : 17/09/2024
     * @description : ADO-37140: scroll up on error message
     */
    scrollToTop() {
        try {
            this.template.querySelector('.scrolltotoppage').scrollTop = 0;
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
}