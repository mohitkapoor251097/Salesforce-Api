import { LightningElement , wire} from 'lwc';
import getFieldsFromMetadata from '@salesforce/apex/OSViewHighlyRestrictedMeetingController.getFieldsFromMetadata';
import getMeetingData from '@salesforce/apex/OSViewHighlyRestrictedMeetingController.getMeetingData';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import { NavigationMixin } from 'lightning/navigation';

const View_Column = {
    label: 'View',
    type: 'button-icon',
    initialWidth: 50,
    typeAttributes:
    {   
        iconName: 'action:preview',
        title: 'Open in New Tab',
        name: 'View',
        alternativeText: 'View'
    }
};

export default class OSHighlyRestrictedMeetingList extends NavigationMixin( LightningElement ) {
    
    metadataRecordApiName = 'HighlyRestrictedMeetings';
    noRecordsPlaceHolder = 'No records to display';
    fieldMappingMap = new Map();
    fieldDataTypeMappingMap = new Map();
    modalFieldMapping = [];
    modalContainer = false;
    meetingRow=[];
    columns = [];
    searchData;
    shLeadCriteria = '';

    shOrganizationCriteria = '';

    meetingName = '';
    dateOfMeeting;
    ofcomLeadName='';
    hideVar = true;
    stakeHolders;
    recordId = '';
    errorMsg = '';


    //Pagination 
    pageSizeOptions = [50,100,200,500]; //Page size options
    totalRecords = 0; //Total no.of records
    pageSize; //No.of records to be displayed per page
    totalPages; //Total no.of pages
    pageNumber = 1; //Page number    
    recordsToDisplay = []; //Records to be displayed on the page
    
    get bDisableFirst() {
        return this.pageNumber == 1;
    }
    get bDisableLast() {
        return this.pageNumber == this.totalPages;
    }

    //Field Datatype Mapping
    dataTypeMapping = {
        String: 'text',
        Currency: 'number',
        Double: 'number',
        DateTime: 'datetime',
        Phone: 'phone',
        Boolean: 'checkbox',
        Url: 'url',
        Date: 'date',
        Int: 'number'
    }

    //constructor is used to call setupColumn method onload  
    constructor() {
        super();
        this.setupColumns();
        
    }

    get showRecords() {
        return this.recordsToDisplay.length > 0;
    }
    
    //Method is used to get the meeting field datatype
    @wire(getObjectInfo, { objectApiName: 'Meeting__c' })
    objectInfo;

    
    setupFieldsDataType(fieldApiName){
        if (this.objectInfo && this.objectInfo.data && this.objectInfo.data.fields) {
            let field = this.objectInfo.data.fields[fieldApiName];
            if(field){
                field = JSON.parse(JSON.stringify(field));
                field.dataType = this.dataTypeMapping[field.dataType];
                this.fieldDataTypeMappingMap.set(fieldApiName,field.dataType);
            }
        }
    }
    
    /*
     * @author      : Coforge
     * @description : fetch the record from the custom metadata type after 
     * that doing the soql for the particular object and bind the data with the datatable.
     * @params      : event
     * @return      : NA
     */
    setupColumns() {
      
        getFieldsFromMetadata({

            metadataRecordName: this.metadataRecordApiName

        }).then((result) => {
            try {
                if(result) {
                    this.columns = this.sanitizeMetadata(result);
                    
                    //Perform search on onload
                    if(this.columns){
                        this.handleSearch();
                    }    
                }
            } catch(e){
                console.log(JSON.stringify(e));
            }

        })
        .catch((error) => {
            console.log(error);
        });
    }

    /*
     * @author      : Coforge
     * @description : split the custom metadata records fields vlaues 
     * and create the columns to be bind with the datatable. 
     * @params      : event
     * @return      : NA
     */
    sanitizeMetadata(result) {
        
        const temp = [];
        //Adding the preview button icon
        temp.push(View_Column);

        //Metadata fieldmapping
        const fieldsMapping = result.FieldsMapping__c.split(",");
        
        for(const obj of fieldsMapping) {

            //Split the fieldmapping in Api Name and Label
            const val = obj.split("=");

            //Map is used to store the field mapping
            this.fieldMappingMap.set(val[0].trim(),val[1].trim());

            //Map is used to store the field and their data type
            this.setupFieldsDataType(val[0].trim());
            
            if(this.fieldDataTypeMappingMap && this.fieldDataTypeMappingMap.has(val[0].trim()) && this.fieldDataTypeMappingMap.get(val[0].trim())){
                
                temp.push({fieldName: val[0].trim(), label: val[1].trim(), type: this.fieldDataTypeMappingMap.get(val[0].trim())});

            }else{
                temp.push({fieldName: val[0].trim(), label: val[1].trim(), type: 'text'});
            }
        }
        return temp;
    }

    
    //OnChange Name  function
    onChangeName(event) {
        this.meetingName = event.detail.value;
        this.handleSearch();   
    }

    //OnChange Name  function
    onChangeDateOfMeeting(event) {
        this.dateOfMeeting = event.detail.value;
        this.handleSearch();   
    }

    //OnChange Name  function
    onChangeOfcomLead(event) {
        this.ofcomLeadName = event.detail.value;
        this.handleSearch();   
    }

    //Function is used to search the records from apex
    handleSearch() {

        this.searchData = [];
        
        getMeetingData({
            meetingName : this.meetingName,
            dateOfMeeting : this.dateOfMeeting,
            ofcomLeadName : this.ofcomLeadName
            })
        .then(result => {
            if(result){
                
                this.searchData = this.sanitizeRecords(result);
                //Checking the search result
                if(this.searchData){
                    this.totalRecords = this.searchData.length;// update total records count 
                    this.pageSize = this.pageSizeOptions[0]; //set pageSize with default value as first option
                    this.paginationHelper(); // call helper menthod to update pagination logic 
                }
            }
            this.errorMsg = undefined;
        })
        .catch(error => {
            this.searchData = undefined;
            window.console.log('error =====> '+JSON.stringify(error));
            if(error && error.body && error.body.message) {
                this.errorMsg = error.body.message;
            }
        }) 
    }

    //Method is used to senitize the search results
    sanitizeRecords(result) {
        const data = [];
        for(let row of result) {
            const finalRow = {}
            let rowIndexes = Object.keys(row); 
            rowIndexes.forEach((rowIndex) => 
            {   
                let relatedFieldValue
                relatedFieldValue = row[rowIndex];

                if(relatedFieldValue.constructor === Object) {
                    this.transformObjectToRow(relatedFieldValue, finalRow, rowIndex)        
                }
                else {
                    finalRow[rowIndex] = relatedFieldValue;
                }

            });
            data.push(finalRow);
        }
        return data;
    }

    //Function is used to transform relation field in same object
    transformObjectToRow = (fieldValue, finalRow, fieldName) => 
    {        
        let rowIndexes = Object.keys(fieldValue);
        rowIndexes.forEach((key) => 
        {
            let finalKey = fieldName + '.'+ key;
            finalRow[finalKey] = fieldValue[key];
        })
    }

    //Manage records per page Function
    handleRecordsPerPage(event) {
        this.pageSize = event.target.value;
        this.paginationHelper();
    }

    //Previous Page Function
    previousPage() {
        this.pageNumber = this.pageNumber - 1;
        this.paginationHelper();
    }

    //Next Page Function
    nextPage() {
        this.pageNumber = this.pageNumber + 1;
        this.paginationHelper();
    }

    //First Page Function
    firstPage() {
        this.pageNumber = 1;
        this.paginationHelper();
    }

    //Last Page Function
    lastPage() {
        this.pageNumber = this.totalPages;
        this.paginationHelper();
    }

    // JS function to handel pagination logic 
    paginationHelper() {
        this.recordsToDisplay = [];
        
        // calculate total pages
        this.totalPages = Math.ceil(this.totalRecords / this.pageSize);
        
        // set page number 
        if (this.pageNumber <= 1) {
            this.pageNumber = 1;
        } else if (this.pageNumber >= this.totalPages) {
            this.pageNumber = this.totalPages;
        }

        // set records to display on current page
        if(this.searchData.length > 0){ 
            for (let i = (this.pageNumber - 1) * this.pageSize; i < this.pageNumber * this.pageSize; i++) {
                if (i === this.totalRecords) {
                    break;
                }
                this.recordsToDisplay.push(this.searchData[i]);
            }
        }
    }

    //Handle Row Action and open modal
    handleRowAction( event ) {
        let tempArray = [];
        this.modalContainer=true;
        const actionName = 'view';
        const row = event.detail.row;
        //Set and pass recordId for Stakeholder Lead related list component
        this.recordId = row.Id;
        if(row){
            for (let [key, value] of this.fieldMappingMap) {

                if(this.fieldDataTypeMappingMap && this.fieldDataTypeMappingMap.has(key) && this.fieldDataTypeMappingMap.get(key)){
                    
                    tempArray.push({'key':value,'value':row[key],'type':this.fieldDataTypeMappingMap.get(key)});
                }else{
                      tempArray.push({'key':value,'value':row[key],'type':'text'});
                  }
            }
        }
        
        this.meetingRow = tempArray;
        
        //Pass the value on the basis of action
        switch ( actionName ) {
            case 'view':
                this.modalContainer=true;
                this.shLeadCriteria = 'Meeting__c = \''+this.recordId+'\' AND StakeholderType__c = \'Stakeholder Lead\'';
                this.shOrganizationCriteria = 'Meeting__c = \''+this.recordId+'\' AND StakeholderType__c = \'Stakeholder Organization\'';
                
                break;
        }
    }
    
   //Close Modal
   closeModalAction(){
    this.modalContainer=false;
   }
}