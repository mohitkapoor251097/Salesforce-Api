/*       
* @author      : Coforge
* @date        : 23/04/2024
* @description : ADO-26354 Adding Contacts to the IRMS Case
               : ADO-31497 : Organisational Role Relationship to Case Records
*/
import { LightningElement, api, wire, track } from 'lwc';
import getCasesOrgRole from "@salesforce/apex/IRComCreatePortalUser.getCasesOrgRole"; // ADO-31497
import addAndRemoveCaseContact from "@salesforce/apex/IRComCreatePortalUser.addAndRemoveCaseContact"; // ADO-31497
import { subscribe } from 'lightning/empApi';       //ADO 31497: BUG 32807 Fix

export default class IRComAddContactToCase extends LightningElement {
    @api recordId;
    @track currentRecordid
    showAddContactModal = false;
    showRemoveContactModal = false;
    @track caseorgroles = [];
    targetaccountorgroles = [];
    @track showCaseProject = false;
    orgRoleTitle = '';
    @track caseOrgRoleNoDataPreView = false;
    spinnerFlag = false;
    subscription = null;
    @track isCaseUpdated = false;

    /*       
    * @author      : Coforge
    * @date        : 23/04/2024
    * @description : org role data table coloumns
    */
    orgRoleColumns = [
        {
            label: 'Organisational Roles',
            fieldName: 'NameUrl',
            type: 'url',
            initialWidth: 200,
            typeAttributes: {
                label: { fieldName: 'Name' }, tooltip: { fieldName: 'Name' },
                target: '_blank'
            },
            sortable: true
        },
        { label: 'Types', fieldName: 'OrgTypes', initialWidth: 180, sortable: true },
        { label: 'First Name', fieldName: 'FirstName', initialWidth: 130, sortable: true },
        { label: 'Last Name', fieldName: 'LastName', initialWidth: 130, sortable: true },
        { label: 'Email Address', fieldName: 'Email', initialWidth: 140, sortable: true },
        { label: 'Associated Account', fieldName: 'TargetAccountName', initialWidth: 180, sortable: true }
                    //Show & Tell Feedback ADO 33991
    ];

    /*       
    * @author      : Coforge
    * @date        : 23/05/2024
    * @description : ADO 31497: BUG 32807 Fix | This method will call on page load
    */
    connectedCallback() {
        this.isCaseUpdated = false;
        this.populateCasesOrgRole(); // This method will populate eligible org role records linked with the current IRMS case record
        this.subscribeToEvent(); // This method is called to listen the platform event to refresh the lightning data when target account has been changed from case record.
    }

    /*       
    * @author      : Coforge
    * @date        : 23/05/2024
    * @description : ADO 31497: BUG 32807 Fix | This method will call from connectedCallback and fetch org role from apex
    */
    populateCasesOrgRole() {
        getCasesOrgRole({ caseRecId: this.recordId })
            .then((result) => {
                if (result) {
                    for (var key in result) {
                        if (key == 'LinkedOrgRoles' && result[key] != null && result[key][0] != null) {
                            result[key].forEach(orgRole => {
                                //craete object and add all fields which are using in datatable
                                let orgRoleRec = {};
                                orgRoleRec["Name"] = orgRole.Name;
                                orgRoleRec["NameUrl"] = '/' + orgRole.Id; // create org role record url
                                orgRoleRec["Id"] = orgRole.Id;
                                orgRoleRec["FirstName"] = orgRole.Contact__r.FirstName;
                                orgRoleRec["LastName"] = orgRole.Contact__r.LastName;
                                orgRoleRec["Email"] = orgRole.Email__c;
                                orgRoleRec["TargetAccountName"] = orgRole.Licensee_or_Organisation__r.Name;
                                orgRoleRec["OrgTypes"] = orgRole.Types__c;          //Show & Tell Feedback ADO 33991
                                this.caseorgroles.push(orgRoleRec);
                                //flag to display orgRole data table
                                if (this.caseorgroles.length > 0) {
                                    this.caseOrgRoleNoDataPreView = true;
                                }
                            });
                        }
                        if (key == 'UnlinkedOrgRoles' && result[key] != null && result[key][0] != null) {
                            result[key].forEach(orgRole => {
                                //craete object and add all fields which are using in datatable
                                let orgRoleRec = {};
                                orgRoleRec["Name"] = orgRole.Name;
                                orgRoleRec["NameUrl"] = '/' + orgRole.Id; // create org role record url
                                orgRoleRec["Id"] = orgRole.Id;
                                orgRoleRec["FirstName"] = orgRole.Contact__r.FirstName;
                                orgRoleRec["LastName"] = orgRole.Contact__r.LastName;
                                orgRoleRec["Email"] = orgRole.Email__c;
                                orgRoleRec["TargetAccountName"] = orgRole.Licensee_or_Organisation__r.Name;
                                orgRoleRec["OrgTypes"] = orgRole.Types__c;          //Show & Tell Feedback ADO 33991 
                                this.targetaccountorgroles.push(orgRoleRec);
                            });
                        }
                    }
                    // org role title with number of orgroles
                    this.orgRoleTitle = 'Organisational Roles (' + this.caseorgroles.length + ')';
                    // flag to display datatable after record load
                    this.showCaseProject = true;
                    //stop spinner flag 
                    this.spinnerFlag = false;
                } else {
                    this.spinnerFlag = false;
                }
            })
            .catch((error) => {
                this.spinnerFlag = false;
                //Let's send the user a toast with our custom error message
                this.showNotification('Error Messgage', error, 'error');
            });
    }

    /*       
    * @author      : Coforge
    * @date        : 23/04/2024
    * @description : Display toast message
    */
    showNotification(title, message, variant) {
        try {
            const evt = new ShowToastEvent({
                title: title,
                message: message,
                variant: variant,
                mode: 'dismissable'
            });
            this.dispatchEvent(evt);
        } catch (error) {
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 23/04/2024
    * @description : ADO-26354 display modal component on click add contact button
    */
    openAddContactModal() {
        this.showAddContactModal = true;
    }

    /*       
    * @author      : Coforge
    * @date        : 23/04/2024
    * @description : ADO-26354 display modal component on click remove contact button
    */
    openRemoveContactModal() {
        this.showRemoveContactModal = true;
    }

    /*       
    * @author      : Coforge
    * @date        : 23/04/2024
    * @description : ADO-26354 get dispatched event from child component and close modal
    */
    closeModal(event) {
        this.showAddContactModal = event.detail.closemodal;
        this.showRemoveContactModal = event.detail.closemodal;
    }

    /*       
    * @author      : Coforge
    * @date        : 23/04/2024
    * @description : ADO-26354 after update record fetch the updated records
    */
    refershData(event) {
        this.refreshLightningDataTable();  //ADO 31497: BUG 32807 Fix
    }

    /*       
    * @author      : Coforge
    * @date        : 23/04/2024
    * @description : ADO-26354 sort datatable records
    */
    doSorting(event) {
        this.sortBy = event.detail.fieldName;
        this.sortDirection = event.detail.sortDirection;
        this.sortData(this.sortBy, this.sortDirection);
    }

    /*       
    * @author      : Coforge
    * @date        : 23/04/2024
    * @description : ADO-26354 sort datatable records
    */
    sortData(fieldname, direction) {
        let parseData = JSON.parse(JSON.stringify(this.caseorgroles));
        // Return the value stored in the field
        let keyValue = (a) => {
            return a[fieldname];
        };
        // cheking reverse direction
        let isReverse = direction === 'asc' ? 1 : -1;
        // sorting data
        parseData.sort((x, y) => {
            x = keyValue(x) ? keyValue(x) : '';
            y = keyValue(y) ? keyValue(y) : '';
            return isReverse * ((x > y) - (y > x));
        });
        this.caseorgroles = parseData;
    }

    /*
    * @author      : Coforge
    * @date        : 23/05/2024
    * @description : ADO 31497: BUG 32807 Fix | This method is used to subscribe the platform event
    * @params      : none
    * @return      : none
    */
    subscribeToEvent() {
        const channel = '/event/FieldChangeEvent__e';
        const messageCallback = (response) => {

            // Handle event
            if (response.data.payload.RecordId__c) {
                this.handleEvent(response);
            }
        };

        subscribe(channel, -1, messageCallback).then(response => {
            this.subscription = response;
        }).catch(error => {
            console.error('Error subscribing to channel:', JSON.stringify(error));
        });
    }

    /*
    * @author      : Coforge
    * @date        : 23/05/2024
    * @description : ADO 31497: BUG 32807 Fix | This method is used to handle the response of the platform event
    * @params      : response
    * @return      : none
    */
    handleEvent(response) {
        if (response.data.payload.RecordId__c == this.recordId) {
            this.isCaseUpdated = true;
            this.removeExistingOrgRoleContact();
            this.refreshLightningDataTable();
        }
    }

    /*
    * @author      : Coforge
    * @date        : 23/05/2024
    * @description : ADO 31497: BUG 32807 Fix | This method is used to refresh the lightning data table 
    * @params      : response
    * @return      : none
    */
    refreshLightningDataTable() {
        this.caseorgroles = [];
        this.targetaccountorgroles = [];
        this.showCaseProject = false;
        this.populateCasesOrgRole();
    }

    /*
    * @author      : Coforge
    * @date        : 23/05/2024
    * @description : ADO 31497: Inactive org role (contact) in case of target account changed 
    * @params      : response
    * @return      : none
    */
    removeExistingOrgRoleContact(){
         if(this.isCaseUpdated){
            addAndRemoveCaseContact({ action: 'Remove contact', orgRoleList: this.caseorgroles, caseId: this.recordId })
            .then((result) => {
            })
            .catch((error) => {
                console.error('Error while removing contact on target account changed', JSON.stringify(error));
            });
        }
    }
}