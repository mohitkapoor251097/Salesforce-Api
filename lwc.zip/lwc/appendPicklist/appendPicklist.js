/**
* @description   Displays CSLE report picklist options.
* @author        Coforge
* @date          19 Feb  2025
* @lastModified  03 April  2025
* @ChangeLog     Intitial Version 1.0 
*/
import LightningDatatable from 'lightning/datatable';
import appendPicklistEdit from './appendPicklistEdit.html';
import appendPicklistStatic from './appendPicklistStatic.html'
import appendTextAreaEdit from './appendTextAreaEdit.html'
import appendTextAreaStatic from './appendTextAreaStatic.html'

export default class appendPicklist extends LightningDatatable {

    static customTypes = {
        picklistColumn: {
            template: appendPicklistStatic,
            editTemplate: appendPicklistEdit,
            standardCellLayout: true,
            typeAttributes: ['label', 'placeholder', 'options', 'value', 'context', 'variant', 'name']
        },
        textAreaColumn: {   // ADO - 54864 Showing for Text Area field for view and edit
            template: appendTextAreaStatic,
            editTemplate: appendTextAreaEdit,
            standardCellLayout: true,
            typeAttributes: ['label', 'placeholder', 'value', 'context', 'variant', 'name']
        }
    };
}