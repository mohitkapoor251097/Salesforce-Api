/*********************************************************************
# File....................: osRestrictedGscList
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............: 02/03/2025
# Last Modified by........: Coforge
# Last Modified Date......: 
# Description.............: Component is used to show reports of Restricted GSC for Case, Meeting, Interaction
# VF Page.................: NA
# VF Component............: NA
# L Comp..................: NA
# Handler Class...........: NA
# Test Class..............: NA
# Change Log..............: NA
#Trigger Name ............: Case

**********************************************************************/
import { LightningElement, api, wire } from 'lwc';
import getRestrictedGscRecords from '@salesforce/apex/OSRestrictedGscListController.getSobjectRecords';
import getSearchData from '@salesforce/apex/OSRestrictedGscListController.getSearchData';
import generateSearchData from './generateSearchData';
import {GSC_CONSTANTS} from './osRestrictedGscListConstants';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';

// case columns to be displayed
const caseColumns = [
    { label: 'View', type: 'button-icon', initialWidth: 50, typeAttributes: { iconName: 'action:preview', title: 'Open in New Tab', name: 'View', alternativeText: 'View' } } ,
    { label: 'GSC Classification', fieldName: 'Government_Security_Classification__c', type: 'text' },
    { label: 'Service Name', fieldName: 'Service_Name__r.Name', type: 'text' },
    { label: 'Date/Time', fieldName: 'CreatedDate', type: 'date' ,typeAttributes:{
        year: "numeric",
        month: "long",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit"
    }},
    { label: 'Case Owner', fieldName:  'Owner.Name', type: 'text' },
    { label: 'Case Status', fieldName: 'Status', type: 'text' },
];

// meeting columns to be displayed
const meetingColumns = [
    { label: 'View', type: 'button-icon', initialWidth: 50, typeAttributes: { iconName: 'action:preview', title: 'Open in New Tab', name: 'View', alternativeText: 'View' } } ,
    { label: 'GSC Classification', fieldName: 'Government_Security_Classification__c', type: 'text' },
    { label: 'Date Of Meeting', fieldName: 'DateofMeeting__c', type: 'date' ,typeAttributes:{
        year: "numeric",
        month: "long",
        day: "2-digit",
    }},
    { label: 'Meeting Title', fieldName: 'Name', type: 'text' },
];

// interaction columns to be displayed
const interactionColumns = [
    { label: 'View', type: 'button-icon', initialWidth: 50, typeAttributes: { iconName: 'action:preview', title: 'Open in New Tab', name: 'View', alternativeText: 'View' } } ,
    { label: 'GSC Classification', fieldName: 'Government_Security_Classification__c', type: 'text' },
    { label: 'Interaction Date', fieldName: 'Interaction_Date__c', type: 'date' ,typeAttributes:{
        year: "numeric",
        month: "long",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit"
    }},
    { label: 'Interaction Title', fieldName: 'Name', type: 'text' },
];

// Master Repository columns to be displayed
const masterRepositoryColumns = [
    { label: 'View', type: 'button-icon', initialWidth: 50, typeAttributes: { iconName: 'action:preview', title: 'Open in New Tab', name: 'View', alternativeText: 'View' } } ,
    { label: 'GSC Classification', fieldName: 'Government_Security_Classification__c', type: 'text' },
    { label: 'Date / Time of Master Repository', fieldName: 'CreatedDate', type: 'date' ,typeAttributes:{
        year: "numeric",
        month: "long",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit"
    }},
    { label: 'Master Repository Name', fieldName: 'Name', type: 'text' },
];

export default class OsRestrictedGscList extends LightningElement {

    @api objectName ;
    objectLabel;
    @api title;
    @api fields;
    @api whereClause;
    accountSearch = false;
    meetingOwnerSearch = false;
    interactionOwnerSearch = false;
    masterRepositoryOwnerSearch = false;
    recordId;
    dataRecord = [];
    staticDataRecord = [];
    modalContainer = false;
    selectedRecord;
    page = 1;
    pageSize = 10; // Number of records per page
    totalRecords = 0;
    totalPages = 0;
    currentPageData = [];
    gscClassificationName = '';
    accountName = '';
    recordOwner = '';
    datetime = '';
    pageSizeOptions = [50,100,200,500];
    recordIds;
    showMeetingData = false;
    showInteractionData = false; 

    shOrganizationCriteria = '';
    ofcomParticipantCriteria ='';
   
    // case fields to be shown in popup
    caseFieldsWithLabel =[{ label : 'Government Security Classification', fieldName : 'Government_Security_Classification__c',type:'text'},
        { label : 'Service Name', fieldName : 'Service_Name__r.Name',type:'text'},
        { label : 'Case Owner', fieldName : 'Owner.Name',type:'text'},
        { label : 'Case Status', fieldName : 'Status',type:'text'},
        { label : 'CreatedDate', fieldName : 'CreatedDate',type:'datetime'}
    ];
    // meeting fields to be shown in popup
    meetingFieldsWithLabel =[{ label : 'Government Security Classification', fieldName : 'Government_Security_Classification__c',type:'text'},
        { label : 'Meeting Owner', fieldName : 'Owner.Name',type:'text'},
        { label: 'Meeting Title', fieldName: 'Name', type: 'text' },
        { label : 'Date Of Meeting', fieldName : 'DateofMeeting__c',type:'date'}
    ];
    // interaction fields to be shown in popup
    interactionFieldsWithLabel =[{ label : 'Government Security Classification', fieldName : 'Government_Security_Classification__c',type:'text'},
        { label : 'Interaction Owner', fieldName : 'Owner.Name',type:'text'},
        { label: 'Interaction Title', fieldName: 'Name', type: 'text' },
        { label : 'Interaction Date', fieldName : 'Interaction_Date__c',type:'datetime'}
    ];
    // Master Repository fields to be shown in popup
    masterRepositoryFieldsWithLabel =[{ label : 'Government Security Classification', fieldName : 'Government_Security_Classification__c',type:'text'},
        { label : 'Master Repository Owner', fieldName : 'Owner.Name',type:'text'},
        { label: 'Master Repository Title', fieldName: 'Name', type: 'text' },
        { label : 'Date/Time of Master Repository creation', fieldName : 'CreatedDate',type:'datetime'}
    ];
    // get Object Label from API Name
    @wire(getObjectInfo, { objectApiName: '$objectName' })
    wiredObjectInfo({ error, data }) {
        if (data) {
            this.objectLabel = data.label; // Fetch Object Label
        } else if (error) {
            console.error('Error fetching object info:', error);
        }
    }

    // get data column for data table
    get dataColumn(){
        if(this.objectName === GSC_CONSTANTS.CASE_OBJECT_API_NAME){
            this.accountSearch = true;
            return caseColumns;
        }else if(this.objectName === GSC_CONSTANTS.MEETING_OBJECT_API_NAME){
            this.meetingOwnerSearch = true;
            this.showMeetingData = true;
            return meetingColumns;
        }else if(this.objectName === GSC_CONSTANTS.INTERACTION_OBJECT_API_NAME){
            this.interactionOwnerSearch = true;
            this.showInteractionData = true;
            return interactionColumns;
        }else if(this.objectName === GSC_CONSTANTS.MASTER_REPOSITORY_OBJECT_API_NAME){
            this.masterRepositoryOwnerSearch = true;
            return masterRepositoryColumns;
        }else{

        }
    }


    // disbaled previous page 
    get previousDisabled() {
        return this.page <= 1;
    }

    // disbaled next page
    get nextDisabled() {
        return this.page >= this.totalPages;
    }

    connectedCallback(){
        this.getData(this.whereClause);
    }

    // get data for current page only
    updateCurrentPageData() {
        const start = (this.page - 1) * this.pageSize;
        const end = this.page * this.pageSize;
        this.currentPageData = Object.values(this.dataRecord).slice(start, end);
    }

    // disable first button
    get bDisableFirst() {
        return this.page === 1;
    }

    // disabled last button
    get bDisableLast() {
        return this.page === this.totalPages;
    }

    // First page button
    firstPage() {
        this.page = 1;
        this.updateCurrentPageData();
    }

    // Last page  button
    lastPage() {
        this.page = this.totalPages;
        this.updateCurrentPageData();
    }

    // next button
    handleNext() {
        if (this.page < this.totalPages) {
            this.page++;
            this.updateCurrentPageData();
        }
    }

    // previous button
    handlePrevious() {
        if (this.page > 1) {
            this.page--;
            this.updateCurrentPageData();
        }
    }

    // on slection of page size number of records will be visible in the page
    handlePageSize(event){
        this.pageSize = event.target.value;
        this.updateCurrentPageData();
    }
    
    // on click of  eye icon the row acction will call and will show modal with more fields 
    handleRowAction(event) {
        const action = event.detail.action;
        const row = event.detail.row;
        
        switch (action.name) {
            case 'View':
            this.modalContainer = true;
            this.recordId = row.Id;
            this.selectedRecord = [];

            if(this.objectName === GSC_CONSTANTS.CASE_OBJECT_API_NAME){
                this.caseFieldsWithLabel.forEach( fieldData => {
                    this.selectedRecord.push({ 'label' : fieldData.label, 'type' : fieldData.type, 'value' : this.dataRecord[row.Id][fieldData.fieldName]});
                })
            }else if(this.objectName === GSC_CONSTANTS.MEETING_OBJECT_API_NAME){
                this.shOrganizationCriteria = 'Meeting__c = \''+this.recordId+'\' AND StakeholderType__c = \'Stakeholder Organization\'';
                this.ofcomParticipantCriteria = 'Meeting__c = \''+this.recordId+'\' AND StakeholderType__c = \'Ofcom Participant\'';
                this.meetingFieldsWithLabel.forEach( fieldData => {
                    this.selectedRecord.push({ 'label' : fieldData.label, 'type' : fieldData.type, 'value' : this.dataRecord[row.Id][fieldData.fieldName]});
                })
            }else if(this.objectName === GSC_CONSTANTS.INTERACTION_OBJECT_API_NAME){
                this.shOrganizationCriteria = 'Interaction__c = \''+this.recordId+'\' AND StakeholderType__c = \'Stakeholder Organization\'';
                this.ofcomParticipantCriteria = 'Interaction__c = \''+this.recordId+'\' AND StakeholderType__c = \'Ofcom Participant\'';
                this.interactionFieldsWithLabel.forEach( fieldData => {
                    this.selectedRecord.push({ 'label' : fieldData.label, 'type' : fieldData.type, 'value' : this.dataRecord[row.Id][fieldData.fieldName]});
                })
            }else if(this.objectName === GSC_CONSTANTS.MASTER_REPOSITORY_OBJECT_API_NAME){
                this.masterRepositoryFieldsWithLabel.forEach( fieldData => {
                    this.selectedRecord.push({ 'label' : fieldData.label, 'type' : fieldData.type, 'value' : this.dataRecord[row.Id][fieldData.fieldName]});
                })
            }else{

            }
            
            
           
            break;
        }
    }

    // close modal
    closeModalAction(){

        this.modalContainer = false;
    }

    // search data with GSC name 
    onChangeGSCClassification(event){
         
        this.gscClassificationName = event.detail.value;
        this.filterSearchData();
    }

    // search data with account name
    onChangeOfAccountName(event){
        
        this.accountName = event.detail.value;
        this.filterSearchData();
    }

    // search data with owner
    onChangeOfMeetingOwner(event){
        
        this.recordOwner = event.detail.value;
        this.filterSearchData();
    }
    // search data with owner
    onChangeOfInteractionOwner(event){
        
        this.recordOwner = event.detail.value;
        this.filterSearchData();
    }
    // search data with owner
    onChangeOfMasterRepositoryOwner(event){
        
        this.recordOwner = event.detail.value;
        this.filterSearchData();
    }
    // search data with created date
    onChangeDateTime(event){
       
        this.datetime = event.detail.value;
        this.filterSearchData();
           
    }

    // Get data to add in data table
    getData(filter){
        
        getRestrictedGscRecords({objectName: 
            this.objectName, 
            whereClause : filter, fields: this.fields })
        .then(allRecords => {
            const filteredData = generateSearchData({'allRecords' : allRecords, 'fields' : this.fields });
            this.dataRecord = filteredData;
            this.staticDataRecord = filteredData;
            this.recordIds = Object.keys(this.staticDataRecord);
            this.totalRecords = Object.values(this.dataRecord).length;
            this.totalPages = Math.ceil(this.totalRecords / this.pageSize);
            this.updateCurrentPageData();
        
        })
    }


    // get filter data 
    filterSearchData(){
        // search parms
        const searchParams = JSON.stringify({
            objectName: this.objectName || null,
            recordIds: this.recordIds || [],
            accountName: this.accountName || null,
            recordOwner: this.recordOwner || null,
            caseCreationDate: this.datetime || null,
            gscClassificationName: this.gscClassificationName || null,
            fields: this.fields || null
        });
        
        getSearchData({
            jsonParams: searchParams
        }).then( allRecords => {
            const filteredData = generateSearchData({'allRecords' : allRecords, 'fields' : this.fields });
            this.dataRecord = filteredData;
            this.totalRecords = Object.values(this.dataRecord).length;
            this.totalPages = Math.ceil(this.totalRecords / this.pageSize);
            this.updateCurrentPageData();
        });
    }
}