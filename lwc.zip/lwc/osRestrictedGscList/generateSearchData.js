export default function generateData({ allRecords, fields }) {

    return Object.keys(allRecords)
    .reduce((obj, key) => {

        let recordsWithApiName = {}; 

        fields.split(',').forEach(field => {
            if (field.includes(".")) {
                const [firstPart, secondPart] = field.split(".", 2);

                recordsWithApiName[field] = allRecords[key][firstPart]?allRecords[key][firstPart][secondPart]:'';
            }else{
                recordsWithApiName[field] = allRecords[key][field]; 

            }
        });

        obj[key] = recordsWithApiName;
    return obj;
    }, {});
}