// constants file call in main js file.
export const GSC_CONSTANTS = {
    MEETING_OBJECT_API_NAME: 'Meeting__c',
    INTERACTION_OBJECT_API_NAME : 'Interaction__c',
    CASE_OBJECT_API_NAME: 'Case',
    MASTER_REPOSITORY_OBJECT_API_NAME: 'Master_Repository__c',
    NO_GSC_VALUE: 'No GSC marking',
    AGGREGATE_YES: 'Yes',
    AGGREGATE_NO: 'No',
    GSC_FIELD_API_NAME: 'Government_Security_Classification__c',
    AGGRETAGED_FIELD_API_NAME: 'Aggregated_Sensitive_Material__c',
    GSC_SHOW_POPUP_FIELD_API_NAME:'GSC_show_popup__c',
    ID_FIELD_API_NAME: 'Id',
    OWNERID_FIELD_API_NAME: 'OwnerId',
    GSC_OFFICIAL_SENSITIVE: 'Official Sensitive',
    GSC_HOLDING_O: 'Holding O',
    GSC_HOLDING_OS: 'Holding OS',
    QUEUE_SC_CLEARED: 'SC Cleared',
    QUEUE_SC_ADDITIONAL: 'SC Additional',
    GSC_CONFIRMATION_MODAL_TEXT: 'Does this Record include any reference, in whole or in part, Government Security Classified data?',
    GSC_AGGREGATE_MODAL_TEXT: 'Does this Record contain Aggregated Sensitive Material?'
};