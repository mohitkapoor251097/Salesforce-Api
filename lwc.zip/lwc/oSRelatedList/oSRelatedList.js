import { LightningElement, api,track } from 'lwc';

import getFieldsFromMetadata from '@salesforce/apex/OS_MeetingController.getFieldsFromMetadata';
import getRelatedList from '@salesforce/apex/OS_MeetingController.getRelatedList';
import NoWritePermission from '@salesforce/customPermission/ReadOnly_permission';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import COMMON_ERROR from '@salesforce/label/c.CommonError';
import { NavigationMixin } from 'lightning/navigation';


const DELETE_BUTTON_COLUMN = {
    type: 'button-icon',
    initialWidth: 50,
    typeAttributes:
    {
        iconName: 'utility:delete',
        name: 'delete',
        alternativeText: 'Delete'
    }
};
//start for W-002684
const Edit_Column = {
    type: 'button-icon',
    initialWidth: 50,
    typeAttributes:
    {
        iconName: 'utility:edit',
        name: 'Edit',
        alternativeText: 'Edit'
    }
};

const View_Column = {
    label: 'View',
    type: 'button-icon',
    initialWidth: 50,
    typeAttributes:
    {   
        iconName: 'action:preview',
        title: 'Open in New Tab',
        name: 'View',
        alternativeText: 'View'
    }
};

//end for W-002684

export default class NewRelatedComponent extends NavigationMixin(LightningElement){//LightningElement {
    
    @api recordId;
    @api readOnly = false;
    @api title;   
    @api filterCriteria;
    @api searchFilterCriteria;
    @api metadataRecordApiName;
    @api stakeholders = [];
    @api stakeholdertype;
    @api searchmetadataname; // used to pass the search metatdata record developername
    @api removeAddButtom = false; // Added to hide + button
    @api createrecordmetadata;
    // start for W-002684
    @api  relatedname;  
    isEditVar = false; 
   @track dataval={}; 
   @api meetingactions; 
   // end for W-002684
    columns = [];
    records = [];
    showCreateRecordModel = false;
    showSearch = false;
    showDeletePopup = false;
    whareClause = '';
    searchTitle = 'Search';
    //searchMetadata = 'SearchContact';
    createRecordTitle = 'Create Record';
    createRecordMetadata = 'CreateContact';
    noRecordsPlaceHolder = 'No records to display';
    searchText = 'Search';
    deleteMessage = 'Are you sure, you want to delete?';
    //url = window.location.origin + "/lightning/o/Meeting__c/new?";
    objectName;
   get searchshow(){
        if(this.removeAddButtom=='true'){
            return true;
        }
            return this.readOnly;
     
    }

    /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
    //This getter and setter method is used to set value from meeting object
   _stakeholderData = [];

    @api
    get stakeholderData(){
        return this._stakeholderData;
    }
    set stakeholderData(value){
        if(value && value.length > 0){
            let mapOfContactIds = new Map();
            let tempArray = [];
            this.records = [];
            
            for(const obj of value){
                if(!mapOfContactIds.has(obj.Contact__c)){
                    mapOfContactIds.set(obj.Contact__c);
                    tempArray.push(obj);
                }
            }
            this.records = tempArray;
            this._stakeholderData = tempArray;
        }else{
            this.records = [];
        }
    }
    /*
     * @author      : Coforge
     * @description : This method checks if related name is equal to Action then
     * assign boolean value to true (W-002684)
     
     * @params      : event
     * @return      : NA
     */
   get searchIcon(){
      if(this.relatedname=='Action'){
            return true;
        }
        return this.readOnly;
    }
  
/*
     * @author      : Coforge
     * @description : first getting the data from custom metedata and based on that doing the 
     * soql on particular object to fetch the data and map that with the datatable.
     * @params      : event
     * @return      : NA
     */
    connectedCallback() {
        if(this.filterCriteria) {
            this.whareClause = this.filterCriteria.replace('@recordId@', this.recordId);
            //this.url = this.url + "c__ParentId=" + this.recordId;
        }
        
        this.setupColumns();
    }

    get showRecords() {
        return this.records.length > 0;
    }

    get isMeeting() {
        // ADO 7249 added the interaction object
        return (this.objectName == 'Meeting__c' || this.objectName == 'Interaction__c' ) && !NoWritePermission;
    }

/*
     * @author      : Coforge
     * @description : this property is used to exclude the records from the list. 
     * @params      : event
     * @return      : NA
     */
    get recordIdsToExclude() {
        let result;
        if (this.stakeholdertype == 'Stakeholder Organization' ){
            result = this.records.map(element => element.Account__c);
        }else{
            result = this.records.map(element => element.Account_PA__c != null ? element.Account_PA__c : element.Contact__c);
        }
        return result;
    }

/*
     * @author      : Coforge
     * @description : this property is used to show the add button icon 
     * @params      : NA
     * @return      : NA
     */

    openCreateRecordModel() {
        this.showCreateRecordModel = true;
    }

/*
     * @author      : Coforge
     * @description : this property is used to redirect on meeting record page 
     * @params      : NA
     * @return      : NA
     */
    
    openCreateMeeting() {
        /*
        this[NavigationMixin.Navigate]({
            "type": "standard__webPage",
            "attributes": {
                "url": this.url
            }
        });
        */
        /* User Story-13247  */
        // ADO 7249 updated the objectApiName from meeting to dynamic
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: this.objectName,
                actionName: 'new'
            },
            state: {
                c__ParentId: this.recordId
            },
        });
    }

    closeCreateRecordModel() {
        this.showCreateRecordModel = false;
        //start for W-002684
        if(this.isEditVar==true){
            this.isEditVar=false;
        }
        //end for W-02684
    }
/*
     * @author      : Coforge
     * @description : fetch the record from the custom metadata type after 
     * that doing the soql for the particular object and bind the data with the datatable.
     * @params      : event
     * @return      : NA
     */
    setupColumns() {
      
        getFieldsFromMetadata({

            metadataRecordName: this.metadataRecordApiName
        }).then((result) => {
            try {
                if(result) {
                    this.columns = this.sanitizeMetadata(result);                 
                    this.fetchRecords();
                 
                }
            } catch(e){
                this.showNoRecordsToast(COMMON_ERROR,'error','dismissable');
            }

        })
        .catch((error) => {
            console.log(error);
            this.showNoRecordsToast(COMMON_ERROR,'error','dismissable');
        });
    }
/*
     * @author      : Coforge
     * @description : fetch the record for the particular object with filter criteria and bind the data with the datatable.
     * @params      : event
     * @return      : NA
     */

    fetchRecords() {
        
        getRelatedList({
            metadataRecordName: this.metadataRecordApiName,
            filterCriteria: this.whareClause
        }).then((result) => {
            try{
                if(result) {
                    this.records = this.sanitizeRecords(result);
                }
            } catch(e){
                this.showNoRecordsToast(COMMON_ERROR,'error','dismissable');
            }
        })
        .catch((error) => {
            console.log(error);
            this.showNoRecordsToast(COMMON_ERROR,'error','dismissable');
        });
    }
/*
     * @author      : Coforge
     * @description : map the data with the fields described in the custom metadata types record
     * @params      : event
     * @return      : NA
     */
    sanitizeRecords(result) {
        console.log('Inside sanitizeRec--')
        const data = [];
        for(let row of result) {
            const finalRow = {}
            let rowIndexes = Object.keys(row); 
            console.log("field names",rowIndexes);
            rowIndexes.forEach((rowIndex) => 
            {
                console.log('rowIndesxes--'+ rowIndex);
                /**Added by Shabana -W-002629--- Start */
                let relatedFieldValue
                if(rowIndex == "MeetingDateColor__c"){
                    // parse image url from image tag
                    const imageFormula = row[rowIndex];
                    relatedFieldValue = imageFormula.substr(10);
                    relatedFieldValue = relatedFieldValue.slice(0, relatedFieldValue.indexOf("alt")-2);
                }else{
                    relatedFieldValue = row[rowIndex];
                }
                /**Added by Shabana -W-002629--- End */
                //const relatedFieldValue = row[rowIndex]; commented by Shabana - W-002629
                if(relatedFieldValue.constructor === Object) {
                    this.transformObjectToRow(relatedFieldValue, finalRow, rowIndex)        
                }
                else {
                    finalRow[rowIndex] = relatedFieldValue;
                }
            });
            data.push(finalRow);
         
            if(data){
                console.log('FinalRow--'+ JSON.stringify(data));
                if (this.stakeholdertype == 'Stakeholder Organization'  ){
                    data.forEach(item => item['displayName'] = item['Account__r.Name']);
                }else if (this.stakeholdertype == 'Stakeholder Lead' || this.stakeholdertype == 'Stakeholder Participant' || this.stakeholdertype == 'Ofcom Participant' ){
                    data.forEach((item) => {
                        if(item['Account_PA__c'] && item['Account_PA__c']){
                            item['displayName'] = item['Account_PA__r.Name'];
                            item['Contact__r.Email'] = item['Account_PA__r.PersonEmail'];
                        }else{
                            item['displayName'] = item['Contact__r.Name'];
                        }
                    });
                }
                // W-002684 2 start
                else if(this.relatedname=='Action'){
                        data.forEach((item) => {
                        if(item['Id'] && item['Name']){
                            item['displayName'] = item['Name'];
                            //W-002672
                            //item['URL'] = window.location.origin + '/lightning/r/Meeting_Actions__c/' +item['Id'] +'/view'
                        }
                       
                    });
                }
                // W-002684 2 end
                else {
                  
                    //data.forEach(item => item['URL'] = window.location.origin + '/lightning/r/'+ this.objectName+'/' +item['Id'] +'/view');
                    //W-002750 start
                      data.forEach((item) => {
                        item['displayName'] = item['Name'];
                     if(item['Contact__c']!=undefined){
                        item['URL1'] = window.location.origin + '/lightning/r/Contact/' +item['Contact__c'] +'/view'
                    }
                    if(item['Account_PA__c']!=undefined){
                        item['URL1'] = window.location.origin + '/lightning/r/Account/' +item['Account_PA__c'] +'/view'
                    }
                }
                    );
                    //W-002750 end
                }
            }
        } 
        return data;
    }
/*
     * @author      : Coforge
     * @description : tranform the object into the rows
     * @params      : event
     * @return      : NA
     */
    transformObjectToRow = (fieldValue, finalRow, fieldName) => 
    {        
        let rowIndexes = Object.keys(fieldValue);
        rowIndexes.forEach((key) => 
        {
            let finalKey = fieldName + '.'+ key;
            finalRow[finalKey] = fieldValue[key];
        })
    }
/*
     * @author      : Coforge
     * @description : split the custom metadata records fields vlaues 
     * and create the columns to be bind with the datatable. 
     * @params      : event
     * @return      : NA
     */
    sanitizeMetadata(result) {
        console.log('Inside index');
        const temp = [];
        //Adding the preview clickable button icon
        temp.push(View_Column);

        const fieldsMapping = result.FieldsMapping__c.split(",");
        var index = 0;
        for(const obj of fieldsMapping) {
            const val = obj.split("=");
           console.log('val--' + val);
            if (index == 0){ 
                temp.push({fieldName: 'displayName',title:val[1].trim(), label: val[1].trim(), type: 'text'});
            }
            
            //W-002750 start
            else if(val[1].trim()=='Ofcom Lead'){
              temp.push({fieldName: 'URL1', title:val[1].trim(),label: val[1].trim(), type: 'url',typeAttributes: { 
                label:{
                    fieldName:val[0].trim()
                },target: '_blank'
            }}
            );
            }
           
            //W-002750 end
            
            
            else{
                //Added by Shabana -W-002629 -- Start
                if(val[0].trim() =='MeetingDateColor__c'){ 
                    temp.push({fieldName: val[0].trim(), label: val[1].trim(), type: 'image'});
                }else{
                    temp.push({fieldName: val[0].trim(),title:val[1].trim(), label: val[1].trim(), type: 'text'});
                }
                //Added by Shabana - W-002629 -- End
            //temp.push({fieldName: val[0].trim(), label: val[1].trim(), type: 'text'}); Commented by Shabana - W-002629
            }
            index =index+1;
        }
        
        if(this.readOnly == false) {
            temp.push(DELETE_BUTTON_COLUMN);
        }
        //Start for W-002684
       if(this.relatedname=='Action' && this.readOnly == false){
            temp.push(Edit_Column);
        }
        //end for W-002684
        this.objectName =result.ObjectAPIName__c;
        return temp;
    }

    /*
     * @author      : Coforge
     * @description : to delete a particular row of the datatable  
     * @params      : event
     * @return      : NA
     */

    handleRowAction(event) {
        //W-002684 2 start
        const actionName = event.detail.action.name;
        if(actionName=='Edit' && this.relatedname=='Action'){
           this.dataval = event.detail.row;
            this.showCreateRecordModel=true;
            this.isEditVar = true;
           
        }else if(actionName =='delete'){
           this.isEditVar = false;
            //W-002684 end
            this.rowToBeDeleted = event.detail.row;
            console.log('rowToBeDeleted==>',this.rowToBeDeleted);
            this.showDeletePopup = true;
        }else if(actionName=='View'){
            this.handleView(event.detail.row);
        }
    }
    /*
     * @author      : Coforge
     * @description : delete the record after the confirmation on popup
     * @params      : event
     * @return      : NA
     */
    handleDeletePopupClose(event) {
        try{
            this.showDeletePopup = false;
            if(event.detail.value === 'no') {
                this.rowToBeDeleted = {};
                return;
            }

            const rows = [];
            
            console.log('this.records==>',JSON.stringify(this.records));
            for(const element of this.records) {
                if(this.stakeholdertype == 'Stakeholder Organization'){ 
                    if(element.Account__c !== this.rowToBeDeleted.Account__c) {
                        rows.push(element);
                    }
                }else if(this.stakeholdertype == 'Stakeholder Lead' || this.stakeholdertype =='Stakeholder Participant' || this.stakeholdertype == 'Ofcom Participant'){
                    if(element.Contact__c !== this.rowToBeDeleted.Contact__c || element.Account_PA__c !== this.rowToBeDeleted.Account_PA__c ) {
                        rows.push(element);
                    }
                }
                // start for W-002684
                else if(this.relatedname=='Action'){
                    if(element.UniqueId !== this.rowToBeDeleted.UniqueId || (element.Id!=undefined && element.Id!== this.rowToBeDeleted.Id)) {
                        rows.push(element);
                    }
                }
                //End for W-002684
                
            }
            
            this.records = rows;
            this.dispatchEvent(new CustomEvent('deleterow', {detail : { data : this.rowToBeDeleted}}));
            this.rowToBeDeleted = {};
        } catch(e){
            this.showNoRecordsToast(COMMON_ERROR,'error','dismissable');
        }
    }
    /*
     * @author      : Coforge
     * @description : Method is used to open record in new tab
     * @params      : event
     * @return      : NA
     */
    handleView(row){

        let tempRecordId;

        if(row && row['StakeholderType__c'] == 'Stakeholder Lead' || row['StakeholderType__c'] == 'Stakeholder Participant'){
            if(row['Account_PA__c']){
                tempRecordId = row['Account_PA__c'];
            }else{
                tempRecordId = row['Contact__c'];
            }
        }else if(row && row['StakeholderType__c'] == 'Ofcom Participant' && row['Contact__c']){
            tempRecordId = row['Contact__c'];
        }else if(row && row['StakeholderType__c'] == 'Stakeholder Organization' && row['Account__c']){
            tempRecordId = row['Account__c'];
        }else{
            tempRecordId = row['Id']?row['Id']:'';
        }
        
        //Navigate the record in new tab
        this[NavigationMixin.GenerateUrl]({
            type: 'standard__recordPage',
            attributes: {
                recordId: tempRecordId,
                actionName: 'view',
            },
        }).then((url) => {
            window.open(url, '_blank');
        });
    }

    openSearchPopup(event) {
        this.showSearch = true;
        
    }
    /*
     * @author      : Coforge
     * @description : it will return the selected records to the parent component.
     * if the component is configure for stakeholder organization, stakeholder participants, 
     * stakeholder lead and ofcom participants then it will return a particular form of data. 
     * for other compoents it will return the selected record.    
     * @params      : event
     * @return      : NA
     */

    closeSearchPopup(event) {
    try{
        if(event.detail) {
            if (this.stakeholdertype == 'Stakeholder Organization'){
                
                let temp = [];
                let temp1 = [];
                for(const element of this.records) {
                    temp.push(element);
                }
                for(const element1 of event.detail) {
                    let tempdetail = { 'Account__c':'' ,'Account__r.Name':'','Account__r.Address__c':'','StakeholderType__c':'','URL':'', 'displayName':''};
                    tempdetail['Account__c'] = element1.Id;
                    tempdetail['Account__r.Id'] = element1.Id;
                    tempdetail['Account__r.Name'] = element1.Name;
                    tempdetail['Account__r.Address__c'] = element1.Address__c;
                    tempdetail['StakeholderType__c'] = this.stakeholdertype;
                    tempdetail['displayName'] = element1.Name;
                    tempdetail['Account__r.OS_Business_Owner__c'] = element1.OS_Business_Owner__c;// added by Eshan
                    
                    temp.push(tempdetail);
                    temp1.push(tempdetail);
                }
                this.records = temp;
                
                this.dispatchEvent(new CustomEvent('addrows', {detail : { data : temp1 }}));
            }
            else if (this.stakeholdertype == 'Stakeholder Lead'){
                
                let temp = [];
                let temp1 = [];
                for(const element of this.records) {
                    temp.push(element);
                }
                
                for(const element1 of event.detail) {
                    
                    let tempdetail;
                    
                    if(element1.Id && element1.Id.substring(0,3)==='001'){
                        let tempAccountObj = {'Id':'','Name':''};
                        if(element1.Organisational_Roles_Contact__r){
                            for(let orgRole of element1.Organisational_Roles_Contact__r){
                                if(orgRole.Contact__c && orgRole.Licensee_or_Organisation__c && orgRole.Contact__c == element1.Id){
                                    tempAccountObj['Id'] = orgRole.Licensee_or_Organisation__c;
                                    tempAccountObj['Name'] = orgRole.Licensee_or_Organisation__r.Name;
                                }
                            }
                            if(tempAccountObj){
                                //Temp Detail for Person Account
                                tempdetail = { 'Contact__c':'','Account__r.Id':'','Contact__r.Id':'','Contact__r.Name':'','Account__r.Name':'','Contact__r.JobTitle__c':'','Contact__r.Email':'','Account_PA__c':'','StakeholderType__c':'','displayName':''};
                                tempdetail['Contact__c'] = element1.Id; //Added by Shabana
                                tempdetail['Account__r.Id'] = tempAccountObj.Id;
                                tempdetail['Account__r.Name'] = tempAccountObj.Name;
                                tempdetail['Contact__r.Name'] = element1.Name;
                                tempdetail['Contact__r.Id'] = element1.Id;
                                tempdetail['Contact__r.Email'] = element1.PersonEmail;
                                tempdetail['Contact__r.JobTitle__c'] = '';
                                tempdetail['StakeholderType__c'] = this.stakeholdertype;
                                tempdetail['displayName'] = element1.Name;
                                tempdetail['Account_PA__c'] = element1.Id;
                            }
                        }
                    }else{
                        //Temp Detail for Contact
                        tempdetail = { 'Contact__c':'','Account__r.Id':'','Contact__r.Id':'','Contact__r.Name':'','Account__r.Name':'','Contact__r.JobTitle__c':'','Contact__r.Email':'','URL':'','StakeholderType__c':'','displayName':'','Preferred_language__c':''};// ADO -16070 Added Preffered language
                        tempdetail['Contact__c'] = element1.Id;
                        tempdetail['Account__r.Id'] = element1.Account.Id;
                        tempdetail['Account__r.Name'] = element1.Account.Name;
                        tempdetail['Contact__r.Name'] = element1.Name;
                        tempdetail['Contact__r.Id'] = element1.Id;
                        tempdetail['Contact__r.Email'] = element1.Email;
                        tempdetail['Contact__r.JobTitle__c'] = element1.JobTitle__c;
                        tempdetail['StakeholderType__c'] = this.stakeholdertype;
                        tempdetail['displayName'] = element1.Name;
                        tempdetail['Contact__r.Preferred_language__c'] = element1.Preferred_language__c;// ADO -16070
                        
                    }
                    temp.push(tempdetail);
                    temp1.push(tempdetail);
                }
                this.records = temp;
                
                this.dispatchEvent(new CustomEvent('addrows', {detail : { data : temp1 }}));

            }else if (this.stakeholdertype == 'Stakeholder Participant'){
                    
                    let temp = [];
                    let temp1 = [];
                    for(const element of this.records) {
                        temp.push(element);
                    }
                    
                    for(const element1 of event.detail) {

                        if(element1.Id && element1.Id.substring(0,3)==='001'){
                            
                            let tempAccountObj = {'Id':'','Name':''};
                            if(element1.Organisational_Roles_Contact__r){
                                for(let orgRole of element1.Organisational_Roles_Contact__r){
                                    if(orgRole.Contact__c && orgRole.Licensee_or_Organisation__c && orgRole.Contact__c == element1.Id){
                                        tempAccountObj['Id'] = orgRole.Licensee_or_Organisation__c;
                                        tempAccountObj['Name'] = orgRole.Licensee_or_Organisation__r.Name;
                                    }
                                }
                                if(tempAccountObj){
                                    //Temp Detail for Person Account
                                    let tempdetail = { 'Contact__c':'','Account__r.Id':'','Contact__r.Id':'','Contact__r.Name':'','Account__r.Name':'','Contact__r.JobTitle__c':'','Contact__r.Email':'','Account_PA__c':'','StakeholderType__c':'','displayName':''};
                                        tempdetail['Contact__c'] = element1.Id;
                                        tempdetail['Account__r.Id'] = tempAccountObj.Id;
                                        tempdetail['Account__r.Name'] = tempAccountObj.Name;
                                        tempdetail['Contact__r.Name'] = element1.Name;
                                        tempdetail['Contact__r.Id'] = element1.Id;
                                        tempdetail['Contact__r.Email'] = element1.PersonEmail;
                                        tempdetail['Contact__r.JobTitle__c'] = '';
                                        tempdetail['StakeholderType__c'] = this.stakeholdertype;
                                        tempdetail['displayName'] = element1.Name;
                                        tempdetail['Account_PA__c'] = element1.Id;

                                        temp.push(tempdetail);
                                        temp1.push(tempdetail);
                                }
                            }

                        }else{
                            //Temp Detail for Contact
                            let tempCondetail = { 'Contact__c':'','Account__r.Id':'','Contact__r.Id':'','Contact__r.Name':'','Account__r.Name':'','Contact__r.JobTitle__c':'','Contact__r.Email':'','StakeholderType__c':'','displayName':'','Preferred_language__c':''};// ADO -16070 Added Preffered language
                                tempCondetail['Contact__c'] = element1.Id;
                                tempCondetail['Account__r.Id'] = element1.Account.Id;
                                tempCondetail['Account__r.Name'] = element1.Account.Name;
                                tempCondetail['Contact__r.Name'] = element1.Name;
                                tempCondetail['Contact__r.Id'] = element1.Id;
                                tempCondetail['Contact__r.Email'] = element1.Email;
                                tempCondetail['Contact__r.JobTitle__c'] = element1.JobTitle__c;
                                tempCondetail['StakeholderType__c'] = this.stakeholdertype;
                                tempCondetail['displayName'] = element1.Name;
                                tempCondetail['Contact__r.Preferred_language__c'] = element1.Preferred_language__c; // ADO -16070

                                temp.push(tempCondetail);
                                temp1.push(tempCondetail);
                        }
                    }
                    this.records = temp;
                    
                    this.dispatchEvent(new CustomEvent('addrows', {detail : { data : temp1 }}));

                }else if (this.stakeholdertype == 'Ofcom Participant'){
                    
                    let temp = [];
                    let temp1 = [];
                    for(const element of this.records) {
                        temp.push(element);
                    }
                    for(const element1 of event.detail) {
                        debugger;
                        
                        //Added teamname for W-002672
                        let tempdetail = { 'Contact__c':'','Account__r.Id':'','Contact__r.Id':'','Contact__r.Name':'','Account__r.Name':'','Contact__r.JobTitle__c':'','Contact__r.Email':'','URL':'','StakeholderType__c':'','Contact__r.Team_Name__c':'','displayName':''};
                        tempdetail['Contact__c'] = element1.Id;
                        tempdetail['Account__r.Id'] = element1.Account.Id;
                        tempdetail['Account__r.Name'] = element1.Account.Name;
                        tempdetail['Contact__r.Name'] = element1.Name;
                        tempdetail['Contact__r.Id'] = element1.Id;
                        tempdetail['Contact__r.Email'] = element1.Email;
                        tempdetail['Contact__r.JobTitle__c'] = element1.JobTitle__c;
                        tempdetail['StakeholderType__c'] = this.stakeholdertype;
                        tempdetail['Contact__r.Team_Name__c'] = element1.Team_Name__c; //W-002672
                        tempdetail['displayName'] = element1.Name;

                        temp.push(tempdetail);
                        temp1.push(tempdetail);
                    }
                    this.records = temp;
                    
                    this.dispatchEvent(new CustomEvent('addrows', {detail : { data : temp1 }}));
            }else {
                let temp = [];
                for(const element of this.records) {
                    temp.push(element);
                }
                for(const element1 of event.detail) {
                    temp.push(tempdetail);
                }
                this.records = temp;
                this.dispatchEvent(new CustomEvent('addrows', {detail : { data : event.detail }}));
            }
        }
        this.showSearch = false;
    } catch(e){
        console.log('error==>',JSON.stringify(e));
        this.showNoRecordsToast(COMMON_ERROR,'error','dismissable');
    }
}

    /*
     * @author      : Coforge
     * @description : it will return the selected records to the parent component.
     * if the component is configure for stakeholder organization, stakeholder participants, 
     * stakeholder lead and ofcom participants then it will return a particular form of data. 
     * for other compoents it will return the selected record.    
     * @params      : event
     * @return      : NA
     */

    closeCreatePopup(event) {
     try{
            if(event.detail) {
                var isSameRecord = false; //W-002684
                //Start for W-002684
               if(this.relatedname=='Action'){
                    const temp = [];
                    const temp1 = [];
                    for(const element of this.records) {
                        temp.push(element);
                    }
                    for(const element1 of event.detail) {
                       
                       this.editDataRecord(temp,element1,isSameRecord,temp1);
                    }
                   this.records = temp;
                 
                   this.dispatchEvent(new CustomEvent('addrows', {detail : { data : temp }}));
                } 
                //End for W-002684
                //start for W-002653
                if (this.stakeholdertype == 'Stakeholder Organization'){ 
                    let temp = [];
                    let temp1 = [];
                    for(const element of this.records) {
                        temp.push(element);
                    }
                
                    for(const element1 of event.detail) {
                        
                        let tempdetail = {'Account__c':'' ,'Account__r.Id':'' ,'Account__r.Name':'','Account__r.Address__c':'','URL':'','StakeholderType__c':'','displayName':''};
                        tempdetail['Account__c'] = element1.Id; //bug-fix
                        tempdetail['Account__r.Id'] = element1.Id;
                        tempdetail['Account__r.Name'] = element1.Name;
                        tempdetail['Account__r.Address__c'] = element1.Address__c;
                        tempdetail['StakeholderType__c']=this.stakeholdertype ;//bug fix
                        tempdetail['displayName'] = element1.Name;
                        temp.push(tempdetail);
                        temp1.push(tempdetail);
                    }
                    this.records = temp;
                    
                    this.dispatchEvent(new CustomEvent('addrows', {detail : { data : temp1 }}));
                
                }
                //end for W-002653

                if (this.stakeholdertype == 'Stakeholder Lead'){
                    
                    let temp = [];
                    let temp1 = [];
                    for(const element of this.records) {
                        temp.push(element);
                    }
                    for(const element1 of event.detail) {
                        debugger;
                        let tempdetail = { 'Account__r.Id':'','Contact__c':'','Contact__r.Id':'','Contact__r.Name':'','Account__r.Name':'','Contact__r.JobTitle__c':'','Contact__r.Email':'','URL':'','StakeholderType__c':'','displayName':'','Contact__r.Preferred_language__c':''};
                        tempdetail['Account__r.Id'] = element1['Account.Id'];
                        tempdetail['Account__r.Name'] = element1['Account.Name'];
                        tempdetail['Contact__c'] = element1['Id']; //bug-fix
                        tempdetail['Contact__r.Name'] = element1['Name'];
                        tempdetail['Contact__r.Id'] = element1['Id'];
                        tempdetail['Contact__r.Email'] = element1['Email'];
                        tempdetail['Contact__r.JobTitle__c'] = element1['JobTitle__c'];
                        tempdetail['StakeholderType__c']=this.stakeholdertype ;//bug fix
                        tempdetail['displayName'] = element1['Name'];
                        tempdetail['Contact__r.Preferred_language__c'] = element1['Preferred_language__c'];
                        temp.push(tempdetail);
                        temp1.push(tempdetail);
                    }
                    this.records = temp;

                    this.dispatchEvent(new CustomEvent('addrows', {detail : { data : temp1 }}));

                }else if (this.stakeholdertype == 'Stakeholder Participant'){
                    
                    let temp = [];
                    let temp1 = [];
                    for(const element of this.records) {
                        temp.push(element);
                    }
                    for(const element1 of event.detail) {
                        
                        let tempdetail = { 'Account__r.Id':'','Contact__c':'','Contact__r.Id':'','Contact__r.Name':'','Account__r.Name':'','Contact__r.JobTitle__c':'','Contact__r.Email':'','URL':'','StakeholderType__c':'','displayName':'','Contact__r.Preferred_language__c':''};
                            tempdetail['Account__r.Id'] = element1['Account.Id'];
                            tempdetail['Account__r.Name'] = element1['Account.Name'];
                            tempdetail['Contact__r.Name'] = element1['Name'];
                            tempdetail['Contact__c'] = element1['Id']; //bug-fix
                            tempdetail['Contact__r.Id'] = element1['Id'];
                            tempdetail['Contact__r.Email'] = element1['Email'];
                            tempdetail['Contact__r.JobTitle__c'] = element1['JobTitle__c'];
                            tempdetail['StakeholderType__c']=this.stakeholdertype ;//bug fix
                            tempdetail['displayName'] = element1['Name'];
                            tempdetail['Contact__r.Preferred_language__c'] = element1['Preferred_language__c'];
                            temp.push(tempdetail);
                            temp1.push(tempdetail);
                    }
                    this.records = temp;
                    
                    this.dispatchEvent(new CustomEvent('addrows', {detail : { data : temp1 }}));

                }else if (this.stakeholdertype == 'Ofcom Participant'){
                    
                    let temp = [];
                    let temp1 = [];
                    for(const element of this.records) {
                        temp.push(element);
                    }
                    for(const element1 of event.detail) {
                        
                        //Added teamname for W-002672
                        let tempdetail = { 'Account__r.Id':'','Contact__c':'','Contact__r.Id':'','Contact__r.Name':'','Account__r.Name':'','Contact__r.JobTitle__c':'','Contact__r.Email':'','URL':'','StakeholderType__c':'','Contact__r.Team_Name__c':'','displayName':''};
                            tempdetail['Account__r.Id'] = element1['Account.Id'];
                            tempdetail['Account__r.Name'] = element1['Account.Name'];
                            tempdetail['Contact__r.Name'] = element1['Name'];
                            tempdetail['Contact__c'] = element1['Id']; //bug-fix
                            tempdetail['Contact__r.Id'] = element1['Id'];
                            tempdetail['Contact__r.Email'] = element1['Email'];
                            tempdetail['Contact__r.JobTitle__c'] = element1['JobTitle__c'];
                            tempdetail['StakeholderType__c']=this.stakeholdertype ;//bug fix
                            tempdetail['Contact__r.Team_Name__c']=element1['Team_Name__c']; //W-002672
                            tempdetail['displayName'] = element1['Name'];
                            temp.push(tempdetail);
                            temp1.push(tempdetail);
                    }
                    this.records = temp;
                    
                    this.dispatchEvent(new CustomEvent('addrows', {detail : { data : temp1 }}));
                }
                else if(this.stakeholdertype != 'Stakeholder Organization' && this.relatedname!='Action'){ //2684
                    console.log('Inside else part-');
                    let temp = [];
                    for(const element of this.records) {
                        temp.push(element);
                    }
                    for(const element1 of event.detail) {
                        temp.push(tempdetail);
                    }
                    this.records = temp;
                    this.dispatchEvent(new CustomEvent('addrows', {detail : { data : event.detail }}));
                }
              
            }
            this.showCreateRecordModel = false;
            //Added for W-002684
            if(this.isEditVar==true){
                this.isEditVar = false;
            }
            
        } catch(e){
           console.log('Inside excep--');
            this.showNoRecordsToast(COMMON_ERROR,'error','dismissable');
        }
    }
     /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : To display meeting action data (W-002684)
     * @params      : temp
     * @params      : element1
     * @params      : isSameRecord
     * @params        : temp1
     * @return      : NA
     */
    editDataRecord(temp,element1,isSameRecord,temp1){
       for(const item of temp){
        if(item.UniqueId==element1.UniqueId && (item.Id==undefined)){
            isSameRecord = true;
            item['Action_Owner__c'] = element1.Action_Owner__c;
            item['Action_Description__c'] = element1.Action_Description__c;
            item['Due_Date__c'] = element1.Due_Date__c;
            item['UniqueId'] = element1.UniqueId;
            item['Action_Owner__r.Name'] = element1.ActionName;
            break;

        }else if( item.Id!=undefined && item.Id==element1.Id){
          isSameRecord = true;
          item['Action_Owner__c'] = element1.Action_Owner__c;
          item['Action_Description__c'] = element1.Action_Description__c;
          item['Due_Date__c'] = element1.Due_Date__c;
          item['UniqueId'] = element1.UniqueId;
          item['Action_Owner__r.Name'] = element1.ActionName;
          break;
        }
  
       }
       
    if(isSameRecord==false){
        let tempdetail = {'Action_Owner__c':'' ,'Action_Description__c':'', 'Due_Date__c':'','UniqueId':'','Action_Owner__r.Name':'','URL':''};
        tempdetail['Action_Owner__c'] = element1.Action_Owner__c;
        tempdetail['Action_Description__c'] = element1.Action_Description__c;
        tempdetail['Due_Date__c'] = element1.Due_Date__c;
        tempdetail['UniqueId'] = element1.UniqueId;
        tempdetail['Action_Owner__r.Name'] = element1.ActionName;
        temp.push(tempdetail);
        temp1.push(tempdetail);
    }
    
   }

    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : To show the toast message for success and error 
     * @params      : title
     * @params      : variant
     * @params      : mode
     * @return      : NA
     */
    showNoRecordsToast(title,variant,mode) {
        const event = new ShowToastEvent({
            title: title,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(event);
    }

}