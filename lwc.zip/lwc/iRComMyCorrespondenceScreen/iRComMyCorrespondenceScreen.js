/**
* @description   Displays the IRMS cases files
* @author        Coforge
* @date          27 August 2024
* @lastModified  27 August 2024
* @description : ADO-37141 My Correspondence Screen 
*              : ADO-37261 Correspondence Detailed IR SRC Case View Pop-up Screen
*/
import { LightningElement, api, track } from 'lwc';
import getIRSRCCaseRecord from '@salesforce/apex/IRComCreatePortalUser.getIRSRCCaseRecord';
import { loadScript } from 'lightning/platformResourceLoader';
import jsResourceUrl from '@salesforce/resourceUrl/IR_Templates';

export default class IRComMyCorrespondenceScreen extends LightningElement {
    @api targetaccount;
    @api relatedcaseaccess;
    @api unrelatedcaseaccess;
    irSRCCaseCount;
    paginationCaseslist = [];
    srccase;
    showSpinner = false;
    @track isPagination = false;
    finalSRCCaseList;
    jsresource = jsResourceUrl + '/js/timeDateFormat.js';
    formatDateTimeLib;
    isMyCorrespondenceScreen=true;
    isVisibleDetailViewScreen=false;
    selectedSRCCaseDetails;  //ADO-37261
  
    /*       
    * @author      : Coforge
    * @date        : 27/08/2024
    * @description : ADO-27141: method called on page load to get the ir src record data
    */
    connectedCallback() {
        try {
            this.showSpinner = true;
            this.loadDateTimeFormatter();
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 27/08/2024
    * @description : ADO-37141: method used to fetch display logic of IR SRC case record.
    */
    populateRequestList(targetcp, isrelated, isunrelated) {
        try {
            getIRSRCCaseRecord({ targetAccountId: targetcp, isRelatedCaseAccess: isrelated, isUnrelatedCaseAccess: isunrelated })
                .then((result) => {
                    // Loop through each record in the result and format the CreatedDate
                    result = result.map(record => {
                        if (record.CreatedDate) {
                            record.CreatedDate = this.formatDateTimeLib(record.CreatedDate);
                        }
                        return record;
                    });

                    this.irSRCCaseCount = result.length;
                    this.srccase = result;
                    this.paginationCaseslist = result;
                    this.isPagination = true;
                    this.showSpinner = false;
                })
                .catch((error) => {
                    this.showSpinner = false;
                    window.location.href = '/apex/licensingcomerror';
                });
        } catch (e) {
            this.showSpinner = false;
            window.location.href = '/apex/licensingcomerror';
        }
    }


    /*       
    * @author      : Coforge
    * @date        : 27/08/2024
    * @description : ADO-37141: method called to get the current record data from pagination
    */
    currentSRCCaseList(event) {
        this.finalSRCCaseList = [...event.detail.records];
    }

    /*       
    * @author      : Coforge
    * @date        : 28/08/2024
    * @description : ADO-37141: method called from connected callback method
    */
    loadDateTimeFormatter() {
        loadScript(this, this.jsresource)
            .then(() => {
                this.formatDateTimeLib = window.formatResponseReceivedDate;
                if (this.targetaccount != undefined && this.targetaccount != null) {
                    this.populateRequestList(this.targetaccount[0].Id, this.relatedcaseaccess, this.unrelatedcaseaccess);
                }
            })
            .catch(error => {
                this.showSpinner = false;
                window.location.href = '/apex/licensingcomerror';
            });
    }

     /*       
    * @author      : Coforge
    * @date        : 28/08/2024
    * @description : ADO-37141/37261: method called from detailed view button
    */
    handleViewClick(event) {
        try {
             const caseId = event.target.dataset.id;
            const selectedSRCCase = this.paginationCaseslist.find(caseitem => caseitem.Id === caseId);
            if (selectedSRCCase) {
                this.selectedSRCCaseDetails = selectedSRCCase;
            }
            this.isMyCorrespondenceScreen = false;
            this.isVisibleDetailViewScreen = true;
        } catch (e) {
            this.showSpinner = false;
            window.location.href = '/apex/licensingcomerror';
        }
    }

     /*       
     * @author      : Coforge
     * @date        : 27/08/2024
     * @description :ADO-37261 Method called on Back button to view the my correspondence screen
     */
    handleisVisibleDetailViewScreen(event) {
        try {
             const { isMyCorrespondenceScreen, isVisibleDetailViewScreen} = event.detail;
            this.isMyCorrespondenceScreen = isMyCorrespondenceScreen;
            this.isVisibleDetailViewScreen = isVisibleDetailViewScreen;
        } catch (e) {
            this.showSpinner = false;
            window.location.href = '/apex/licensingcomerror';
        }
    }
}