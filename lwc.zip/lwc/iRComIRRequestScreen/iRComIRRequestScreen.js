/**
* @description   Displays the IR cases summary table
* @author        Coforge
* @date          16 May 2024
* @lastModified  24 May 2024
* @description : ADO-22358 Navigation to the 'All IR Requests' screen
               : ADO 22367 Logic for making IR case records visible to external CP users.
               : ADO 22376 Access to the Detailed IR Request Screen
               : ADO-37140 New Data Field - Related IR Contact
               : ADO-22373 'External Status' and 'Draft Notice' status automation for the 'Draft Notice Stage'
               : ADO-22379 'External Status' and 'Final Notice' status automation and manual settings for the 'Final Notice 
*/
import { LightningElement, api, track, wire } from 'lwc';
import getCaseRequestList from '@salesforce/apex/IRComCreatePortalUser.getIRRequestList';
import myImageResource from '@salesforce/resourceUrl/IR_Templates';
import irCommunitySetting from '@salesforce/apex/IR_Utility.getIRCustomSettingValue';//ADO 33991
import updateIRCaseExtStatus from '@salesforce/apex/IRComCreatePortalUser.updateIRCaseExtStatus';//ADO 22373
export default class IRComIRRequestScreen extends LightningElement {
    imageurl = myImageResource + '/image/Ir_alert.jpg';

    irCaseCount;
    paginationCaseslist = [];
    @track isPagination = false;
    finalcaselist;
    @track isiRComIRRequestScreen = true;
    @track IsDetailedRequestScreen = false;
    //ADO-22359 Start
    @api targetaccount;
    @api relatedcaseaccess;
    @api unrelatedcaseaccess;
    showSpinner = false;
    //ADO-22359 End
    @api selectedCaseDetails;//ADO-22376
    @track externalStatus; //ADO-33991 
    @api currentloggedorgrole = []; //ADO-37140
    isUpdateIRMSCase=false; //ADO 22373/ 22379

    /*       
  * @author      : Coforge
  * @date        : 19/06/2024
  * @description : ADO-33991: method called on all Request page load to get the ir custom setting data
  */
    @wire(irCommunitySetting)
    getIRCustomSettingData({ error, data }) {
        try {
            if (data) {
                this.externalStatus = data.IR_Notification_ALert_Status_Value__c;
            } else if (error) {
                window.location.href = '/apex/licensingcomerror';
            }
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
   * @author      : Coforge
   * @date        : 23/05/2024
   * @description : ADO-22358/22367: method called on page load to get the ir record data
   */
    connectedCallback() {
        try {
            this.showSpinner = true;
            if (this.targetaccount != undefined && this.targetaccount != null) {
                this.populateRequestList(this.targetaccount[0].Id, this.relatedcaseaccess, this.unrelatedcaseaccess);
            }

        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 23/05/2024
    * @description : ADO-22358/22373/22379: method used to open request detail screen and Call updateIRMSCaseRecord function to update the external status and draft notice status
    */
    handleViewClick(event) {
        try {
            this.isUpdateIRMSCase=false;
            this.showSpinner = true;
            const caseId = event.target.dataset.id;
            /*ADO-22376 start*/
            const selectedCase = this.paginationCaseslist.find(caseitem => caseitem.Id === caseId);
            if (selectedCase) {
                this.selectedCaseDetails = selectedCase;
            }
            /*ADO-22376 End*/
            /*ADO 22373/22379 start*/
            const caseRecord = { ...this.selectedCaseDetails }
            // Check if External Status is 'Unopened (Draft Notice)'
            if (caseRecord && caseRecord.External_Status__c == 'Unopened (Draft Notice)') {
                caseRecord.External_Status__c = 'In progress (Draft Notice)';
                this.isUpdateIRMSCase=true;
            }else if (caseRecord && caseRecord.External_Status__c == 'Unopened (Final Notice)') { // Check if External Status is 'Unopened (Final Notice)'
                caseRecord.External_Status__c = 'In progress (Final Notice)';
                this.isUpdateIRMSCase=true;
            }
              // Check if Draft Notice Status is 'Unopened'
            if (caseRecord && caseRecord.Draft_Notice_Status__c == 'Unopened') {
                caseRecord.Draft_Notice_Status__c = 'In progress - No comments received';
                this.isUpdateIRMSCase=true;
            }
            //Update IRMS Case if isUpdateIRMSCase return true. 
            if(this.isUpdateIRMSCase){
                this.updateIRMSCaseRecord(caseRecord);
            }else{
                    this.isiRComIRRequestScreen = false;
                    this.IsDetailedRequestScreen = true;
                    this.showSpinner = false;
            }
            /*ADO 22373/22379 End*/
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 24/09/2024
    * @description : ADO 22373/22379: This method will call updateIRCaseExtStatus Apex method to update the external status and draft notice status
    */
    updateIRMSCaseRecord(caseRecord){
        updateIRCaseExtStatus({ caserecord: JSON.stringify(caseRecord) })
            .then((result) => {
                if(result ===true){
                this.isiRComIRRequestScreen = false;
                this.IsDetailedRequestScreen = true;
                this.showSpinner = false;
                }
            })
            .catch((error) => {
                window.location.href = '/apex/licensingcomerror';
            });
    }

    /*       
       * @author      : Coforge
       * @date        : 23/05/2024
       * @description : ADO-22358: method called to get the current record data from pagination
       */
    currentCaseList(event) {
        this.finalcaselist = [...event.detail.records];
    }

    /*       
   * @author      : Coforge
   * @date        : 23/05/2024
   * @description : ADO-22358: Get the values from iRComDetailedRequestScreen through custom event
   */
    exposedircases(event) {
        try {
            const { isExposed, isDetailedRequestScreen } = event.detail;
            this.isiRComIRRequestScreen = isExposed;
            this.IsDetailedRequestScreen = isDetailedRequestScreen;
            this.connectedCallback(); //ADO 37140
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 30/05/2024
    * @description : ADO-22367: method used to fetch display logic of case record.
    */

    populateRequestList(targetcp, isrelated, iaunrelated) {
        try {
            getCaseRequestList({ targetAccountId: targetcp, isRelatedCaseAccess: isrelated, isUnrelatedCaseAcces: iaunrelated })
                .then((result) => {
                    /*ADO 22358 Show and tell feedback fixed */
                    this.paginationCaseslist = result.map(caseItem => {
                        const { imageUrl, className } = this.getImageUrlAndClass(caseItem.External_Status__c);
                        return {
                            ...caseItem,
                            imageUrl,
                            className
                        };
                    });
                    this.irCaseCount = (this.paginationCaseslist).length;
                    this.isPagination = true;
                    this.showSpinner = false;
                })
                .catch((error) => {
                    window.location.href = '/apex/licensingcomerror';
                });
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
    /*       
   * @author      : Coforge
   * @date        : 04/06/2024
   * @description : ADO 22358/33991 Show and tell feedback fixed 
   */
    getImageUrlAndClass(status) {
        let imageUrl = '';
        let className = '';

        if (this.externalStatus != null && this.externalStatus != undefined) {
            let statusArray = this.externalStatus.split(',');
            /*  ADO 33991 Status value update start*/
            if (statusArray.includes(status)) {
                imageUrl = this.imageurl; // Replace with your actual image URL logic
                className = 'grid-button slds-button slds-button_brand slds-m-around_x-small marginRight';
            } else {
                className = 'grid-button slds-button slds-button_brand slds-m-around_x-small marginRight default';
            }
        }
        else {
            className = 'grid-button slds-button slds-button_brand slds-m-around_x-small marginRight default';

        }
        /* ADO 33991 Status value update End*/
        return { imageUrl, className };
    }
}