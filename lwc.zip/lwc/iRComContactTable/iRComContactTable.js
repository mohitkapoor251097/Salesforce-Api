/**
* @description   Get the data from iRComDashboardScreen and display in Custom table
* @author        Coforge
* @date          27 February 2024
* @lastModified  26 Feb 2025
* @description : ADO-26710 : New IR Dashboard page in LWC including header & footer
                 ADO-22343 : Auto creation of person account based on new org role contact 
                 ADO-22338 : Contact Management Privileges for External CP User
                 ADO-27683: Functionality for "View" and "Edit/Delete" buttons for IR Regulatory Contacts and General IR Contacts Table.
                 ADO-22353 : Visibility on Org role holder profile
                 ADO 22354 : Visibility on GIR Org role holder profile
                 ADO-30477 : Show and tell feedback
                 ADO-26706 : Pagination functionality for IR Regulatory Contact
                 ADO-26707 : Pagination functionality for General IR Contact
*/
import { LightningElement, api, track } from 'lwc';
//import LightningConfirm from 'lightning/confirm';
import updateOrgRoleAsiInactive from '@salesforce/apex/IR_Utility.updateOrgRoleAsiInactive';
export default class IRComContactTable extends LightningElement {
    
    @api title;
    @api orgrolelist = [];
    @api buttonlabel;
    @api currentloggedorgrole = [];
    opencontactmodal = false; //ADO 27683
    showSpinner; // To show spinner until data is fetched
    //ADO-22338 Start
    @api iscreate;
    @api isedit;
    @api isdelete;
    @api iseditother;
    jsonObj = [];
    finalOrgrolelist;
    // ADO-22338 end
    //ADO 27683start
    @api selectedContactDetails;
    isDeletePopUpOpen = false;
    deletionid;
    //ADO 27683 end
    //ADO 26706/26707 Start
    paginationOrgrolelist = [];
    @track isPagination = false;
    orgRoleCount;
    //ADO 26706/26707 End

    connectedCallback() {
        //22338 start
        try{
            if(this.orgrolelist != undefined || this.orgrolelist != null){
                let temporaryList = JSON.parse(JSON.stringify(this.orgrolelist));;
                temporaryList.forEach((items) => {
                    items["isOwnRecord"] = items.Id === this.currentloggedorgrole;
                    this.jsonObj.push(items);
                });
                //ADO- 26706/26707 Start // initializing list to send it to pagination lwc
                this.paginationOrgrolelist = JSON.parse(JSON.stringify(this.jsonObj));
                this.orgRoleCount = (this.paginationOrgrolelist).length;
                this.isPagination = true;
                //ADO- 26706/26707 End
            }
        }catch{
            window.location.href = '/apex/licensingcomerror';
        }        
        //22338 End
    }

    /*       
    * @author      : Coforge
    * @date        : 04/02/2024
    * @description : ADO-22343: dispatch custom event and pass details to IRComDashboardScreen
    */
    createNewIRContact() {
        try {
            //BUG-52118 Fix Start
            if(this.iscreate){
                window.location.href = '/apex/licensingcomerror';
            }//BUG-52118 Fix End
            else {
                this.clearExistingErrorMessage(); //ADO 27683
                var orgRoleType = '';
                if (this.buttonlabel == 'Create new regulatory contact') {
                    orgRoleType = 'IR Regulatory Contact';
                } else if (this.buttonlabel == 'Create new general contact') {
                    orgRoleType = 'General IR Contact';
                }
                this.dispatchEvent(new CustomEvent("openlicencecontactpopup", {
                    detail: {
                        selectedContact: null,
                        contactType: orgRoleType // Passing the Contact's type
                    }
                }));
            }
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 04/03/2024
    * @description : ADO-27683: Functionality for "View" and "Edit/Delete" buttons for IR Regulatory Contacts and General IR Contacts Table.
    */
    handleViewClick(event) {

        try {
            this.clearExistingErrorMessage(); //ADO 27683
            this.opencontactmodal = true;
            const contactId = event.target.dataset.id;
            const selectedContact = this.orgrolelist.find(contact => contact.Id === contactId);
            document.body.style.overflow = 'hidden';
            if (selectedContact) {
                // Store the selected contact details in the property
                this.selectedContactDetails = {
                    FirstName: selectedContact.Contact__r.FirstName,
                    LastName: selectedContact.Contact__r.LastName,
                    Email: selectedContact.Email__c,
                    Phone: selectedContact.Phone__c,   //ADO-30477 Show and tell feedback
                    Street: selectedContact.Street__c,
                    City: selectedContact.City__c,
                    PostalCode: selectedContact.PostalCode__c,
                    State: selectedContact.State__c,
                    Country: selectedContact.Country_Picklist__c
                    // Add other properties you want to include
                };
            }
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
    /*       
    * @author      : Coforge
    * @date        : 07/03/2024
    * @description : ADO-27683: Edit button Functionality for IR Regulatory Contacts and General IR Contacts Table
    */
    closemodalaction(event) {
        try {
            this.opencontactmodal = event.detail.value;
            document.body.style.overflow = '';
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
    /*       
    * @author      : Coforge
    * @date        : 07/03/2024
    * @description : ADO-27683: Edit button Functionality for IR Regulatory Contacts and General IR Contacts Table
    */
    async handledelete(event) {
        try {
            this.deletionid = event.target.dataset.id;
            document.body.style.overflow = 'hidden';
            //BUG-52118 Fix Start
            if(this.isdelete){
                window.location.href = '/apex/licensingcomerror';
            }//BUG-52118 Fix End
            else if (this.currentloggedorgrole === event.target.dataset.id) {
                document.body.style.overflow = '';
                this.dispatchEvent(new CustomEvent("displayerrormessage", {
                    detail: {
                        message: "This contact record is possibly associated with current logged in user. Please contact system administrator to update these details."
                    }
                }));
            } else {
                this.isDeletePopUpOpen = true;
                this.dispatchEvent(new CustomEvent("displayerrormessage", {
                    detail: {
                        message: ""
                    }
                }));
            }
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
     * @author      : Coforge
     * @date        : 07/03/2024
     * @description : ADO-27683: Edit button Functionality for IR Regulatory Contacts and General IR Contacts Table
     */
    editButtonHandler(event) {

        try {
            //BUG-52118 Fix Start
            if(this.iseditother || this.isedit){
                window.location.href = '/apex/licensingcomerror';
            }//BUG-52118 Fix End
            else {
                this.clearExistingErrorMessage(); //ADO 27683
                var orgRoleID = event.target.dataset.id;
                var selectedOrgRole = this.orgrolelist.find(orgObj => orgObj.Id === orgRoleID);
                this.dispatchEvent(new CustomEvent("openlicencecontactpopup", {
                    detail: {
                        selectedContact: selectedOrgRole,
                        contactType: selectedOrgRole.Types__c // Passing the Contact's type
                    }
                }));
            }
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
    /*       
        * @author      : Coforge
        * @date        : 07/03/2024
        * @description : ADO-27683: Edit button Functionality for IR Regulatory Contacts and General IR Contacts Table
        */
    closeModalAction() {
        this.isDeletePopUpOpen = false;
        document.body.style.overflow = '';
    }
    /*       
    * @author      : Coforge
    * @date        : 08/03/2024
    * @description : ADO-27683: Edit button Functionality for IR Regulatory Contacts and General IR Contacts Table
    */
    handleconfirmlogic() {
        try {
            this.showSpinner = true; // To display the spinner
            updateOrgRoleAsiInactive({ orgroleId: this.deletionid })
                .then(result => {
                    // Handle success
                    if (result) {
                         this.showSpinner = false; 
                        window.location.href = '/IRComDashboard';
                    }
                })
                .catch(error => {
                    window.location.href = '/apex/licensingcomerror';
                });
            this.isDeletePopUpOpen = false;
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
    /*       
   * @author      : Coforge
   * @date        : 08/03/2024
   * @description : ADO-27683: Edit button Functionality for IR Regulatory Contacts and General IR Contacts Table
   */
    clearExistingErrorMessage() {
        try{
            this.dispatchEvent(new CustomEvent("displayerrormessage", {
                detail: {
                    message: ""
                }
            }));
        }catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : May 02, 2024
    * @description : ADO: 26706/26707 Method called on onupdate event of paginationcmp to set the list of IR org role for current page
    * @return      : None
    * @param       : event
    */
    currentPageOrgRoleList(event) {
        this.finalOrgrolelist = [...event.detail.records];  //Initalizing list of org role to display on table.
    }
}