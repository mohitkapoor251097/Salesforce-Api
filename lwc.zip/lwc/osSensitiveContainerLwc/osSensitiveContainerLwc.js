import { LightningElement, api, wire } from 'lwc';
import getRecordSensitiveInfo from '@salesforce/apex/OSSensitiveContainerLwcController.getRecordSensitiveInfo';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import COMMON_ERROR from '@salesforce/label/c.CommonError';
import { NavigationMixin } from 'lightning/navigation';
import {GSC_CONSTANTS} from './osSensitiveContainerLwcConstants';

//We have removed the custom label and passing the message from lightning page
//import osSensitiveContainerLwc_ModalMessage from '@salesforce/label/c.osSensitiveContainerLwc_ModalMessage';

export default class OsSensitiveContainerLwc extends NavigationMixin(LightningElement) {

    recordDistressingContent = [];
    @api metadataRecordApiName;
    @api fieldToDisplay;
    @api objectApiName;
    @api modalMessage;
    //displayCustomMessage = osSensitiveContainerLwc_ModalMessage;
    @api recordId;
    @api title;
    
    modalContainer = false;
    isDisplayCmp = false;
    contentFlagValue = '';

    distressingTemplate ;
    gscTemplate ;
    gscValueacknowledge;
    gscAcknowledgeInfo = GSC_CONSTANTS.GSC_ACKNOWLEDGE_INFO_TEXT;
    gscAcknowledgeConfirmation = GSC_CONSTANTS.GSC_ACKNOWLEDGE_CONFIRMATION_TEXT;
    /*
     * @author      : Coforge
     * @description : Call the method in connectedCallback lifecycle load
     * @params      : event
     * @return      : NA
     */

    connectedCallback() {
        this.getRecordSensitiveData();
    }

    /*
     * @author      : Coforge
     * @description : fetch the record to display sensitive info
     * @params None
     * @return List of records
     */
    getRecordSensitiveData() {
         getRecordSensitiveInfo({
            metadataRecordName: this.metadataRecordApiName,
            recordId : this.recordId
        }).then((result) => {
            try{
                if(result) {
                    this.recordDistressingContent = this.sanitizeRecords(result);
                    
                    //Check the data and open the modal accordingly
                    if( this.recordDistressingContent && this.recordDistressingContent.length > 0){
                        this.modalContainer = true;
                        this.isDisplayCmp = true;
                        this.distressingTemplate = true;
                    }else{
                        this.distressingTemplate = false;
                    }
                    // Display GSC sensitive message when GSC selected as Official Sensitive and Aggregated
                    if (
                        result[0][GSC_CONSTANTS.GSC_FIELD_API_NAME] === GSC_CONSTANTS.GSC_OFFICIAL_SENSITIVE &&
                        result[0][GSC_CONSTANTS.GSC_AGGREGATED_FIELD_API_NAME] === GSC_CONSTANTS.GSC_YES
                    ) {
                        this.gscValueacknowledge = GSC_CONSTANTS.GSC_ACKNOWLEDGE_FLAGED_TEXT + ' ' + GSC_CONSTANTS.GSC_AGGREGATED_OFFICIAL_SENSITIVE;
                        this.gscTemplate = true;
                        this.modalContainer = true;
                        this.isDisplayCmp = true;
                    } 
                    // Display GSC sensitive message when GSC selected as Official/ Official Sensitive 
                    else if (
                        result[0][GSC_CONSTANTS.GSC_FIELD_API_NAME] === GSC_CONSTANTS.GSC_OFFICIAL ||
                        result[0][GSC_CONSTANTS.GSC_FIELD_API_NAME] === GSC_CONSTANTS.GSC_OFFICIAL_SENSITIVE
                    ) {
                        this.gscValueacknowledge = GSC_CONSTANTS.GSC_ACKNOWLEDGE_FLAGED_TEXT + ' ' + result[0][GSC_CONSTANTS.GSC_FIELD_API_NAME];
                        this.gscTemplate = true;
                        this.modalContainer = true;
                        this.isDisplayCmp = true;
                    } 
                    else {
                        this.gscTemplate = false;
                    }
                    
                }
            } catch(e){
                console.log('error==>',JSON.stringify(e));
                this.showNoRecordsToast(COMMON_ERROR,'error','dismissable');
            }
        })
        .catch((error) => {
            console.log('error==>',JSON.stringify(error));
            this.showNoRecordsToast(COMMON_ERROR,'error','dismissable');
        });
    }

    /*
     * @author      : Coforge
     * @description : map the data with the fields described in the custom metadata types record
     * @params      : event
     * @return      : NA
     */
    sanitizeRecords(result) {
        const data = [];
        for(let row of result) {
            let rowIndexes = Object.keys(row);

            rowIndexes.forEach((rowIndex) => {
                if(rowIndex == this.fieldToDisplay){
                    let distressingContent = row[rowIndex];
                    this.contentFlagValue = distressingContent;

                    //Get the multiselect picklist value and 
                    if(distressingContent && distressingContent != undefined){
                        for(let content of distressingContent.split(';')){
                            if(content){
                                data.push(content);
                            }
                        }
                    }  
                }
            }); 
        }
        return data;
    }

    /*
     * @author      : Coforge
     * @description : Close the modal and redirect to list view
     * @params      : event
     * @return      : NA
    */
    closeMoalOpenListView(){
        this.handleListViewNavigation();
        this.modalContainer=false;
    }

    /*
     * @author      : Coforge
     * @description : Close the modal 
     * @params      : event
     * @return      : NA
    */
    closeModalAction(){
        this.modalContainer=false;
    }

    /*
     * @author      : Coforge
     * @description : Redirect to Record object list view 
     * @params      : event
     * @return      : NA
    */
    handleListViewNavigation() {
        // Navigate to the Accounts object's Recent list view.
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: this.objectApiName,
                actionName: 'list'
            },
            state: {
                filterName: 'Recent' 
            }
        });
    }

    /*
     * @author      : Coforge
     * @date        : 03/01/2024
     * @description : To show the toast message for success and error 
     * @params      : title
     * @params      : variant
     * @params      : mode
     * @return      : NA
     */
    showNoRecordsToast(title,variant,mode) {
        const event = new ShowToastEvent({
            title: title,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(event);
    }
}