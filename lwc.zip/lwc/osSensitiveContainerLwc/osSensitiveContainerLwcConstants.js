export const GSC_CONSTANTS = {
    NO_GSC_VALUE: 'No GSC marking',
    GSC_OFFICIAL_SENSITIVE: 'Official Sensitive',
    GSC_AGGREGATED_OFFICIAL_SENSITIVE: 'Aggregated Official Sensitive',
    GSC_OFFICIAL: 'Official',
    GSC_YES: 'Yes',
    GSC_ACKNOWLEDGE_FLAGED_TEXT: 'This Record is flagged as',
    GSC_ACKNOWLEDGE_INFO_TEXT: 'You require a legitimate business purpose to view this document.',
    GSC_ACKNOWLEDGE_CONFIRMATION_TEXT: 'Selecting ‘Yes’ records your acknowledgment and agreement.',
    GSC_FIELD_API_NAME: 'Government_Security_Classification__c',
    GSC_AGGREGATED_FIELD_API_NAME: 'Aggregated_Sensitive_Material__c'
};