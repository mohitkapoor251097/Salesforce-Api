import { LightningElement,wire } from 'lwc';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import Account from "@salesforce/schema/Account";
import fetchCaseRecord from '@salesforce/apex/OSAccountSearchLookupIRMSCases.fetchCaseRecord';
import {ACCOUNTLOOKUP_CONSTANTS} from './oSAccountLookupIRMSCasesConstants';

const columns = [
    { label: 'Case Number', fieldName: 'CaseLink', type: 'url',
       typeAttributes: { label: {fieldName: 'CaseNumber'},tooltip:"Case Number", target: '_self',menuAlignment : 'left'}},
    {label: 'Date/Time Opened', fieldName: 'Date_Time_Opened__c', type: 'date',
    typeAttributes: { day: 'numeric', month: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }},
    { label: 'Internal Ofcom Project Title', fieldName: 'Internal_Ofcom_Project_Title__c', type: 'text' },
    { label: 'Legal Powers', fieldName: 'Legal_Powers__c', type: 'picklist' },
    { label: 'Request Type', fieldName: 'Request_Type__c', type: 'picklist' },
    { label: 'Status', fieldName: 'Status', type: 'picklist' },
    { label: 'Date/Time Closed', fieldName: 'ClosedDate', type: 'date',
    typeAttributes: { day: 'numeric', month: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }},    
];
export default class OSAccountLookupIRMSCases extends LightningElement {
    accountId;
    columns = columns;
    selectedRecord = [];
    selectedCaseRecord = [];
    hasRecords = false; 
    showRecords = false;
    businessRecordTypeId;
    noRecordsPlaceHolder = ACCOUNTLOOKUP_CONSTANTS.NO_RECORDS;
    pageNumber = 1;
    totalRecordCount;
    totalPageCount;
    pageSize = 5;
    isFirstPage = true;
    isLastPage = false;

   //To get Business Account record type Id.  
@wire(getObjectInfo, { objectApiName: Account })
    getBusinessRecordTypeId({error,data}){
       if(data){
        let objArray  = data.recordTypeInfos;
            this.businessRecordTypeId=Object.values(objArray)
            .find(rt => rt.name === ACCOUNTLOOKUP_CONSTANTS.BUSINESS_ACCOUNT_RECORD_TYPE_NAME)?.recordTypeId;
       }else if(error){
        this.error = error; 
        }
     };

    //Get all IRMS cases based on accountId selected by user.
    handleAccountSelection(event){
        this.accountId = event.detail.recordId;
        this.hasRecords = false; 
        this.showRecords = false;
        this.selectedRecord = [];

        if(this.accountId !== '' && this.accountId !== null){  
            this.showRecords = true;
            fetchCaseRecord({ recordId: this.accountId }) 
            .then((result) => { 
                if(result !== null && result.length > 0 && result !== ''){ 
                    this.hasRecords = true;
                    this.totalRecordCount = result.length;
                    this.totalPageCount = Math.ceil(this.totalRecordCount/this.pageSize); 
                    this.pageNumber = 1;
                    let CaseLink;
                    this.selectedCaseRecord = result.map(row => {
                       CaseLink = `/${row.Id}`;
                       return {...row , CaseLink}
                   })
                    this.error = null; 
                    this.handlePageChange()
                }  
            }) 
            .catch((error) => { 
                this.error = error; 
                this.selectedRecord = {}; 
            }); 
          }
    }
//To get business account record type as Account Lookup.
 get filter(){
    return {
        criteria: [
            {
                fieldPath: 'RecordTypeId',
                operator: 'eq',
                value: this.businessRecordTypeId? this.businessRecordTypeId : null
            }
        ]
    };
}
  //To display Business Owner as additional field in Account lookup along with Account Name.
    displayInfo = {
        additionalFields: [ACCOUNTLOOKUP_CONSTANTS.BUSINESS_OWNER_FIELD_API_NAME]
    }

    //To hold the last pagenumber value
        get rowNumberOffset() {
            return (this.pageNumber-1)*this.pageSize;
        }

        //When user click on Previous button
    handlePrevPage(){
        if(this.pageNumber > 1){
            this.pageNumber = this.pageNumber - 1;
        }
            this.handlePageChange()
    }

     //When user click on Next button
    handleNextPage(){
       if(this.pageNumber < this.totalPageCount){
            this.pageNumber = this.pageNumber + 1;
       }
       this.handlePageChange()
    }

    //To update Page buttons on click of Next/Prev button
    updatePageButtons(){
        if(this.pageNumber === 1){
            this.isFirstPage = true;
        }else{
            this.isFirstPage = false;
        }
        if(this.pageNumber >= this.totalPageCount){
            this.isLastPage = true;
        }else{
            this.isLastPage = false;
        }   
    }

    //Get all the records on click of Next/Prev button
    handlePageChange(){
      this.selectedRecord = []; 
       for(let rec = this.rowNumberOffset; rec < this.rowNumberOffset + this.pageSize; rec++){
        if(rec < this.totalRecordCount){
            let caseRec = this.selectedCaseRecord[rec];
            this.selectedRecord.push(caseRec);
        }
       }
        this.updatePageButtons();
    }
}