// constants file call in main js file.
export const ACCOUNTLOOKUP_CONSTANTS = {
    NO_RECORDS : 'No records to display',
    BUSINESS_ACCOUNT_RECORD_TYPE_NAME : 'Business Account',
    BUSINESS_OWNER_FIELD_API_NAME: 'OS_Business_Owner__c'
};