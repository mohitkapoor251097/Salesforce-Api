import { LightningElement, api} from 'lwc';
import getFieldsFromMetadata from '@salesforce/apex/OSRelatedlistwithoutsharingController.getFieldsFromMetadata';
import getRelatedList from '@salesforce/apex/OSRelatedlistwithoutsharingController.getRelatedList';
import { NavigationMixin } from 'lightning/navigation';

const View_Column = {
    label: 'View',
    type: 'button-icon',
    initialWidth: 50,
    typeAttributes:
    {   
        iconName: 'action:preview',
        title: 'Open in New Tab',
        name: 'View',
        alternativeText: 'View'
    }
};


export default class OsRelatedlistwithoutsharing extends NavigationMixin(LightningElement) {
    
    @api searchFilterCriteria;
    @api metadataRecordApiName;
    @api stakeholdertype;
    @api filterCriteria;
    @api readOnly = false;
    @api recordId;   
   
    columns = [];
    records = [];
    
    whareClause = '';
    
    noRecordsPlaceHolder = 'No records to display';
    
    objectName;
   
    
    /*
     * @author      : Coforge
     * @description : first getting the data from custom metedata and based on that doing the 
     * soql on particular object to fetch the data and map that with the datatable.
     * @params      : event
     * @return      : NA
     */
    connectedCallback() {

        if(this.filterCriteria) {
            this.whareClause = this.filterCriteria.replace('@recordId@', this.recordId);
        }
        
        this.setupColumns();
    }

    get showRecords() {
        return this.records.length > 0;
    }

    /*
     * @author      : Coforge
     * @description : fetch the record from the custom metadata type after 
     * that doing the soql for the particular object and bind the data with the datatable.
     * @params      : event
     * @return      : NA
     */
    setupColumns() {
      
        getFieldsFromMetadata({

            metadataRecordName: this.metadataRecordApiName

        }).then((result) => {
            try {
                if(result) {
                    this.columns = this.sanitizeMetadata(result);
                    
                    if(this.columns){
                        this.fetchRecords();
                    }   
                 
                }
            } catch(error){
                console.log('error==>'+JSON.stringify(error));
            }

        })
        .catch((error) => {
            console.log('error==>'+JSON.stringify(error));
        });
    }

    /*
     * @author      : Coforge
     * @description : split the custom metadata records fields vlaues 
     * and create the columns to be bind with the datatable. 
     * @params      : event
     * @return      : NA
     */
    sanitizeMetadata(result) {
        const temp = [];

        //Adding the preview button icon
        temp.push(View_Column);

        const fieldsMapping = result.FieldsMapping__c.split(",");
        var index = 0;
        for(const obj of fieldsMapping) {
            const val = obj.split("=");
            if (index == 0){ 
             
                temp.push({fieldName: 'displayName',title:val[1].trim(), label: val[1].trim(), type: 'text'});

            }else{
                if(val[0].trim() =='MeetingDateColor__c'){ 
                    temp.push({fieldName: val[0].trim(), label: val[1].trim(), type: 'image'});
                }else{
                    temp.push({fieldName: val[0].trim(),title:val[1].trim(), label: val[1].trim(), type: 'text'});
                }
            }
            index =index+1;
        }
        
        return temp;
    }

    /*
     * @author      : Coforge
     * @description : fetch the record for the particular object with filter criteria and bind the data with the datatable.
     * @params      : event
     * @return      : NA
     */

    fetchRecords() {
        
        getRelatedList({
            metadataRecordName: this.metadataRecordApiName,
            filterCriteria: this.whareClause
        }).then((result) => {
            try{
                if(result) {
                   
                    this.records = this.sanitizeRecords(result);
                }
            } catch(error){
               console.log('error===>',JSON.stringify(error));
            }
        })
        .catch((error) => {
            console.log('error===>',JSON.stringify(error));
        });
    }

    /*
     * @author      : Coforge
     * @description : map the data with the fields described in the custom metadata types record
     * @params      : event
     * @return      : NA
     */
    sanitizeRecords(result) {
        const data = [];
        for(let row of result) {
            const finalRow = {}
            let rowIndexes = Object.keys(row); 
            rowIndexes.forEach((rowIndex) => { 
                
                let relatedFieldValue
                if(rowIndex == "MeetingDateColor__c"){
                    // parse image url from image tag
                    const imageFormula = row[rowIndex];
                    relatedFieldValue = imageFormula.substr(10);
                    relatedFieldValue = relatedFieldValue.slice(0, relatedFieldValue.indexOf("alt")-2);
                }else{
                    relatedFieldValue = row[rowIndex];
                }
                
                
                if(relatedFieldValue.constructor === Object) {
                    this.transformObjectToRow(relatedFieldValue, finalRow, rowIndex)        
                }
                else {
                    finalRow[rowIndex] = relatedFieldValue;
                }
            });

            data.push(finalRow);

            if(data){    
                if (this.stakeholdertype == 'Stakeholder Organization'  ){
                    data.forEach(item => item['displayName'] = item['Account__r.Name']);

                }else if (this.stakeholdertype == 'Stakeholder Lead' || this.stakeholdertype == 'Stakeholder Participant' || this.stakeholdertype == 'Ofcom Participant' ){
                    data.forEach((item) => {
                        if(item['Account_PA__c'] && item['Account_PA__c']){
                            item['displayName'] = item['Account_PA__r.Name'];
                        }else{
                            item['displayName'] = item['Contact__r.Name'];
                        }
                        });
                }
                    
            }
        } 
        return data;
    }

    /*
     * @author      : Coforge
     * @description : tranform the object into the rows
     * @params      : event
     * @return      : NA
     */
    transformObjectToRow = (fieldValue, finalRow, fieldName) => 
    {        
        let rowIndexes = Object.keys(fieldValue);
        rowIndexes.forEach((key) => 
        {
            let finalKey = fieldName + '.'+ key;
            finalRow[finalKey] = fieldValue[key];
        })
    }
    

    /*
     * @author      : Coforge
     * @description : Handle on row Action
     * @params      : event
     * @return      : NA
     */
    handleRowAction( event ) {
        
        const row = event.detail.row;

        let tempRecordId;

        if(row && row['StakeholderType__c'] == 'Stakeholder Lead' || row['StakeholderType__c'] == 'Stakeholder Participant'){
            if(row['Account_PA__c']){
                tempRecordId = row['Account_PA__c'];
            }else{
                tempRecordId = row['Contact__c'];
            }
        }else if(row && row['StakeholderType__c'] == 'Ofcom Participant' && row['Contact__c']){
            tempRecordId = row['Contact__c'];
        }else if(row && row['StakeholderType__c'] == 'Stakeholder Organization' && row['Account__c']){
            tempRecordId = row['Account__c'];
        }else{
            tempRecordId = row['Id']?row['Id']:'';
        }
        

        this[NavigationMixin.GenerateUrl]({
            type: 'standard__recordPage',
            attributes: {
                recordId: tempRecordId,
                actionName: 'view',
            },
        }).then((url) => {
            window.open(url, '_blank');
        });
    }
     
}