/*********************************************************************
# File......................: ChannelProgrammeDetailsScreen
# Version...................: 1.0
# Created by................: Coforge
# Last Modified Date........: Feb 19, 2025
# Description...............: This LWC will be used to channel/station search dropdown.
# Change Log................: V1.00 : Initially version : ADO44070: BCF1.06 Search for channel/station name [EPG data entry]
                              V1.01 : ADO44094: BCF1.10 Select the broadcast date from the calendar field [EPG data entry]
                              V1.02 : ADO44095: BCF1.12 Select Time of Broadcast and programme [EPG data entry]
                              V1.03 : ADO44096: BCF1.14 No programme found [EPG data entry]
                              V1.04 : ADO44099: BCF1.20 Confirm EPG programme data entry and proceed [EPG data entry]
                              V1.05 : ADO44098: BCF1.18 Layout of EPG complaints data entry page [EPG data entry]
                              V1.06 : ADO44100: BCF1.22 Reset EPG data section to start EPG data entry again [EPG data entry]
                              V1.07 : ADO44102: BCF1.26 Show progress indicator above the complaints form [EPG data entry]
                              V1.08 : ADO44103: BCF2.02 Continue data entry for ‘Other’ channel [manual data entry]
                              V1.09 : ADO44104: BCF2.04 Enter channel/programme data manually [manual data entry]
                              V1.10 : ADO44105: BCF2.06 Redirect to manual data entry after static channel selection [manual data entry]
                              V1.11 : ADO51696: BCF2.16 Reset data on manual data entry form [manual data entry]
                              v1.12 : ADO44105: BCF2.06 Redirect to manual data entry after static channel selection [manual data entry]
                              v1.13 : ADO44106: BCF2.08 Redirect to manual data entry if date falls outside EPG range [manual data entry]
                              v1.14 : ADO44107: BCF2.10 Redirect to manual data entry when API is down [manual data entry]
                              v1.15 : ADO44108: BCF2.12 Pre-populate manual form with previously entered EPG data [manual data entry]
                              v1.16 : ADO47581: BCF4.01 Welsh translation of complaints form
                              v1.17 : ADO44113: BCF3.08 Reset all data entry from the submission webform [complete and submit]
                              v1.18 : ADO44117: BCF3.16 Record how programme details were logged in complaint [complete and submit]
                              v1.19 : ADO44118: BCF3.18 Automatically associate target (licensee) in SF case for major non-BBC channels [complete and submit]
**********************************************************************/
import { LightningElement, api, track } from 'lwc'; // ADO44095 change
import getChannelRecord from "@salesforce/apex/WebformAuraUtility.fetchChannelRecord";
import fetchCustomLabel from '@salesforce/apex/WebformAuraUtility.fetchCustomLabel';
import getCustomSetting from '@salesforce/apex/WebformAuraUtility.getCustomSetting';
import encryptString from '@salesforce/apex/WebformAuraUtility.encryptString'; // ADO44102 changes
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import resourceWebformsLWC from '@salesforce/resourceUrl/WebformsLWC';
import fetchProgrammeList from "@salesforce/apex/WebformAuraUtility.fetchProgrammeList"; // ADO44095 change

export default class ChannelProgrammeDetailsScreen extends LightningElement {
    @api lwcAlias;
    @api lang;
    @api programInformation; // ADO44102 change
    isListening = false;
    isShowdateOfBroadcast = false;
    pickListOrdered;
    searchResults;
    selectedSearchResult;
    showSpinner = true;
    listOfCustomLabels = ['WebFormsChannelStationField', 'WebFormsDateOfBroadcastFieldv2', 'WebFormsSelectAnOption', 'WebformResetConfirmation', 'WebformComplainSummaryHeading', 'WebFormsEnterChannelStationField','ChannelPlaceholderWebForm','ProceedButtonWebform','ProgrammeWebform','ProgrammeNoMatchesFoundWebform','WebFormsResetButton','WebFormsTimeOfBroadcastField','WebFormVSPOtherValue','WebFormsCancelButton','DateWebform','TimeWebform','WebFormEPGProgrammeLabel1','WebFormEPGProgrammeLabel2','WebFormEPGProgrammeLabel3','WebFormsDateFieldValidation', 'WebformDatePickerInstruction'];
    customLabels = new Map();
    dropdownOptions;
    customSetting;
    isShowDropdown = false;
    isManualFormOpen = false;
    searchInputCharacterLimit;
    selectedDropdownValue;
    manualChannelName;
    selectedDropdownId; // ADO44094 change
    selectedDate; // ADO44094 change
    disableChannelField = false;
    disableDateOfBroadCastField = false;
    isShowProgrammeDropdown = false;  // ADO44095 change 
    isShowManualChannelField = false; // ADO44096: This is use to hide manual channel entry field when user select 'No matches found. Enter manually instead.'  value from programme dropdown.
    isResetModalOpen = false;  // Rest Button confirmation popup model
    isDisableProceedButton = true;
    isShowManualProgrammeInput = false;
    isShowManualDateInput = false;
    isShowManualTimeInput = false;
    selectedTime;
    disableFutureDates = false;
    currentDate;
    OTHER_VALUE = ''; // 47581
    currentLI = 0;
    isShowValidationMessage = false;
    

    /* ADO44095 changes start Variables for programme picklist options */
    @track programmePicklistOptions = [];
    showProgrammePickList = false;
    @track selectedProgrammeValue = '';
    /* ADO44095 changes end */    
    daysRange; //ADO44106 change
    dateRangeExceeded = false; //ADO44106 change
    selectedStartTime; //ADO44108 change
    channelTarget; // ADO44118 change
    isManualEntry = false; // ADO44117 change
    isiOS;
    
    constructor() {
        super();
    }
    
    /*
    * @author      : Coforge
    * @date        : Feb 05, 2025
    * @description : This method will be used to fetch static resources, custom settings, custom labels and channel records.
    */
   	connectedCallback() {
        this.showSpinner = true;
        this.isiOS = this.detectOS();
		loadStyle(this, resourceWebformsLWC + '/WebformsLWC/css/webforms.css');

        if(this.programInformation != undefined && this.programInformation != '' && this.programInformation != null){
			this.displaySummaryBox = true;
       	}
        const today = new Date();
        const yyyy = today.getFullYear();
        let mm = today.getMonth() + 1; // Months start at 0!
        let dd = today.getDate();
        if (dd < 10) dd = '0' + dd;
        if (mm < 10) mm = '0' + mm;
        this.currentDate = yyyy + '-' + mm + '-' + dd;

        this.getCustomLabel();
        this.fetchCustomSeting();
        this.getChannels();
        this.isShowDropdown = false; // ADO44094 change
        // Set up a counter to keep track of which <li> is selected
        this.addEventListener('keydown', function(event){
            var listItems =  this.template.querySelectorAll(".listChannel");
            switch(event.keyCode){
            case 38: // Up arrow    
            // Remove the highlighting from the previous element
            if(this.currentLI > 0){
                this.currentLI = this.currentLI -1;
            }
            if(listItems[this.currentLI] != null && listItems[this.currentLI] != '' && listItems[this.currentLI] != undefined){
                if(Object.values(listItems[this.currentLI].classList).includes("highlight")){
                    listItems[this.currentLI].classList.remove("highlight");
                    listItems[this.currentLI].tabIndex  = -1;
                }
            }
            temp = this.currentLI > 0 ? this.currentLI -1 : 0;     // Decrease the counter 
            if(listItems[temp] != null && listItems[temp] != '' && listItems[temp] != undefined){
                listItems[temp].classList.add("highlight"); // Highlight the new element
                listItems[temp].tabIndex  = 0;
                //---- JAWS ----//
                listItems[temp].focus({preventScroll: true});
                listItems[temp].scrollIntoView({block: 'center'});
            }
            break;
            case 40: // Down arrow
            // Remove the highlighting from the previous element
            if(this.currentLI > 0){
                var temp = this.currentLI -1 ;
                if(listItems[temp] != null && listItems[temp] != '' && listItems[temp] != undefined){
                    if(Object.values(listItems[temp].classList).includes("highlight")){
                        listItems[temp].classList.remove("highlight");
                        listItems[temp].tabIndex  = -1;
                    }
                }
                this.currentLI = this.currentLI < listItems.length-1 ? this.currentLI : listItems.length-1; // Increase counter 
                if(listItems[temp] != null && listItems[temp] != '' && listItems[temp] != undefined){
                    listItems[this.currentLI].classList.add("highlight");
                    listItems[this.currentLI].tabIndex  = 0;
                    
                    //---- JAWS ----//
                    listItems[this.currentLI].focus({preventScroll: true});
                    listItems[this.currentLI].scrollIntoView({block: 'center'});
                }
                this.currentLI = this.currentLI + 1;       // Highlight the new element
                break;
            }
            else{
                if(listItems[this.currentLI] != null && listItems[this.currentLI] != '' && listItems[this.currentLI] != undefined){
                    listItems[this.currentLI].classList.add("highlight");
                    listItems[this.currentLI].tabIndex  = 0;
                    //---- JAWS ----//
                    listItems[this.currentLI].focus({preventScroll: true});
                    listItems[this.currentLI].scrollIntoView({block: 'center'});
                }
                this.currentLI = this.currentLI + 1;
                break;
            }
            case 13:
                event.preventDefault();
                var listItem =  this.template.querySelectorAll(".highlight");
                if(listItem[0] !=null && listItem[0] !='' && listItem[0] != undefined){
                    if(listItem[0].textContent !=null && listItem[0].textContent !='' && listItem[0].textContent != undefined){
                     this.selectedDropdownValue = listItem[0].textContent;
                    }

                    this.selectSearchResultByEnter(listItem[0].dataset.value);
                }
                this.dropdownOptions = [];
                var listItems =  this.template.querySelectorAll(".listChannel");
                if(listItems){
                    if(listItems[this.currentLI] != null && listItems[this.currentLI] != '' && listItems[this.currentLI] != undefined){
                        if(Object.values(listItems[this.currentLI].classList).includes("highlight")){
                            listItems[this.currentLI].classList.remove("highlight");
                            listItems[this.currentLI].tabIndex  = -1;
                        }
                    }
                }
                this.currentLI = 0;
            }
            var listItem =  this.template.querySelectorAll(".highlight");
            if(listItem[0] != null && listItem[0] != '' && listItem[0] != undefined){
                listItem[0].scrollIntoViewIfNeeded(false);
            }
        });
        window.addEventListener("click", (event) => {
            this.hideDropdown(event);
        });
    }

    /*
    * @author      : Coforge
    * @date        : Apr 08, 2025
    * @description : This method is used to check dropdown items.
    */
    get hasDropdownOptions(){
        let hasDropdownItem = this.dropdownOptions && this.dropdownOptions.length > 0;
        if(!this.isShowDropdown){
            hasDropdownItem = this.isShowDropdown;
        }
        return hasDropdownItem;
    }

    get dateAriaDescribedAttribute(){
        return this.isShowValidationMessage ? 'date-error-message' : undefined;
    }

    get channelAriaControlsAttribute(){
        return this.hasDropdownOptions ? 'ullist' : '';
    }

    /*
    * @author      : Coforge
    * @date        : Apr 04, 2025
    * @description : This method is used to remove double focus on input date.
    */
    handleDateKeyDown(event){
        if(event.key === 'Tab' && !event.shiftKey){
            event.preventDefault();
            const focusableElements = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
            const focusable = Array.from(this.template.querySelectorAll(focusableElements)).filter(el => !el.disabled && !el.readonly && getComputedStyle(el).display !== 'none' && getComputedStyle(el).visibility !== 'hidden');            
            const index = focusable.indexOf(event.target);
            
            if(event.shiftKey){
                if(index > 0){
                    focusable[index - 1].focus();
                }
            }else{
                if(index < focusable.length - 1){               
                    focusable[index + 1].focus();
                }
            }
        }
    }

    selectSearchResultByEnter(selectedVal) {
        const selectedValue = selectedVal;
        this.selectSearchResultConsolidate(selectedValue);
    }

    /*
    * @author      : Coforge
    * @date        : Feb 19, 2025
    * @description : This method is used to display manual form.
    */
    openManualEntryPage(){
        this.isManualFormOpen = true;
        this.isShowManualChannelField = false;
        this.isShowdateOfBroadcast =true;
        this.isShowManualProgrammeInput = true;
        this.isShowManualTimeInput = true;
        this.isShowProgrammeDropdown = false;
        this.validateMandatoryField();
    }

    /*
    * @author      : Coforge
    * @date        : Feb 05, 2025
    * @description : This method will be used to get custom label translation by passing two arguments, i.e. a list of custom labels and language code into which the custom labels will be translated. 
    */
    getCustomLabel() {
        fetchCustomLabel({ listOfCustomLabel: this.listOfCustomLabels, language: this.lang })
		.then(result => {
			this.customLabels = JSON.parse(result);
            this.OTHER_VALUE = this.customLabels.WebFormVSPOtherValue;
    	})
		.catch(error => {
			console.error('Error while fetching custom label: ' + JSON.stringify(error));
		})
    }

    /*
    * @author      : Coforge
    * @date        : Feb 05, 2025
    * @description : This method fetches the custom setting and uses the field 'Minimum_Character_Search__c' to determine the minimum number of characters required for performing a channel search on the webform. The default minimum is set to 2 characters.
    */
    fetchCustomSeting() {
        getCustomSetting()
		.then(result => {
			this.customSetting = JSON.parse(result);
			this.searchInputCharacterLimit = (this.customSetting[0].Minimum_Character_Search__c != undefined && this.customSetting[0].Minimum_Character_Search__c != '' && this.customSetting[0].Minimum_Character_Search__c != null) ? this.customSetting[0].Minimum_Character_Search__c : 2;
			this.daysRange = this.customSetting[0].Days_Range_for_EPG_Data__c; //ADO44106 change
    })
		.catch(error => {
			console.error('Error while fetching custom setting: ' + JSON.stringify(error));
		})
    }

    /*
    * @author      : Coforge
    * @date        : Feb 05, 2025
    * @description : This method fetches channel records whenever this component is loaded.
    */
    getChannels() {
	getChannelRecord()
		.then(result => {
            let mapOfhannelMaster = JSON.parse(result);
            this.searchResults = Object.entries(mapOfhannelMaster).map(([value, key]) => {
				return { label: key.Display_Name__c, value: key.Id, isStatic: key.Is_Static__c, EPG_ChannelId:key.EPG_Channel_ID__c, targetId: key.Target__c, name:key.Name, className: 'slds-listbox__item' }; // ADO44094, ADO44118 change
			}).concat([{ label: this.OTHER_VALUE, value: this.OTHER_VALUE, className: 'slds-listbox__item' }]);
            this.pickListOrdered = this.searchResults;
		})
		.catch(error => {
			this.searchResults = [];
		});
    }
   
    /*
    * @author      : Coforge
    * @date        : Feb 05, 2025
    * @description : This method sets a boolean value whenever the component is rendered and shows/hides the channel search dropdown.
    */
    renderedCallback() {
        if (this.isListening) return;
        window.addEventListener("click", (event) => {
        });
        this.isListening = true;
        this.showSpinner = false;
    }

    /*
    * @author      : Coforge
    * @date        : Feb 05, 2025
    * @description : This method sets a boolean value to show/hides the channel search dropdown and date of the broadcast label.
    */
    hideDropdown(event) {
        if(event.target && event.target.nodeName == 'BODY'){
            event.target.nodeName
            this.isShowDropdown = false;
        }
        var listItems = this.template.querySelectorAll(".highlight");
        if(listItems[0] != null && listItems[0] != '' && listItems[0] != undefined){
            if(Object.values(listItems[0].classList).includes("highlight")){
                listItems[0].classList.remove("highlight");
                listItems[0].tabIndex  = -1;
            }
        }
        this.currentLI = 0;
    }

    /*
    * @author      : Coforge
    * @date        : Feb 05, 2025
    * @description : This method is used to trim the beginning and last space from the channel search input value and check its length to perform the search operation.
    */
    isValidInput(input) {
        let result = input.replace(/^\s+|\s+$/g, '');
        this.searchKey = result;
        return this.searchKey;
    }

    /*
    * @author      : Coforge
    * @date        : Feb 05, 2025
    * @description : This method will run on channel search input change and take search input based on this, validate whether the value is valid or not and perform the channel search operation by calling filterRecords method.
    */
    searchChannel(event) {
        this.isShowdateOfBroadcast = false;
        this.isShowDropdown = true;
        this.isManualFormOpen = false;
        this.isShowManualDateInput = false;
        this.isShowManualProgrammeInput = false;
        this.isShowManualTimeInput = false;
        this.isShowManualChannelField = false;
        var inputValue = event.detail.value;
        this.showProgrammePickList = false; // ADO44095 change
        if (this.isValidInput(inputValue)) {
            this.filterRecords();
            var listItems =  this.template.querySelectorAll(".listChannel");
            if(listItems){
                if(listItems[this.currentLI] != null && listItems[this.currentLI] != '' && listItems[this.currentLI] != undefined){
                if(Object.values(listItems[this.currentLI].classList).includes("highlight")){
                    listItems[this.currentLI].classList.remove("highlight");
                    listItems[this.currentLI].tabIndex  = -1;
                }
             }
            }
            this.currentLI = 0;
        } else {
            var listItems =  this.template.querySelectorAll(".listChannel");
            if(listItems){
                if(listItems[this.currentLI] != null && listItems[this.currentLI] != '' && listItems[this.currentLI] != undefined){
                    if(Object.values(listItems[this.currentLI].classList).includes("highlight")){
                        listItems[this.currentLI].classList.remove("highlight");
                        listItems[this.currentLI].tabIndex  = -1;
                    }
                }
            }
            this.currentLI = 0;
            this.dropdownOptions = [];
        }
    }

    /*
    * @author      : Coforge
    * @date        : Feb 05, 2025
    * @description : This method filters the fetched records based on the search key and prepares the channel selection dropdown option. 
    */
    filterRecords() {
        if(this.searchKey && this.searchKey.length == 1) {
                        this.dropdownOptions = this.searchResults.filter(record =>
				record.label.toLowerCase().startsWith(this.searchKey.toLowerCase()) || (record.label === this.OTHER_VALUE && record.value === this.OTHER_VALUE)
			).map(record => ({
				label: record.label,
				value: record.value
			}));
        }
        else if(this.searchKey && this.searchKey.length >= this.searchInputCharacterLimit) {
                        this.dropdownOptions = this.searchResults.filter(record =>
				record.label.toLowerCase().includes(this.searchKey.toLowerCase()) || (record.label === this.OTHER_VALUE && record.value === this.OTHER_VALUE)
			).map(record => ({
				label: record.label,
				value: record.value
			}));
        }
    }

    /*
    * @author      : Coforge
    * @date        : Feb 05, 2025
    * @description : This method stores the selected value from the channel selection dropdown list whenever the user selects the channel and, based on the selection, it will show /hide the date of broadcast and the manual channel entry field.Also, call the filter method to filter the dropdown list based on the selected value.
    */
    selectSearchResultConsolidate(selValue){
        this.selectedSearchResult = this.pickListOrdered.find(
            (pickListOption) => pickListOption.value === selValue
        );
        this.selectedDropdownValue = this.selectedSearchResult.label;
        this.channelTarget = this.selectedSearchResult.targetId; // ADO44118 change
        this.searchKey = this.selectedDropdownValue;
        this.filterRecords();
        this.isShowDropdown = false;
        if (this.selectedSearchResult.value === this.OTHER_VALUE) {
            this.isManualFormOpen = true;
            this.isShowManualChannelField = true;
            this.isShowManualDateInput = true;
            this.isShowdateOfBroadcast = false;
            this.isShowManualProgrammeInput = true;
            this.isShowManualTimeInput = true;
            this.isDisableProceedButton = true;
            this.manualChannelName = '';
        } else {
            this.isManualFormOpen = false;
            this.isShowManualChannelField = false;
            this.isShowManualProgrammeInput = false;
            this.isShowManualTimeInput = false;
        }
        // ADO44105 change
        this.disableChannelField = true;
        if(this.selectedSearchResult.isStatic === false){ 
            this.isShowdateOfBroadcast = true;
            this.disableFutureDates = true;
            this.selectedDropdownId = this.selectedSearchResult.EPG_ChannelId  //ADO44094 change
        }else{
            this.isShowdateOfBroadcast = false;
            this.disableFutureDates = false;
            this.isManualFormOpen = true;
            this.isShowManualChannelField = this.selectedSearchResult.value === this.OTHER_VALUE ? true:false;
            this.isShowManualDateInput = true;
            this.isShowManualProgrammeInput = true;
            this.isShowManualTimeInput = true;
            this.isShowProgrammeDropdown = false;
            this.isDisableProceedButton = true;
        }
    }

    /*
    * @author      : Coforge
    * @date        : Feb 05, 2025
    * @description : This method stores the selected value from the channel selection dropdown list whenever the user selects the channel and, based on the selection, it will show /hide the date of broadcast and the manual channel entry field.Also, call the filter method to filter the dropdown list based on the selected value.
    */
    selectSearchResult(event) {
        const selectedValue = event.currentTarget.dataset.value;
        this.selectSearchResultConsolidate(selectedValue);
    }

    /*
    * @author      : Coforge
    * @date        : Feb 05, 2025
    * @description : This method runs on channel search input focus and shows the dropdown option if the searchResults are not null.
    */
    showPickListOptions() {
        this.isShowDropdown = true;
        if (!this.searchResults) {
                this.dropdownOptions = this.pickListOrdered;
        }
    }

    /*
    * @author      : Coforge
    * @date        : Feb 05, 2025
    * @description : This method stores the manual channel value.
    */
    handleManualChannelChange(event) {
        this.manualChannelName = event.target.value;
        this.validateMandatoryField();
    }

    /*
    * @author      : Coforge
    * @date        : Apr 04, 2025
    * @description : This method is used to detect the OS.
    */
    detectOS() {
        let userAgent = navigator.userAgent || navigator.vendor || window.opera;
        userAgent = userAgent.toLowerCase();
        if(userAgent.includes('macintosh')){
            return true; // 'Mac Safari, Mac Chrome, Ipad Safari'
        }
        else if(userAgent.includes('windows')){
            return false; // 'Windows Chrome'
        }
        else if(userAgent.includes('iphone')){
            return true; // 'Iphone Safari, Iphone Chrome';
        }
        else if(userAgent.includes('linux')){
            return false; // 'Android Chrome';
        }
        else if(userAgent.includes('ipad')){
            return true; // 'Ipad Chrome';
        }
        return false;
    }

    /*
    * @author      : Coforge
    * @date        : Feb 13, 2025
    * @description : This method is used to handle date of broadcast changes.
    */
    handleOnDateChange(event){
        this.selectedDate = event.target.value;
        this.isShowDropdown = false;
        if(this.selectedDate != null && this.selectedDate != '' && this.selectedDate != undefined){
            this.disableDateOfBroadCastField = true;
            this.isShowProgrammeDropdown = true;
            if(event.currentTarget.dataset.id !== 'dateOfBroadcastManualField'){
                // show spinner until programme picklist is available
                this.showSpinner = true;
                this.checkDaysRange();
                if(this.dateRangeExceeded == undefined){
                    return;
                }
                else if(this.dateRangeExceeded == false){
                    // calling programme methods
                    this.getProgrammeList();  
                    this.validateField('remove');
                }
                else{
                    this.showSpinner = false;
                    this.isManualFormOpen = true;
                    this.isShowManualProgrammeInput = true;
                    this.isShowManualTimeInput = true;
                    this.validateField('remove');
                }
            }
        }
    }
        
    /*
    * @author      : Coforge
    * @date        : Apr 09, 2025
    * @description : This method is used to add or remove style class.
    */
    validateField(addOrRemove) {
        const broadcastDateDiv = this.template.querySelectorAll(".dateofBroadcastDiv");
        if (broadcastDateDiv && addOrRemove ==='add') {
            this.isShowValidationMessage = true;
            broadcastDateDiv[0].classList.add('hasError');
        }
        else if(broadcastDateDiv && addOrRemove ==='remove'){
            if(broadcastDateDiv[0] !=null && broadcastDateDiv[0] !='' && broadcastDateDiv[0] !=undefined){
                if(broadcastDateDiv[0].classList !=null && broadcastDateDiv[0].classList !='' && broadcastDateDiv[0].classList != undefined && broadcastDateDiv[0].classList.contains('hasError')){
                    this.isShowValidationMessage = false;
                    broadcastDateDiv[0].classList.remove('hasError');
                }
           }
        }
    }

    /*
    * @author      : Coforge
    * @date        : Feb 19, 2025
    * @description : This method is used to handle manual form date of broadcast changes.
    */
    handleOnManualDateChange(event){
        this.selectedDate = event.target.value;
        this.disableDateOfBroadCastField = true;
        this.validateMandatoryField();
    }

    /*
    * @author      : Coforge
    * @date        : Feb 13, 2025
    * @description : This method will make the API call to get the programme data
    */
    getProgrammeList() {
        fetchProgrammeList({ channelId: this.selectedDropdownId, selectedDate: this.selectedDate, epgSettings: JSON.stringify(this.customSetting) })
        .then(data =>{
            // ADO44096 change
            var programmeData = JSON.parse(data);
            let found = programmeData.find(item => item === "ProgrammeAPIisDown"); //ADO44107
            if(found !=undefined && found !=null && found !='' && found){
                this.openManualEntryPage();
            }
            else{
                var tempProgrammeData = this.checkProgrammeStartEndTime(programmeData);  //44095
                this.programmePicklistOptions = tempProgrammeData.length > 0  ? tempProgrammeData.map(item =>({
                    label: item,
                    value: item
                })) : [{label:this.customLabels.ProgrammeNoMatchesFoundWebform ,value:'No Programme Found'}];
                this.showProgrammePickList = true;
            }
            this.showSpinner = false;
        })
        .catch (error => {
            console.error('Error while fetching programme: ' + JSON.stringify(error));
            this.showSpinner = false;
        });
    }

    /*
    * @author      : Coforge
    * @date        : Feb 23, 2025
    * @description : This method is use to check start and end time of the selected programme
    */
    checkProgrammeStartEndTime(programmeData){
        programmeData.forEach((item, index) => {
            let times = item.split(' - ');
            let startTime = times[0].trim();
            let endTime = times[1].split(' ')[0].trim();
            if (startTime === endTime) {
                programmeData[index] = times[1];
            } 
        });
       return programmeData;
    }

    /*
    * @author      : Coforge
    * @date        : Feb 13, 2025
    * @description : This method will run on programme picklist change and fetch selected value.
    */
    handleProgramChange(event){
        this.selectedProgrammeValue = event.target.value;
        this.validateMandatoryField();
        // ADO44096 change
        if(this.selectedProgrammeValue === 'No Programme Found'){
            this.isDisableProceedButton = true;
            this.isManualFormOpen = true;
            this.isShowManualDateInput = true;
            this.isShowManualProgrammeInput = true;
            this.isShowManualTimeInput = true;
            this.isShowDropdown = false;
            this.isShowdateOfBroadcast = false;
            this.isShowProgrammeDropdown = false;
            this.isShowManualChannelField = false;
            this.selectedProgrammeValue = '';
        }
        else{
            let timePattern = /^(\d{2}:\d{2}) - (\d{2}:\d{2})/; // Regix patter that check HH:MM - HH:MM formate of selected programme
            let selectedProgram = this.selectedProgrammeValue;
            this.selectedTime = timePattern.test(selectedProgram) ? [selectedProgram.split(' ').slice(0,3).join(' ')]: [selectedProgram.split(' ')[0]]; 
            this.selectedProgrammeValue = timePattern.test(selectedProgram) ? selectedProgram.replace(this.selectedTime,'').trim(): selectedProgram.replace(this.selectedTime,'').trim();
            let selectedTimeLocal = this.selectedTime; //ADO44108
            this.selectedStartTime = selectedTimeLocal.toString().split(' - ')[0]; //ADO44108
        }
    }

    /*
    * @author      : Coforge
    * @date        : Feb 19, 2025
    * @description : This method is use to check all the mandatory field of the webform
    */
    validateMandatoryField(){
        let channelSelected = ((this.selectedDropdownValue != undefined && this.selectedDropdownValue != null && this.selectedDropdownValue != '' && this.selectedSearchResult.name != undefined && this.selectedSearchResult.name != null && this.selectedSearchResult.name != '') || (this.selectedDropdownValue.trim() == this.OTHER_VALUE && this.manualChannelName.trim())) ? true : false;
        this.isDisableProceedButton = (channelSelected && this.selectedDate && this.selectedProgrammeValue.trim()) ? false : true;
    }

	/*
    * @author      : Coforge
    * @date        : Feb 19, 2025
    * @description : This method is used to send the program summary data to the SitesFormCSLEStandardsComplaints vf component.
    */
    handleProceed(event){

        // Prevention: if User enable the Proceed button from inspect, it will still not work.
        if(this.isDisableProceedButton){
            event.preventDefault();
            return;
        }
        this.showSpinner = true;
        let selectedTime = (this.selectedTime != undefined && this.selectedTime != '' && this.selectedTime != null) ? this.selectedTime : '';
        let channelName = (this.manualChannelName != undefined && this.manualChannelName != '' && this.manualChannelName != null) ? this.manualChannelName : this.selectedDropdownValue;

        let str = this.selectedDate;
        var yyyy = [str.split('-').slice(0,1).join(' ')];
        str = str.replace((yyyy+'-'),'').trim();
        var mm = [str.split('-').slice(0,1).join(' ')];
        str = str.replace((mm+'-'),'').trim();
        var dd = str;
        let selectedDateStr = dd + '/' + mm + '/' + yyyy;

        let programSummary = this.customLabels.ProgrammeWebform +': '+ this.selectedProgrammeValue + '<br/>' +
        this.customLabels.WebFormsChannelStationField+': ' + channelName + '<br/>' +
        this.customLabels.DateWebform+': ' + selectedDateStr + '<br/>' +
        this.customLabels.TimeWebform +': '+ selectedTime;
        
        let params = '{' +
        '"displayMainForm":true,' +
        '"sectionNumber":2,' +
        '"programInfo":"' + programSummary + '",' +
        '"isManualEntry":' + this.isManualEntry + ',' +
        '"channelTarget":"' + this.channelTarget + '"' +
        '}';
        
        encryptString({ str : params })
        .then(result => {
            /* Note: Dispatching an event and re-rendering the element does not display the Google reCAPTCHA, leading to intermittent issues. For this reason, we are passing the encrypted parameter to the Visualforce page. */
            let redirectURL = '/SitesFormCSLEStandardsComplaints?params=' + result;
            redirectURL += (this.lang != undefined && this.lang != '' && this.lang != null) ? ('&lang=' + this.lang) : '';
            window.open(redirectURL, '_self');
        })
        .catch(error => {});
        this.showSpinner = false;
	}

    /*
    * @author      : Coforge
    * @date        : Feb 19, 2025
    * @description : This method is used to open the reset confirmation pop-up model. 
    */
    handleResetButton() {
        this.isResetModalOpen = true;
    }

    /*
    * @author      : Coforge
    * @date        : Feb 19, 2025
    * @description : This method is used to access funcationality on key-board's Enter button click. 
    */
    handleButtonKeyDown(event){
        if(event.target.name === this.customLabels.WebFormsResetButton && (event.target.dataset.name !== "confirmResetButton" || event.target.dataset.name === undefined) && event.keyCode === 13){
            this.handleResetButton();
        }else if(event.target.name === this.customLabels.ProceedButtonWebform && event.keyCode === 13){
            this.handleProceed();
        }else if(event.target.name === this.customLabels.WebFormEPGProgrammeLabel2 && event.keyCode === 13){
            this.openManualEntryPage();
        }else if(event.target.name === this.customLabels.WebFormsCancelButton && event.keyCode === 13){
            this.closeModal();
        }else if(event.target.dataset.name === "confirmResetButton" && event.keyCode === 13){
            this.handleConfirmResetButton();
        }else if(event.target.dataset.id === "closeButtonLWC" && event.keyCode === 13){
            this.closeModal();
        }
    }

    /*
    * @author      : Coforge
    * @date        : Feb 19, 2025
    * @description : This method is used to close the reset confirmation pop-up model. 
    */
    closeModal() {
        // Close modal when user clicks the close button (X)
        this.isResetModalOpen = false;
    }
    
    /*
    * @author      : Coforge
    * @date        : Feb 19, 2025
    * @description : This method is used to reset variables and close confirmation pop-up model.
    */
    handleConfirmResetButton(){
        this.closeModal();
        this.resetVariable();
    }

    /*
    * @author      : Coforge
    * @date        : Feb 19, 2025
    * @description : This method is use to reset the variables
    */
    resetVariable(){
        this.isShowDropdown = false;
        this.isShowdateOfBroadcast = false;
        this.isShowProgrammeDropdown = false;
        this.isShowManualChannelField = false;
        this.isShowManualDateInput = false;
        this.isShowManualProgrammeInput = false;
        this.isShowManualTimeInput = false;
        this.isManualFormOpen = false;
        this.disableDateOfBroadCastField = false;
        this.selectedDropdownValue='';
        this.selectedDate ='';
        this.manualChannelName ='';
        this.selectedProgrammeValue ='';
        this.selectedStartTime = '';
        this.dropdownOptions = [];
        this.disableChannelField = false;
        this.isDisableProceedButton = true;
        this.validateField('remove');
    }
    
    /*
    * @author      : Coforge
    * @date        : Feb 19, 2025
    * @description : This method is used to handle manual programme entry.
    */
    handleManualProgrammeInput(event){
        this.selectedProgrammeValue = event.target.value;
        this.isManualEntry = true; // ADO44117 change
        this.selectedTime = this.selectedStartTime;
        this.validateMandatoryField();
    }

    /*
    * @author      : Coforge
    * @date        : Feb 19, 2025
    * @description : This method is used to handle manual time entry.
    */
    handleSelectedTime(event){
        this.selectedTime = event.detail.value;
        this.selectedStartTime = this.selectedTime;
        this.isManualEntry = true; // ADO44117 change
        this.validateMandatoryField();
    }

    /*
    * @author      : Coforge
    * @date        : Feb 13, 2025
    * @description : This method will run on programme picklist change and fetch selected value.
    */
    checkDaysRange(){
        const today = new Date();
        const localSelectedDate = this.selectedDate;
        const thresholdDate = new Date();
        const thresholdDateOld = new Date();
        if(this.isiOS){
            thresholdDate.setDate(today.getDate());
            thresholdDateOld.setDate(today.getDate() - this.daysRange);
            const thresholdDateConverted = thresholdDate.toISOString().split('T')[0];
            const thresholdDateConvertedOld = thresholdDateOld.toISOString().split('T')[0];
            if(localSelectedDate > thresholdDateConverted && this.selectedSearchResult.EPG_ChannelId) { // for future dates
                this.validateField('add');
                this.disableDateOfBroadCastField = false;
                this.showSpinner = false;
                this.dateRangeExceeded = undefined;
            }
            else if(localSelectedDate < thresholdDateConvertedOld){ // date older than daysRange
                this.dateRangeExceeded = true;
            }
            else { // valid date
                this.dateRangeExceeded = false;
            }
        }
        else{
            // Calculate the threshold date from today          
            thresholdDate.setDate(today.getDate() - this.daysRange);
            const thresholdDateConverted = thresholdDate.toISOString().split('T')[0];    
            // Compare the selected date with the X days ago range
            if (localSelectedDate < thresholdDateConverted) {
                this.dateRangeExceeded = true;
            }
            else {
                this.dateRangeExceeded = false;
            }
        }
    }
}