/*********************************************************************
# File....................: OsCaseActivityLogRecipient
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............: 02/04/2025
# Last Modified by........: Coforge
# Last Modified Date......: 
# Description.............: Component is used to show and add multiple recipients on Case Activity Log Object
# VF Page.................: NA
# VF Component............: NA
# L Comp..................: NA
# Handler Class...........: NA
# Test Class..............: NA
# Change Log..............: NA
#Trigger Name ............: Case

**********************************************************************/
import { LightningElement,api,track,wire } from 'lwc';
import getRelatedListData from '@salesforce/apex/CaseActivityLogController.getRelatedListData';
import userRecordAccess from '@salesforce/apex/CaseActivityLogController.userRecordAccess';
import saveAndDeleteMasterRepositoryItems from '@salesforce/apex/CaseActivityLogController.saveAndDeleteCaseActivityLogLineItems';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';

export default class OsCaseActivityLogRecipient extends LightningElement {

    @api recordId = '';
    @track stakeholderOrganization = [];
    shOrganizationCriteria = 'Case_Activity_Log__c = \'@recordId@\' AND StakeholderType__c = \'Ofcom Participant\'';
    sTAKEHOLDER_ORGANIZATIONS = 'Ofcom Participant	';
    stakeHolders;
    ERROR_LABEL = 'error';
    DISMISSABLE_LABEL= 'dismissable';
    showSaveButton = false;
    readOnly = false;
    createContactMetadata = 'CreateContact'; 
    lightningSpinner = false;
    mapOfStakeHolders = new Map(); 
    mapOfStakeHoldersDelete = new Map(); 
    wiredCaseActivityResult ;
    mapOfExistActivityLogLineItem = new Map();
    // connectedCallback to get userRecordAccess
    connectedCallback() {
        if (this.recordId) {
            userRecordAccess({ recordId: this.recordId })
                .then(result => {
                    this.readOnly = !result;
                })
                .catch(error => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error',
                            message: error.body.message,
                            variant: 'error'
                        })
                    );
                });
        }
    }

    @wire(getRelatedListData, { recordId: '$recordId' })
    getMasterRepositoryRecords(wiredResult) {
        this.wiredCaseActivityResult = wiredResult;

        const { data, error } = wiredResult;
        if (data) {
            const temp = [];
            for (const obj of data.caseActivityLogLineItem) {
                this.addStakeholderData(obj, temp); 
                this.mapOfExistActivityLogLineItem.set(this.generateKey(obj.Contact__c, obj.StakeholderType__c), obj);
            }
            this.stakeHolders = temp;
        } else if (error) {
            console.error('Wire error', error);
        }
    }


  
    /*
     * @author      : Coforge
     * @date        : 02/04/2025
     * @description : This @wire method is fetching the Participients related with Case Activity Log
     * @params      : obj,temp1
     * @return      : none
     */
    addStakeholderData(obj,temp){
        let temporg = {'Id':'','Contact__r.Name':'','Contact__c':'','Case_Activity_Log__c':'','StakeholderType__c':''};
        temporg['Contact__r.Name'] = obj.Contact__r?.Name;
        temporg.Contact__c = obj.Contact__r?.Id;
        temporg.Case_Activity_Log__c = obj.Case_Activity_Log__c;
        temporg.StakeholderType__c = obj.StakeholderType__c;
        temporg.Id = obj.Id;
        temp.push(temporg);
    }

    /*
     * @author      : Coforge
     * @date        : 02/04/2025
     * @description : This method will execute when new Participients are added to the page.
     * @params      : event
     * @return      : NA
     */
    addStakeholderOrganizations(event) {
        this.lightningSpinner = true;
        this.showSaveButton = true;
        if(event.detail.data) { 

                for(const obj of event.detail.data) {
                  
                    let temporg = {'Contact__r.Name':'','Contact__c':'','StakeholderType__c':'','Case_Activity_Log__c':''};
                    temporg['Contact__r.Name'] = obj["Contact__r.Name"];
                    temporg.Contact__c = obj["Contact__r.Id"];
                    temporg.StakeholderType__c = this.sTAKEHOLDER_ORGANIZATIONS;
                    temporg.Case_Activity_Log__c = this.recordId;
                    this.mapOfStakeHolders.set(this.generateKey(temporg.Contact__c,temporg.StakeholderType__c),temporg);                                        
                    if(this.mapOfExistActivityLogLineItem.has(this.generateKey(temporg.Contact__c,temporg.StakeholderType__c))){
                        this.mapOfStakeHoldersDelete.delete(this.generateKey(temporg.Contact__c,temporg.StakeholderType__c));
                    }
                }
                this.lightningSpinner =false;

        }
    }

    /*
     * @author      : Coforge
     * @date        : 02/04/2025
     * @description : This method will be used to delete the Participients
     * @params      : event
     * @return      : NA
     */
    deleterecords(event){
        this.lightningSpinner = true;
        this.showSaveButton = true;
        let rawData = event.detail.data;
       
        let newRecord = {
            "Id": rawData.Id,
            "Contact__r.Name": rawData["Contact__r.Name"],
            "Contact__c": rawData.Contact__c,
            "StakeholderType__c": rawData.StakeholderType__c,
            "Case_Activity_Log__c": rawData.Case_Activity_Log__c 
            };
            this.mapOfStakeHoldersDelete.set(this.generateKey(newRecord.Contact__c,newRecord.StakeholderType__c),newRecord);                    
            if(!this.mapOfExistActivityLogLineItem.has(this.generateKey(newRecord.Contact__c,newRecord.StakeholderType__c))){
                this.mapOfStakeHolders.delete(this.generateKey(newRecord.Contact__c,newRecord.StakeholderType__c));
            }
        this.lightningSpinner = false;
    }
    /*
     * @author      : Coforge
     * @date        : 02/04/2025
     * @description : This method will be used to create and delete the Participients
     * @params      : event
     * @return      : NA
     */
    handleSaveAndDelete() {
        this.lightningSpinner =true;
        let addRecords = [];
        let deleteRecords = [];

        this.mapOfExistActivityLogLineItem.forEach((value, key) => {
            if(this.mapOfStakeHolders.has(key)){
                this.mapOfStakeHolders.delete(key);
            }

            if(!this.mapOfStakeHoldersDelete.has(key) ){
                
                this.mapOfStakeHoldersDelete.delete(key);
            }

            if(this.mapOfStakeHoldersDelete.has(key)){
                
                this.mapOfStakeHoldersDelete.set(key,value);
            }
        });
         //Fill list from map
         if(this.mapOfStakeHolders.size > 0){
                    
           addRecords = [...addRecords,...this.mapOfStakeHolders.values()];
                
        }
        if(this.mapOfStakeHoldersDelete.size > 0){
                    
            deleteRecords = [...deleteRecords,...this.mapOfStakeHoldersDelete.values()];
                 
         }
         
        // Call Apex method
        saveAndDeleteMasterRepositoryItems({recordsToSave: addRecords, recordIdsToDelete: deleteRecords})
            .then(() => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Records added / deleted successfully',
                        variant: 'success'
                    })
                );
                deleteRecords = [];// Clear the list after deletion
                addRecords = [];// Clear the list after adittion
                this.mapOfStakeHolders = new Map();// clear map 
                this.mapOfStakeHoldersDelete = new Map();// clear map 
                this.mapOfExistActivityLogLineItem = new Map(); // clear map
                this.showSaveButton = false;
                this.lightningSpinner = false;
                refreshApex(this.wiredCaseActivityResult);
            })
            .catch(error => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error',
                        message: error.body.message,
                        variant: 'error'
                    })
                );
            });
    }
    
    /*
     * @author      : Coforge
     * @date        : 02/04/2025
     * @description : This method will be called when 
     * @params      : event
     * @return      : NA
     */
    handleCancel() {
        window.location.reload();
    }


    generateKey(contactId, stakeholderType) {
        return `${contactId}${stakeholderType}`.replace(/\s+/g, '');
    }
}