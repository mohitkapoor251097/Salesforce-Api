import { LightningElement,track, wire } from 'lwc';
import getNMSAdminSettingsRecord from '@salesforce/apex/NMS_AdminSettingsUI_Controller.getNMSAdminSettingsRecord';
import getCustomRecordFields from '@salesforce/apex/NMS_AdminSettingsUI_Controller.getCustomRecordFields';
import saveNmsSettingsRecord from '@salesforce/apex/NMS_AdminSettingsUI_Controller.saveNmsSettingsRecord';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';

export default class NmsAdminSettingsUI extends LightningElement {
    @track nmsRecordOptions = [];
    @track showRecord = false;
    @track customRecordFieldTypeMap = [];
    @track selectedRecordLabel='';
    @track nmsRecord = [];
    @track customRecordData;
    @track recordFieldMap;
    @track recordExposedFields;
    isEditable = false;
    isCancel = false;

    @wire(getNMSAdminSettingsRecord)
    wiredOptions({error, data}){
        if(data){
            let returnMap = data;
            let tempList = JSON.parse(JSON.stringify(returnMap));
            for (var key in tempList) {
                this.recordFieldMap = [];
                this.recordFieldMap.push({key:key, value:tempList[key]});
                this.nmsRecordOptions = [...this.nmsRecordOptions,{value: tempList[key], label: key}];
            }
        }
        if(error){
            this.error = error;
        }
    }

    get nmsOptions(){
        return this.nmsRecordOptions;
    }

    handlePicklistChange(event){
        this.isEditable = false;
        this.isCancel = false;
        this.selectedRecordLabel = event.target.options.find(opt => opt.value === event.detail.value).label;
        this.showRecord = true;
        this.recordExposedFields=event.detail.value;
        getCustomRecordFields({nmsRecordLabel: this.selectedRecordLabel,exposedFields:this.recordExposedFields})
            .then(result => {
                this.customRecordFieldTypeMap = [];
                this.customRecordData = [];
                this.nmsRecord = [];
                this.customRecordData = result;
                this.nmsRecord = JSON.parse(JSON.stringify(this.customRecordData.selectedNmsRecord));
                let tempList = JSON.parse(JSON.stringify(this.customRecordData.nmsRecordField));
                let tempListTwo = [];
                tempList.forEach(element => {
                    let dtOutputVal = '';
                    if(element.dataType == 'DATE' && element.fieldValue!=undefined){
                        let dateObj = new Date(element.fieldValue);
                        let isoString = dateObj.toISOString();
                        element.fieldValue = isoString;

                        let dtVal = new Date(element.fieldValue);
                        let year = dtVal.getFullYear();
                        let month = dtVal.getMonth()+1;
                        let dt = dtVal.getDate();

                        if (dt < 10) {
                            dt = '0' + dt;
                        }
                        if (month < 10) {
                            month = '0' + month;
                        }
                        dtOutputVal = year+'/'+month+'/'+dt;
                    }
                    else if(element.dataType == 'DATE' && element.fieldValue==undefined){
                        element.fieldValue = '';
                    }
                    tempListTwo.push({dataType:element.dataType,fieldLabel:element.fieldLabel,fieldApiName:element.fieldApiName,fieldValue:element.fieldValue,dateOutputValue:dtOutputVal});
                    
                });
                this.customRecordFieldTypeMap = tempListTwo;
                this.error = undefined;
            })
            .catch(error => {
                this.error = error;
                this.customRecordData = undefined;
            })
            

    }

    handleEdit(){
        this.isEditable = true;
        this.isCancel = true;
    }
    handleCancel(){
        this.isCancel = false;
        this.isEditable = false;
    }

    handleSave(){
        saveNmsSettingsRecord({nmsUpdatedRecord : this.nmsRecord})
        .then(result => {
            this.isCancel = false;
            this.isEditable = false;
            const toastEvent = new ShowToastEvent({
                title:'Success!',
                message:'Record updated successfully',
                variant:'success'
            });
            this.dispatchEvent(toastEvent);
            eval("$A.get('e.force:refreshView').fire();");
        })
        .catch(error => {
            this.error = error;
            const toastEvent = new ShowToastEvent({
                title:'Failure!',
                message:JSON.stringify(this.error),
                variant:'error'
            });
            this.dispatchEvent(toastEvent);
        })
    }

    handleFieldValueChange(event){
        let eventFieldName = event.detail.fieldName;
        let eventFieldValue = event.detail.fieldValue;
        let tempList = JSON.parse(JSON.stringify(this.nmsRecord));
        tempList[eventFieldName]= eventFieldValue;
        this.nmsRecord = tempList;
    }
}