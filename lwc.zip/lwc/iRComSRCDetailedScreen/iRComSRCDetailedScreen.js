/**
* @description   Displays the IRMS cases files
* @author        Coforge
* @date          03 September 2024
* @lastModified  04 September 2024
* @description : ADO-37261 Correspondence Detailed IR SRC Case View Pop-up Screen
*/
import { LightningElement, api, track } from 'lwc';
export default class IRComSRCDetailedScreen extends LightningElement {
    @api srccase;
    contentversionlist;
    showSpinner = false;

     //ADO-37261 Start
    selectedsrccaseid;
    metadatatypes=' ';
    title='Attachment details';
    isvisiblecontentversionscreen=false;
    isvisiblecdetailscreen=false;
    isvisiblebackbutton;
  // ADO-37261 End

            
     connectedCallback() {
        try {
            this.selectedsrccaseid= this.srccase.Id;
            this.isvisiblecontentversionscreen=true;
            this.isvisiblecdetailscreen=true;
            this.isvisiblebackbutton=false;
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }       
    /*       
    * @author      : Coforge
    * @date        : 03/09/2024
    * @description : ADO-37261: method send a custom event to parent to open the MyCorrespondence screen
    */
    handleback() {
        try {
            const updatedValues = {
                isMyCorrespondenceScreen: true,
                isVisibleDetailViewScreen: false
            };
            this.dispatchEvent(new CustomEvent('updatevalues', {
                detail: updatedValues
            }));
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }

    }
   
}