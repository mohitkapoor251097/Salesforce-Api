/*********************************************************************
# File......................: timePicker
# Version...................: 1.0
# Created by................: Coforge
# Last Modified Date........: Mar 20, 2025
# Description...............: This is a generic custom time picker LWC.
# Change Log................: V1.00 : Initially version
**********************************************************************/
import { LightningElement,track,api } from 'lwc';

export default class TimePickerLWC extends LightningElement {
	@track hour = '00';
	@track minute = '00'; 
	@track showPopup = false;
	@track popupValues = [];
	@track popupHoursValues = [];
	currentType = '';
	isShowTimePicker=false;
	@track isOpenHrsMinutesPopup = false;
	@track isOpenHrsPopup = false;
	isListening = false;
	@api programmestarttime;
  
  	/*
    * @author      : Coforge
    * @date        : March 19, 2025
    * @description : This constructor is used to bind events to hour and minute popup whenever user clicks outside the popup.
    */
  	constructor() {
		super();
    	this.closePopups = this.closePopups.bind(this);
	}

	/*
    * @author      : Coforge
    * @date        : March 19, 2025
    * @description : This method is used to prevent entries in the field except delete and backspace.
    */
	allowDeletion(event){
		if (event.key !== "Backspace" && event.key !== "Delete" && event.key !== "Tab") {
			event.preventDefault(); 
		}
		if(event.key == 'ArrowUp'){
			this.incrementMinute(event);
		}
		if(event.key == 'ArrowDown'){
			this.decrementMinute(event);
		}
	}

	handleClosePopup(event){
		const parentDiv = event.currentTarget;
		if(!parentDiv.contains(event.relatedTarget)){
			this.showPopup = false;
		}
	}

	get time() {
		this.prepareTime(this.programmestarttime);
		// let returnTime = (this.hour !=='00' && this.minute !=='00' || (this.hour ==='00' && this.minute !=='00') || ((this.hour !=='00' && this.minute ==='00'))) ? `${this.hour}:${this.minute}`:'';
    	let returnTime =  `${this.hour}:${this.minute}`;
    	return returnTime;
  	}

  	/*
    * @author      : Coforge
    * @date        : March 19, 2025
    * @description : This method is used to increase hour value with the click of the up arraw button.
    */
  	incrementHour(event) {
    	event.preventDefault();
    	let hour = parseInt(this.hour, 10);
    	hour = (hour + 1) % 24;
    	this.hour = hour < 10 ? `0${hour}` : `${hour}`;
    	this.dispatchTime(this.hour+':'+this.minute);
  	}

	/*	
    * @author      : Coforge
    * @date        : March 19, 2025
    * @description : This method is used to decrease hour value with the click of the down arraw button.
    */
  	decrementHour(event) {
    	event.preventDefault();
    	let hour = parseInt(this.hour, 10);
    	hour = (hour - 1 + 24) % 24;
    	this.hour = hour < 10 ? `0${hour}` : `${hour}`;
    	this.isShowTimePicker = false;
    	this.dispatchTime(this.hour+':'+this.minute);
  	}

	/*
    * @author      : Coforge
    * @date        : March 19, 2025
    * @description : This method is used to increase minute value with the click of the up arraw button.
    */
  	incrementMinute(event) {
    	event.preventDefault();
    	let minute = parseInt(this.minute, 10);
    	minute = (minute + 1) % 60;
    	this.minute = minute < 10 ? `0${minute}` : `${minute}`;
		if(minute == '00'){ this.incrementHour(event); }
		else{ this.dispatchTime(this.hour+':'+this.minute); }
  	}

	/*
    * @author      : Coforge
    * @date        : March 19, 2025
    * @description : This method is used to decrease minute value with the click of the down arraw button.
    */
  	decrementMinute(event) {
    	event.preventDefault();
    	let minute = parseInt(this.minute, 10);
    	minute = (minute - 1 + 60) % 60;
    	this.minute = minute < 10 ? `0${minute}` : `${minute}`;
		if(minute == '59'){ this.decrementHour(event); }
		else{ this.dispatchTime(this.hour+':'+this.minute); }
  	}

	/*
    * @author      : Coforge
    * @date        : March 19, 2025
    * @description : This method is used to open hour popup with the click of hour value.
    */
  	openHourPopup() {
    	this.isOpenHrsPopup = true;
    	this.currentType = 'hour';
    	this.popupHoursValues = Array.from({ length: 24 }, (_, i) =>
      		i < 10 ? `0${i}` : `${i}`
    	);
		this.showPopup = true;
    	setTimeout(() => document.addEventListener('click', this.closePopups), 0);
  	}

   	/*
    * @author      : Coforge
    * @date        : March 19, 2025
    * @description : This method is used to open minute popup with the click of minute value.
    */
  	openMinutePopup() {
    	this.isOpenHrsMinutesPopup = true;
    	this.currentType = 'minute';
    	this.popupValues = Array.from({ length: 12 }, (_, i) =>
      		i * 5 < 10 ? `0${i * 5}` : `${i * 5}`
    	);
    	this.showPopup = true;
    	this.isShowTimePicker = true;
    	setTimeout(() => document.addEventListener('click', this.closePopups), 0);
  	}

  	/*
    * @author      : Coforge
    * @date        : March 19, 2025
    * @description : This method is used to close hour and minute popup whenever user clicks outside the popup.
    */
  	closePopups = (event) => {
		if(!this.template.contains(event.target)) {
       		this.isOpenHrsPopup = false;
       		this.isOpenHrsMinutesPopup = false;
       		this.showPopup = false;
       		document.removeEventListener('click', this.closePopups);
   		}
	};

	/*
    * @author      : Coforge
    * @date        : March 19, 2025
    * @description : Prevents the click event from propagating to parent elements.
                   : This ensures that clicking inside the popup does not trigger the document-level click event listener that would close the popup.
    */
	stopPropagation(event) {
  		event.stopPropagation();
	}

	/*
    * @author      : Coforge
    * @date        : March 19, 2025
    * @description : This method is used to assign hour or minute values on a click of the popup values selection and dispatch this time to the parent component.
    */
  	handlePopupSelect(event) {
    	const value = event.target.dataset.value;
    	if (this.currentType === 'hour') {
			this.hour = value;
      		this.isOpenHrsPopup = false;
    	} else if (this.currentType === 'minute') {
			this.minute = value;
      		this.isOpenHrsMinutesPopup = false;
    	}
    	this.showPopup =  true;
    	this.dispatchTime(this.hour+':'+this.minute);
  	}

	/*
    * @author      : Coforge
    * @date        : March 19, 2025
    * @description : Validates and formats the time input (HH:MM), ensuring hours (0-23) and minutes (0-59) are within range
    */
  	validateOutputInput(event) {
    	const value = event.target.value;
		this.prepareTime(value);
  	}

	prepareTime(value){
    	if(value != undefined && value !='' && value != null){
			const [hourStr, minuteStr] = value.split(':');
			let hour = parseInt(hourStr, 10);
			let minute = parseInt(minuteStr, 10);
			if (isNaN(hour) || hour < 0 || hour > 23) hour = 0;
			if (isNaN(minute) || minute < 0 || minute > 59) minute = 0;
			this.hour = hour < 10 ? `0${hour}` : `${hour}`;
			this.minute = minute < 10 ? `0${minute}` : `${minute}`;
    	}
  	}
	
	/*
    * @author      : Coforge
    * @date        : March 19, 2025
    * @description : This method is used to open a time popup with a click inside the time input field.
    */
  	handleonTimeInputClick(event){
    	event.stopPropagation(); // Prevent closing immediately
    	this.showPopup = true;
    	this.isShowTimePicker = true;  
    	setTimeout(() => document.addEventListener('click', this.closePopups), 0);
		this.handleClick();
  	}

	handleClick() {
		const triggerElement = this.template.querySelector('.time-output');
        const popupElement = this.template.querySelector('.time-popup');

        // Get the position of the trigger element
        const triggerRect = triggerElement.getBoundingClientRect();

        // Calculate the desired position for the pop-up
        let popupTop = triggerRect.bottom + 220;
        
		if(popupTop > window.innerHeight){
			popupElement.style.setProperty('top', '-254px');
		}
		else{
			popupElement.style.setProperty('top', '0px');
		}
	}

	/*
    * @author      : Coforge
    * @date        : March 19, 2025
    * @description : This method is used send selected time to parent component.
    */
  	dispatchTime(timeValue){
    	this.dispatchEvent( new CustomEvent('selectedtime',{
      		detail: {
				value: timeValue
      		}
  		})
  		);
  	}
}