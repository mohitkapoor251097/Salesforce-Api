/*
* @description   Displays the Contact record view popup
* @author        Coforge
* @date          29 feb  2024
* @lastModified  08 march  2024
* @ChangeLog    ADO-27683: Functionality for "View" and "Edit/Delete" buttons for IR Regulatory Contacts and General IR Contacts Table.
                ADO-27683: First Letter is displaying in small case in 'contact' and 'details'
                ADO-28411 : Show and Tell Review Feedback Points
*/

import { LightningElement, api } from 'lwc';
export default class IRComContactViewModal extends LightningElement {
    @api isshowmodal;
    @api header;
    @api value;
    connectedCallback() {
        /*BUG : 27935 FIX START \ ADO 28411 IR removed from title(header)*/
        if(this.header == 'Regulatory Contacts'){
            this.header = 'Regulatory Contact';
        } 
        if(this.header == 'General Contacts'){
            this.header = 'General Contact';
        }
        /*BUG : 27935 FIX END*/
    }

    /*       
        * @author      : Coforge
        * @date        : 01/03/2024
        * @param       : None
        * @description : ADO-27683: Functionality for "View" and "Edit/Delete" buttons for IR Regulatory Contacts and General IR Contacts Table.
        */
    closeModalAction() {

        try {
            this.dispatchEvent(new CustomEvent('closemodalaction', { detail: false }));
            this.isshowmodal = false;
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
}