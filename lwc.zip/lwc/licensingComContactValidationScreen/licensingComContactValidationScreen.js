import { LightningElement,api } from 'lwc';
import prepareSSOData from '@salesforce/apex/Licensing_Utility.prepareSSOData';
import AERO_MYSPECTRA_URL from '@salesforce/label/c.AERO_MYSPECTRA_URL';
import getContactOrgRoleRecords from '@salesforce/apex/Licensing_Utility.getContactOrgRoleRecords';
import getLPEConfingSetting from '@salesforce/apex/Licensing_Utility.getLPEConfingSetting'; //W-002911
import getContactOrgRoleRecordCreatedDate from '@salesforce/apex/Licensing_Utility.getContactOrgRoleRecordCreatedDate'; ///W-002911

export default class LicensingComContactValidationScreen extends LightningElement {
    @api paymentcontact;
    @api licencecontact; //W-002838
    @api licensee; //W-002838
    selectedLicensee; //W-002838
    selectedLicenceContact; //W-002838
    selectedPaymentContact; //W-002838
    licenseeAccount; //W-002838
    confirmCheckbox = false; //W-002838
    checkboxValidation; //W-002838
    showSpinner;
    isShowWaitngModal = false; //W-002911
    executedIndicator; //W-002911

    /*       
    * @author      : Coforge
    * @date        : 30/11/2022
    * @description : W-002838 : Method called when component is loaded to bring data for contact validation screen
    * @return      : None
    * @param       : None
    */   
    connectedCallback() {
    try{
   //  this.selectedLicenceContact = JSON.parse(this.licencecontact);
   //  this.selectedPaymentContact = JSON.parse(this.paymentcontact);
   
   // US-25154 Start : Escaping line breaks in JSON   
     this.selectedLicenceContact = JSON.parse(this.licencecontact.replace(/[\r\n]/gm, ' ')); 
     this.selectedPaymentContact = JSON.parse(this.paymentcontact.replace(/[\r\n]/gm, ' '));
   // US-25154 End

      // When licensee recieved is object type
        if(typeof this.licensee === 'object'){
            this.selectedLicensee = this.licensee;
        }
        // When licensee recieved is json type
        else{
            this.selectedLicensee = JSON.parse(this.licensee);
        }

        // Making a set of record ids which do not have the required field values to be shown on UI / to be passed to SSO
        const recordIds = new Set();
        recordIds.add(this.selectedLicensee.Id); // Added for ADO 25155
        recordIds.add(this.selectedLicenceContact.Id); // Added for ADO 25155
        recordIds.add(this.selectedPaymentContact.Id); // Added for ADO 25155

        // If any record exists whose fields are unavailable
        if(recordIds.size > 0){
            // Query to fetch the required fields
            getContactOrgRoleRecords({ orgRoleIds: Array.from(recordIds) })
                .then((result) => {
                    this.assignContactRecords(result);
                })
                .catch((error) => {
                    window.location.href='/apex/licensingcomerror';
                });
        }
    }catch(e){
        window.location.href='/apex/licensingcomerror';     //PMD Issue Fixed here
    }
    }
     

    /*       
    * @author      : Coforge
    * @date        : 23/11/2022
    * @description : W-002828 : Reloading on click of previous button
    * @return      : None
    * @param       : None
    */
    goToPreviousScreen(){  //PMD Issue fixed here
        try{
            location.reload();
        }catch(e){
            window.location.href='/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 28/03/2023
    * @description : W-002911 : Method called on click of next button and check
                                Delay timer after payment contact creation prior to passing user over via SSO to mySPECTRA 
    * @return      : None
    * @param       : None
    */
    async checkSystemTime(){
        try{
            this.showSpinner = true;
            this.isShowWaitngModal = false;
            if(this.confirmCheckbox == false){
                this.showSpinner = false;
                this.template.querySelector('[data-id="errorMessage"]').classList.add('error');
                // To highlight the checkbox
                this.template.querySelector('[data-id="checkboxError"]').classList.add('slds-has-error');
                this.checkboxValidation = "Confirmation that your contact details are correct is required"; 
            }
            else{
                const recordIds = new Set();
                var paymentContact;
                var licenceContact;
                // Creating a map of contact type to their record Ids
                var contactTypeToRecordIdMap = new Map([
                                                    ["Licence Contact", this.selectedLicenceContact.Id],
                                                    ["Payment Contact", this.selectedPaymentContact.Id]
                                                    ]);
                recordIds.add(this.selectedLicenceContact.Id);
                recordIds.add(this.selectedPaymentContact.Id);
                if(recordIds.size > 0){
                    // Query to fetch the required fields
                     var result = await getContactOrgRoleRecordCreatedDate({ orgRoleIds: Array.from(recordIds) });
                    
                        // Fetching the Licence Contact, Payment Contact org roles
                        Array.from(result).forEach(function(orgRole){
                            if(contactTypeToRecordIdMap.get('Licence Contact') == orgRole.Id){
                                licenceContact = orgRole
                            }
                            if(contactTypeToRecordIdMap.get('Payment Contact') == orgRole.Id){
                                paymentContact = orgRole;
                            }
                        });
                       
                }
                //var getLPEConfingSettingResult = await getLPEConfingSetting();
                getLPEConfingSetting()
                    .then((result) => {
                    var currentdate = new Date().toISOString();

                    var paymentCreatedDateDiff = Math.abs(Date.parse(currentdate) - Date.parse(paymentContact.LastModifiedDate))/ (1000); // ADO11696 change
                    var licencecontactCreatedDateDiff = Math.abs(Date.parse(currentdate) - Date.parse(licenceContact.LastModifiedDate))/ (1000); // ADO11696 change
                    console.log(licencecontactCreatedDateDiff+'<--licence--||--payment-->'+paymentCreatedDateDiff);
                    if(paymentCreatedDateDiff < result.Delay_Timer__c || licencecontactCreatedDateDiff < result.Delay_Timer__c){
                        this.isShowWaitngModal = true;
                        this.showSpinner = false;
                        this.executedIndicator = 0;
                        var timerCount = 0;
                        this._interval = setInterval(() => {
                            if(timerCount <result.Delay_Timer__c){
                                timerCount = timerCount +1;
                                this.executedIndicator = (100/result.Delay_Timer__c)*timerCount;
                            }
                            else if(timerCount ==result.Delay_Timer__c){
                                this.redirectToMySpectra();
                            }
                            
                        }, 1000)
                    }else{
                        this.redirectToMySpectra();
                    }
                    })
                    .catch(error => {
                        this.isShowWaitngModal = false; 
                        window.location.href='/apex/licensingcomerror';
                    });
                   
            }
        }catch(e){
           this.isShowWaitngModal = false;
           window.location.href='/apex/licensingcomerror';
        }
        
    }
    /*       
    * @author      : Coforge
    * @date        : 05/12/2022
    * @description : W-002841 : Method called from checkSystemTime method and redirect to the mySPECTRA
    * @return      : None
    * @param       : None
    */  
    redirectToMySpectra(){
    try{
        //W-002842 : Prepare SSO Data and redirect to mySpectra in case of successfully handshake start here
            prepareSSOData({ selectedLicensee: JSON.stringify(this.selectedLicensee),
                selectedLicenceContact : JSON.stringify(this.selectedLicenceContact),
                selectedPaymentContact : JSON.stringify(this.selectedPaymentContact),
                caseCode : 'caseCode=01'
                })
                .then((result) => {
                    if(result=='Success'){
                        window.location.href=AERO_MYSPECTRA_URL;
                    }else{
                        this.template.querySelector('[data-id="errorMessage"]').classList.add('error');
                        this.checkboxValidation = result; 
                    }
                })
                .catch((error) => {
                    window.location.href='/apex/licensingcomerror';
                });
                //W-002842 : Prepare SSO Data and redirect to mySpectra in case of successfully handshake end here
        
    }catch(e){
        window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 05/12/2022
    * @description : W-002841 : Method called when checkbox is ticked/unticked
    * @return      : None
    * @param       : None
    */  
    handleCheckboxChange(){
    try{
        this.confirmCheckbox = !this.confirmCheckbox;
        // Removing error if checkbox is ticked
        if(this.confirmCheckbox == true && this.checkboxValidation != ""){
            this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
            this.template.querySelector('[data-id="checkboxError"]').classList.remove('slds-has-error');
            this.checkboxValidation = ""; 
        }
    }catch(e){
        window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 07/12/2022
    * @description : W-002839 : redirect to Licence Contact Selection Screen
    * @return      : None
    * @param       : None
    */ 
    redirectToLicenceContact(){
    try{    
        this.dispatchEvent(new CustomEvent('gotolicencecontact'));
    }catch(e){
        window.location.href='/apex/licensingcomerror';
    } 
    }

    /*       
        * @author      : Coforge
        * @date        : 07/12/2022
        * @description : W-002840 : redirect to Licence Contact Selection Screen
        * @return      : None
        * @param       : None
        */ 
    redirectToPaymentContact(){
    try{        
        this.dispatchEvent(new CustomEvent('gotopaymentcontact')); 
    }catch(e){
        window.location.href='/apex/licensingcomerror';
    }
    }
    
    /*       
        * @author      : Coforge
        * @date        : 22/12/2022
        * @description : W-002838 : Assigns the contact org roles to the variables that are displayed on the UI, and also passed to SSO on Next click
        * @return      : None
        * @param       : result
        */ 
    assignContactRecords(result){
    try{
        // Creating a map of contact type to their record Ids
        var contactTypeToRecordIdMap = new Map([
            ["Licensee", this.selectedLicensee.Id],
            ["Licence Contact", this.selectedLicenceContact.Id],
            ["Payment Contact", this.selectedPaymentContact.Id]
            ]);
        
        var licenseeFromQuery;
        var licenceContactFromQuery;
        var paymentContactFromQuery;

        // Fetching the Licensee, Licence Contact, Payment Contact org roles
        Array.from(result).forEach(function(orgRole){
                if(contactTypeToRecordIdMap.get('Licensee') == orgRole.Id ){
                    licenseeFromQuery = orgRole;
                }
                if(contactTypeToRecordIdMap.get('Licence Contact') == orgRole.Id){
                    licenceContactFromQuery = orgRole
                }
                if(contactTypeToRecordIdMap.get('Payment Contact') == orgRole.Id){
                    paymentContactFromQuery = orgRole;
                }
        });
        
        // Passing the contact org roles to the UI variables
        if(licenseeFromQuery != undefined){
            this.selectedLicensee = licenseeFromQuery;
        }
        if(licenceContactFromQuery != undefined){
            this.selectedLicenceContact = licenceContactFromQuery;
        }
        if(paymentContactFromQuery != undefined){
            this.selectedPaymentContact = paymentContactFromQuery;
        }
    }catch(e){
        window.location.href='/apex/licensingcomerror';
    }
    }
	
	/*       
    * @author      : Coforge
    * @date        : 11/01/2023
    * @description : W-002883 : LPE Accessibility issue fixing  here
    * @return      : None
    * @param       : None
    */
    cancellink(){
    try{
        window.location.href='/apex/LicensingComDashboard';   
    }catch(e){
        window.location.href='/apex/licensingcomerror';
    }      
        
    } 
}