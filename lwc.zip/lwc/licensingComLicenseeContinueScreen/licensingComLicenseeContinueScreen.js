/**
* @description   Displays Available Licencees list
* @author        Coforge
* @date          22 Dec 2022
* @lastModified  23 Dec 2022
* @changelog     Intitial Version 1.0 : 22-12-2022 : W-002873 : LPE user journey with contact grid in CP : CP29.1, CP29.2 and CP29.3] Select licensee (if multiple) from grid for continue application
*                         
*/
import {LightningElement,api} from 'lwc';
import prepareSSOData from '@salesforce/apex/Licensing_Utility.prepareSSOData';
import AERO_MYSPECTRA_URL from '@salesforce/label/c.AERO_MYSPECTRA_URL';
import GenericLicensingWebFormUrl from '@salesforce/label/c.GenericLicensingWebFormUrl'; //< ADO15407>

export default class LicensingComLicenseeContinueScreen extends LightningElement {
    
    showSpinner=true; // To show spinner until data is fetched
	@api licenseeOrgRoleContinueJSONList; // Its value is fetched from lightning out component
    gridSelected; // Grid selected by user        
    licenseeList; // Licensee org role list displayed on the UI
    licenseeCount; // Count of org role displayed on the UI
    selectGridValidation; // string variable to display validation error
    licenseeCardsHeader; // It displays licensee Cards Header
    openLicenseeScreen; // It is used to show/hide the content of Licensee selection screen
    Webformlabelvalue=GenericLicensingWebFormUrl + 'SlepWebForm'; //< ADO15407>

    /*       
    * @author      : Coforge
    * @date        : 22/12/2022
    * @description : Method called when component is loaded to bring data for licensee selection screen 
    * @return      : None
    * @param       : None
    */   
    connectedCallback() {
    try{
            this.openLicenseeScreen = true; //To render licensee selection screen on the UI
            this.licenseeCardsHeader = 'Select from the list of associated licensees'; //  It displays licensee Cards Header on UI
            
            if(this.licenseeOrgRoleContinueJSONList!=undefined && this.licenseeOrgRoleContinueJSONList!=null){
                this.licenseeList = JSON.parse(this.licenseeOrgRoleContinueJSONList); // parse the licensee org role JSON into licensee List
                this.licenseeCount = (this.licenseeList).length; // Populate the number of records in the licensee list                
            }else{
                this.licenseeCount = 0; // Resetting the licensee counter
            }
        this.showSpinner = false; // To hide spinner
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }   
    }

    /*       
    * @author      : Coforge
    * @date        : 22/12/2022
    * @description : Method called when select Licensee button is clicked for licensee selection screen 
    * @return      : None
    * @param       : event
    */
    selectedGrid(event){
    try{
				var scrollOptions = {
                left: 0,
                top: document.body.scrollHeight, /* W-002883 : LPE Accessibility issue fixing  here */ 
                behavior: 'smooth'
            }
            window.scrollTo(scrollOptions);
        var gridName = event.target.value;
		this.gridSelected=null; // Reset the existing grid value
        /*Selected card record id is fetched and styling class is added/removed to card */    
        for(let i=0; i<this.licenseeList.length; i++){
            if(this.licenseeList[i].Id == gridName){
                this.template.querySelector('[data-id="' +gridName+ '"]').classList.add('gridBackground');
                this.gridSelected = this.licenseeList[i];
                this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
            	this.selectGridValidation = "";
            }
            else{
                this.template.querySelector('[data-id="' +this.licenseeList[i].Id+ '"]').classList.remove('gridBackground');	
            }
        }    
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 022/12/2022
    * @description : Method called when Next  button is clicked
    * @return      : None
    * @param       : None
    */  
    redirectToMySpectra(){
    try{
        if(this.gridSelected==null){
            /*On click of next without selecting card we are displaying error on top of grids  */
            this.template.querySelector('[data-id="errorMessage"]').classList.add('error');
            this.selectGridValidation = "Licensee selection is required";
            var scrollOptions = {
                left: 0,
                top: 580,
                behavior: 'smooth'
            }
            window.scrollTo(scrollOptions);
        }
        else{
        this.showSpinner = true;
            //START W-002874 Send data to mySpectra
            prepareSSOData({ selectedLicensee: JSON.stringify(this.gridSelected),
                selectedLicenceContact : null,
                selectedPaymentContact : null,
                caseCode : 'caseCode=02'
                })
                .then((result) => {
                    this.showSpinner = false;
                    if(result=='Success'){
                    window.location.href=AERO_MYSPECTRA_URL;
                    }
                })
                .catch((error) => {
                    window.location.href='/apex/licensingcomerror';
                });
            //END W-002874    
            }
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

    /*       
    * @author      : Coforge
    * @date        : 11/01/2023
    * @description : W-002883 : LPE Accessibility issue fixing  here
    * @return      : None
    * @param       : None
    */
    cancellink(){
    try{
        window.location.href='/apex/LicensingComDashboard';    
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }     
    } 

    /*       
    * @author      : Coforge
    * @date        : 11/01/2023
    * @description : W-002883 : LPE Accessibility issue fixing  here
    * @return      : None
    * @param       : None
    */
    previouslink(){
    try{
       window.location.href='/apex/licensingcomapplyforlicence?licence=Aeronautical Radio'; 
    }catch(e){
         window.location.href='/apex/licensingcomerror';
    }
    }

}