/**
* @description   Allows inserting Custom Data Source object records through CSV
* @author        Coforge
* @date          19 Mar 2025
* @ChangeLog     Intitial Version 1.0 : 19-03-2025 : ADO 50844 :  Inserting Custom Data Source object records through CSV
* @ChangeLog                      
*/

import { LightningElement, track, api,wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import csvFileRead from '@salesforce/apex/CSVFileReadLWCController.csvFileRead';
import getallFieldValues from '@salesforce/apex/CSVFileReadLWCController.getAllFieldLabelsAndApiNames';
import insertSObjectData from '@salesforce/apex/CSVFileReadLWCController.insertSObjectData';
import { NavigationMixin } from 'lightning/navigation';
import getDocumentUrlByName from '@salesforce/apex/CSVFileReadLWCController.getDocumentUrlByName';

export default class csvUploaderClone extends NavigationMixin(LightningElement) {
   
   @track error;
   @track data;
   @track requiredFields = [];
   @api csvHeaders = [];
   @api salesforceFieldOptions=[];
   @api csvHeaderMap = new Map();
   @api csvData;
   @api rawCsvData;
   @api documentId;
   @api selectedSalesforceFieldMap2 = new Map();
   @api objectName;
   @api showLoading = false;
   @track downloadTemplateUrl ;
   samplefileName = 'Data Source Sample File';
   @track showStep2;
 

    connectedCallback() {
        console.log('objectName in child (connectedCallback):', this.objectName); // Log it as soon as the component is connected
    }

    /*       
    * @author      : Coforge
    * @date        : 19/03/2025
    * @description : Method called on click of 'Download' button.
    * @return      : None
    * @param       : event
    */
    downloadFile() {
        if (!this.samplefileName) {
            this.showToast('Error', 'File name is missing or invalid.', 'error');
            return;
        }

        // Call Apex to get the document URL
        getDocumentUrlByName({ samplefileName: this.samplefileName })
            .then((url) => {
                // Create an anchor element to trigger the download
                const link = document.createElement('a');
                link.href = url;
                link.download = this.fileName; // Optional: Use the file name as the downloaded file name
                link.click(); // Trigger the download
            })
            .catch((error) => {
                this.showToast('Error', 'There was an error downloading the file: ' + error.body.message, 'error');
            });
    }
 
    /*       
    * @author      : Coforge
    * @date        : 19/03/2025
    * @description : Method to fetch Custom Data Source Object fields in dropdown.
    * @return      : None
    * @param       : event
    */

    @wire(getallFieldValues, { objectApiName: '$objectName' }) // Pass the parameter
    wiredFieldValue({ data, error }) {
       console.log('objectName in child:', this.objectName); 
        if (data) {
            const options = Object.keys(data).map(label => ({
               label: label.charAt(0).toUpperCase() + label.slice(1),
               value: data[label]
            }));
            const sortedFields = options.sort((a, b) => {
            // Alphabetically sort by label if not required
            return b.label.localeCompare(a.label);
        });
           this.salesforceFieldOptions = [{ label: '--------------------------------------------None--------------------------------------------', value: '' }, ...options];
        } else if (error) {
           console.error('Error fetching', error);
        }
    }
    get acceptedCSVFormats() {
       return ['.csv'];
    }

    /*       
    * @author      : Coforge
    * @date        : 19/03/2025
    * @description : Method called on CSV Upload.
    * @return      : None
    * @param       : event
    */

    uploadFileHandler(event) {
       const uploadedFiles = event.detail.files;
       console.log('sdd>>' + typeof uploadedFiles);
       console.log('sdd>>' + JSON.stringify(uploadedFiles));
       
       this.rawCsvData = uploadedFiles;
       console.log('rawCsvData---'+this.rawCsvData);
       this.fileName = uploadedFiles[0].name;
       console.log('fileName>>'+ this.fileName);
 
       csvFileRead({ contentDocumentId: uploadedFiles[0].documentId })
            .then(result => {
                console.log('CSV Data:', result);
                this.csvData = result.data;
                console.log('csvData---'+this.csvData);
                this.documentId = uploadedFiles[0].documentId;
                console.log('documentId---'+ this.documentId);

                // Get headers and data from the result
                this.csvHeaders = result.headers.filter(header =>
                   header &&
                   header.trim() !== ''
                );
                this.data = result.data;
             
                console.log('CSV Headers:', this.csvHeaders);

                if( this.csvHeaders.length == 0 && this.data.length ==0 ){
                this.showToast('Error!', 'Empty CSV File!', 'error');
                return;
                }

                this.csvHeaders.forEach((header, index) => {
                   this.csvHeaderMap.set(index, header); // Populate the map
                });
                console.log('CSV Header Map:', this.csvHeaderMap);
                this.showToast('Success!', 'CSV file processed successfully!', 'success');
                this.showStep2 = true;
            })
            .catch(error => {
               this.error = error;
               this.showToast('Error!', error.body?.message || 'Error processing file', 'error');
            });
    }
    
    /*       
    * @author      : Coforge
    * @date        : 19/03/2025
    * @description : Method called on change in dropdown values.
    * @return      : None
    * @param       : event
    */

    handleFieldMappingChange(event) {
        // Get all comboboxes
        const comboboxes = this.template.querySelectorAll('.map-field-dropdown');
        // For each combobox, generate its options based on selections in other comboboxes
        comboboxes.forEach(currentCombobox => {
        // Get values selected in other comboboxes
            const valuesSelectedInOtherComboboxes = new Set();
            comboboxes.forEach(otherCombobox => {
                if (otherCombobox !== currentCombobox && otherCombobox.value) {
                    valuesSelectedInOtherComboboxes.add(otherCombobox.value);
                }
            });
      
            // Filter options for the current combobox
            const filteredOptions = this.salesforceFieldOptions.filter(option => {
                // Exclude options selected in other comboboxes
                if (valuesSelectedInOtherComboboxes.has(option.value)) return false;
                // Include all other options
                return true;
            });
            // Update the combobox options
            currentCombobox.options = filteredOptions;
        });
    }        
    
    /*       
    * @author      : Coforge
    * @date        : 19/03/2025
    * @description : Method called on click of 'Upload & Import' button.
    * @return      : None
    * @param       : event
    */

    handleImport() {  

        this.showLoading = true;
        let comboboxes = this.template.querySelectorAll('.map-field-dropdown');
           let selectedSalesforceFieldMap = new Map();
           //Clear existing validation errors first
           comboboxes.forEach(combobox => {
            combobox.setCustomValidity('');
            combobox.reportValidity();  // 🔥 Force UI refresh to clear error messages
        });
           comboboxes.forEach((combobox, index) => {
            selectedSalesforceFieldMap.set(index, combobox.value);
        });
        let isDataSourceMapped = [...selectedSalesforceFieldMap.values()].includes('csv_data_source_name__c'); // Replace with actual API name
        console.log('isDataSourceMapped >>>', isDataSourceMapped);

        // Step 1: Find the index of "CSV_Name__c" in csvHeaderMap (Left Side)
        let csvDataSourceIndex = this.csvHeaders.findIndex(header => {
            // Trim header, convert to lowercase, and check if it includes "data source name"
            return header.trim().includes('Data Source Name');
        });
        console.log(`CSV Data Source Name Index from CSV Headers: ${csvDataSourceIndex}`);

        // Step 2: Find the index where "csv_data_source_name__c" is selected in comboboxes (Right Side)
        let comboboxDataSourceIndex = -1;
        let dataSourceCombobox = null; // Store the combobox element

        comboboxes.forEach((combobox, i) => {
            if (combobox.value === 'csv_data_source_name__c') {
                comboboxDataSourceIndex = i;
                dataSourceCombobox = combobox;
            }
        });
        console.log(`CSV Data Source Name Index from Comboboxes: ${comboboxDataSourceIndex}`);

        let comboboxDataSourceIndexes = []; // Array to track indices of comboboxes with the value 'csv_data_source_name__c'
        let invalidComboboxes = []; // Array to track comboboxes that need to be invalidated

        comboboxes.forEach((combobox, i) => {  
            if (i === csvDataSourceIndex && combobox.value && combobox.value.includes('csv_data_source_name__c')) {
                // Skip adding this combobox to the validation list
            } 
    
            else if  (combobox.value === 'csv_data_source_name__c') {
                comboboxDataSourceIndexes.push(i);  // Store the index of the combobox with the value 'csv_data_source_name__c'
                invalidComboboxes.push(combobox);  // Store the actual combobox element for invalidation
            }
        });
        console.log(`Indexes of Comboboxes with 'csv_data_source_name__c': ${comboboxDataSourceIndexes}`);
     
        if (comboboxDataSourceIndexes.length >= 1) {
            // If more than one combobox is selected with 'csv_data_source_name__c', invalidate them
            invalidComboboxes.forEach((combobox) => {
                combobox.value = null; // Clear the value
                combobox.setCustomValidity('Incorrect mappings found. Please select the correct field to map Data Source Name.');
                combobox.reportValidity();  // Trigger custom validity message
            });
            this.handleFieldMappingChange(event);
            this.showToast('Error', 'Incorrect Mapping: Please ensure correct mapping for Data Source Name.', 'error');
            this.showLoading = false;
            return;  // 🚨 Stop Execution!
        }


        if (csvDataSourceIndex === -1) {
            console.log('❌ CSV Data Source Name is not mapped!');
            this.showToast('Error', 'The file does not contain a column for "CSV Data Source Name".', 'error');
            this.showLoading = false;
            this.showStep2 = false;
            this.fileName = '';
            return; // 🚨 Stop Execution!
        }

        if(comboboxDataSourceIndex === -1){
            // 🔴 Check if "CSV Data Source Name" is mapped
            let isDataSourceMapped = false;
            isDataSourceMapped = [...selectedSalesforceFieldMap.values()].includes('csv_data_source_name__c'); // Replace with actual API name
            console.log('isDataSourceMapped>>>'+isDataSourceMapped);
            let hasDataSourceError = false;

            if(!isDataSourceMapped){
                hasDataSourceError = true;
            }
            
            if (isDataSourceMapped==false || !isDataSourceMapped) {
                // let hasDataSourceError = false;
                for (let i = 0; i < comboboxes.length; i++) {
                    let combobox = comboboxes[i];
                    console.log('csvdatasourceindex=='+csvDataSourceIndex);
                    if(i==csvDataSourceIndex){
                        console.log('i=='+i);
                        combobox.value = null;
                        combobox.setCustomValidity('You must select a value for "CSV Data Source Name".');
                        hasDataSourceError = true;
                        combobox.reportValidity();
                        this.handleFieldMappingChange(event);
                        break; // ✅ This will exit the loop immediately after setting the error.
                    }
                }
            }
     
            if (hasDataSourceError) {
                this.showToast('Error', 'You must select a value for "CSV Data Source Name".', 'error');
                this.showLoading = false;
                return; // 🚨 Stop Execution!
            }
        }

        let selectedSalesforceFieldMapObj = {};
        selectedSalesforceFieldMap.forEach((value, key) => {
            selectedSalesforceFieldMapObj[key.toString()] = value; // Convert Map to Object
        });
    
        let selectedSalesforceFieldMapJSON = JSON.stringify(selectedSalesforceFieldMapObj);
        // Call Apex method
        insertSObjectData({
            objectName: this.objectName,
            contentDocumentId2: this.documentId,
            selectedSalesforceFieldMap2OjbString: selectedSalesforceFieldMapJSON
        }).then(result => {
            if (result.status) {
                this.showToast('Success', 'Records have been inserted successfully!', 'success');
                this.showLoading = false;
            } 
            else {
                console.error('Insert Error:', JSON.stringify(result));
                console.error('Demo Error:', result.status);
                this.showToast('Error',result.errormessage , result.errormessage);
                this.showLoading = false;
            }
            setTimeout(() => {
                this.showStep2 = false;
                this.fileName = '';  // Clear file name 
            }, 2000); 
        }).catch(error => {
            console.error('Insert Error:', error);
            this.showToast('Error', result.errormessage, result.errormessage);
            this.showLoading = false;
        });
    }
    
    /*       
    * @author      : Coforge
    * @date        : 19/03/2025
    * @description : Method to display Toast message.
    * @return      : None
    * @param       : event
    */

    showToast(title, message, variant) {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant, // Can be 'success', 'error', 'info', 'warning'
            mode: 'dismissable' // You can choose 'dismissable' or 'pester' based on preference
        });
        this.dispatchEvent(event);
    }
    
}