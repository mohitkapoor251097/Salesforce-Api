/*       
    * @author      : Coforge
    * @date        : 08/02/2024
    * @description : ADO-22349 :  Validation of Contact details
                     ADO-26708 : Display logic for My Details ,My Organsiational and IR Group Contact Details
                     ADO-22352 : Navigational buttons consistency
                     ADO-22348 : Modification of existing IR Group Contact
                     ADO-26710 : New IR Dashboard page in LWC including header & footer
                     ADO-27687 : Functionality to edit IR Contact Personal Details.
                     ADO-22338 : Contact Management Privileges for External CP User
                     ADO-22343 : Auto creation of person account based on new org role contact 
                     ADO-22353 : Visibility on Org role holder profile
                     ADO 22354 : Visibility on GIR Org role holder profile
                     ADO-27824 : Feedback User Story Sprint 1&2
                     ADO-27683 : Functionality for "View" button for IR Regulatory Contacts and General IR Contacts Table.
                     ADO-22357 : Periodic validation of contact details.
                     ADO-22355 : Visibility on IR Projects Contacts.
                     ADO-22358 : Navigation to the 'All IR Requests' screen
                     ADO-22359 : Visibility and Actions available for IR Requests related to a CP business account
                     ADO-37141 : My Correspondence Screen
                     ADO-38237 : Prevention of Business Account Address Update from CP 
    */
import { LightningElement, track, api } from 'lwc';
import verifyLoggedInUserAccount from '@salesforce/apex/IR_Utility.verifyLoggedInUserAccount';
import updateIRGroupContact from '@salesforce/apex/IR_Utility.updateIRGroupContact';
import getIROrgRoleDetails from '@salesforce/apex/IR_Utility.getIROrgRoleDetails';
import getIRAccessMatrix from '@salesforce/apex/IR_Utility.getIRAccess';
import getIRCasesList from '@salesforce/apex/IRComCreatePortalUser.getIRCasesList'; //ADO-22355

export default class IRComDashboardScreen extends LightningElement {
    openMandatoryDetailPopUpFlag = true;
    personAccountRecord;

    //26708:- Changes - Start
    orgRoleRecord;
    businessAccountRecordList = [];
    personAccountRecordList = [];
    @track isGroupContactEdit = true;
    @track isGroupContactFieldDisable = true;
    showSpinner; // To show spinner until data is fetched
    @track groupContactName = ' ';
    @track groupContactEmail = ' ';
    IROrgRole = [];
    GIROrgRole = [];
    @track irProjectTableShow=false;// ADO 22355
    irProjects; // ADO 22355
    //26708:- Changes - End
    //22352 - navigation - start
    dashboardscreen = true;
    homebuttondisabled = true;
    iRProjectbuttondisable = false;
    iRprojectscreen = false;
    allIRRequestbuttondisable = false;
    fWSbuttondisable = false;
    myCorrespondencebuttondisable = false;
    rGEiRProjectbuttondisable = false;
    //22352 - navigation - end
    //22358 - start
     iRCaseRequestScreen = false; 
    //22358 - End
    errorMessage; //22348 Error Message Variable
    oldGroupContactName;
    oldGroupContactEmail;

    //ADO-22338:Start
    disableUpdateBAName = false; //not in use
    disableUpdateBAAddress = false;
    disableUpdateOwnDetails = false;
    disableCreateGIRC = false;
    disableEditGIRC = false;
    disableDeleteGIRC = false;
    disableEditIRRC = false;
    disableCreateIRRC = false;
    disableDeleteIRRC = false;
    disableCreateEditMainIRGC = false;
    disableUpdateOtherGIRCContact = false; //not in use
    disableUpdateOtherIRRCContact = false;
    //ADO-22338:End
    //ADO-22359 Start
    hasRelatedCaseAccess = false;
    hasUnrelatedCaseAccess = false;
    //ADO-22359 End
    isIRMyCorrespondenceScreen=false;//ADO 37141

    /*       
    * @author      : Coforge
    * @date        : 08/02/2024
    * @description : ADO-22349: method called on page load to get the IR related data and it's access matrix details
    */
    connectedCallback() {
        try {
            //ADO- 22349 Added changes for Validation of Contact details
            this.verifyLoggedInUserAccountRecord();
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 08/02/2024
    * @description : ADO-22349/22357: Validation of Contact details and Periodic validation of contact details
    */
    verifyLoggedInUserAccountRecord() {
        verifyLoggedInUserAccount()
            .then((result) => {
                for (var key in result) {
                    this.personAccountRecord = result[key];
                    if (key == 'MandatoryDetails' && result[key] != null && result[key] != null) {
                        this.dispatchEvent(new CustomEvent('openUpdateMandatoryDetailsPopup', {
                            detail: { personaccountdata: this.personAccountRecord }
                        }));
                    }else if(key == 'VerifyDetails' && result[key] != null && result[key] != null){
                        this.dispatchEvent(new CustomEvent('openUpdateMandatoryDetailsPopup', {
                            detail: { personaccountdata: this.personAccountRecord,
                                      setVerifyButtonName: 'Verify Contact' }
                        }));
                    }
                }
                if (this.personAccountRecord == null) {
                    return this.getIRRelatedData(); // Fetch IR related data                     
                }
            })
            .catch((error) => {
                window.location.href = '/apex/licensingcomerror';
            });
    }
    
    /*       
    * @author      : Coforge
    * @date        : 29/02/2024
    * @description : ADO 27687 : Functionality to Edit My Details button.
    */
    editMyDetailHandler() {
        try {
            //BUG-52118 Fix Start
            if(this.disableUpdateOwnDetails){
                window.location.href = '/apex/licensingcomerror';
            }//BUG-52118 Fix End
            else if (this.errorMessage != null && (this.errorMessage.includes('Invalid email address') || this.template.querySelector('[data-id="groupEmailId"]').classList.contains('slds-has-error'))) {
                this.groupContactEmail = this.oldGroupContactEmail;
                this.groupContactName = this.oldGroupContactName;
                this.errorMessage = '';   //Removing validation message from UI in the begining to remove existing errors if any
                this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
                this.template.querySelector('[data-id="groupEmailId"]').classList.remove('slds-has-error');
            }else if (this.errorMessage != null && this.errorMessage != '') {
                this.errorMessage = '';
                this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
            }
            this.dispatchEvent(new CustomEvent('openUpdateMandatoryDetailsPopup', {
                detail: { personaccountdata: this.personAccountRecordList[0] }
            }));
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }
    /*       
    * @author      : Coforge
    * @date        : 29/02/2024
    * @description : ADO 27687 : Functionality to edit Address button.
    */
    editAddressHandler() {
        try {
            //BUG-52118 Fix Start
            if(this.disableUpdateBAAddress){
                window.location.href = '/apex/licensingcomerror'; 
            }//BUG-52118 Fix End
            else if(this.errorMessage != null && (this.errorMessage.includes('Invalid email address') || this.template.querySelector('[data-id="groupEmailId"]').classList.contains('slds-has-error'))) {
                this.groupContactEmail = this.oldGroupContactEmail;
                this.groupContactName = this.oldGroupContactName;
                this.errorMessage = '';   //Removing validation message from UI in the begining to remove existing errors if any
                this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
                this.template.querySelector('[data-id="groupEmailId"]').classList.remove('slds-has-error');
            }else if (this.errorMessage != null && this.errorMessage != '') {
                this.errorMessage = '';
                this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
            }
            /* ADO 27824 issetcpflag added*/
            if (this.businessAccountRecordList[0].IsPersonAccount) {
                this.dispatchEvent(new CustomEvent('openUpdateMandatoryDetailsPopup', {
                    detail: {
                        personaccountdata: this.businessAccountRecordList[0],
                        issetcpflag: true
                    }
                }));
            } else {
                this.dispatchEvent(new CustomEvent('openBusinessAccountPopup', {
                    detail: { businessAccountdata: this.businessAccountRecordList[0] }
                }));
            }
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 22/02/2024
    * @description : ADO-22348: Enable edit group contact fields.
    */
    editIRGroupContact() {
        try {
            //BUG-52118 Fix Start
            if(this.disableCreateEditMainIRGC){
                window.location.href = '/apex/licensingcomerror';
            }//BUG-52118 Fix End
            else{
                this.errorMessage = '';
                this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
                this.isGroupContactEdit = false;
                this.isGroupContactFieldDisable = false;
                this.oldGroupContactName = this.template.querySelector(".groupName").value;
                this.oldGroupContactEmail = this.template.querySelector(".groupEmail").value;
            }
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 22/02/2024
    * @description : ADO-22348: Save the group contact fields. 
    */
    saveIRGroupContact() {

        try {
            this.showSpinner = true; // To display the spinner
            var groupEmail = this.template.querySelector(".groupEmail"); // Fetch group email value
            var groupName = this.template.querySelector(".groupName"); // Fetch group name value
            this.groupContactEmail = groupEmail.value;
            this.groupContactName = groupName.value;
            const businessRecCopy = { ...this.businessAccountRecordList[0] }; // Fetch the business account record 

            businessRecCopy.IR_Group_Contact_Email_Address__c = groupEmail.value; // reterive group email value 
            businessRecCopy.IR_Group_Contact_Name__c = groupName.value; // reterive group name value

            updateIRGroupContact({ irGroupAccount: businessRecCopy })
                .then((result) => {
                    // if any error occurred enter in this scope and display the error on UI.
                    if (result) {
                        this.template.querySelector('[data-id="errorMessage"]').classList.add('error');
                        this.template.querySelector('[data-id="groupEmailId"]').classList.add('slds-has-error');  //BUG: 27786 Fix
                        this.errorMessage = result;
                        this.showSpinner = false;
                        this.scrollToTop();  //ADO 27824
                    } else {
                        this.errorMessage = '';   //Removing validation message from UI in the begining to remove existing errors if any
                        this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
                        this.template.querySelector('[data-id="groupEmailId"]').classList.remove('slds-has-error'); //BUG: 27786 Fix
                        this.isGroupContactEdit = true;
                        this.isGroupContactFieldDisable = true; // disable email field  
                        this.showSpinner = false; //Updating business records and hide the spinner
                        window.location.href = '/IRComDashboard';//Bug 29048 Fix
                    }
                })
                .catch((error) => {
                    window.location.href = '/apex/licensingcomerror';
                });
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 22/02/2024
    * @description : ADO-26710: IR Group contact conditional style functionality.
    */

    get getgroupName() {
        return this.isGroupContactEdit ? 'groupName border-hidden' : 'groupName form-control';
    }

    /*       
    * @author      : Coforge
    * @date        : 22/02/2024
    * @description : ADO-26710: IR Group contact conditional style functionality.
    */

    get getgroupEmail() {
        return this.isGroupContactFieldDisable ? 'groupEmail border-hidden' : 'groupEmail form-control';
    }

    /*       
    * @author      : Coforge
    * @date        : 19/02/2024
    * @description : ADO-26708: Fetch IR related org roles and account details.
    */
    getIRRelatedData() {
        try {
            getIROrgRoleDetails()
                .then((result) => {
                    for (var key in result) {
                        if (key == 'SingleTargetIRRecord' && result[key] != null && result[key][0] != null) {
                            this.openMandatoryDetailPopUpFlag = false;
                            this.orgRoleRecord = result[key][0];

                            this.personAccountRecordList.push(this.orgRoleRecord.Contact__r);
                            this.businessAccountRecordList.push(this.orgRoleRecord.Licensee_or_Organisation__r);

                            if (this.orgRoleRecord.Licensee_or_Organisation__r != null && this.orgRoleRecord.Licensee_or_Organisation__r.IR_Group_Contact_Name__c != null) {
                                this.groupContactName = this.orgRoleRecord.Licensee_or_Organisation__r.IR_Group_Contact_Name__c;
                            }

                            if (this.orgRoleRecord.Licensee_or_Organisation__r != null && this.orgRoleRecord.Licensee_or_Organisation__r.IR_Group_Contact_Email_Address__c != null) {
                                this.groupContactEmail = this.orgRoleRecord.Licensee_or_Organisation__r.IR_Group_Contact_Email_Address__c;
                            }
                        }
                        /*Start ADO-22353/22354 */
                        if (key == 'ListTargetIRRecord') {
                            result[key].forEach(orgRole => {
                                if (orgRole.Types__c == 'IR Regulatory Contact') {
                                    this.IROrgRole.push(orgRole);
                                } else if (orgRole.Types__c == 'General IR Contact') {
                                    this.GIROrgRole.push(orgRole);
                                }
                            });
                        } /*End ADO-22353/22354 */
                    }
                    
                    if (this.orgRoleRecord != undefined && this.orgRoleRecord != null) {
                        this.getIRCasesList();//ADO-22355 // It is called to load all related IR project details
                        return this.setAccessMatrix(this.orgRoleRecord.Types__c); //This method is called here to get the org role type at run time i.e. in real time to establish the access matrix for IR
                    }                    
                })
                .catch((error) => {
                    window.location.href = '/apex/licensingcomerror';
                });                
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
        * @author      : Coforge
        * @date        : 23/02/2024
        * @description : ADO-22352: Navigational button functionality
        * @return      : None
        * @param       : None
        * 
        */

    handleNavigation(event) {

          try {
           if (this.errorMessage != null && (this.errorMessage.includes('Invalid email address') || (this.template.querySelector('[data-id="groupEmailId"]')!=null && this.template.querySelector('[data-id="groupEmailId"]').classList.contains('slds-has-error')))) { //ADO-28411
                this.groupContactEmail = this.oldGroupContactEmail;
                this.groupContactName = this.oldGroupContactName;
                this.errorMessage = '';   //Removing validation message from UI in the begining to remove existing errors if any
                this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
                this.template.querySelector('[data-id="groupEmailId"]').classList.remove('slds-has-error');
            }else if (this.errorMessage != null && this.errorMessage != '') {
                this.errorMessage = '';
                this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
            }
            /*ADO-22358 (iRCaseRequestScreen variable added) */ 
            const buttonMappings = {
                'IR Projects': { iRprojectscreen: true, iRProjectbuttondisable: true, dashboardscreen: false, homebuttondisabled: false, allIRRequestbuttondisable: false, fWSbuttondisable: false, myCorrespondencebuttondisable: false, rGEiRProjectbuttondisable: false, iRCaseRequestScreen: false, isIRMyCorrespondenceScreen: false },
                'Home/MyAccount': { iRprojectscreen: false, iRProjectbuttondisable: false, dashboardscreen: true, homebuttondisabled: true, allIRRequestbuttondisable: false, fWSbuttondisable: false, myCorrespondencebuttondisable: false, rGEiRProjectbuttondisable: false, iRCaseRequestScreen: false, isIRMyCorrespondenceScreen: false },
                'All IR Requests': { iRCaseRequestScreen:true, iRprojectscreen: false, iRProjectbuttondisable: false, dashboardscreen: false, homebuttondisabled: false, allIRRequestbuttondisable: true, fWSbuttondisable: false, myCorrespondencebuttondisable: false, rGEiRProjectbuttondisable: false, isIRMyCorrespondenceScreen: false },
                'Forward Looking Schedule': { iRprojectscreen: true, iRProjectbuttondisable: false, dashboardscreen: false, homebuttondisabled: false, allIRRequestbuttondisable: false, fWSbuttondisable: true, myCorrespondencebuttondisable: false, rGEiRProjectbuttondisable: false, iRCaseRequestScreen: false, isIRMyCorrespondenceScreen: false },
                'My Correspondence': { isIRMyCorrespondenceScreen: true, iRprojectscreen: false, iRProjectbuttondisable: false, dashboardscreen: false, homebuttondisabled: false, allIRRequestbuttondisable: false, fWSbuttondisable: false, myCorrespondencebuttondisable: true, rGEiRProjectbuttondisable: false, iRCaseRequestScreen: false },
                'Raise a General Enquiry': { iRprojectscreen: true, iRProjectbuttondisable: false, dashboardscreen: false, homebuttondisabled: false, allIRRequestbuttondisable: false, fWSbuttondisable: false, myCorrespondencebuttondisable: false, rGEiRProjectbuttondisable: true, iRCaseRequestScreen: false, isIRMyCorrespondenceScreen: false }
            };
 
            const changes = buttonMappings[event.target.dataset.id];
 
            if (changes) {
                Object.assign(this, changes);
            }
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
        * @author      : Coforge
        * @date        : 29/02/2024
        * @description : ADO-22338: This method will return IRCom_AccessMatrix__mdt record.
        * @return      : None
        * @param       : event
        */
    setAccessMatrix(orgType) {
        try {
            getIRAccessMatrix({ irOrgRoleType: orgType })
                .then((result) => {
                    this.disableUpdateBAName = !result.Update_Business_Name__c;
                    this.disableUpdateBAAddress = !result.Update_Business_Address__c;
                    this.disableUpdateOwnDetails = !result.Update_Own_Details__c;
                    this.disableCreateGIRC = !result.Create_GIRC_Contact__c;
                    this.disableEditGIRC = !result.Amend_GIRC_Contact__c;
                    this.disableDeleteGIRC = !result.Delete_GIRC_Contact__c;
                    this.disableEditIRRC = !result.Amend_IRRC_Contact__c;
                    this.disableDeleteIRRC = !result.Delete_IRRC_Contact__c;
                    this.disableCreateIRRC = !result.Create_IRRC_Contact__c;
                    this.disableCreateEditMainIRGC = !result.Update_Main_IR_Group_Contact__c;
                    //ADO-22338 Update other contact start
                    this.disableUpdateOtherGIRCContact = !(result.Update_Other_Contact_Details__c && result.Amend_GIRC_Contact__c);
                    this.disableUpdateOtherIRRCContact = !(result.Update_Other_Contact_Details__c && result.Amend_IRRC_Contact__c);
                    //ADO-22338 Update other contact end
                    //ADO-22359 Start
                    this.hasRelatedCaseAccess = result.View_Related_Case__c;
                    this.hasUnrelatedCaseAccess = result.View_Unrelated_Case__c;
                    //ADO-22359 End
                    //ADO-38237 Start
                    if (this.businessAccountRecordList[0].IsPersonAccount) {
                        this.disableUpdateBAAddress = true;
                    }
                    //ADO-38237 End
                    this.showSpinner = false; // To hide spinner
                })
                .catch((error) => {
                    window.location.href = '/apex/licensingcomerror';
                });
        }
        catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 04/02/2024
    * @description : ADO-22343: dispatch custom event and pass details to IRLightningOutCmp
    */
    opencontactpopup(event) {
        try {
            this.dispatchEvent(new CustomEvent('openIRContactPopup', {
                detail: {
                    licenseeId: this.businessAccountRecordList[0].Id,
                    selectedContact: event.detail.selectedContact,
                    contactType: event.detail.contactType
                }
            }));
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 05/03/2024
    * @description : ADO-27824: Dev Review Feedback story for scroll up on error message
    */
    scrollToTop() {
        window.scroll({
            top: 0,
            left: 0,
            behavior: 'smooth'
        });
    }
    /*       
        * @author      : Coforge
        * @date        : 08/03/2024
        * @description :  ADO-27683 : Functionality for "View" button for IR Regulatory Contacts and General IR Contacts Table.
        */
    displayOrgRoleDeletionMsg(event) {

        try {
            if(event.detail.message != '') {
                this.errorMessage = event.detail.message;
                this.template.querySelector('[data-id="errorMessage"]').classList.add('error');
                this.scrollToTop();
            }else if (this.errorMessage != null && (this.errorMessage.includes('Invalid email address') || this.template.querySelector('[data-id="groupEmailId"]').classList.contains('slds-has-error'))) {
                this.groupContactEmail = this.oldGroupContactEmail;
                this.groupContactName = this.oldGroupContactName;
                this.errorMessage = '';   //Removing validation message from UI in the begining to remove existing errors if any
                this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
                this.template.querySelector('[data-id="groupEmailId"]').classList.remove('slds-has-error');
            }else if (this.errorMessage != null && this.errorMessage != '') {
                this.errorMessage = '';
                this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
            }
            else if(event.detail.message == '') {
                this.errorMessage = '';
                this.template.querySelector('[data-id="errorMessage"]').classList.remove('error');
            }
        } catch (e) {
            window.location.href = '/apex/licensingcomerror';
        }
    }

    /*       
    * @author      : Coforge
    * @date        : 16/04/2024
    * @description :  ADO 22355: Visibility on IR Projects Contacts.
    */    
    getIRCasesList() {
        getIRCasesList({ targetAccountId: this.orgRoleRecord.Licensee_or_Organisation__c })
            .then((result) => {
                this.irProjects = result;
                this.irProjectTableShow = true;
            })
            .catch((error) => {
                window.location.href = '/apex/licensingcomerror';
            });
    }
}