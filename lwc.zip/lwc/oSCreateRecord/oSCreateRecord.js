import { LightningElement, api, wire } from 'lwc';
import getFieldsFromMetadata from '@salesforce/apex/OS_MeetingController.getFieldsFromMetadata';
import EMAIL_SUFFIX from '@salesforce/label/c.OfcomEmailSuffix';
import OFCOM_BUSINESS_ACCOUNT_ID from '@salesforce/label/c.OfcomBusinessAccountId';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import COMMON_ERROR from '@salesforce/label/c.CommonError';
//W-002684  start 
import {
    getRecord,
    getFieldValue
} from 'lightning/uiRecordApi';
import NAME_FIELD from '@salesforce/schema/User.Name';
//W-002684 end
export default class CreateRecordComponent extends LightningElement {
    lookupId; //W-002684
    
    @api title;
    @api metadataRecordApiName;
    @api stakeholders = [];
    @api stakeholdertype='';
    //Start for W-002684
    @api relatedname; 
    @api editData; 
    @api iscreate; 
    @api  isedit; 
    //End for W-002684 
    uniqueId;
    isDisableVar= false; // disable submit
    objectApiName = '';
    fields = [];
    taskField = {}; //W-002684
    testvarr='';
    requiredIndex = 1;
    selectedAccount = '';
    userName;
    errclass = '';
   fieldValues = []; //layout-fix
//start for W-002684
@wire(getRecord, { recordId : '$lookupId', fields: [NAME_FIELD]})
    user;

actionName(){
    this.userName = getFieldValue(this.user.data, NAME_FIELD);
}
//end for W-002684
    get stakeholder() {
        const accountOptions=[];
        if (this.stakeholders != null){  //W-002878
            for(const v of this.stakeholders) {
                if (v.StakeholderType__c == 'Stakeholder Organization'){
                    accountOptions.push({ label: v['Account__r.Name'], value: v['Account__c'] });
                    
                }
            }
        }
        return accountOptions.length > 0;
    };


    connectedCallback() {
        
        this.fetchCustomMetadata();
       
    }

    cancelLabel = 'Cancel';
    submitLabel = 'Submit';
   
    
 /*
     * @author      : Coforge
     * @description : This method is used to get the fields from the custom metadatatype
     * @params      : event
     * @return      : NA
     */
    fetchCustomMetadata() {
        getFieldsFromMetadata({
            metadataRecordName: this.metadataRecordApiName
        }).then((result) => {
            try{
                if(result) {
                    this.objectApiName = result.ObjectAPIName__c;
                    this.fields = JSON.parse(result.Fields__c);
                   
                    // start for W-002684
                     if(this.isedit=='EditProp'){
                         this.addEditActionData();
                         
                    }
                  
                    //end for W-002684
                }    
            } catch(e){
                this.showNoRecordsToast(COMMON_ERROR,'error','dismissable');
            }
        })
        .catch((error) => {
            console.log(error);
            this.showNoRecordsToast(COMMON_ERROR,'error','dismissable');
        });
    }
    /*
     * @author      : Coforge
     * @description : This method is used to get the fields from the custom metadatatype
     * @params      : event
     * @return      : NA
     */
    addEditActionData(){
         if(this.editData.Action_Owner__c!=undefined){
            this.lookupId = (this.editData.Action_Owner__c).toString();
         }
         for(const item of this.fields){
            let rowKeys = Object.values(item);
            
            if(rowKeys[0]=='Action_Owner__c'){
              this.taskField['Action_Owner__c'] = this.editData.Action_Owner__c==undefined ? '' : this.editData.Action_Owner__c;
              item['val'] = this.editData.Action_Owner__c==undefined ? '' : this.editData.Action_Owner__c ;
             
             }
             if(rowKeys[0]=='Action_Description__c'){
                 this.taskField['Action_Description__c'] = this.editData.Action_Description__c;
                 item['val'] = this.editData.Action_Description__c;
             }
             if(rowKeys[0]=='Due_Date__c'){
               this.taskField['Due_Date__c'] = this.editData.Due_Date__c; 
               item['val']= this.editData.Due_Date__c;
             }
         
        }
    }
    

    handleAccountSelection(event) {
        this.selectedAccount = event.detail;
        this.isDisableVar=false;
    }
    handle_Submit_Click(event){
        console.log('inside before submit');
        let isChildValidated = true;
        [...this.template.querySelectorAll("c-o-s-show-stakeholder-organization")].forEach((element) =>{
        if(element.checkValidity() === false){
            isChildValidated = false;
        }
      
        });
        
      
    }
 /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This method is used to save the record
     * @params      : event
     * @return      : NA
     */
    handleSubmit(event) {
        try{
            console.log('Inside submit part--');
        //W-002684 start
        if(this.relatedname=='Actions'){
          
            return true;
        }
        //W-002684 end
            this.isDisableVar=true; //test
            event.stopPropagation()
            event.preventDefault();
            const inputFields = event.detail.fields;
            if(this.stakeholdertype!= 'Stakeholder Organization'){ //added if condition for W-002653
                if(this.selectedAccount) {
                    inputFields.AccountId = this.selectedAccount;
                } else if(this.stakeholdertype === 'Ofcom Participant') {
                    inputFields.AccountId = OFCOM_BUSINESS_ACCOUNT_ID;
                  }
              
                 else  {
                    this.dispatchEvent(new ShowToastEvent({ title: 'Please select Account', variant: 'error', mode: 'dismissable' }));
                    return;
                 }

                 if('Ofcom Participant' === this.stakeholdertype) {
                     //fix
                     let email;
                   
                     if(inputFields.FirstName==null){
                         email = ['', inputFields.LastName.replaceAll(" ","")].filter(Boolean).join("") + EMAIL_SUFFIX;
                     }
                     else  {
                     email = [inputFields.FirstName.replaceAll(" ","") || '', inputFields.LastName.replaceAll(" ","")].filter(Boolean).join(".") + EMAIL_SUFFIX;   
                     }
                    inputFields.Email = email;
                    inputFields.Ofcom_Employee__c = true;
                    inputFields.Team_Name__c =  inputFields.Team_Name__c;
                 }
                 // ADO -16070 Added Preffered language field input
                if('Stakeholder Lead' === this.stakeholdertype || 'Stakeholder Participant' === this.stakeholdertype) {
                    inputFields.Preferred_language__c =  inputFields.Preferred_language__c;
                 }
            }
            
            this.template.querySelector('[data-id="createContactForm"]').submit(inputFields);
            this.fieldValues.push(inputFields);
           
            
        } catch(e){
			console.log('Inside exception-',e);	
            this.showNoRecordsToast(COMMON_ERROR,'error','dismissable');
        }
    }
 /*
     * @author      : Coforge
     * @description : This method executes after the successfull record creation
     * @params      : event
     * @return      : NA
     */
    handleSuccess(event) {
        try{
        //W-002684 start
        if(this.relatedname=='Actions'){
            return true;
        }
        //W-002684 end
            event.stopPropagation()
            event.preventDefault();
            this.recordId = event.detail.id;  

            if(event.detail.id) {
                if(this.stakeholdertype == 'Stakeholder Lead' || this.stakeholdertype == 'Stakeholder Participant' || this.stakeholdertype == 'Ofcom Participant'
                ){ 
                        const fields = event.detail.fields;
                       //fix start
                        let ofcomEmail;
                        if('Ofcom Participant' === this.stakeholdertype){
                            if(fields.FirstName.value==null){
                                ofcomEmail = ['', fields.LastName.value.replaceAll(" ","")].filter(Boolean).join("") + EMAIL_SUFFIX;
                            }
                            else {
                                ofcomEmail = [fields.FirstName.value.replaceAll(" ","") || '', fields.LastName.value.replaceAll(" ","")].filter(Boolean).join(".") + EMAIL_SUFFIX;   
                            }
                        }
                        const email = 'Ofcom Participant' === this.stakeholdertype ? ofcomEmail : fields.Email.value;
                        //fix end
                        const fullName = [fields.Salutation.value, fields.FirstName.value, fields.MiddleName.value, fields.LastName.value].filter(Boolean).join(" ");
                       
                        const data = [{
                        Name: fullName,
                        'Account.Name': 'Ofcom Participant' === this.stakeholdertype ? '' : fields.Account.value.fields.Name.value,
                       'Team_Name__c': 'Ofcom Participant' !== this.stakeholdertype ? '' :  this.fieldValues[0].Team_Name__c, //Added for W-002672 //layout-fix
                        'JobTitle__c':  this.fieldValues[0].JobTitle__c, //layout-fix
                        'Email': email,
                        'Id': event.detail.id,
                        'Account.Id': fields.AccountId.value,
                        'Preferred_language__c' : 'Ofcom Participant' === this.stakeholdertype ? '' : this.fieldValues[0].Preferred_language__c //// ADO -16070 Added Preffered language
                        }];
                        this.dispatchEvent(new CustomEvent('submit', { detail : data}));
                        }
                       //start for W-002653
                       //Sending created account data to meeting component
                       else if(this.stakeholdertype == 'Stakeholder Organization'){
                            const fields = event.detail.fields;
                            
                            const data = [{
                            Name: fields.Name.value, 
                            'Address__c' : [fields.BillingStreet.value, fields.BillingCity.value ,', ', fields.BillingState.value , ' ', fields.BillingPostalCode.value, fields.BillingCountry.value].filter(Boolean).join(""),
                            'Id': event.detail.id
                             }];
                            
                            this.dispatchEvent(new CustomEvent('submit', { detail : data}));
                       }
                       //end for W-002653
                    else{
                        const fields = event.detail.fields;
                        this.dispatchEvent(new CustomEvent('submit', { detail : fields}));
                    }
                }
                this.showNoRecordsToast('Record created successfully.','success','dismissable');
        } catch(e){
           console.log('create contact excep-');
           console.log('Create-');
            this.showNoRecordsToast(COMMON_ERROR,'error','dismissable');
        }
    }
/*
     * @author      : Shabana-Coforge
     * @description : This method will handle the error
     * @params      : event
     * @return      : NA
     */
    handleError(event){
        //W-002684 start
        if(this.relatedname=='Actions'){
            return true;
        }
        //W-002684 end
        const errlog = event.detail.detail;
        if(errlog.includes("href=")){
            let countryListUrl = errlog.substr(errlog.indexOf("href=")+5);
            countryListUrl = countryListUrl.slice(0,countryListUrl.indexOf("target=")-2);
            let urlLabel = errlog.substr(errlog.indexOf("_blank")+8);
            urlLabel = urlLabel.slice(0,urlLabel.indexOf("</a>"));
            const event = new ShowToastEvent({
                "title": "Invalid Country Name!",
                "message": "{0}",
                variant: 'error',
                mode: 'dismissable',
                "messageData": [
                    {
                        url: countryListUrl,
                        label: urlLabel,
                        target: '_blank'
                    }
                ]
            });
            this.dispatchEvent(event);
        }else{
            this.showNoRecordsToast(errlog,'error','dismissable');
        }
        
    }
 /*
     * @author      : Coforge
     * @description : This method will raise the close event
     * @params      : event
     * @return      : NA
     */
    handleCancel(event) {
      this.dispatchEvent(new CustomEvent('close', {}));
    }

    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : To show the toast message for success and error 
     * @params      : title
     * @params      : variant
     * @params      : mode
     * @return      : NA
     */
    showNoRecordsToast(title,variant,mode) {
        const event = new ShowToastEvent({
            title: title,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(event);
    }
    //test
     enableSubmit(){
         this.isDisableVar = false;
     }
    
     /*
     * @author      : Coforge
     * @date        : 
     * @description : To set relatedname variable true (W-002684)
     * @params      : 
     * @params      : 
     * @params      : 
     * @return      : NA
     */
     get RelatedNames(){
        if(this.relatedname=='Actions'){
            
          return true;
        }
        else{
          return false;
        }
     }
     /*
     * @author      : Coforge
     * @date        : 
     * @description : This will execute on onchange event on Action related list (W-002684)
     * @params      : 
     * @params      : 
     * @params      : 
     * @return      : NA
     */
     handleChangeAction(event){
        this.taskField[event.target.name] = event.detail.value;
        if(this.lookupId!=(this.taskField['Action_Owner__c'])){
            // As we are not getting wired data inside submit so we are initializing lookupId here.
            this.lookupId = (this.taskField['Action_Owner__c']).toString();  
        }
    }
     /*
     * @author      : Coforge
     * @date        : 
     * @description : This will throw custom validation
     * @params      : 
     * @params      : 
     * @params      : 
     * @return      : NA
     */
    
    isFieldRequired(){
        let isRequiredEmpty = true;
        this.template.querySelectorAll('lightning-input-field').forEach(element => {
        if(element.reportValidity()==false){
            isRequiredEmpty = false;
        }
        });
        return isRequiredEmpty;
       
    }
    /*
     * @author      : Coforge
     * @date        : 
     * @description : This will submit the action details and send to related list (W-002684)
     * @params      : 
     * @params      : 
     * @params      : 
     * @return      : NA
     */
     handleAddAction(){
        if(this.isFieldRequired()==false){ //validation check
            return true;
        }
         this.actionName(); //to get ActionOwnerName
       if(this.taskField['Action_Owner__c']==''){ //if ownerId is blank then Action Owner name should be blank
          this.userName= '';
       }
        var current = new Date();
        let data;
        if(this.isedit=='EditProp'){ //To send existing unique key while updating data
            data = [{
            'Action_Owner__c' : this.taskField['Action_Owner__c'],
            'Action_Description__c' : this.taskField['Action_Description__c'],
            'Due_Date__c'  : this.taskField['Due_Date__c'],
             'UniqueId' : this.editData.UniqueId,
             'ActionName' : this.userName,
             'Id' : this.editData.Id === null ? '' : this.editData.Id
              }];
        }
        else if(this.isedit!='EditProp'){ //Creating unique id while inserting data
          data = [{
            'Action_Owner__c' : this.taskField['Action_Owner__c'],
            'Action_Description__c' : this.taskField['Action_Description__c'],
            'Due_Date__c' : this.taskField['Due_Date__c'],
             'UniqueId' : current.toLocaleString(),
             'ActionName' : this.userName
              }];
        }
   
     this.dispatchEvent(new CustomEvent('submit', { detail : data}));
    
     
      }
      
    
     
}