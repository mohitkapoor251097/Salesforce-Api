import { LightningElement , api, wire} from 'lwc';
import caseSubmitForReview from '@salesforce/apex/RFICaseAdditionalInfoSubmitController.caseSubmitForReview';
import { CloseActionScreenEvent } from 'lightning/actions';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { CurrentPageReference } from 'lightning/navigation';
import RFI_Record_Submitted_Successfully from '@salesforce/label/c.RFI_Record_Submitted_Successfully';
import RFI_Case_Additional_Information_Submitted_Msg from '@salesforce/label/c.RFI_Case_Additional_Information_Submitted_Msg';
import { NavigationMixin } from 'lightning/navigation'; //Added by Abhinav -Feedback point S&T-4
const DISMISSABLE_LABEL= 'dismissable';
const SUCCESS_LABEL = 'success';
const ERROR_LABEL = 'error';

export default class RfiCaseAdditionalInfoSubmit extends NavigationMixin(LightningElement) {
    label={
        RFI_Case_Additional_Information_Submitted_Msg,
        RFI_Record_Submitted_Successfully
    };
    @api recordId;
    isSpinner = false;
    message;

    /*
    * @author      : Coforge
    * @date        : 02/01/2025
    * @description : This method is used to set the record Id.
    * @params      : CurrentPageReference
    * @return      : none
    */
    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        if (currentPageReference) {
            this.recordId = currentPageReference.state.recordId;
        }
    }

    /*
    * @author      : Coforge
    * @date        : 02/01/2025
    * @description : This method is used to update case lifecyle and owner along with the mandatory field check.
    * @params      : none
    * @return      : none
    */
            caseInfoSubmitForReview() {
                this.isSpinner = true;
                // This method is used to validate the mandatory fields first
                    caseSubmitForReview({ recordId: this.recordId })
                    .then((result) => {
                        if (result && result == this.label.RFI_Record_Submitted_Successfully){
                            this.isSpinner = false;

                            this.showNoRecordsToast(this.label.RFI_Record_Submitted_Successfully,SUCCESS_LABEL,DISMISSABLE_LABEL);
                            this.dispatchEvent(new CloseActionScreenEvent());


                        //Navigating to the list view
                            this[NavigationMixin.Navigate]({
                                    type: 'standard__objectPage',
                                    attributes: {
                                        objectApiName: 'Case',
                                        actionName: 'list'
                                    },
                                    state: {
                                        filterName: 'Recent'
                                    },
                });

                   // setTimeout(() => {window.location.reload();}, 2000);
                }else{
                    this.isSpinner = false;
                    this.message = result;
                    this.showNoRecordsToast(result,ERROR_LABEL,DISMISSABLE_LABEL);
                    this.dispatchEvent(new CloseActionScreenEvent());

                }
            })   
            .catch((error) => {
                this.isSpinner = false;
                this.message = error.body.message;
                this.showNoRecordsToast(error.body.message,ERROR_LABEL,DISMISSABLE_LABEL);
                    
            });
    }


    /*
    * @author      : Coforge
    * @date        : 02/01/2025
    * @description : This method is used to Close the modal.
    * @params      : none
    * @return      : none
    */
    closeModal() {
        this.dispatchEvent(new CloseActionScreenEvent());
    }

    /*
     * @author      : Coforge
     * @date        : 02/01/2025
     * @description : To show the toast message for success and error 
     * @params      : title
     * @params      : variant
     * @params      : mode
     * @return      : NA
     */
    showNoRecordsToast(title,variant,mode) {
        const event = new ShowToastEvent({
            title: title,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(event);
    }
}