/*********************************************************************
# File......................: midComNiicsFormScreen
# Version...................: 1.0
# Created by................: Coforge
# Last Modified Date........: Nov 27, 2024
# Description...............: This LWC will be used to display NIICS Return form.
# Change Log................: V1.0 : Initially version : ADO41132: MID NIICS 09: Ability to provide NIICS details for parent and child(s) accounts (Dropdown for Parent child and Ability to display their data)
                            : V1.1 : ADO41133: MID NIICS 10: Ability to enter the data for the NIICS Type (Save button functionality)
                            : V1.2 : ADO41134: MID NIICS 11: Ability to view the sum of rows & ADO41135: MID NIICS 12: Ability to view the column total
                            : V1.3 : ADO41130: MID NIICS 07: Ability to view NIICS Return details in read only mode and generate PDF from Ofcom Portal
                            : V1.4 : ADO41136: MID NIICS 13: Ability to Save and Submit the NIICS Return details from Ofcom Portal (Ready to submit, Re-open button functionality)
**********************************************************************/
import { LightningElement, api } from 'lwc';
import fetchRecordById from '@salesforce/apex/MIDAuraUtility.getRecordById';
import manipulateRecord from '@salesforce/apex/MIDAuraUtility.manipulateRecord'; // ADO41133 change
import verifyCommunityUser from '@salesforce/apex/MIDAuraUtility.verifyCommunityUser'; // ADO41130 change
import resourceMIDReturn from '@salesforce/resourceUrl/MID_Returns';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader'; // ADO41134 & ADO41135 change

export default class MidComNiicsFormScreen extends LightningElement {
    @api readOnlyMode;
    @api retURL;
    @api wSchedule;
    @api ispdf; // ADO41130 change
    @api niicsRecId; // ADO41130 change
    niicsReturnDetailRec;
    niicsReturnDetailRecClone; // ADO41136 change
    showSpinner=true;
    selectService = [];
    wScheduleRec;
    selectedService = '';
    hasModifyPermission;
    hasSubmitPermission;
    hasViewPermission;
    isUploadable;
    schedule;
    status;
    withinValidSubmissionPeriod;
    displayReadytoSubmit; // ADO41136 change
    displayReopen; // ADO41136 change
    displaySubmitReturn; // ADO41136 change
    displayButtons; // ADO41136 change
    isDropdownChanged; // ADO41133 change
    displayErrorBox;
    counter = 0;  // ADO41134 & ADO41135 change 
    calcs = { "Total_active_users__c": 0, "Total_nmbr_residential_calls__c": 0, "Total_nmbr_business_calls__c": 0, "Total_nmbr_video_calls_by_customer_type__c": 0, "Total_nmbr_voice_calls_by_customer_type__c": 0, "Total_residential_call_mins__c": 0, "Total_business_call_mins__c": 0, "Total_video_call_mins_by_customer_type__c": 0, "Total_voice_call_mins_by_customer_type__c": 0, "Total_nmbr_calls_via_mobile_app__c": 0, "Total_nmbr_calls_via_desktop_app__c": 0, "Total_nmbr_calls_via_other__c": 0, "Total_nmbr_video_calls_by_app_type__c": 0, "Total_nmbr_voice_calls_by_app_type__c": 0, "Total_nmbr_calls_with_2_participants__c": 0, "Total_nmbr_calls_with_X2_participants__c": 0, "Total_nmbr_video_calls_by_participants__c": 0, "Total_nmbr_voice_calls_by_participants__c": 0, "Total_nmbr_messages_by_customer_type__c": 0, "Total_nmbr_messages_by_app_type__c": 0, "Total_nmbr_messages_by_message_type__c": 0, "Total_nmbr_messages_by_recipients__c": 0, "Total_nmbr_calls_by_customer_type__c": 0, "Total_call_mins_by_customer_type__c": 0, "Total_nmbr_calls_by_app_type__c": 0, "Total_nmbr_calls_by_participants__c": 0}; // ADO41134 & ADO41135 change
    calcMap = new Map([
        ['Total_active_users__c', ['Residential_active_users__c', 'Business_active_users__c']],
        ['Total_nmbr_residential_calls__c', ['Nmbr_residential_video_calls__c', 'Nmbr_residential_voice_calls__c']],
        ['Total_nmbr_business_calls__c', ['Nmbr_business_video_calls__c', 'Nmbr_business_voice_calls__c']],
        ['Total_nmbr_video_calls_by_customer_type__c', ['Nmbr_residential_video_calls__c', 'Nmbr_business_video_calls__c']],
        ['Total_nmbr_voice_calls_by_customer_type__c', ['Nmbr_residential_voice_calls__c', 'Nmbr_business_voice_calls__c']],
        ['Total_residential_call_mins__c', ['Residential_video_call_mins__c', 'Residential_voice_call_mins__c']],
        ['Total_business_call_mins__c', ['Business_video_call_mins__c', 'Business_voice_call_mins__c']],
        ['Total_video_call_mins_by_customer_type__c', ['Residential_video_call_mins__c', 'Business_video_call_mins__c']],
        ['Total_voice_call_mins_by_customer_type__c', ['Residential_voice_call_mins__c', 'Business_voice_call_mins__c']],
        ['Total_nmbr_calls_via_mobile_app__c', ['Nmbr_video_calls_via_mobile_app__c', 'Nmbr_voice_calls_via_mobile_app__c']],
        ['Total_nmbr_calls_via_desktop_app__c', ['Nmbr_video_calls_via_desktop_app__c', 'Nmbr_voice_calls_via_desktop_app__c']],
        ['Total_nmbr_calls_via_other__c', ['Nmbr_video_calls_via_other__c', 'Nmbr_voice_calls_via_other__c']],
        ['Total_nmbr_video_calls_by_app_type__c', ['Nmbr_video_calls_via_mobile_app__c', 'Nmbr_video_calls_via_desktop_app__c', 'Nmbr_video_calls_via_other__c']],
        ['Total_nmbr_voice_calls_by_app_type__c', ['Nmbr_voice_calls_via_mobile_app__c', 'Nmbr_voice_calls_via_desktop_app__c', 'Nmbr_voice_calls_via_other__c']],
        ['Total_nmbr_calls_with_2_participants__c', ['Nmbr_video_calls_with_2_participants__c', 'Nmbr_voice_calls_with_2_participants__c']],
        ['Total_nmbr_calls_with_X2_participants__c', ['Nmbr_video_calls_with_X2_participants__c', 'Nmbr_voice_calls_with_X2_participants__c']],
        ['Total_nmbr_video_calls_by_participants__c', ['Nmbr_video_calls_with_2_participants__c', 'Nmbr_video_calls_with_X2_participants__c']],
        ['Total_nmbr_voice_calls_by_participants__c', ['Nmbr_voice_calls_with_2_participants__c', 'Nmbr_voice_calls_with_X2_participants__c']],
        ['Total_nmbr_messages_by_customer_type__c', ['Nmbr_residential_messages__c', 'Nmbr_business_messages__c']],
        ['Total_nmbr_messages_by_app_type__c', ['Nmbr_messages_via_a_mobile_app__c', 'Nmbr_messages_via_a_desktop_app__c', 'Nmbr_messages_via_other__c']],
        ['Total_nmbr_messages_by_message_type__c', ['Nmbr_Basic_text_messages__c', 'Nmbr_enhanced_messages__c']],
        ['Total_nmbr_messages_by_recipients__c', ['Nmbr_messages_with_1_recipient__c', 'Nmbr_messages_with_X1_recipient__c']],
        ['Total_nmbr_calls_by_customer_type__c', ['Total_nmbr_residential_calls__c', 'Total_nmbr_business_calls__c']],
        ['Total_call_mins_by_customer_type__c', ['Total_residential_call_mins__c', 'Total_business_call_mins__c']],
        ['Total_nmbr_calls_by_app_type__c', ['Total_nmbr_calls_via_mobile_app__c', 'Total_nmbr_calls_via_desktop_app__c', 'Total_nmbr_calls_via_other__c']],
        ['Total_nmbr_calls_by_participants__c', ['Total_nmbr_calls_with_2_participants__c', 'Total_nmbr_calls_with_X2_participants__c']]
    ]); // ADO41134 & ADO41135 change

    /*
    * @author      : Coforge
    * @date        : Nov 07, 2024
    * @description : ADO41132: MID NIICS 09: Ability to provide NIICS details for parent and child(s) accounts (Dropdown for Parent child and Ability to display their data)
    */
    connectedCallback() {
        
        loadStyle(this, resourceMIDReturn + '/MID_Returns/style/MIDReturnLWC.css');
        
        try {
            this.showSpinner = true;
            let selectServiceParent = [];
            let selectServiceChild = [];
            const map = new Map();
            this.displayErrorBox = false;
            
            this.wScheduleRec = JSON.parse(this.wSchedule);

            Object.keys(this.wScheduleRec).forEach((key) => {
                switch (key) {
                    case 'hasModifyPermission':
                        this.hasModifyPermission = this.wScheduleRec[key];
                    break;
                    case 'hasSubmitPermission':
                        this.hasSubmitPermission = this.wScheduleRec[key];
                    break;
                    case 'hasViewPermission':
                        this.hasViewPermission = this.wScheduleRec[key];
                    break;
                    case 'isUploadable':
                        this.isUploadable = this.wScheduleRec[key];
                    break;
                    case 'schedule':
                        this.schedule = this.wScheduleRec[key];
                    break;
                    case 'status':
                        this.status = this.wScheduleRec[key];
                    break;
                    case 'withinValidSubmissionPeriod':
                        this.withinValidSubmissionPeriod = this.wScheduleRec[key];
                    break;
                    default:
                    break;
                }
            });
            /* ADO41136 change start */
            if(this.readOnlyMode){
                this.displayButtons = false;
            }
            else{
                this.displayButtons = true;
                this.displayReadytoSubmit = (this.status == 'In progress') ? true : false;
                this.displayReopen = (this.hasModifyPermission && this.status == 'Ready to submit') ? true : false;
                this.displaySubmitReturn = (this.hasSubmitPermission && this.status == 'Ready to submit') ? true : false;
                this.readOnlyMode = !this.displayReadytoSubmit;
            }
            /* ADO41136 change end */
            let parentChildAccMap;
            fetchRecordById({ recordId: this.schedule.Id })
            .then(data => {
                parentChildAccMap = JSON.parse(data);
                Object.keys(parentChildAccMap).forEach((key) => {
                    map.set(key, parentChildAccMap[key]);
                });
                for(const [key, value] of map) {
                    if(key == 'ParentAccount') {
                        if(value != undefined && value != null && value != ''){
                            value.forEach(val => {
                                selectServiceParent.push({
                                    value: val.Id,
                                    label: val.Service_Name__c
                                });
                                this.selectedService = val.Id;
                            });
                        }
                    }
                    else if(key == 'ChildAccount') {
                        if(value != undefined && value != null && value != ''){
                            value.forEach(val => {
                                selectServiceChild.push({
                                    value: val.Id,
                                    label: val.Service_Name__c
                                });
                            });
                        }
                    }
                }
                
                this.selectService = selectServiceParent.concat(selectServiceChild);
                if(this.selectService.length > 0){ /* ADO41130 changes start */
                    if(this.ispdf && this.niicsRecId != undefined && this.niicsRecId != null && this.niicsRecId != ''){
                        this.selectedService =  this.niicsRecId;
                        let selectServiceindx = this.selectService.findIndex(item => item.value == this.selectedService); 
                        let dummyArr = [];
                        dummyArr.push(this.selectService[selectServiceindx]);
                        this.selectService = dummyArr;
                    }
                    else {
                        this.selectedService =  this.selectService[0].value;
                    } /* ADO41130 changes end */
                    this.fetchNiicsReturnDetails();
                }
                else{
                    this.displayErrorBox = true;
                    this.dispatchEvent(new CustomEvent('hideStatusCmp'));
                    /* ADO41136 change start */
                    this.schedule['Status__c'] = 'Not started';
                    manipulateRecord({ 
                        recordStr : JSON.stringify(this.schedule),
                        sObjectName : 'Return_Schedule__c'
                    })
                    .then(result => {})
                    .catch(error => {
                        this.exceptionFunction('connectedcallback manipulateRecord', error);
                    });
                    /* ADO41136 change end */
                }
                this.showSpinner=false;
            })
            .catch(error => {
                this.exceptionFunction('connectedCallback fetchRecordById', error);
            });
        }
        catch(e){
            this.exceptionFunction('connectedCallback', e);
        }
    }

    /*
    * @author      : Coforge
    * @date        : Nov 27, 2024
    * @description : ADO41130: MID NIICS 07: Ability to view NIICS Return details in read only mode and generate PDF from Ofcom Portal
    */
    renderedCallback() {
        if(this.ispdf && this.niicsReturnDetailRec != undefined && this.niicsReturnDetailRec != null && this.niicsReturnDetailRec != ''){
            this.adjustTextareaHeight();
            this.printhandler();
        }
    }

    /*
    * @author      : Coforge
    * @date        : Dec 11, 2024
    * @description : This method will be used to adjust the height of textarea elements.
    */
    adjustTextareaHeight() {
        const textareas = this.template.querySelectorAll('[class="commentText"]');
        if(textareas){
            textareas.forEach( textarea => {
                var txtarea = this.template.querySelector('[data-id="'+ textarea.name +'"]');
                let scrollHeight = txtarea.scrollHeight + 2;
                
                switch (textarea.name) {  // making static because this.refs is not iterable
                    case 'Active_user_comments__c':
                        this.refs.Active_user_comments__c.style.height = `${scrollHeight}px`;
                    break;
                    case 'Nmbr_calls_by_customer_type_comments__c':
                        this.refs.Nmbr_calls_by_customer_type_comments__c.style.height = `${scrollHeight}px`;
                    break;
                    case 'Call_mins_by_customer_type_comments__c':
                        this.refs.Call_mins_by_customer_type_comments__c.style.height = `${scrollHeight}px`;
                    break;
                    case 'Calls_by_app_type_comments__c':
                        this.refs.Calls_by_app_type_comments__c.style.height = `${scrollHeight}px`;
                    break;
                    case 'Calls_by_participants_comments__c':
                        this.refs.Calls_by_participants_comments__c.style.height = `${scrollHeight}px`;
                    break;
                    case 'Messages_by_recipients_comments__c':
                        this.refs.Messages_by_recipients_comments__c.style.height = `${scrollHeight}px`;
                    break;
                    default:
                    break;
                }
            });
        }
    }

    /*
    * @author      : Coforge
    * @date        : Nov 07, 2024
    * @description : ADO41132: MID NIICS 09: Ability to provide NIICS details for parent and child(s) accounts (Dropdown for Parent child and Ability to display their data)
    */
    fetchNiicsReturnDetails() {
        fetchRecordById({ recordId: this.selectedService })
        .then(data => {
            this.niicsReturnDetailRec = JSON.parse(data);
            this.niicsReturnDetailRecClone = JSON.parse(data); // ADO41136 change
            /* ADO41134 & ADO41135 change start */
            for(const [key, value] of this.calcMap){
                this.calcs[key] = this.niicsReturnDetailRecClone[key]; // ADO41136 change
                this.calcs[key] = new Intl.NumberFormat('en-GB').format(this.calcs[key]); // ADO41136 change
            }
            this.counter += 1;
            /* ADO41134 & ADO41135 change end */
            /* ADO41136 change start */
            for(let f in this.niicsReturnDetailRec) {
                if(typeof this.niicsReturnDetailRec[f] === 'number'){
                    this.niicsReturnDetailRec[f] = new Intl.NumberFormat('en-GB').format(this.niicsReturnDetailRec[f]);
                }
                if(this.niicsReturnDetailRec[f] == 'undefined'){
                    this.niicsReturnDetailRec[f] = null;
                }
            }
            /* ADO41136 change start */
            let textareas = this.template.querySelectorAll('[class="commentText"]');
            if(textareas){
                textareas.forEach( textarea => {
                    var txtarea = this.template.querySelector('[data-id="'+ textarea.name +'"]');
                    txtarea.value = this.niicsReturnDetailRec[textarea.name];
                });
            }
        })
        .catch(error => {
            this.exceptionFunction('fetchNiicsReturnDetails', error);
        });
    }

    /*
    * @author      : Coforge
    * @date        : Nov 07, 2024
    * @description : ADO41132: MID NIICS 09: Ability to provide NIICS details for parent and child(s) accounts (Dropdown for Parent child and Ability to display their data)
    */
    regexTest(event) {
        if(!(event.keyCode >= 48 && event.keyCode <= 57)) {
            event.preventDefault();
        }
    }

    /*
    * @author      : Coforge
    * @date        : Jan 03, 2025
    * @description : This method is used to allow pasting of only numbers.
    */
    avoidPasting(event){
        let clipboardData = event.clipboardData || window.clipboardData;
        let pastedData = clipboardData.getData('text');
        pastedData = pastedData.substring(0,15);
        var thenum = pastedData.replace(/\D/g,'');
        if(!isNaN(Number(thenum)) && Number(thenum) > 0) {
            // do nothing
        }
        else {
            event.preventDefault();
        }
    }

    /*
    * @author      : Coforge
    * @date        : Dec 10, 2024
    * @description : this method is used to avoid the enter key input.
    */
    avoidNewLine(event){
        if(event.keyCode == 13) {
            event.preventDefault();
        }
    }

    /*
    * @author      : Coforge
    * @date        : Nov 27, 2024
    * @description : ADO41136: MID NIICS 13: Ability to Save and Submit the NIICS Return details from Ofcom Portal (Ready to submit, Re-open button functionality)
    */
    convertNumber(event) {
        let value = event.target.value;
        let name = event.target.name;
        value = value.replaceAll(',','');
        if(value != null && value != ''){
            this.niicsReturnDetailRec[name] = value;
        }
        this.counter += 1;
    }

    /*
    * @author      : Coforge
    * @date        : Nov 07, 2024
    * @description : ADO41132: MID NIICS 09: Ability to provide NIICS details for parent and child(s) accounts (Dropdown for Parent child and Ability to display their data)
    */
    fetchProvidedValues(event){
        let fieldAPI = event.target.name;
        let fieldValue = event.target.value;

        if(fieldAPI === 'ServiceDropdown__c') {
            this.selectedService = fieldValue;
            this.isDropdownChanged = true;
            this.saveData(event); // ADO41133 change
            return;
        }
        else if(typeof this.niicsReturnDetailRecClone[fieldAPI] === 'string'){ // ADO41136 change
            this.niicsReturnDetailRecClone[fieldAPI] = fieldValue; // ADO41136 change
            this.niicsReturnDetailRec[fieldAPI] = fieldValue;
        }
        else if(typeof this.niicsReturnDetailRecClone[fieldAPI] === 'object' || typeof this.niicsReturnDetailRecClone[fieldAPI] === 'number'){ // ADO41136 change
            if(fieldValue.length == 0){
                this.niicsReturnDetailRecClone[fieldAPI] = null; // ADO41136 change
                this.niicsReturnDetailRec[fieldAPI] = null;    
            }
            else{
                fieldValue = fieldValue.replace(/\D/g,'');
                this.niicsReturnDetailRecClone[fieldAPI] = Number(fieldValue); // ADO41136 change
                this.niicsReturnDetailRec[fieldAPI] = Number(fieldValue);
            }
        }
    }

    /*
    * @author      : Coforge
    * @date        : Nov 07, 2024
    * @description : ADO41132: MID NIICS 09: Ability to provide NIICS details for parent and child(s) accounts (Dropdown for Parent child and Ability to display their data)
    */
    handleValueChange(event){
        try{
            this.fetchProvidedValues(event);
            /* ADO41134 & ADO41135 change start */
            loadScript(this, resourceMIDReturn + '/MID_Returns/script/MIDReturnLWC.js')
            .then(() => {
                for(const [key, value] of this.calcMap) {
                    if(window.performCalculations){
                        this.calcs[key] = window.performCalculations(this.niicsReturnDetailRecClone, value, '+'); // ADO41136 change
                        this.niicsReturnDetailRecClone[key] = this.calcs[key]; // ADO41136 change
                        this.niicsReturnDetailRec[key] = this.calcs[key];
                        this.calcs[key] = new Intl.NumberFormat('en-GB').format(this.calcs[key]); // ADO41136 change
                    }
                    this.counter += 1;
                }
            })
            .catch(error => {
                this.exceptionFunction('Calculations', error);
            });
            /* ADO41134 & ADO41135 change end */
        }
        catch(ex){
            this.exceptionFunction('handleValueChange', ex);
        }
    }

    /*
    * @author      : Coforge
    * @date        : Nov 13, 2024
    * @description : ADO41133: MID NIICS 10: Ability to enter the data for the NIICS Type (Save button functionality)
    */
    saveData(event) {
        this.showSpinner = true;
        try {
            manipulateRecord({ 
                recordStr : JSON.stringify(this.niicsReturnDetailRecClone),
                sObjectName : 'NIICS_Return_Detail__c'
            })
            .then(result => {
                if(!this.isDropdownChanged){
                    this.selectedService = JSON.parse(result);
                }
                this.fetchNiicsReturnDetails();
                this.isDropdownChanged = false;
                this.showSpinner = false;
            })
            .catch(error => {
                this.exceptionFunction('saveData', error);
            });
        }
        catch(e){
            this.exceptionFunction('saveData', e);
        }
    }

    /*
    * @author      : Coforge
    * @date        : Nov 13, 2024
    * @description : ADO41133: MID NIICS 10: Ability to enter the data for the NIICS Type (Save button functionality)
    */
    saveExit(event){
        this.saveData(event);
        this.cancellink(event);        
    }

    /*
    * @author      : Coforge
    * @date        : Nov 07, 2024
    * @description : ADO41132: MID NIICS 09: Ability to provide NIICS details for parent and child(s) accounts (Dropdown for Parent child and Ability to display their data)
    */
    cancellink(event){
        try {
            if(this.retURL != undefined && this.retURL != null && this.retURL != ''){
                window.location.href = decodeURIComponent(this.retURL);
            }
            else{
                window.location.href = '/MIDComDashboard';
            }
        }
        catch(e){
            this.exceptionFunction('cancellink', e);
        }   
    }

    /*
    * @author      : Coforge
    * @date        : Nov 27, 2024
    * @description : ADO41130: MID NIICS 07: Ability to view NIICS Return details in read only mode and generate PDF from Ofcom Portal
    */
    generatePDF(){
        let personAccountRec;
        var returnURL = '';
        if(this.retURL != undefined && this.retURL != null && this.retURL != ''){
            var tmp = this.retURL.split("%2F");
            returnURL = tmp.pop();
        }
        
        verifyCommunityUser()
        .then(result => {
            personAccountRec = JSON.parse(result);
            if(personAccountRec['IsPersonAccount']){
                let redirectURL = '/midcomeditreturnnew?page=0&retURL=' + returnURL + 
                            '&returnType=' + this.schedule.Return_Category_Type__c + ' ' + this.schedule.Return_Category_Name__c +
                            '&scheduleId=' + this.schedule.Id + 
                            '&niicsRecId=' + this.selectedService + 
                            '&ispdf=true';
                window.open(redirectURL, '_self');
            }
            else {
                location.replace('/apex/LightningReturnScheduleJavaScriptPage?Id='+this.schedule.Id+'&pageName=MidViewReturnCategoryPages&ispdf=true'+'&niicsRecId='+this.selectedService);
            }
        })
        .catch(error => {
            this.exceptionFunction('verifyPersonAccount', error);
        });
    }

    /*
    * @author      : Coforge
    * @date        : Nov 07, 2024
    * @description : This method is used to print page when LWC is loaded.
    */
    printhandler(){
        if(this.ispdf == true){
            window.print();
        }
    }

    /*
    * @author      : Coforge
    * @date        : Nov 07, 2024
    * @description : This method is used for submitting the return functionality.
    */
    changeStatus(event) {
        let buttonClicked = event.target.name;
        this.showSpinner = true;
        if(buttonClicked === 'Ready to submit'){
            this.schedule['Status__c'] = 'Submitted to Certify';
            this.status = buttonClicked;
            this.readOnlyMode = true;
        }
        else if(buttonClicked === 'Re-open') {
            this.schedule['Status__c'] = 'Work In Progress';
            this.status = 'In progress';
            this.readOnlyMode = false;
        }
        else if(buttonClicked === 'Submit return') {
            var returnURL = '';
            if(this.retURL != undefined && this.retURL != null && this.retURL != ''){
                var tmp = this.retURL.split("%2F");
                returnURL = tmp.pop();
            }
            let redirectURL = '/MIDreturnSubmit?' +
            'page=1' +
            '&retURL=' + returnURL + 
            '&returnType=' + this.schedule.Return_Category_Type__c + ' ' + this.schedule.Return_Category_Name__c +
            '&scheduleId=' + this.schedule.Id;
            window.location.href = redirectURL;
            return;
        }
        manipulateRecord({ 
            recordStr : JSON.stringify(this.schedule),
            sObjectName : 'Return_Schedule__c'
        })
        .then(result => {
            this.displayReadytoSubmit = (this.status == 'In progress') ? true : false;
            this.displayReopen = (this.hasModifyPermission && this.status == 'Ready to submit') ? true : false;
            this.displaySubmitReturn = (this.hasSubmitPermission && this.status == 'Ready to submit') ? true : false;
            this.dispatchEvent(new CustomEvent('reloadStatusCmp',{
                detail:{'status': this.status}
            }));
            if(this.status == 'Ready to submit'){
                this.saveData(event);
            }
            this.showSpinner = false;
        })
        .catch(error => {
            this.exceptionFunction('changeStatus', error);
        });
    }

    /*
    * @author      : Coforge
    * @date        : Nov 07, 2024
    * @description : ADO41132: MID NIICS 09: Ability to provide NIICS details for parent and child(s) accounts (Dropdown for Parent child and Ability to display their data)
    */
    exceptionFunction(methodName, exceptionProp) {
        this.showSpinner = false;
        window.location.href='/apex/licensingcomerror';
    }
}