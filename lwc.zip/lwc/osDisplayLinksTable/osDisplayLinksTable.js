import { LightningElement, wire , track, api} from 'lwc';
import getRecords from '@salesforce/apex/osDisplayLinksController.getRecords';
import osCreateDistressingContentRecords from 'c/osCreateDistressingContentRecords';
import getCustomMetadataRecords from "@salesforce/apex/OsCreateDistressingContentRecordsCtrl.getCustomMetadataRecords";
import deleteFile from "@salesforce/apex/OsCreateDistressingContentRecordsCtrl.deleteFile";
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import COMMON_ERROR from '@salesforce/label/c.CommonError';

import Id from "@salesforce/user/Id";
// ADO 32796 - Add SharePoint URLs in Business / Person Account
import LightningAlert from 'lightning/alert';
import OS_RECORD_LOCK_MESSAGE from '@salesforce/label/c.OS_Record_Lock_Message';

const DML_EXCEPTION = 'DMLException:';
const RECORD__LOCKED_LABEL = 'Record Locked';
const ERROR_LABEL = 'Error';
const FILE_DELETED_LABEL = 'File deleted'; 
const SUCCESS_LABEL = 'success';
const DISMISSABEL_LABEL = 'dismissable';

const actions = [
    { label: 'Edit', name: 'Edit' },
    { label: 'Delete', name: 'delete' }
];

const columns = [
    { 
        label: 'Title',
        fieldName: 'url',
        type: 'url',
        typeAttributes: {label: { fieldName: 'title' },
        target: '_blank'}
    },
    { label: 'Distressing Content Tags', fieldName: 'attributes', type: 'text', wrapText: true, initialWidth: 508 },
    { label: 'Added By', fieldName: 'createdby', type: 'text'},
    { label: 'Date Added', fieldName: 'createddate', type: 'date' },
    { label: 'Modified By', fieldName: 'lastModifiedby', type: 'text' },
    { label: 'Modified Date', fieldName: 'lastModifieddate', type: 'date' }
];

export default class OsDisplayLinksTable extends LightningElement {
    finalColumns = columns;
    rowOffset = 0;
    @api recordId;
    data = [];
    finalData =[];
    error;
    showModal = true;
    result;
    maxFilesAllowed;

    @track showLoadingSpinner = false;
    @api hideEditButton = false;
    selectedRow;

    @track userEditAccess = false;

    /*
     * @author      : Coforge
     * @date        : 03/05/2024
     * @description : This connectedCallback method is call onload of LWC Component.
     * @params      : none
     * @return      : none
     */
    async connectedCallback() {
        try {
            this.handleOnLoadData();
        }
        catch (error) {
            console.error('Error parsing JSON value ', error)
        }
    }

    /*
     * @author      : Coforge
     * @date        : 03/05/2024
     * @description : This handleOnLoadData method is used to load the server data and display in Data table
     * @params      : none
     * @return      : none
     */
    async handleOnLoadData() {
     
        this.finalData = [];
        let rowData = [];
        
        //Making the server call and getting the server data
        var result = await getRecords({recordId :this.recordId});
        console.log('result==>',result);

        if(result != '' &&  result != undefined) {

            //setting the user access value
            this.userEditAccess = result.isActionVisible;

            if(result.documents != '' && result.documents != undefined){

                //Call the Add action button method if user have edit access
                if(this.userEditAccess != undefined && this.userEditAccess == true){
                    this.addActionsButton();
                }
                
                //Getting the record sharepoint data
                const valueJson = JSON.parse(result.documents);

                //Checking the available data and display in table
                if (valueJson.Documents && valueJson.Documents.length > 0) {
                    valueJson.Documents.forEach((vendorVal) => {
                        rowData.push({
                            identifier: vendorVal.identifier,
                            title: vendorVal.title,
                            url: vendorVal.url,
                            attributes: vendorVal.attributes,
                            createdby: vendorVal.createdby,
                            createddate: vendorVal.createddate,
                            lastModifiedby: vendorVal.lastModifiedby != undefined ? vendorVal.lastModifiedby : vendorVal.createdby,
                            lastModifieddate: vendorVal.lastModifieddate != undefined ? vendorVal.lastModifieddate : vendorVal.createddate
                        })
                    })
                    this.finalData = rowData;
                }
            }   
        }
    }

    /*
     * @author      : Coforge
     * @date        : 26/06/2024
     * @description : This addActionsButton method is used to add Action button
     * @params      : none
     * @return      : none
     */
    addActionsButton(){  
        //Map is used to hold table headers
        let actionNameMap = new Map();

        //filling the column header values is map
        for(let obj of columns){
            if(!actionNameMap.has(obj.label)){
                actionNameMap.set(obj.label);
            }
        }
        
        //on the basis of user access , we are adding the action header
        if(!actionNameMap.has('Action')){
            let obj = { label: 'Action', type: 'action', typeAttributes: { rowActions: actions }, fixedWidth: 80 };
            columns.push(obj);
        }
    }
    
    /*
     * @author      : Coforge
     * @date        : 03/05/2024
     * @description : This showRecords method is used to get the finalData length
     * @params      : none
     * @return      : none
     */
    get showRecords() {
        return this.finalData.length > 0;
    }

    /*
     * @author      : Coforge
     * @date        : 03/05/2024
     * @description : This showToast method is display toast method
     * @params      : none
     * @return      : none
     */
    showToast(title, message, variant, mode) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(evt);
    }

    /*
     * @author      : Coforge
     * @date        : 03/05/2024
     * @description : This handleShowModal method is used to open osCreateDistressingContentRecords Lwc Component and called from new button
     * @params      : none
     * @return      : none
     */
    async handleShowModal() {
        var result = await getCustomMetadataRecords({recordId :this.recordId});
        if( result != '' &&  result != undefined && result.Number_of_Files_Allowed__c != '' && result.Number_of_Files_Allowed__c != undefined ){
            this.maxFilesAllowed = result.Number_of_Files_Allowed__c;   
        }
        if(this.maxFilesAllowed === this.finalData.length || this.maxFilesAllowed < this.finalData.length) {
            this.showToast('Limit Error', 'Maximum ' + this.maxFilesAllowed + ' file(s) are allowed.', 'error', 'dismissable');
        }
        else {
            this.result = await osCreateDistressingContentRecords.open({
                recordId : this.recordId,
                size: 'large',
                content: 'Passed into content api',
                headerText:'Add File Information'
            });
        }
        
    }

    /*
     * @author      : Coforge
     * @date        : 03/05/2024
     * @description : This handleRowAction method is used to Edit and Delete the Sharepoint records.
     * @params      : none
     * @return      : none
     */
    async handleRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;
        switch (actionName) {
            case 'delete':
                // Delete the sharepoint records
                this.deleteSharepoint(row.identifier);

                this.showLoadingSpinner = false;
                break;
            case 'Edit':
                // Edit the sharepoint records
                this.handleEditModal(event);
                break;
            default:
        }
    }

/*
     * @author      : Coforge
     * @date        : 03/05/2024
     * @description : This handleRowAction method is used to Edit and Delete the Sharepoint records.
     * @params      : none
     * @return      : none
     */
    async deleteSharepoint(rowIdentifier){
        this.showLoadingSpinner = true;
        //Calling the server method
            await deleteFile({delIdentifier : rowIdentifier, recordId :this.recordId})
            .then((result) => {
                if (result==SUCCESS_LABEL){
                    this.showToast(FILE_DELETED_LABEL,'',SUCCESS_LABEL, DISMISSABEL_LABEL);
                     this.handleOnLoadData();
                     window.location.reload();

                } // ADO 32796 - Add SharePoint URLs in Business / Person Account
                else if (result.includes(RECORD__LOCKED_LABEL)){
                    this.showLoadingSpinner = false;
                    LightningAlert.open({
                        message: OS_RECORD_LOCK_MESSAGE,
                        theme: ERROR_LABEL, // a red theme intended for error states
                        label: ERROR_LABEL,
                    });
                    
                }
            })
            .catch((error) => {
                //W-002679
                 this.showLoadingSpinner = false;
                 let errMsg = error.body.message;
                console.log('errMsg==>',errMsg);
                if(error != undefined && errMsg != undefined && errMsg.includes(DML_EXCEPTION)){
                    //this.showNoRecordsToast(errMsg.message,ERROR_LABEL,DISMISSABLE_LABEL);
                    let errorMessage = errMsg.replace(DML_EXCEPTION, '');
                    LightningAlert.open({
                        message: errorMessage,
                        theme: ERROR_LABEL, // a red theme intended for error states
                        label: ERROR_LABEL, // this is the header text
                    });
                }else{
                    //this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
                    LightningAlert.open({
                        message: COMMON_ERROR,
                        theme: ERROR_LABEL, // a red theme intended for error states
                        label: ERROR_LABEL, // this is the header text
                    });
                }
            });

    }
    /*
     * @author      : Coforge
     * @date        : 03/05/2024
     * @description : This handleEditModal method is used to Edit the Sharepoint records.
     * @params      : none
     * @return      : none
     */
    handleEditModal(event) {

        let rowData = event.detail.row;
        this.result = osCreateDistressingContentRecords.open({
                recordId : this.recordId,
                size: 'large',
                content: 'Passed into content api',
                headerText:'Add File Information',
                _fileName : rowData.title,
                _fileLink : rowData.url,
                _allSelectedflags : rowData.attributes,
                identifier : rowData.identifier,
                isEditMode : 'true'
            });
    }
}