import { LightningElement, api,wire} from 'lwc';
import updateRecordOwner from '@salesforce/apex/RfiEnforcementCaseRejectController.updateRecordOwner';
import checkRecordAccess from '@salesforce/apex/RfiEnforcementCaseRejectController.checkRecordAccess';
import RFI_Case_Reject_Msg from '@salesforce/label/c.RFI_Case_Reject_Msg';
import RFI_Case_Rejected_Successfully_Msg from '@salesforce/label/c.RFI_Case_Rejected_Successfully_Msg';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { CurrentPageReference } from 'lightning/navigation';
import { CloseActionScreenEvent } from 'lightning/actions';

export default class RFIEnforcementCaseReject extends LightningElement {

    label = {
        RFI_Case_Reject_Msg,
        RFI_Case_Rejected_Successfully_Msg
    };

    @api recordId;
    noAccessMessage;
    showPopup;

    /*
    * @author      : Coforge
    * @date        : 27/11/2024
    * @description : This method is used to set the record Id.
    * @params      : CurrentPageReference
    * @return      : none
    */
    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        if (currentPageReference) {
            this.recordId = currentPageReference.state.recordId;
        }
    }

    /*
    * @author      : Coforge
    * @date        : 27/11/2024
    * @description : This method is used to call the checkRecordAccess method.
    * @params      : none
    * @return      : none
    */
    connectedCallback() {
        this.checkRecordAccess();
    }

    /*
    * @author      : Coforge
    * @date        : 27/11/2024
    * @description : This method is used to check record acces.
    * @params      : none
    * @return      : none
    */
    checkRecordAccess(){
        checkRecordAccess({ recordId: this.recordId })
            .then(() => {
                this.showPopup = true;
            })
            .catch((error) => {
                this.showPopup = false;
                this.noAccessMessage = error.body.message;
            });
    }

    /*
    * @author      : Coforge
    * @date        : 27/11/2024
    * @description : This method is used to Close the modal.
    * @params      : none
    * @return      : none
    */
    closeModal() {
        this.dispatchEvent(new CloseActionScreenEvent());
    }
    /*
    * @author      : Coforge
    * @date        : 27/11/2024
    * @description : This method is used to update case Owner.
    * @params      : none
    * @return      : none
    */
    updateRecordOwner() {
        updateRecordOwner({ recordId: this.recordId })
            .then(() => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: this.label.RFI_Case_Rejected_Successfully_Msg,
                        variant: 'success',
                    })
                );
                this.dispatchEvent(new CloseActionScreenEvent());
                setTimeout(() => {
                    window.location.reload();
                }, 2000);
            })
            .catch((error) => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error',
                        message: error.body.message,
                        variant: 'error',
                    })
                );
            });
    }

}