/*********************************************************************
# File....................: masterRepoAddStakeholderOrganisation
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............: 02/04/2025
# Last Modified by........: Coforge
# Last Modified Date......: 
# Description.............: Component is used to show and add multiple Stakeholder Organisations on Master Repository Object
# VF Page.................: NA
# VF Component............: NA
# L Comp..................: NA
# Handler Class...........: NA
# Test Class..............: NA
# Change Log..............: NA
#Trigger Name ............: Case

**********************************************************************/
import { LightningElement,api,track,wire } from 'lwc';
import getRelatedListData from '@salesforce/apex/MasterRepositoryController.getRelatedListData';
import userRecordAccess from '@salesforce/apex/MasterRepositoryController.userRecordAccess';
import saveAndDeleteMasterRepositoryItems from '@salesforce/apex/MasterRepositoryController.saveAndDeleteMasterRepositoryItems';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';

export default class MasterRepoAddStakeholderOrganisation extends LightningElement {

    @api recordId = '';
    @track stakeholderOrganization = [];
    shOrganizationCriteria = 'Master_Repository__c = \'@recordId@\' AND StakeholderType__c = \'Stakeholder Organization\'';
    sTAKEHOLDER_ORGANIZATIONS = 'Stakeholder Organization';
    stakeHolders;
    ERROR_LABEL = 'error';
    DISMISSABLE_LABEL= 'dismissable';
    showSaveButton = false;
    readOnly = false;
    dataInitialized = false;
    lightningSpinner = false;
    mapOfStakeHolders = new Map(); 
    mapOfStakeHoldersDelete = new Map(); 
    wiredMasterRepositoryResult ;
    mapOfExistMasterRepositoryLineItem = new Map();

    // connectedCallback to get userRecordAccess
    connectedCallback() {
        if (this.recordId) {
            userRecordAccess({ recordId: this.recordId })
                .then(result => {
                    this.readOnly = !result;
                    this.dataInitialized = true;
                })
                .catch(error => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error',
                            message: error.body.message,
                            variant: 'error'
                        })
                    );
                });
        }
    }

    // wire to get data in data table
    @wire(getRelatedListData, { recordId: '$recordId' })
    getMasterRepositoryRecords(wiredResult) {
        this.wiredMasterRepositoryResult = wiredResult;

        const { data, error } = wiredResult;
        if (data) {
            const temp = [];
            for (const obj of data.stakeholderData) {
                this.addStakeholderData(obj, temp); 
                this.mapOfExistMasterRepositoryLineItem.set(this.generateKey(obj.Account__c, obj.StakeholderType__c), obj);
            }
            this.stakeHolders = temp;
        } else if (error) {
            console.error('Wire error', error);
        }
    }

  
    /*
     * @author      : Coforge
     * @date        : 02/04/2025
     * @description : This @wire method is fetching the stakeholdlers related with Master Repository
     * @params      : obj,temp1
     * @return      : none
     */
    addStakeholderData(obj,temp){
        let temporg = {'Id':'','Account__r.Name':'','Account__c':'','StakeholderType__c':'','Master_Repository__c':''};
        temporg['Account__r.Name'] = obj.Account__r.Name;
        temporg.Account__c = obj.Account__r.Id;
        temporg.StakeholderType__c = obj.StakeholderType__c;
        temporg.Master_Repository__c = obj.Master_Repository__c;
        temporg.Id = obj.Id;
        temp.push(temporg);
    }

    /*
     * @author      : Coforge
     * @date        : 02/04/2025
     * @description : This method will execute when new stakeholder Organizations are added to the page.
     * @params      : event
     * @return      : NA
     */
    addStakeholderOrganizations(event) {
        this.lightningSpinner =true;
        this.showSaveButton = true;
        if(event.detail.data) { 
                for(const obj of event.detail.data) {
                    let temporg = {'Account__r.Name':'','Account__c':'','StakeholderType__c':'','Master_Repository__c':''};
                    temporg['Account__r.Name'] = obj["Account__r.Name"];
                    temporg.Account__c = obj["Account__r.Id"];
                    temporg.StakeholderType__c = this.sTAKEHOLDER_ORGANIZATIONS;
                    temporg.Master_Repository__c = this.recordId;
                    //temporg.Type__c = 'Account';
                    this.mapOfStakeHolders.set(this.generateKey(temporg.Account__c,temporg.StakeholderType__c),temporg);                                        
                    if(this.mapOfExistMasterRepositoryLineItem.has(this.generateKey(temporg.Account__c,temporg.StakeholderType__c))){
                        this.mapOfStakeHoldersDelete.delete(this.generateKey(temporg.Account__c,temporg.StakeholderType__c));
                    }
                    this.lightningSpinner =false;
                }
        }
    }

    /*
     * @author      : Coforge
     * @date        : 02/04/2025
     * @description : This method will be used to delete the stakeholders
     * @params      : event
     * @return      : NA
     */
    deleterecords(event){
        this.lightningSpinner = true;
        this.showSaveButton = true;
        let rawData = event.detail.data;
        let newRecord = {
            "Id": rawData.Id,
            "Account__r.Name": rawData["Account__r.Name"],
            "Account__c": rawData.Account__c,
            "StakeholderType__c": rawData.StakeholderType__c,
            "Master_Repository__c": rawData.Master_Repository__c
            };
            this.mapOfStakeHoldersDelete.set(this.generateKey(newRecord.Account__c,newRecord.StakeholderType__c),newRecord);                    
            if(!this.mapOfExistMasterRepositoryLineItem.has(this.generateKey(newRecord.Account__c,newRecord.StakeholderType__c))){
                this.mapOfStakeHolders.delete(this.generateKey(newRecord.Account__c,newRecord.StakeholderType__c));
            }
            this.lightningSpinner = false;
    }
    /*
     * @author      : Coforge
     * @date        : 02/04/2025
     * @description : This method will be used to create and delete the stakeholders
     * @params      : event
     * @return      : NA
     */
    handleSaveAndDelete() {
        this.lightningSpinner =true;
        let addRecords = [];
        let deleteRecords = [];

        this.mapOfExistMasterRepositoryLineItem.forEach((value, key) => {
            if(this.mapOfStakeHolders.has(key)){
                this.mapOfStakeHolders.delete(key);
            }

            if(!this.mapOfStakeHoldersDelete.has(key) ){
                
                this.mapOfStakeHoldersDelete.delete(key);
            }

            if(this.mapOfStakeHoldersDelete.has(key)){
                
                this.mapOfStakeHoldersDelete.set(key,value);
            }
        });
         //Fill list from map
         if(this.mapOfStakeHolders.size > 0){
                    
           addRecords = [...addRecords,...this.mapOfStakeHolders.values()];
                
        }
        if(this.mapOfStakeHoldersDelete.size > 0){
                    
            deleteRecords = [...deleteRecords,...this.mapOfStakeHoldersDelete.values()];
                 
         }
         
        // Call Apex method
        saveAndDeleteMasterRepositoryItems({recordsToSave: addRecords, recordIdsToDelete: deleteRecords})
            .then(() => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Records added / deleted successfully',
                        variant: 'success'
                    })
                );
                deleteRecords = [];// Clear the list after deletion
                addRecords = [];// Clear the list after adittion
                this.mapOfStakeHolders = new Map();// clear map 
                this.mapOfStakeHoldersDelete = new Map();// clear map 
                this.mapOfExistMasterRepositoryLineItem = new Map(); // clear map
                this.showSaveButton = false;
                this.lightningSpinner = false;
                refreshApex(this.wiredMasterRepositoryResult);
            })
            .catch(error => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error',
                        message: error.body.message,
                        variant: 'error'
                    })
                );
            });
    }
    
    /*
     * @author      : Coforge
     * @date        : 02/04/2025
     * @description : This method will be called when 
     * @params      : event
     * @return      : NA
     */
    handleCancel() {
        window.location.reload();
    }

    generateKey(contactId, stakeholderType) {
        return `${contactId}${stakeholderType}`.replace(/\s+/g, '');
    }

}