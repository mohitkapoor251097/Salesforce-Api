import LightningDatatable from 'lightning/datatable';
import imageTableControl from './extendedDataTable.html';

export default class SalesforceCodexDataTable extends LightningDatatable  {
    // set extendedDataTable.html as default template for image data type in extended Lightning Datatable
    static customTypes = {
        image: {
            template: imageTableControl
        }
    };
}