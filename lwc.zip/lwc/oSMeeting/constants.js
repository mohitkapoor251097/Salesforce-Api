import MeetingSavedSuccess from '@salesforce/label/c.MeetingSavedSuccess';

const ACTIONS = [
    { label: 'Delete', name: 'delete'}
];

const COLUMNS = [
    { label: 'Name', fieldName: 'Name', type: 'text'},
    { label: 'Address', fieldName: 'Address', type: 'text' },
    {
        type: 'button-icon',
        initialWidth: 50,
        typeAttributes:
        {
            iconName: 'utility:delete',
            name: 'delete',
            alternativeText: 'Delete'
        }
    }
];

const READONLY_COLUMNS = [
    { label: 'Name', fieldName: 'Name', type: 'text'},
    { label: 'Address', fieldName: 'Address', type: 'text' }
];

const CUSTOM_LABELS = {
    MeetingSavedSuccess,
}

const LOADING = 'Loading';
const NAME = 'Name';
const MEETING = 'Meeting';
const MEETING_TITLE = 'Meeting Title';
const MEETING_SUMMARY = 'Meeting Summary';
const MEETING_TOPICS = 'Meeting Topics';
const DATE_OF_MEETING = 'Date of Meeting';
const LINKED_BREIFING = 'Linked Briefing';
const MEETING_TYPE = 'Meeting Type';
const OFCOM_LEAD = 'Ofcom Lead';
const REGULATORY_AREA = 'Regulatory Area';
const SUB_ARES = 'Sub Area';
const ADDITIONAL_NOTES = 'Additional Notes';
const STAKEHOLDER_ORGANIZATIONS = 'Stakeholder Organization';
const STAKEHOLDER_LEADS = 'Stakeholder Lead';
const STAKEHOLDER_PARTICIPANTS = 'Stakeholder Participant';
const OFCOM_PARTICIPANTS = 'Ofcom Participant';
const TYPE_STAKEHOLDER_LEAD = 'Stakeholder Lead';
const TYPE_STAKEHOLDER_PARTICIPANT = 'Stakeholder Participant';
const TYPE_OFCOM_PARTICIPANT = 'Ofcom Participant';
const DELETE_MESSAGE = 'Are you sure, you want to delete?';
const FIELD_CUSTOM_VALIDATION_EXCEPTION = 'FIELD_CUSTOM_VALIDATION_EXCEPTION';

const SEARCH_LABEL = 'Search';
const SUBMIT_LABEL = 'Submit';
const CANCEL_LABEL = 'Cancel';
const AccountObjectApiName = 'Account';
const MeetingObjectApiName = 'Meeting__c';
const ControllingPicklistApiName = 'RegulatoryArea__c';
const DependentPicklistApiName = 'SubArea__c';
const LinkedBreifingFieldApiName = 'Meeting__c';
const OfcomLeadFieldApiName = 'Contact__c';
const EXCEPTION_LABEL = '_EXCEPTION';
const SUCCESS_LABEL = 'success';
const ERROR_LABEL = 'error';
const DISMISSABLE_LABEL= 'dismissable';
const ACCOUNT_PREFIX_LABEL = '001';
const CASE_ID_PREFIX = '500';
/*33079-Auto-populate Stakeholder Organisation Name / Stakeholder Business Account*/
const SEARCH_CONTACT_METADATANAME = 'SearchContact';
const SEARCH_ACCOUNT_METADATANAME = 'SearchAccount';

export { 
    FIELD_CUSTOM_VALIDATION_EXCEPTION,
    SEARCH_CONTACT_METADATANAME,
    SEARCH_ACCOUNT_METADATANAME,
    ACCOUNT_PREFIX_LABEL,
    CASE_ID_PREFIX,
    DISMISSABLE_LABEL,
    EXCEPTION_LABEL,
    SUCCESS_LABEL,
    ERROR_LABEL,
    COLUMNS,
    READONLY_COLUMNS,
    LOADING,
    NAME, 
    MEETING, 
    MEETING_TITLE, 
    MEETING_SUMMARY, 
    DATE_OF_MEETING,
    MEETING_TOPICS,
    LINKED_BREIFING, 
    MEETING_TYPE, 
    OFCOM_LEAD, 
    REGULATORY_AREA, 
    SUB_ARES, 
    ADDITIONAL_NOTES,
    SEARCH_LABEL,
    SUBMIT_LABEL,
    CANCEL_LABEL,
    STAKEHOLDER_ORGANIZATIONS,
    STAKEHOLDER_LEADS,
    STAKEHOLDER_PARTICIPANTS,
    OFCOM_PARTICIPANTS,
    TYPE_STAKEHOLDER_LEAD,
    TYPE_STAKEHOLDER_PARTICIPANT,
    TYPE_OFCOM_PARTICIPANT,
    DELETE_MESSAGE,
    CUSTOM_LABELS,
    AccountObjectApiName,
    MeetingObjectApiName,
    ControllingPicklistApiName,
    DependentPicklistApiName,
    LinkedBreifingFieldApiName,
    OfcomLeadFieldApiName,
};