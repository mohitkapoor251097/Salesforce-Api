import { LightningElement, api, wire , track} from 'lwc';
import getRelatedListData from '@salesforce/apex/OS_MeetingController.getRelatedListData';
import submitMeeting from '@salesforce/apex/OS_MeetingController.submitMeeting';
import getRelatedList from '@salesforce/apex/OS_MeetingController.getRelatedList';

import hasPermission from '@salesforce/customPermission/Standard_permission'; //added for W-002621
import { getRecord, getFieldValue } from "lightning/uiRecordApi";
import { refreshApex } from '@salesforce/apex';//catche fix

import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';

import stakeholderParticipantsLimitError from '@salesforce/label/c.Stakeholder_Participants_Limit_error';
import stakeholderParticipantsLimit from '@salesforce/label/c.Stakeholder_Participants_Limit';
import ofcomParticipantsLimitError from '@salesforce/label/c.Ofcom_Participants_Limit_error';
import OS_Missing_Required_Field from '@salesforce/label/c.OS_Missing_Required_Field';
import ofcomParticipantsLimit from '@salesforce/label/c.Ofcom_Participants_Limit';
import OS_Meeting_Information from '@salesforce/label/c.OS_Meeting_Information';
import OS_Compliance_Concern from '@salesforce/label/c.OS_Compliance_Concern';
import OS_Illegal_Harms from '@salesforce/label/c.OS_Illegal_Harms';
import OS_Legal_Harms from '@salesforce/label/c.OS_Legal_Harms';
import COMMON_ERROR from '@salesforce/label/c.CommonError';
import OS_Other from '@salesforce/label/c.OS_Other';

const FIELDS = ["Meeting__c.Name", "Meeting__c.Compliance_Concern__c", "Meeting__c.Legal_Harm__c",
                 "Meeting__c.Illegal_Harm__c", "Meeting__c.Other_harm__c"];

import { 
    LOADING, 
    SUBMIT_LABEL,
    CANCEL_LABEL,
    MeetingObjectApiName,
    CUSTOM_LABELS,
    FIELD_CUSTOM_VALIDATION_EXCEPTION,
    SEARCH_CONTACT_METADATANAME,
    SEARCH_ACCOUNT_METADATANAME,
    STAKEHOLDER_ORGANIZATIONS,
    STAKEHOLDER_LEADS,
    STAKEHOLDER_PARTICIPANTS,
    OFCOM_PARTICIPANTS,
    ACCOUNT_PREFIX_LABEL,
    CASE_ID_PREFIX,
    DISMISSABLE_LABEL,
    EXCEPTION_LABEL,
    SUCCESS_LABEL,
    ERROR_LABEL, 
} from './constants';



export default class NewMeetingComponent extends NavigationMixin(LightningElement) {

    label = {
        OS_Meeting_Information,
        OS_Compliance_Concern,
        OS_Illegal_Harms,
        OS_Legal_Harms,
        OS_Other
    };

    @api recordId = '';
    //hideVar=true; //W-002621
    hidePlusButton = true; //W-002876
    //onloadHide= true; //W-002621
    //onloadHidechairperson = true; //W-002621
    stakeHolders;
    shOrganizationCriteria = 'Meeting__c = \'@recordId@\' AND StakeholderType__c = \'Stakeholder Organization\'';
    shLeadCriteria = 'Meeting__c = \'@recordId@\' AND StakeholderType__c = \'Stakeholder Lead\'';
    shParticipantCriteria = 'Meeting__c = \'@recordId@\' AND StakeholderType__c = \'Stakeholder Participant\'';
    ofcomParticipantCriteria = 'Meeting__c = \'@recordId@\' AND StakeholderType__c = \'Ofcom Participant\'';
    meetingActionCriteria = 'Meeting__c = \'@recordId@\''; //W-002684 

    headerTitle = 'Create Meeting';
    readOnly = false;
    loadingLabel = LOADING;
    submitLabel = SUBMIT_LABEL;
    cancelLabel = CANCEL_LABEL;
    meetingObjectApiName = MeetingObjectApiName;
    showLoading = false;
    refreshData = true;//W-002679

    currentPageReference = null; 
    meetingActions; //W-002684
    createRecordTitle = 'Create Record';
    createRecordMetadata = 'CreateContact';
    showCreateRecordModel = false;
    showCreateRecordModelLead = false //W-002878

    /* W-5137-Define Meeting Topics start */
    isComplianceConcern = false;
    isLegalHarm = false;
    isIllegalHarm = false;
    isOtherHarm = false;

    other_Compliance_Concern__Field;
    violence_against_women__Field;
    child_Sexual_Abuse__Field;
    safety_Functions__Field;
    lH_SubCat__Field;
    iH_Other__Field;
    general__Field;
    other__Field;
    /* W-5137-Define Meeting Topics End */
    
    /* User Story-13247 Start */
    _parentId;
    caseRecordId;

    @api
    get parentId() {
        return this._parentId;
    }

    set parentId(value) {
        this._parentId = value;
        if(this._parentId && this._parentId.substring(0,3) === CASE_ID_PREFIX){
            this.caseRecordId = this._parentId;
            
        }
    }
    /* User Story-13247 End */
    /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
    @track stakeholderOrganization = [];
    @track ofcomParticipants = [];
    @track stakeParticipants = [];
    @track stakeholderLeads = [];

    mapOfContactIds = new Map();
    setOfStakeholderOrg = new Set();
    isPreventRecursion = false;

    //Start for W-002621
     /*
     * @author      : Coforge
     * @date        : 10/08/2022
     * @description : This method is showing toast when there is error on submit.
     * @params      : none
     * @return      : none
     */
    handleError(event) {
        if(event.detail.detail!=null){
            this.showNoRecordsToast(event.detail.detail,ERROR_LABEL,DISMISSABLE_LABEL);
        }
    }
    
    /* W-5137-Define Meeting Topics Start */

    /*
    * @author      : Coforge
    * @date        : 10/08/2022
    * @description : This method is used to set field value on isComplianceConcern change.
    * @params      : none
    * @return      : none
    */
    handleComplianceConcernChange(event){
        this.isComplianceConcern = event.target.value;

        if(!this.isComplianceConcern){
            this.general__Field = '';
            this.safety_Functions__Field = '';
            this.other_Compliance_Concern__Field = '';
        }
        
    }
    
    /*
    * @author      : Coforge
    * @date        : 10/08/2022
    * @description : This method is used to set field value on isLegalHarm change.
    * @params      : none
    * @return      : none
    */
    handleLegalHarmChange(event){
        this.isLegalHarm = event.target.value;
        if(!this.isLegalHarm){
            this.lH_SubCat__Field = '';
        }
    }

    /*
    * @author      : Coforge
    * @date        : 10/08/2022
    * @description : This method is used to set field value on isIllegalHarm change.
    * @params      : none
    * @return      : none
    */
    handleIllegalHarmChange(event){
        this.isIllegalHarm = event.target.value;
        if(!this.isIllegalHarm){
            this.child_Sexual_Abuse__Field = '';
            this.violence_against_women__Field = '';
            this.iH_Other__Field = '';
        }
    }

    /*
    * @author      : Coforge
    * @date        : 10/08/2022
    * @description : This method is used to set field value on isOtherHarm change.
    * @params      : none
    * @return      : none
    */
    handleOtherHarmChange(event){
        this.isOtherHarm = event.target.value;
        if(!this.isOtherHarm){
            this.other__Field = '';
        }
    }

    /*
    * @author      : Coforge
    * @date        : 29/02/2024
    * @description : This method is used to give validation
    * @params      : none
    * @return      : none
    */
    validateFields() {
        let isValid = false;
        let inputFields = this.template.querySelectorAll('lightning-input-field');
        inputFields.forEach(inputField => {
            if (!inputField.reportValidity() && isValid == false) {
                isValid = true;
                inputField.scrollIntoView();
                inputField.focus();
            }
        });
        if(isValid){
            this.showNoRecordsToast(OS_Missing_Required_Field,ERROR_LABEL,DISMISSABLE_LABEL);
            return;
        }
    }

    /* W-5137-Define Meeting Topics End */
    /*
     * @author      : Coforge- Shabana
     * @date        : 07/09/2022
     * @description : This method is to handle onSubmit
     * @params      : none
     * @return      : Boolean
     */
    handleSubmit(event){
        // Custom logic before submission
        //W-002679
        this.refreshData = false;
        if((this.recordId ==undefined || this.recordId =='') && this.stakeHolders.length !==0){
            event.stopPropagation();
            event.preventDefault();
            let ofcomParticipants=0;
            let stakeholderParticipants = 0;
            for(let i=0;i<this.stakeHolders.length; i++){
                if(this.stakeHolders[i].StakeholderType__c ==STAKEHOLDER_PARTICIPANTS){
                    stakeholderParticipants +=1;
                }
                else if(this.stakeHolders[i].StakeholderType__c ==OFCOM_PARTICIPANTS){
                    ofcomParticipants +=1;
                }
            }
            if(ofcomParticipants > Number(ofcomParticipantsLimit)){
                this.showNoRecordsToast(ofcomParticipantsLimitError,ERROR_LABEL,DISMISSABLE_LABEL);
                return;
            }
            else if(stakeholderParticipants > Number(stakeholderParticipantsLimit)){
                this.showNoRecordsToast(stakeholderParticipantsLimitError,ERROR_LABEL,DISMISSABLE_LABEL);
                return;
            }
            else{
                const inputFields = event.detail.fields;
                //Blank related field if Compliance_Concern__c is false
                if(!this.isComplianceConcern){
                    inputFields.General__c = '';
                    inputFields.Safety_Functions__c = '';
                    inputFields.Other_Compliance_Concern__c = '';
                }
                //Blank related field if Illegal_Harm__c is false
                if(!this.isIllegalHarm){
                    inputFields.Child_Sexual_Abuse__c = '';
                    inputFields.Violence_against_women__c = '';
                    inputFields.IH_Other__c = '';
                }
                //Blank related field if Legal_Harm__c is false
                if(!this.isLegalHarm){
                    inputFields.LH_SubCat__c = '';
                }
                //Blank related field if Other_harm__c is false
                if(!this.isOtherHarm){
                    inputFields.Other__c = '';
                }
                
                this.template.querySelector('[data-id="createMeetingForm"]').submit(inputFields);
            }
        }else{
            const inputFields = event.detail.fields;
            //Blank related field if Compliance_Concern__c is false
            if(!this.isComplianceConcern){
                inputFields.General__c = '';
                inputFields.Safety_Functions__c = '';
                inputFields.Other_Compliance_Concern__c = '';
            }
            //Blank related field if Illegal_Harm__c is false
            if(!this.isIllegalHarm){
                inputFields.Child_Sexual_Abuse__c = '';
                inputFields.Violence_against_women__c = '';
                inputFields.IH_Other__c = '';
            }
            //Blank related field if Legal_Harm__c is false
            if(!this.isLegalHarm){
                inputFields.LH_SubCat__c = '';
            }
            //Blank related field if Other_harm__c is false
            if(!this.isOtherHarm){
                inputFields.Other__c = '';
            }
        
            this.template.querySelector('[data-id="createMeetingForm"]').submit(inputFields);
        }
    }

    /*
     * @author      : Coforge
     * @date        : 10/08/2022
     * @description : This method is checking whether current user has Standard custom permission.
     * @params      : none
     * @return      : Boolean
     */
    get standardPermission() {
        return hasPermission;
    }
    
    /*
     * @author      : Coforge
     * @date        : 10/08/2022
     * @description : This method set boolean variable true or false according to meeting type values
                      on calling of onload method
     * @params      : 
     * @return      : none
     */

    connectedCallback() {
        setTimeout(() => {
            if(this.readOnly == false && this._parentId != '' && this._parentId != undefined && 
            this.isPreventRecursion == false){
            this.addAutoStakeOrganization();
            this.isPreventRecursion = true;
            }
        }, 3000);
    }

    handleOnLoad(){
        /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
        this.mapOfContactIds.set('Contact__c',this.template.querySelector( '[ data-id="Contact__c" ]').value);
        this.mapOfContactIds.set('Chairperson__c',this.template.querySelector( '[ data-id="Chairperson__c" ]').value);
        
        /*33079-Auto-populate Stakeholder Organisation Name / Stakeholder Business Account*/
        /*if(this.readOnly == false && this._parentId != '' && this._parentId != undefined && 
            this.isPreventRecursion == false){
            
            window.setTimeout(() => {
            this.addAutoStakeOrganization();
            }, 2000);

            this.isPreventRecursion = true;
        }*/
    }

    /*
     * @author      : Coforge
     * @date        : 12/06/2024
     * @description : This method is used to auto add stakeholder organization if create meeting record from account record.
     * @params      : 
     * @return      : none
     */
    /*33079-Auto-populate Stakeholder Organisation Name / Stakeholder Business Account*/
    addAutoStakeOrganization(){
        //only process account record and checking the parentId map to prevent the multple time method calling
        if(this._parentId.substring(0,3) === ACCOUNT_PREFIX_LABEL ){
            let tempStakeOrganization = [];

            getRelatedList({
					metadataRecordName: SEARCH_ACCOUNT_METADATANAME,
					filterCriteria: 'Id = \''+ this._parentId +'\''
				}).then((result) => {
					try{
						if(result && result.length > 0 && !this.setOfStakeholderOrg.has(this._parentId)) {
                            //transform the data in required child component format
							let obj = this.mapStakeholderOrgData(result[0]);

                               //Add the object and assign it to osRelatedList Child component
                                tempStakeOrganization.push(obj);
                                this.stakeholderOrganization = tempStakeOrganization;

                                this.stakeHolders.push(this.transformAccountObject(obj));
                                //Add parentId in set to avoid multiple run
                                this.setOfStakeholderOrg.add(this._parentId);
						}
					} catch(e){
						this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
					}
				})
				.catch((error) => {
					console.log(error);
					this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
				});
        }
    }
    /*
     * @author      : Coforge
     * @date        : 10/08/2022
     * @description : This method is used to set the server side value in child getter and setter variable
     * @params      : 
     * @return      : none
     */
    /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
    parsedServerData(result){
        let particiapnttemp = [];
        let stakeLeadsTemp = [];
        let ofcomtemp = [];
        if(result) {
            for(let objResult of result){
                if(objResult && (objResult.StakeholderType__c == STAKEHOLDER_PARTICIPANTS || objResult.StakeholderType__c == OFCOM_PARTICIPANTS || objResult.StakeholderType__c == STAKEHOLDER_LEADS)){
                    let obj;
                    if(objResult.Account_PA__c != '' && objResult.Account_PA__c != null && objResult.Account_PA__c != undefined){
                        obj = this.mappStakeParticipantAccountServerData(objResult);
                    }else{
                        obj = this.mappStakeParticipantServerData(objResult);
                    }

                    if(obj && obj.StakeholderType__c == STAKEHOLDER_PARTICIPANTS){
                        particiapnttemp.push(obj); 
                    }else if(obj && obj.StakeholderType__c == OFCOM_PARTICIPANTS){
                        ofcomtemp.push(obj);
                    }else if(obj && obj.StakeholderType__c == STAKEHOLDER_LEADS){
                        stakeLeadsTemp.push(obj);
                    }
                }
            }
            this.stakeParticipants = particiapnttemp; 
            this.ofcomParticipants = ofcomtemp;
            this.stakeholderLeads =  stakeLeadsTemp;
            }
        
    }
    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This @wire method is fetching the Meeting Name
     * @params      : meetingid
     * @return      : meeting
     */
    @wire(getRecord, {
        recordId: "$recordId",
        fields: FIELDS
      })
      getMeeting( {data, error} ) {
        if( data && this.refreshData) {
            this.headerTitle = 'Edit ' + data.fields.Name.value;
            
            /* W-5137-Define Meeting Topics Start */
            this.isComplianceConcern =  data.fields.Compliance_Concern__c.value;
            this.isLegalHarm =  data.fields.Legal_Harm__c.value;
            this.isIllegalHarm =  data.fields.Illegal_Harm__c.value;
            this.isOtherHarm =  data.fields.Other_harm__c.value;
            /* W-5137-Define Meeting Topics End */
        }
    }


    /*
     * @author      : Coforge
     * @date        : 02/09/2022
     * @description : This @wire method is fetching the stakeholdlers and Actions related with meeting(W-002684)
     * @params      : meetingid
     * @return      : stakeholders,meetingActions
     */
    @wire(getRelatedListData, { recordId: '$recordId' })
    getMeetingRecords1( {data, error} ) {
        if( data && this.refreshData) { //Added refreshData check for W-002679
            const temp = [];
            const temp1 = [];

            for(const obj1 of data.actionsData) {
                this.addMeetingActionData(obj1,temp1); //meeting Action data mapping
            } 
            this.meetingActions = temp1; 

            for(const obj of data.stakeholderData){
                this.addStakeholderData(obj,temp); //stakeholder type data mapping
            }
            
            /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
            //set the ofcom Lead and ofcom participant data
            if(data.stakeholderData.length > 0){
                this.parsedServerData(data.stakeholderData);
            }
            
           this.stakeHolders = temp;
        }
    }
    /*
     * @author      : Coforge
     * @date        : 02/09/2022
     * @description : This @wire method is fetching the stakeholdlers and Actions related with meeting(W-002684)
     * @params      : obj1,temp1
     * @return      : none
     */
    addMeetingActionData(obj1,temp1){
        let temporg = {'Id':'','Action_Owner__c':'','Action_Description__c':'','Due_Date__c':'','Meeting__c':'','Action_Owner__r.name':'','Name':''};
        temporg['Action_Owner__c'] = obj1.Action_Owner__c;
        temporg['Action_Description__c'] = obj1.Action_Description__c;
        temporg['Due_Date__c'] = obj1.Due_Date__c;
        temporg['Meeting__c'] = obj1.Meeting__c;
        temporg['Name'] = obj1.Name;
        temporg.Id = obj1.Id;
        temp1.push(temporg);
    }
    /*
     * @author      : Coforge
     * @date        : 02/09/2022
     * @description : This @wire method is fetching the stakeholdlers related with meeting(W-002684)
     * @params      : obj,temp1
     * @return      : none
     */
    addStakeholderData(obj,temp){
        let temporg = {'Id':'','Account__r.Name':'','Account__c':'','StakeholderType__c':'','Meeting__c':'','Contact__c':'','Account_PA__c':''};
        temporg['Account__r.Name'] = obj.Account__r.Name;
        temporg.Account__c = obj.Account__r.Id;
        temporg.StakeholderType__c = obj.StakeholderType__c;
        temporg.Contact__c = obj.Contact__c;
        temporg.Account_PA__c = obj.Account_PA__c;
        temporg.Meeting__c = obj.Meeting__c;
        temporg.Id = obj.Id;
        temp.push(temporg);
    }
    
    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This method will execute when new stakeholder leads are added to the page.
     * @params      : event
     * @return      : NA
     */
    addStakeholderLeads(event) {
        try{
            const stakeholderLeadTemp = [];
            const tempNew = [];
            const temp = [];

            for(const obj of this.stakeHolders){
                temp.push(obj);
            }
            
            for(const obj of this.stakeParticipants){
                tempNew.push(obj);
            }

            for(const obj of this.stakeholderLeads){
                stakeholderLeadTemp.push(obj);
            }

            if(event.detail.data) {           
                for(const obj of event.detail.data) {
                    let temporg = {'Account__r.Name':'','Account__c':'','StakeholderType__c':'','Meeting__c':'','Contact__c':'','Account_PA__c':''};
                    temporg['Account__r.Name'] = obj["Account__r.Name"];
                    temporg.Account__c = obj["Account__r.Id"];
                    temporg.StakeholderType__c = 'Stakeholder Lead';
                    //Checking if Contact__r.Id having contactId or accountIds and then assign to accordingly
                    if(obj["Contact__r.Id"] && obj["Contact__r.Id"].substring(0,3) === ACCOUNT_PREFIX_LABEL){
                        temporg.Account_PA__c = obj["Contact__r.Id"];
                        temporg.Contact__c = '';
                        temporg['Contact__r.Id'] = '';
                    }else{
                        temporg.Contact__c = obj["Contact__r.Id"];
                    }

                    temporg.Meeting__c = this.recordId;
                    temp.push(temporg);
                    
                    //Adding Stakeholder Lead
                    stakeholderLeadTemp.push(obj);

                    /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
                    //Clone and create Stakeholder Participant from Stakeholder lead record
                    let cloneObj = {...obj};
                    cloneObj['StakeholderType__c'] = STAKEHOLDER_PARTICIPANTS;
                    tempNew.push(cloneObj);
                }

                this.stakeHolders = temp;
                this.stakeParticipants = tempNew;
                this.stakeholderLeads = stakeholderLeadTemp;
                
                /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
                //Assigning the values in the server side list to insert or delete data
                if(tempNew && tempNew.length > 0){

                    let tempNewArray = this.transformArrayObject(tempNew);

                    let ofcomParticipantsMap = new Map(tempNewArray.map((obj) => [(obj.Account_PA__c!= null ? obj.Account_PA__c : obj.Contact__c)+obj.StakeholderType__c, obj]));
                    let stakeHoldersMap = new Map();
                    if(this.stakeHolders.length > 0){
                        for(let obj of this.stakeHolders){
                            if(obj.Contact__c != undefined && obj.Contact__c != '' && !stakeHoldersMap.has(obj.Contact__c)){
                                stakeHoldersMap.set(obj.Contact__c+obj.StakeholderType__c,obj);
                            }
                            else if(obj.Account_PA__c != undefined && obj.Account_PA__c != '' && !stakeHoldersMap.has(obj.Account_PA__c)){
                                stakeHoldersMap.set(obj.Account_PA__c+obj.StakeholderType__c,obj);
                            }
                            else if((obj.Account_PA__c == undefined || obj.Account_PA__c == '') && (obj.Contact__c == undefined || obj.Contact__c == '') && 
                            !stakeHoldersMap.has(obj.Account__c)){
                                stakeHoldersMap.set(obj.Account__c+obj.StakeholderType__c,obj);
                            }
                        }
                    }
                    
                    /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
                    //Creating the teamp list from map and assign to server list
                    if(ofcomParticipantsMap && ofcomParticipantsMap.size > 0){
                        for(let key of ofcomParticipantsMap.keys()){

                            if(!stakeHoldersMap.has(key)){
                                stakeHoldersMap.set(key,ofcomParticipantsMap.get(key));
                            }
                        }
                        let teamNewArray = [];
                        for(let key of stakeHoldersMap.keys()){
                            teamNewArray.push(stakeHoldersMap.get(key));
                        }
                        this.stakeHolders = teamNewArray;
                    }
                }
                
            }
        }catch(e){
            this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
        }
    }

    
    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This method will execute when new stakeholder Organizations are added to the page.
     * @params      : event
     * @return      : NA
     */
    addStakeholderOrganizations(event) {
        try{
            let mapOfStakeHolders = new Map(); 
            const temp = [];
            for(const element of this.stakeHolders) {
                if(element.Contact__c != '' && element.Contact__c != undefined){
                    mapOfStakeHolders.set(element.Contact__c+element.StakeholderType__c,element);
                }
                if(element.Account_PA__c != '' && element.Account_PA__c != undefined){
                    mapOfStakeHolders.set(element.Account_PA__c+element.StakeholderType__c,element);
                }
                if((element.Account_PA__c == undefined || element.Account_PA__c == '') && (element.Contact__c == undefined || element.Contact__c == '') && 
                    !mapOfStakeHolders.has(element.Account__c)){
                    mapOfStakeHolders.set(element.Account__c+element.StakeholderType__c,element);
                }
            }

            if(event.detail.data) { 
                        
                for(const obj of event.detail.data) {
                    let temporg = {'Account__r.Name':'','Account__c':'','StakeholderType__c':'','Meeting__c':'','Contact__c':'','Account_PA__c':''};
                    temporg['Account__r.Name'] = obj["Account__r.Name"];
                    temporg.Account__c = obj["Account__r.Id"];
                    temporg.StakeholderType__c = STAKEHOLDER_ORGANIZATIONS;
                    temporg.Meeting__c = this.recordId;
                    mapOfStakeHolders.set(temporg.Account__c+temporg.StakeholderType__c,temporg);
                    //temp.push(temporg);
                }
               
                //Fill list from map
                if(mapOfStakeHolders.size > 0){
                    for(let obj of mapOfStakeHolders.values()){
                        temp.push(obj)
                    }
                }
                //Assign templist to server list
                this.stakeHolders = temp;
            }
            
        }catch(e){
            this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
        }
        
    }

    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This method will be used to soft delete the stakeholders
     * @params      : event
     * @return      : NA
     */
    /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
    deleterecords(event){
        try{
            const rows = [];
            
            let mapOfStakeHolders = new Map(); 
            let stakeholderLeadMap = new Map(); 

            //Creating map from stakeHolder server list
            for(const element of this.stakeHolders) {
                if(element.Contact__c != '' && element.Contact__c != undefined){
                    mapOfStakeHolders.set(element.Contact__c+element.StakeholderType__c,element);
                }
                if(element.Account_PA__c != '' && element.Account_PA__c != undefined){
                    mapOfStakeHolders.set(element.Account_PA__c+element.StakeholderType__c,element);
                }
                if((element.Account_PA__c == undefined || element.Account_PA__c == '') && (element.Contact__c == undefined || element.Contact__c == '') && 
                    !mapOfStakeHolders.has(element.Account__c)){
                    mapOfStakeHolders.set(element.Account__c+element.StakeholderType__c,element);
                }
            }

            //Creating map from stakeHolder lead record list
            for(let obj of this.stakeholderLeads){
                let key = obj.Account_PA__c != undefined ? obj.Account_PA__c : obj.Contact__c;
                if(key != undefined && !stakeholderLeadMap.has(key)){
                    stakeholderLeadMap.set(key,obj);
                }
            }
            

            //Create map Key for elemenet deletion
            let mapKey
            if(event.detail.data.StakeholderType__c == STAKEHOLDER_ORGANIZATIONS){
                mapKey = event.detail.data.Account__c + event.detail.data.StakeholderType__c;
            }else{
                mapKey = (event.detail.data.Account_PA__c != undefined ? event.detail.data.Account_PA__c  : event.detail.data.Contact__c )+ event.detail.data.StakeholderType__c;
            }

            if(event.detail.data.StakeholderType__c != '' && event.detail.data.StakeholderType__c != undefined &&
                mapOfStakeHolders.has(mapKey)){
                mapOfStakeHolders.delete(mapKey);
            }
            
            //Functionalty executed when Stakeholder lead added in related list
            if(event.detail.data.StakeholderType__c == STAKEHOLDER_LEADS){
                //Remove the value from client side variable who used to display the values
                let mapOfStakeParticpant = new Map();
                let temp = [];

                //Create a map from stakeParticipants array
                if(this.stakeParticipants.length > 0){

                    for(let obj of this.stakeParticipants){
                        
                        if(obj && obj.Contact__c != undefined && !mapOfStakeParticpant.has(obj.Contact__c)){
                            mapOfStakeParticpant.set(obj.Contact__c+obj.StakeholderType__c,obj);
                        }
                        if(obj && obj.Account_PA__c != undefined && !mapOfStakeParticpant.has(obj.Account_PA__c)){
                            mapOfStakeParticpant.set(obj.Account_PA__c+obj.StakeholderType__c,obj);
                        }
                    }
                    
                    //Create map Key for elemenet deletion
                    let mapKey = (event.detail.data.Account_PA__c != undefined ? event.detail.data.Account_PA__c  : event.detail.data.Contact__c ) + 'Stakeholder Participant';

                    //Delete data from display map
                    if(mapOfStakeParticpant.has(mapKey)){
                        mapOfStakeParticpant.delete(mapKey);
                    }
                    //Delete data from server map
                    if(mapOfStakeHolders.has(mapKey)){
                        mapOfStakeHolders.delete(mapKey);
                    }

                    //create templist from map and assign it to stakeParticipants
                    for(let key of mapOfStakeParticpant.keys()){
                        if(key != undefined && key != ''){
                            temp.push(mapOfStakeParticpant.get(key));
                        }
                    }
                    this.stakeParticipants = temp;
                }

                //Deleting the Stakeholder lead record from local list
                let key = event.detail.data.Account_PA__c != undefined ? event.detail.data.Account_PA__c : event.detail.data.Contact__c;
                if(key != undefined && stakeholderLeadMap.has(key)){
                    stakeholderLeadMap.delete(key);
                }

            }

            //Functionalty executed when Stakeholder participant added in related list
            //Remove the stakeholder participant also from local stakeholer list , if existed
            if(event.detail.data.StakeholderType__c == STAKEHOLDER_PARTICIPANTS && this.stakeParticipants.length > 0){
                
                let recordIdToDelete = event.detail.data.Account_PA__c != undefined ? event.detail.data.Account_PA__c : event.detail.data.Contact__c; 
                
                //Delete the the record on the base of Contact
                if(recordIdToDelete != '' && recordIdToDelete != undefined){
                    this.stakeParticipants.splice(this.stakeParticipants.findIndex(a => (a.Account_PA__c != undefined ? a.Account_PA__c : a.Contact__c) === recordIdToDelete) , 1);
                    
                    //Delete the same Stakeholder lead while deleting the Stakeholder partcipant
                    if(mapOfStakeHolders.has(recordIdToDelete+STAKEHOLDER_LEADS)){
                        mapOfStakeHolders.delete(recordIdToDelete+STAKEHOLDER_LEADS);

                        //Delete the Stakeholder lead also while delete same stakeholder participant record
                        if(stakeholderLeadMap.has(recordIdToDelete)){
                            stakeholderLeadMap.delete(recordIdToDelete);
                        }
                    }
                }    
            }
            
            //Functionalty executed when ofcom participant added in related list
            //Deleting the ofcom participant from local ofcomParticipants list if ofcom partcipant delete from child component
            if(event.detail.data.StakeholderType__c == OFCOM_PARTICIPANTS && this.ofcomParticipants.length > 0){
               
               let mapOfOfcomParticpant = new Map();
                for(let obj of this.ofcomParticipants){
                    if(obj && obj.Contact__c != undefined && !mapOfOfcomParticpant.has(obj.Contact__c)){
                            mapOfOfcomParticpant.set(obj.Contact__c,obj);
                        }
                }
                
                //delete the ofcom participant
                if(mapOfOfcomParticpant.has(event.detail.data.Contact__c)){
                    mapOfOfcomParticpant.delete(event.detail.data.Contact__c);

                    //checking ofcom lead and ofcom participant lookup field values
                    let inputLead = this.template.querySelector( '[ data-id="Contact__c" ]').value;
                    let inputChairPerson = this.template.querySelector( '[ data-id="Chairperson__c" ]').value;
                    
                    //Removing the ofcom lead and ofcom chairperson lookup field
                    if(event.detail.data.Contact__c != undefined){

                        //Removing ofcom lead and ofcom chairperson , if both have same recordid in lookup
                        if(inputLead == event.detail.data.Contact__c && inputChairPerson == event.detail.data.Contact__c){
                            this.template.querySelector( '[ data-id="Contact__c" ]').value = '';
                            this.template.querySelector( '[ data-id="Chairperson__c" ]').value = '';

                        }else if( inputLead == event.detail.data.Contact__c){
                            //Removing ofcom lead , if related ofcom partcipant will deleted from the child list
                            this.template.querySelector( '[ data-id="Contact__c" ]').value = '';

                        }else if(inputChairPerson == event.detail.data.Contact__c){
                            //Removing ofcom chairperson , if related ofcom partcipant will deleted from the child list
                            this.template.querySelector( '[ data-id="Chairperson__c" ]').value = '';
                        }
                    }
                }

                //create new temparray for ofcom particpant and assign it to local list to display
                let teampArray = [];
                for(let mapKey of mapOfOfcomParticpant.keys()){
                    if(mapKey != '' && mapKey != undefined){
                        teampArray.push(mapOfOfcomParticpant.get(mapKey));
                    }
                }     
                this.ofcomParticipants =  teampArray;   
            }


            //Convert stakeholder lead map to array 
            let tempStaleholderLead = [];
            for(let mapKey of stakeholderLeadMap.keys()){
                if(mapKey != undefined){
                    tempStaleholderLead.push(stakeholderLeadMap.get(mapKey));
                }
            }
            //assign the Stakeholder temp array into stakeholderLeads local list
            this.stakeholderLeads = tempStaleholderLead;

            //create final list from map after deleting the data and set to server llist for deletion
            if(mapOfStakeHolders.size > 0){
                for(let key of mapOfStakeHolders.keys()){
                    rows.push(mapOfStakeHolders.get(key));
                }
            }
            this.stakeHolders = rows;
            console.log('deleted Rows==>',rows);
        }catch(e){
            this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
        }
    }     

    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This method will execute when new stakeholder participants are added to the page.
     * @params      : event
     * @return      : NA
     */
    addStakeholderParticipants(event) {
        try{
            let mapOfOfcomParticpant = new Map();
            const temp = [];
            /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
            //Set client side Data from stakeParticipants and create map 
            if(this.stakeParticipants.length > 0){
                for(let obj of this.stakeParticipants){
                    if(obj && obj.Contact__c != undefined && !mapOfOfcomParticpant.has(obj.Contact__c)){
                        mapOfOfcomParticpant.set(obj.Contact__c,obj);
                    }
                    if(obj.Account_PA__c != undefined && !mapOfOfcomParticpant.has(obj.Account_PA__c)){
                        mapOfOfcomParticpant.set(obj.Account_PA__c,obj);
                    }

                }
            }

            for(const obj of this.stakeHolders){
                temp.push(obj);
            }

            if(event.detail.data) {           
                for(const obj of event.detail.data) {
                    let temporg = {'Account__r.Name':'','Account__c':'','StakeholderType__c':'','Meeting__c':'','Contact__c':'','Account_PA__c':''};
                    temporg['Account__r.Name'] = obj["Account__r.Name"];
                    temporg.Account__c = obj["Account__r.Id"];
                    temporg.StakeholderType__c = 'Stakeholder Participant';
                    //Checking if Contact__r.Id having contactId or accountIds and then assign to accordingly
                    if(obj["Contact__r.Id"] && obj["Contact__r.Id"].substring(0,3)=== ACCOUNT_PREFIX_LABEL){
                        temporg.Account_PA__c = obj["Contact__r.Id"];
                        temporg.Contact__c = '';
                        temporg['Contact__r.Id'] = '';
                    }else{
                        temporg.Contact__c = obj["Contact__r.Id"];
                    }
                    temporg.Meeting__c = this.recordId;
                    temp.push(temporg);

                    /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
                    if(obj.Contact__c != undefined && !mapOfOfcomParticpant.has(obj.Contact__c)){
                        mapOfOfcomParticpant.set(obj.Contact__c,obj);
                    }

                    if(obj.Account_PA__c != undefined && !mapOfOfcomParticpant.has(obj.Account_PA__c)){
                        mapOfOfcomParticpant.set(obj.Account_PA__c,obj);
                    }
                }
                this.stakeHolders = temp;
                
                /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
                //Set client side Data teamp list and assign it to stakeParticipants
                let newTemp = [];
                if(mapOfOfcomParticpant.size > 0){
                    for(let key of mapOfOfcomParticpant.keys()){
                        if(key != undefined && key != ''){
                            newTemp.push(mapOfOfcomParticpant.get(key));
                        }
                    }
                    this.stakeParticipants = newTemp;
                }
            }
        }catch(e){
            this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
        }
    }
    
    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This method will execute when new ofcom participants are added to the page.
     * @params      : NA
     * @return      : NA
     */
     addOfcomParticipants(event) {
        try{
            let mapOfOfcomParticpant = new Map();
            const temp = [];
            /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
            //Set client side Data from ofcomParticipants and create map 
            if(this.ofcomParticipants.length > 0){
                for(let obj of this.ofcomParticipants){
                    if(obj && obj.Contact__c != undefined && !mapOfOfcomParticpant.has(obj.Contact__c)){
                        mapOfOfcomParticpant.set(obj.Contact__c,obj);
                    }
                }
            }

            for(const obj of this.stakeHolders){
                temp.push(obj);
            }

            if(event.detail.data) {           
                for(const obj of event.detail.data) {
                    let temporg = {'Account__r.Name':'','Account__c':'','StakeholderType__c':'','Meeting__c':'','Contact__c':''};
                    temporg['Account__r.Name'] = obj["Account__r.Name"];
                    temporg.Account__c = obj["Account__r.Id"];
                    temporg.StakeholderType__c = OFCOM_PARTICIPANTS;
                    temporg.Contact__c = obj["Contact__r.Id"];
                    temporg.Meeting__c = this.recordId;
                    temp.push(temporg);

                    if(obj.Contact__c != undefined && !mapOfOfcomParticpant.has(obj.Contact__c)){
                        mapOfOfcomParticpant.set(obj.Contact__c,obj);
                    }
                    
                }
                this.stakeHolders = temp;
            }
            
            //Set client side Data teamp list and assign it to ofcomParticipants
            /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
            let newTemp = [];
            if(mapOfOfcomParticpant.size > 0){
                for(let key of mapOfOfcomParticpant.keys()){
                    if(key != undefined && key != ''){
                        newTemp.push(mapOfOfcomParticpant.get(key));
                    }
                }
                this.ofcomParticipants = newTemp;
            }
            

        }catch(e){
            this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
        }
    }
    
    /*
     * @author      : Coforge
     * @date        : 29/04/2024
     * @description : This method will execute when ofcom Lead and Ofcom Particiapnt lookup field added or removed on the page.
     * @params      : NA
     * @return      : NA
     */
    async addOfcomParticipantDataSelect(event){
        this.addOfcomParticipantData(event.target.value, event.target.dataset.id);
    }

    /*
     * @author      : Coforge
     * @date        : 29/04/2024
     * @description : This method will execute when ofcom Lead and Ofcom Particiapnt lookup field added or removed on the page.
     * @params      : NA
     * @return      : NA
     */
    /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
    async addOfcomParticipantData(selectedRecordId, datasetId){
        try{

            let mapOfOfcomParticpant = new Map();
            let contactIdToDelete;

			//Set client side Data from ofcomParticipants and create map 
            if(this.ofcomParticipants.length > 0){
                for(let obj of this.ofcomParticipants){
                    if(obj && obj.Contact__c != undefined && !mapOfOfcomParticpant.has(obj.Contact__c)){
                        mapOfOfcomParticpant.set(obj.Contact__c,obj);
                    }
                }
            }
            
            //checking ofcom lead and ofcom participant lookup field values
            let inputLead = this.template.querySelector( '[ data-id="Contact__c" ]').value;
            let inputChairPerson = this.template.querySelector( '[ data-id="Chairperson__c" ]').value;
            
			//remove data if we unselect the ofcom Lead and ofom chairperson
			if(selectedRecordId == '' || selectedRecordId == undefined){
                
                //ignore remove if Ofcom chairpserson have the same lookup value
                if(datasetId  == 'Contact__c'){
                    if(inputChairPerson == this.mapOfContactIds.get('Contact__c')){
                        return;
                    }
                }
                //ignore remove if ofcom lead have the same lookup field
                if(datasetId  == 'Chairperson__c'){
                    if(inputLead == this.mapOfContactIds.get('Chairperson__c')){
                        return;
                    }
                }
                
                contactIdToDelete = this.mapOfContactIds.get(datasetId);
                
                if(contactIdToDelete && contactIdToDelete !== '' && mapOfOfcomParticpant.has(contactIdToDelete)){
                    this.stakeHolders.splice(this.stakeHolders.findIndex(a => a.Contact__c === contactIdToDelete) , 1)
					mapOfOfcomParticpant.delete(contactIdToDelete);
                }
                this.mapOfContactIds.set('Contact__c', inputLead);
                this.mapOfContactIds.set('Chairperson__c', inputChairPerson);

			}else{
                
                if(inputLead && inputLead != null && inputLead != ''){
                    this.mapOfContactIds.set('Contact__c',inputLead);
                }
                if(inputChairPerson && inputChairPerson != null && inputChairPerson != ''){
                    this.mapOfContactIds.set('Chairperson__c',inputChairPerson);
                }
            }
            
			//After selecting the ofcom lead or ofcom participant in lookup field, fetch the complete information from server and assign to child ofcom partcipant list
			if(selectedRecordId != undefined && selectedRecordId != ''  && 
            (this.mapOfContactIds.get('Contact__c')== selectedRecordId || this.mapOfContactIds.get('Chairperson__c')== selectedRecordId)) {
				
				await getRelatedList({
					metadataRecordName: SEARCH_CONTACT_METADATANAME,
					filterCriteria: 'Id = \''+ selectedRecordId +'\''
				}).then((result) => {
					try{
						if(result) {
							let obj = this.mappOfcomParticipantData(result[0]);
                            if(obj.Contact__c && obj.Contact__c != undefined){
                                mapOfOfcomParticpant.set(obj.Contact__c,obj);
                            }
						}
					} catch(e){
						this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
					}
				})
				.catch((error) => {
					console.log(error);
					this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
				});
			}

            //Set client side Data from mapOfOfcomParticpant 
			let tempParticipant = [];
            let tempStakeHolders = [];

            let mapOfStakeHolders = new Map();
            if(this.stakeHolders.length > 0){
                for(const element of this.stakeHolders) {
                    if(element.Contact__c != '' && element.Contact__c != undefined){
                        mapOfStakeHolders.set(element.Contact__c+element.StakeholderType__c,element);
                    }
                    if(element.Account_PA__c != '' && element.Account_PA__c != undefined){
                        mapOfStakeHolders.set(element.Account_PA__c+element.StakeholderType__c,element);
                    }
                    if((element.Account_PA__c == undefined || element.Account_PA__c == '') && (element.Contact__c == undefined || element.Contact__c == '') && 
                        !mapOfStakeHolders.has(element.Account__c)){
                        mapOfStakeHolders.set(element.Account__c+element.StakeholderType__c,element);
                    }
                }
            }

            //assigning data into ofcomParticipants and stakeHolders server list
            if(mapOfOfcomParticpant.size > 0){
                for(let key of mapOfOfcomParticpant.keys()){
                    tempParticipant.push(mapOfOfcomParticpant.get(key));
                    
                    let mapKey =key+OFCOM_PARTICIPANTS;
                    if(!mapOfStakeHolders.has(mapKey)){
                        mapOfStakeHolders.set(mapKey,this.transformObject(mapOfOfcomParticpant.get(key)));
                    }
                }
            }

            //Delete the ofcom participant data from server list also
            if(contactIdToDelete != '' && contactIdToDelete != undefined && mapOfStakeHolders.has(contactIdToDelete)){
                mapOfStakeHolders.delete(contactIdToDelete);
            }

            //create the tempserver list from map and assign to main server list
            if(mapOfStakeHolders.size > 0){
                for(let mapKey  of mapOfStakeHolders.keys()){
                    if(mapKey != undefined){
                        tempStakeHolders.push(mapOfStakeHolders.get(mapKey));
                    }
                }
            }
            //Assign the temparray t0 main array
            this.ofcomParticipants = tempParticipant;
            this.stakeHolders = tempStakeHolders;
        }catch(e){
            this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
        }
}   


    /*
     * @author      : Coforge
     * @date        : 16/04/2024
     * @description : This method used to create stakeholder account object and assign the value and return the object
     * @params      : result
     * @return      : tempdetail
     */
    /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
    mapStakeholderOrgData(obj){
        let tempdetail = { 'Account__c':'' ,'Account__r.Name':'','Account__r.Address__c':'','StakeholderType__c':'','URL':'', 'displayName':''};
        tempdetail['Account__c'] = obj.Id;
        tempdetail['Account__r.Id'] = obj.Id;
        tempdetail['Account__r.Name'] = obj.Name;
        tempdetail['Account__r.Address__c'] = obj.Address__c;
        tempdetail['StakeholderType__c'] = STAKEHOLDER_ORGANIZATIONS;
        tempdetail['displayName'] = obj.Name;
        tempdetail['Account__r.OS_Business_Owner__c'] = obj.OS_Business_Owner__c;
        return tempdetail;
    }

    /*
     * @author      : Coforge
     * @date        : 16/04/2024
     * @description : This method used to create the object and assign the value and return the object
     * @params      : result
     * @return      : tempdetail
     */
    /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
    mappOfcomParticipantData(obj){
        let tempdetail;
            tempdetail = { 'Contact__c':'','Account__r.Id':'','Contact__r.Id':'','Contact__r.Name':'','Account__r.Name':'','Contact__r.JobTitle__c':'','Contact__r.Email':'','URL':'','StakeholderType__c':'','Contact__r.Team_Name__c':'','displayName':'', 'Meeting__c':''};
            tempdetail['Contact__c'] = obj.Id;
            tempdetail['Account__r.Id']= obj.AccountId;
            tempdetail['Account__r.Name'] = obj['Account.Name'];
            tempdetail['Contact__r.Name']  = obj.Name;
            tempdetail['Contact__r.Id'] = obj.Id;
            tempdetail['Contact__r.Email'] = obj.Email;
            tempdetail['Contact__r.JobTitle__c'] = obj.JobTitle__c;
            tempdetail['StakeholderType__c'] = OFCOM_PARTICIPANTS ;
            tempdetail['Contact__r.Team_Name__c'] = obj.Team_Name__c;
            tempdetail['displayName'] = obj.Name;
            tempdetail['Meeting__c'] = this.recordId;
        return tempdetail;
    }

    /*
     * @author      : Coforge
     * @date        : 16/04/2024
     * @description : This method used to create the object and assign the value and return the object
     * @params      : result
     * @return      : tempdetail
     */
    /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
    mappStakeParticipantServerData(obj){
        let tempdetail;
        tempdetail = { 'Contact__c':'','Account__r.Id':'','Contact__r.Id':'','Contact__r.Name':'','Account__r.Name':'','Contact__r.JobTitle__c':'','Contact__r.Email':'','URL':'','StakeholderType__c':'','Contact__r.Team_Name__c':'','displayName':'', 'Meeting__c':''};
            tempdetail['Contact__c'] = obj.Contact__c;
            tempdetail['Account__r.Id']= obj.Account__c;
            tempdetail['Account__r.Name'] = obj.Account__r.Name;
            tempdetail['Contact__r.Name']  = obj.Contact__r.Name;
            tempdetail['Contact__r.Id'] = obj.Contact__c;
            tempdetail['Contact__r.Email'] = obj.Contact__r.Email;
            tempdetail['Contact__r.JobTitle__c'] = obj.Contact__r.JobTitle__c;
            tempdetail['StakeholderType__c'] = obj.StakeholderType__c;
            tempdetail['Contact__r.Team_Name__c'] = obj.Contact__r.Team_Name__c;
            tempdetail['displayName'] = obj.Contact__r.Name;
            tempdetail['Contact__r.Preferred_language__c'] = obj.Contact__r.Preferred_language__c;
            tempdetail['Meeting__c'] = this.recordId;
        return tempdetail;
    }

    /*
     * @author      : Coforge
     * @date        : 16/04/2024
     * @description : This method used to create the object and assign the value and return the object
     * @params      : result
     * @return      : tempdetail
     */
    /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
    mappStakeParticipantAccountServerData(obj){
        let tempdetail;
        tempdetail = { 'Contact__c':'','Account__r.Id':'','Contact__r.Id':'','Contact__r.Name':'','Account__r.Name':'','Contact__r.JobTitle__c':'','Contact__r.Email':'','URL':'','StakeholderType__c':'','Contact__r.Team_Name__c':'','displayName':'', 'Meeting__c':''};
            tempdetail['Contact__c'] = obj.Contact__c;
            tempdetail['Account__r.Id']= obj.Account__c;
            tempdetail['Account__r.Name'] = obj.Account__r.Name;
            tempdetail['Contact__r.Name']  = obj.Account_PA__r.Name;
            tempdetail['Contact__r.Id'] = obj.Account_PA__c;
            tempdetail['Contact__r.Email'] = obj.Account_PA__r.PersonEmail;
            tempdetail['Contact__r.JobTitle__c'] = obj.Account_PA__r.JobTitle__pc;
            tempdetail['StakeholderType__c'] = obj.StakeholderType__c;
            tempdetail['Contact__r.Team_Name__c'] = obj.Account_PA__r.Team_Name__pc;
            tempdetail['displayName'] = obj.Account_PA__r.Name;
            tempdetail['Contact__r.Preferred_language__c'] = obj.Account_PA__r.Preferred_language__pc;
            tempdetail['Meeting__c'] = this.recordId;
            tempdetail['Account_PA__c'] = obj.Account_PA__c;
        return tempdetail;
    }   

    /*
     * @author      : Coforge
     * @date        : 16/04/2024
     * @description : This method used to create the object and assign the value and return the object
     * @params      : result
     * @return      : tempdetail
     */
    /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
    transformArrayObject (ofcomParticipants){
        let mapOfContactIds = new Map();
        let temp = [];
        if(ofcomParticipants ){
            for(const obj of ofcomParticipants){
                if(!mapOfContactIds.has(obj["Contact__r.Id"])){
                    mapOfContactIds.set(obj["Contact__r.Id"]);
                    if(obj["Contact__r.Id"] && obj["Contact__r.Id"].substring(0,3)==='001'){
                        temp.push(this.transformAccountObject(obj));
                    }else{
                        temp.push(this.transformObject(obj));
                    }
                }
            }
            return temp;
        }  
    }

    /*
     * @author      : Coforge
     * @date        : 16/04/2024
     * @description : This method used to create the object and assign the value and return the object
     * @params      : result
     * @return      : tempdetail
     */
    transformObject(obj){
        let temporg = {'Account__r.Name':'','Account__c':'','StakeholderType__c':'','Meeting__c':'','Contact__c':''};
            temporg['Account__r.Name'] = obj["Account__r.Name"];
            temporg.Account__c = obj["Account__r.Id"];
            temporg.StakeholderType__c = obj["StakeholderType__c"];
            temporg.Contact__c = obj["Contact__r.Id"];
            temporg.Meeting__c = this.recordId;
            return temporg;
    }

    /*
     * @author      : Coforge
     * @date        : 16/04/2024
     * @description : This method used to create the object and assign the value and return the object
     * @params      : result
     * @return      : tempdetail
     */
    transformAccountObject(obj){
        let temporg = {'Account__r.Name':'','Account__c':'','StakeholderType__c':'','Meeting__c':'','Contact__c':''};
            temporg['Account__r.Name'] = obj["Account__r.Name"];
            temporg.Account__c = obj["Account__r.Id"];
            temporg.StakeholderType__c = obj["StakeholderType__c"];
            temporg.Account_PA__c = obj["Contact__r.Id"];
            temporg.Meeting__c = this.recordId;
            return temporg;
    }

    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This method will execute on click of submit button of create meeting page when meeting is saved.
     * @params      : NA
     * @return      : NA
     */
    handleSuccess(event) {
        this.recordId = event.detail.id;
        this.submitMeetings(event.detail.id);
    }
    stakeholderorg
    actionorg //W-002684
    submitMeetings(recordId) {
        this.showLoading = true
        const rows = [];
        const row1 = []; //W-002684
        if (this.stakeHolders.length == 0 ){
            rows.push(this.stakeholderorg);
            this.stakeHolders = rows;
        }
        
        // start for W-002684
        if (this.meetingActions.length == 0 ){
            row1.push(this.actionorg );
            this.meetingActions = row1;
        }
       //end for W-002684
        submitMeeting({ meetingId: this.recordId, wrapper: this.stakeHolders, meetingActions:this.meetingActions })
            .then((result) => {
                if (result==SUCCESS_LABEL){
                    this.showNoRecordsToast(CUSTOM_LABELS.MeetingSavedSuccess,SUCCESS_LABEL,DISMISSABLE_LABEL);   
                    window.location.assign(window.location.origin + '/'+recordId); //added for catche issue in related list
                    this.showLoading = false;
                }else{
                    this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
                    this.showLoading = false;
                }
            })
            .catch((error) => {
                //W-002679
                this.showLoading = false;
                let errMsg = error.body.message;
                if(errMsg != undefined && errMsg.includes(FIELD_CUSTOM_VALIDATION_EXCEPTION)){
                    errMsg = errMsg.substr(errMsg.indexOf(EXCEPTION_LABEL)+11);
                    errMsg = errMsg.slice(0, errMsg.indexOf(": ["));
                    this.showNoRecordsToast(errMsg,ERROR_LABEL,DISMISSABLE_LABEL);
                }else{
                    this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
                }
            });
    }
    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : To show the toast message for success and error 
     * @params      : title
     * @params      : variant
     * @params      : mode
     * @return      : NA
     */
    showNoRecordsToast(title,variant,mode) {
        const event = new ShowToastEvent({
            title: title,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(event);
    }

    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This method will execute on click of Cancel button and will redirect back to the recent list view.
     * @params      : event
     * @return      : NA
     */
    handleCancel(event) {
        this.navigateToRecentListView();
    }
    

    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This method will navigate user to the recently viewed meetings list view.
     * @params      : NA
     * @return      : NA
     */
    navigateToRecentListView() {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: this.meetingObjectApiName,
                actionName: 'list'
            },
            state: { 
                filterName: 'Recent' 
            }
        });
    }
    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This will remove deleted record from wrapper (W-002684)
     * @params      : event
     * @return      : NA
     */
    deleteActionRecord(event){
        try{
            const rows = [];
            for(const element of this.meetingActions) {
                if(element.UniqueId !== event.detail.data.UniqueId || (element.Id!=undefined && 
                    element.Id !== event.detail.data.Id && event.detail.data.Id!=undefined)){
                    rows.push(element);
                    
                }
                this.meetingActions = rows;
            
            }
        }
        catch(e){
            this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);
        }
    }
 /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This will add meetingactions in wrapper (W-002684)
     * @params      : event
     * @return      : NA
     */
    addActionRecords(event){
        try{
            const temp = [];
            if(event.detail.data) {
                for(const obj of event.detail.data) {
                    if(obj.Id!== undefined){
                        this.sendActionDataWithId(obj,temp); //calling method to prepare data with Id
                    } 
                    else {
                        this.sendActionDataWithoutId(obj,temp); //calling method to prepare data without Id
                    }
                }
                this.meetingActions = temp;
            } 
        }
        catch(e){
            this.showNoRecordsToast(COMMON_ERROR,ERROR_LABEL,DISMISSABLE_LABEL);

        }
    }
    /*
     * @author      : Coforge
     * @date        : 20/11/2021
     * @description : This will add meetingactions with id  (W-002684)
     * @params      : obj,temp
     * @return      : NA
     */
    sendActionDataWithId(obj,temp){
        let temporg = {'Action_Owner__c':'','Action_Description__c':'','Due_Date__c':'','Meeting__c':'','UniqueId':'','Id':''};
        temporg['Action_Owner__c'] = obj["Action_Owner__c"]=== undefined ? '': obj["Action_Owner__c"].toString();
        temporg['Action_Description__c'] = obj["Action_Description__c"];
        temporg['Due_Date__c'] = obj["Due_Date__c"];
        temporg['Meeting__c'] = this.recordId;
        temporg['UniqueId'] = obj["UniqueId"];
        temporg['Id'] = obj.Id
        temp.push(temporg);
    }

    /*
     * @author      : Coforge
     * @date        : 05/09/2022
     * @description : This will add meetingactions without id  (W-002684)
     * @params      : obj,temp
     * @return      : NA
     */
   sendActionDataWithoutId(obj,temp){
        let temporg = {'Action_Owner__c':'','Action_Description__c':'','Due_Date__c':'','Meeting__c':'','UniqueId':''};
        temporg['Action_Owner__c'] = obj["Action_Owner__c"]=== undefined ? '': obj["Action_Owner__c"].toString();
        temporg['Action_Description__c'] = obj["Action_Description__c"];
        temporg['Due_Date__c'] = obj["Due_Date__c"];
        temporg['Meeting__c'] = this.recordId;
        temporg['UniqueId'] = obj["UniqueId"];
        temp.push(temporg);
   }

    /*
     * @author      : Coforge
     * @description : this property is used to hide the create popup form 
     * @params      : NA
     * @return      : NA
     */
   closeCreateRecordModel() {
        this.showCreateRecordModel = false;
        this.showCreateRecordModelLead = false;
    }

    /*
     * @author      : Coforge
     * @description : this property is used to show the add button icon 
     * @params      : NA
     * @return      : NA
     */

    openCreateRecordModel() {
        this.showCreateRecordModel = true;
    }

    /*
     * @author      : Coforge
     * @description : this property is used to show the add button icon 
     * @params      : NA
     * @return      : NA
     */
    openCreateRecordModelLead() {
        this.showCreateRecordModelLead = true;
    }

    /*
     * @author      : Coforge
     * @description : closeCreatePopup 
     * @params      : NA
     * @return      : NA
     */
    closeCreatePopup(event) { 
        let selectedRecordId;
        //let tempArray = [];                
           for(const element1 of event.detail) {
                const inputFields = this.template.querySelectorAll(
                    'lightning-input-field'
                );
                
                if (inputFields) {
                    inputFields.forEach(field => {
                        if (this.showCreateRecordModelLead && field.fieldName == 'Contact__c'){
                                //Remove the preselect ofcom lead
                                this.removeOverrideOfcomParticipant(this.template.querySelector( '[ data-id="Contact__c" ]').value);

                                field.value = element1.Id;
                                this.showCreateRecordModelLead = false;
                                
                                //Add it ofcom Participant list
                                if(element1.Id != undefined && element1.Id != ''){
                                   selectedRecordId = element1.Id;
                                }

                                //tempArray.push(element1);
                        } else if (this.showCreateRecordModel && field.fieldName == 'Chairperson__c'){

                                //Remove the preselect ofcom lead
                                this.removeOverrideOfcomParticipant(this.template.querySelector( '[ data-id="Chairperson__c" ]').value);

                                field.value = element1.Id;
                                this.showCreateRecordModel = false;

                                 //Add it ofcom Participant list
                                if(element1.Id != undefined && element1.Id != ''){
                                    selectedRecordId = element1.Id;
                                }
                                
                                //tempArray.push(element1);
                        }
                        //if Contact create for Contact and Chairperson__c then Ofcom Employee should be true
                        if(field.fieldName == 'Ofcom_Employee__c'){
                            field.value = true;
                        }
                    });
                }
        }
         //Add ofcom lead and ofcom particpant in child list and server list if new ofcom lead and ofcom participant list
         /*26303-REQ0151252 Ticket- Auto-populate Ofcom and Stakeholder Participants in a Meeting Record */
        if(selectedRecordId != undefined && selectedRecordId != ''){
            this.addOfcomParticipantData(selectedRecordId,'');
        }
    }
    
    //Method is used to delete the preselect ofcom lead and ofcom participant
    removeOverrideOfcomParticipant(recordIdToRemove){
        if(recordIdToRemove != undefined && recordIdToRemove != ''){
            this.ofcomParticipants.splice(this.ofcomParticipants.findIndex(a => a.Contact__c === recordIdToRemove) , 1);
            this.stakeHolders.splice(this.stakeHolders.findIndex(a => a.Contact__c === recordIdToRemove) , 1);
        }
    }
}