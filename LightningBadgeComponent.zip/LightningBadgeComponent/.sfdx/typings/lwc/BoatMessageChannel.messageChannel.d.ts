declare module "@salesforce/messageChannel/BoatMessageChannel__c" {
    var BoatMessageChannel: string;
    export default BoatMessageChannel;
}