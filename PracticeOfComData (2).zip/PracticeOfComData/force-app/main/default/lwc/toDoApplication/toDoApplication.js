import { createRecord, deleteRecord, updateRecord } from 'lightning/uiRecordApi';
import { LightningElement,wire } from 'lwc';
import {refreshApex} from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import TASK_MANAGER_OBJECT from '@salesforce/schema/Task_Manager__c';
import TASK_Id_FIELD from '@salesforce/schema/Task_Manager__c.Id';
import TASK_NAME_FIELD from '@salesforce/schema/Task_Manager__c.Name';
import TASK_DATE_FIELD from '@salesforce/schema/Task_Manager__c.Task_Date__c';
import COMPLETED_DATE_FIELD from '@salesforce/schema/Task_Manager__c.Completed_Date__c';
import ISCOMPLETED_FIELD from '@salesforce/schema/Task_Manager__c.isCompleted__c';
import loadAllInCompleteRecords from '@salesforce/apex/toDoController.loadAllInCompleteRecords';
import loadAllCompleteRecords from '@salesforce/apex/toDoController.loadAllCompleteRecords';
export default class ToDoApplication extends LightningElement {

    taskname="";
    taskdate=null;
    incompleteTask=[];
    completeTask=[];
     incompletedTaskResult;
     completedTaskResult;
    @wire(loadAllInCompleteRecords) wire_inCompleteRecords(result){
        this.incompletedTaskResult=result;
        let {data,error}=result;
        if(data){
            console.log('InComplete  Task  Record',data);
            this.incompleteTask=data.map(currItem=> ({
                taskId:currItem.Id,
                taskname:currItem.Name,
                taskdate:currItem.Task_Date__c

            }))
            console.log('InComplete  Task Array  Record',this.incompleteTask);
        }
        else if(error){
            console.log('Complete  Task Record',error);
        }
    }


    @wire(loadAllCompleteRecords) wire_CompleteRecords(result){
        this.completedTaskResult=result;
        let {data,error}=result;
        if(data){
            console.log('Complete  Task  Record',data);
            this.completeTask=data.map(currItem=> ({
                taskId:currItem.Id,
                taskname:currItem.Name,
                taskdate:currItem.Task_Date__c

            }))
            console.log('Complete  Task Array  Record',this.completeTask);
        }
        else if(error){
            console.log('Complete  Task Record',error);
        }
    }
    changeHandler(event){
           let {name,value}=event.target;
           if(name==='taskname'){
             this.taskname=value;
           }
           else if(name==='taskdate'){
            this.taskdate=value;
           }

    }

    resetHandler(){
         this.taskname="";
         this.taskdate=null;
    }
    addTaskHandler(){
        if(!this.taskdate){
              this.taskdate=new Date().toISOString().slice(0,10);
        }

        if(this.validateTask()){
            // this.incompleteTask=[...this.incompleteTask,{
            //     taskname:this.taskname,
            //     taskdate:this.taskdate
            // }];
            // this.resetHandler();
            // let sortedArray=this.sortTask(this.incompleteTask);
            // this.incompleteTask=[...sortedArray];
            // console.log('this.incompletearray'+this.incompleteTask);
            let inputFields={};
            inputFields[TASK_NAME_FIELD.fieldApiName]=this.taskname;
            inputFields[TASK_DATE_FIELD.fieldApiName]=this.taskdate;
            inputFields[ISCOMPLETED_FIELD.fieldApiName]=false;
            let recordInput={
                apiName:TASK_MANAGER_OBJECT.objectApiName,
                fields:inputFields
            }
            createRecord(recordInput).then((result)=>{
                console.log('Record Created Sucessfully ',result);
                this.showToast('Success','Task Created Successfully','success');
                this.resetHandler();
                refreshApex(this.incompletedTaskResult);
            });

        }
    }

    validateTask(){
        let isValid=true;
        let element=this.template.querySelector('.taskname');
        if(!this.taskname){
            isValid=false;
        }
        else{
            let taskItem= this.incompleteTask.find((currItem)=>
             currItem.taskname===this.taskname && 
             currItem.taskdate===this.taskdate
             );
             if(taskItem){
                 isValid=false;
                 element.setCustomValidity('Task is Already Available')
             }
        }
        if(isValid){
            element.setCustomValidity("");
        }
        element.reportValidity();
        return isValid;
    }

    sortTask(inputarr){
      let sortedArray= inputarr.sort((a,b)=>{
          const dateA=new Date(a.taskdate);
          const dateB=new Date(b.taskdate);
          return dateA-dateB;
        });

        return sortedArray;
    }


    removalHandler(event){
      let recordId=event.target.name;
      deleteRecord(recordId).then(()=>{
            this.showToast('success','Record Deleted Successfully','success');
            refreshApex(this.incompletedTaskResult);
      }).catch((error)=>{
        this.showToast('Deleted','Record Deletion Failed','error');
      });
    //   this.incompleteTask.splice(index,1);
    //   let sortedArray=this.sortTask(this.incompleteTask);
    //   this.incompleteTask=[...sortedArray];
    //   console.log('this.incompletearray'+this.incompleteTask);


    }


    completetaskHandler(event){
        let recordId=event.target.name;
    //    let removeItem= this.incompleteTask.splice(index,1);
    //    let sortedArray=this.sortTask(this.incompleteTask);
    //    this.incompleteTask=[...sortedArray];
    //    console.log('this.incompletearray'+this.incompleteTask);
    //    this.completeTask=[...this.completeTask,removeItem[0]];

         this.refreshData(recordId);

    }

    dragStartHandler(event){
      event.dataTransfer.setData("index",event.target.dataset.item);
    }

    allowDrop(event){
        event.preventDefault();

    }

    dropElementHandler(event){
          let recordId= event.dataTransfer.getData("index");
          this.refreshData(recordId);
    }

    async refreshData(recordId){
        let inputFields={};
        inputFields[TASK_Id_FIELD.fieldApiName]=recordId;
        inputFields[ISCOMPLETED_FIELD.fieldApiName]=true;
        inputFields[COMPLETED_DATE_FIELD.fieldApiName]=new Date().toISOString().slice(0,10);
          let recordInput={
            fields:inputFields
          };
          try{
            await updateRecord(recordInput);
            await refreshApex(this.incompletedTaskResult);
            await refreshApex(this.completedTaskResult);
            this.showToast('Updated','Record Updated Successfully','success');
          }
          catch(error){
            console.log('Update Operation failed',error);
            this.showToast('Error','Record Updation Failed','error');
          }
         
      
        // let removeItem= this.incompleteTask.splice(index,1);
        // let sortedArray=this.sortTask(this.incompleteTask);
        // this.incompleteTask=[...sortedArray];
        // console.log('this.incompletearray'+this.incompleteTask);
        // this.completeTask=[...this.completeTask,removeItem[0]];
 
    }

    showToast(title,message,variant) {
        const event = new ShowToastEvent({
            title: title,
            message:message,
            variant:variant
               
        });
        this.dispatchEvent(event);
    }

}