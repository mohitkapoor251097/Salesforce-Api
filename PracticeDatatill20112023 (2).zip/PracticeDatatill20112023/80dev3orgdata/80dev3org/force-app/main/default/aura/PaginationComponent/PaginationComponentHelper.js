/*********************************************************************
# File....................: PaginationComponentHelper
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............:  01/04/2021
# Last Modified by........: 
# Last Modified Date......:  
# Description.............: This is a JS Controller of 'paginationComponent'Lightning component.   
# VF Page.................: NA
# VF Component............: NA
# L Comp..................: paginationComponent
# Test Class..............: NA
# Change Log..............: Intitial Version, 1.0
**********************************************************************/
({
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to fetch data for particular page.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    getData: function (component, page, recordToDisply,isSelectedRecordExist) {
        try {
            var pageSize = recordToDisply;
            var offset = (parseInt(page - 1)) * pageSize;
            var data = component.get('v.dataArray');
            // set the pageSize,Page(Number), total records and accounts List(using OFFSET)   
            
            var total = data.length;
            
            let rowData = [];
            var i;
            var limit = offset + (parseInt(pageSize));
            for (i = offset; i < data.length && i < limit; i++) {
                rowData.push(data[i]);
            }
            component.set('v.lstSelectedRecordsList', rowData);
            component.set("v.total", total);
            component.set("v.pages", Math.ceil(total / recordToDisply));
            var offset = (page - 1) * recordToDisply;
            component.set('v.offset', offset + 1);
            var recordToDisplyVal = parseInt(offset) + parseInt(recordToDisply);
            component.set('v.recordToDisply', recordToDisplyVal);
            // If no data is found on particular page, then to redirect to  previous page
            if (rowData.length == 0 && page > 1) {
                component.set("v.page", page - 1);
                this.getData(component, page - 1, recordToDisply);
            }
            
           
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling paginationComponentHelper->getData @@@@' + e);
        }
    },
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to refresh the selected records on parent component.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    setSelectedRecords: function (component,page) {
        try{
            var page = component.get("v.page") || 1;
            var pgName = "page" + page;
            var setEvent = component.getEvent("setAttribute");
            var selectedRows = component.get("v.SelectedCase")[pgName];
            var selectedRowsIds = [];
            if (typeof selectedRows != 'undefined' && selectedRows.length>0) {
                for (var i = 0; i < selectedRows.length; i++) {
                    selectedRowsIds.push(selectedRows[i].Id);
                }
            }
            setEvent.setParams({
                "SelectedCase": selectedRowsIds,
                "selectedCaseMap": component.get("v.SelectedCase")
            });
            setEvent.fire();
        }
        catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling paginationComponentHelper->setSelectedRecords @@@@' + e);
        }
    }
    
})