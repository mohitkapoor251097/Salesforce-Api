/*********************************************************************
# File....................: UploadFileComponentController
# Version.................: 1.0
# Created by..............: NIIT
# Created Date............: 12/08/2020 
# Last Modified by........: NIIT
# Last Modified Date......: 12/08/2020
# Description.............: This is a JS Controller of 'UploadFileComponent'Lightning component.   
# VF Page.................: NA
# VF Component............: NA
# L Comp..................: UploadFileComponent
# Test Class..............: NA
# Change Log..............: Intitial Version, 1.0
**********************************************************************/
({
    /**
    * @author      : NIIT
    * @date        : 12/08/2020
    * @description : This method calls method 'getNumOFFiles' of helper class.
    * @param1      : NA
    * @return      : Void
    */
    getNumOFFiles:function(component,event,helper){
        try{
            helper.getNumOfFiles(component,event);
        }
        catch(e){
            alert($A.get("{!$Label.c.MID_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling getNumOFFiles@@@@' + e);
        }
    }
})