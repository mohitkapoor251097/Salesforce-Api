({
    /*
    * @author      : NIIT
    * @date        : 03/01/2020
    * @description : On load method which shows Email Template and To Address.
    * @params      : component, event, helper
    * @return      : NA
    */
    doInit: function (component, event, helper) {
        try{            
            helper.onloadDisplayEmailTemplate(component);
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling DOINIT Function@@@@ ' + e);
        }
    },
    /*
    * @author      : NIIT
    * @date        : 03/01/2020
    * @description : This function will call on click of Send Button to send an email.
    * @params      : component, event, helper
    * @return      : NA
    */
    sendMail: function (component, event, helper) {       
        try{
            helper.sendHelper(component);
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling sendMail@@@@' + e);
        }
    },
    /*
    * @author      : NIIT
    * @date        : 03/01/2020
    * @description : This function will call to get the selected User record from the COMPONENT event  .
    * @params      : component, event, helper
    * @return      : NA
    */
    handleComponentEvent : function(component, event, helper) {
        try{
            var selectedAccountGetFromEvent = event.getParam("recordByEvent");
            component.set("v.selectedRecordToVar" , selectedAccountGetFromEvent);
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling handleComponentEvent@@@@' + e);
        }
    },
    /*
    * @author      : NIIT
    * @date        : 03/01/2020
    * @description : This function will call to get the selected User record from the COMPONENT event to display in CC and BCC.
    * @params      : component, event, helper
    * @return      : NA
    */
    handleMultiSelectCompEvent : function(component, event, helper) {  
        try{	
            var selectedUserGetFromEvent = event.getParam("recordByEvent");
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling handleMultiSelectCompEvent@@@@' + e);
        }
    },
    /*
    * @author      : NIIT
    * @date        : 03/01/2020
    * @description : This function will call to close the current page and go back to Detail Page.
    * @params      : component, event, helper
    * @return      : NA
    */
    closeMessage : function(component, event, helper) {
        try{
            helper.fireEventToCallVf(component, event);
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling handleMultiSelectCompEvent@@@@' + e);
        }
    },
    
})