/*********************************************************************
# File....................: MultipleFileUploadsController
# Version.................: 1.0
# Created by..............: NIIT
# Created Date............: 12/08/2020 
# Last Modified by........: NIIT
# Last Modified Date......: 12/08/2020
# Description.............: This is a JS Controller of 'MultipleFileUploads' Lightning component.   
# VF Page.................: NA
# VF Component............: NA
# L Comp..................: MultipleFileUploads
# Test Class..............: NA
# Change Log..............: Intitial Version, 1.0
**********************************************************************/
({
    /**
	* @author      : NIIT
	* @date        : 12/08/2020
	* @description : This method calls through Init event handler.
    				 we are setting the recordId into sObjectId in case this component called directly.
	* @param       : component, event, helper
	* @return      : Void
	*/
    doInit : function (component, event, helper){
        try{
            if(component.get("v.sObjectId") == ''){ //it means that component is calling directly else it is calling from another component
                 component.set("v.sObjectId",component.get("v.recordId"));
             }           
        }
        catch(e){
            alert($A.get("{!$Label.c.MID_ContactAdminErrorMessage}"));
            console.log('Exception in calling doInit in controller-->' + e);
        }
    },    
    /**
	* @author      : NIIT
	* @date        : 12/08/2020
	* @description : This method calls method 'handleUploadFinished' of helper class.
                 	 This method calls after uploading new file.
	* @param       : component, event, helper
	* @return      : Void
	*/
    handleUploadFinished : function (component, event, helper) {
        try{
            helper.handleUploadFinished(component, event);
        }
        catch(e){
            alert($A.get("{!$Label.c.MID_ContactAdminErrorMessage}"));
            console.log('Exception in calling handleUploadFinished-->' + e);
        }
    },
    
    /**
	* @author      : NIIT
	* @date        : 12/08/2020
	* @description : This method calls method 'handleCancelUpload' of helper class.
	* @param       : component, event, helper
	* @return      : Void
	*/    
    handleCancelButton : function(component, event, helper){
        try{
            helper.handleCancelButton(component);
        }
        catch(e){
            alert($A.get("{!$Label.c.MID_ContactAdminErrorMessage}"));
            console.log('Exception in calling handleCancelButton-->' + e);
        }
    },
    
    /**
	* @author      : NIIT
	* @date        : 12/08/2020
	* @description : This method calls method 'handleDoneClick' of helper class.
	* @param       : component, event, helper
	* @return      : Void
	*/
    handleDoneClick : function(component, event, helper){
        try{
            helper.handleDoneClick(component); 
        }
        catch(e){
            alert($A.get("{!$Label.c.MID_ContactAdminErrorMessage}"));
            console.log('Exception in calling handleDoneClick-->' + e);
        }
    },  
    
    /**
	* @author      : NIIT
	* @date        : 12/08/2020
	* @description : This method calls method 'delUploadedfiles' of helper class.
	* @param       : component, event, helper
	* @return      : Void
	*/
    delFiles : function(component,event,helper){
        try{
        var uploadedFileIdArr = [];
        uploadedFileIdArr.push(event.currentTarget.id);       
        helper.deleteUploadedfiles(component,uploadedFileIdArr);  
        }catch(e){
            alert($A.get("{!$Label.c.MID_ContactAdminErrorMessage}"));
            console.log('Exception in calling delFiles-->' + e);
        }
    },
})