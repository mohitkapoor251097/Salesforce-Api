({
    /*
    * @author      : NIIT
    * @date        : 03/01/2020
    * @description : This function is used to display the selected record.
    * @params      : component, event, helper
    * @return      : NA
    */
    selectRecord : function(component, event, helper){      
        try{
            // get the selected record from list  
            var getSelectRecord = component.get("v.oRecord");
            // call the event   
            var compEvent = component.getEvent("oSelectedRecordEvent");
            // set the Selected sObject Record to the event attribute.  
            compEvent.setParams({"recordByEvent" : getSelectRecord });  
            // fire the event  
            compEvent.fire();
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling onloadDisplayEmailTemplate@@@@' + e);
        }
    },
})