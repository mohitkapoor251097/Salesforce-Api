/*********************************************************************
# File....................: FilterCasesForBulkUpdateHelper
# Version.................: 1.0
# Created by..............: Coforge Technologies
# Created Date............: 16/06/2021
# Last Modified by........: 
# Last Modified Date......: 
# Description.............: This is a JS Controller of 'FilterCasesForBulkUpdate' Lightning component .   
# VF Page.................: NA
# VF Component............: NA
# Lightning Component.....: FilterCasesForBulkUpdate
# Test Class..............: NA
# Change Log..............: v1.0 Initial Version 
**********************************************************************/
({
    /*
    * @author      : Coforge
    * @date        : 16/06/2021
    * @description : This function call to get records after filtering data.
    * @params      : component, event, helper
    * @return      : NA
    */
    filterRecords: function (component) {
        try {
            component.set("v.spinner", true);
            var stDate = component.get('v.startDate');
            var endDate = component.get('v.endDate');
            var pTitle = component.get('v.projectTitleVar');
            var subject = component.get('v.subjectVar');
            var action = component.get("c.getRecords");
            var nextbutton = component.find('nextButtonId');
            action.setParams({
                "stDate": stDate,
                "endDate": endDate,
                "filterMap": {
                    "Internal_Ofcom_Project_Title__c": pTitle,
                    "Subject": subject
                },
                "operationType": "update"
            });
            action.setCallback(this, function (response) {
                if (response.getState() == "SUCCESS") {
                    component.set('v.data', []);
                    var allRecords = response.getReturnValue();
                    let rowData = [];
                    if (allRecords.length > 0 && allRecords.length <= 10000) {
                        var i = 0;
                        allRecords.forEach((row) => {
                            let rowData1 = {};
                            rowData1 = row;
                            if (row.Account) rowData1.AccountName = row.Account.Name;
                            rowData.push(rowData1);
                        })
                        component.set('v.data', rowData);
                        component.set("v.spinner", false);
                        component.set("v.displayDataTable", false);
                    }
                    else if (allRecords.length > 10000) {
                        component.set("v.displayDataTable", true);
                        component.set("v.errorString", 'Please change filter criteria as it has data more than 10000');
                    }
                    else {
                        component.set("v.displayDataTable", true);
                        component.set("v.errorString", 'No Data Found');
                    }
                } else {
                    var errors = response.getError();
                    var message = "Error: Unknown error";
                    if (errors && Array.isArray(errors) && errors.length > 0)
                        message = "Error: "; //+errors[0].message;
                    component.set("v.error", message);
                    component.set("v.spinner", false);
                }
                component.set("v.spinner", false);
            });
            $A.enqueueAction(action);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in FilterCasesForBulkupdateHelper->filterRecords Function@@@@' + e);
        }
    },
    /*
	* @author      : Coforge
	* @date        : 16/06/2021
	* @description : This function is used to initialize data table after loading of the script.
	* @params      : component, event, helper
	* @return      : NA
	*/
    scriptsLoaded: function (component, event, helper) {
        try {
            var $ = jQuery.noConflict();
            setTimeout(function () {
                jQuery('#caseTableId').DataTable({
                    stateSave: true,
                    responsive: true,
                    selectAllPages: false,
                    pageLength: 10,
                    "fnDrawCallback": function (settings) {
                        var allChecked = true;
                        $('#caseTableId tbody tr').each(function () {
                            $(this).find(':checkbox[name=selectedCases]').each(function () {
                                if (!$(this).is(':checked')) {
                                    allChecked = false;
                                }
                            });
                        });
                        $('#allSelectedCases').prop('checked', allChecked);
                    },
                    "bDestroy": true,
                    "aoColumnDefs": [{
                        "bSortable": false,
                        "aTargets": [0]
                    }]
                });
                jQuery("#caseTableId_length").insertBefore("#caseTableId_info");
                component.set("v.spinner", false);
            }, 100);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in FilterCasesForBulkUpdateHelper->scriptsLoaded Function@@@@' + e);
        }
    },
    /* @author      : Coforge
    * @date        : 16/06/2021
    * @description : This function is used for nagivating to next page based .
    * @params      : component, event, helper
    * @return      : NA
    */
    next: function (component, event, helper) {
        try {
            var caseListIds = component.get("v.listOfSelectedRecords");
            var datalist = component.get("v.data");
            var caseObj;
            for (var i = 0; i < datalist.length; i++) {
                var idData = datalist[i].Id;
                if (caseListIds[0].includes(idData)) {
                    caseObj = datalist[i];
                    break;
                }

            }
            console.log('caseObj++');
             console.log(caseObj);
            var evt = $A.get("e.force:navigateToComponent");
            evt.setParams({
                componentDef: "c:DynamicCaseLayoutComponent",
                componentAttributes: {
                    caseArray: caseListIds,
                    actionName: 'Update',
                    CaseObj: caseObj
                }
            });
            evt.fire();
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in FilterCasesForBulkUpdateHelper->next Function@@@@' + e);
        }

    },
    /*
	* @author      : Coforge
	* @date        : 16/06/2021
	* @description : This function is used to change filter value.
	* @params      : component, event, helper
	* @return      : NA
	*/
    changeFilter: function (cmp, event, helper) {
        try {
            var startDate = cmp.get('v.startDate');
            var subject = cmp.get('v.subjectVar');
            var projectTitle = cmp.get('v.projectTitleVar');
            var endDate = cmp.get('v.endDate');
            var today = new Date();
            var formattoday = $A.localizationService.formatDate(today, "yyyy-MM-dd");
            
            
            if(startDate > formattoday || endDate > formattoday){
                this.showError(cmp,'Start/End date should be today or less than today');
            }else if(startDate > endDate){
                this.showError(cmp,'Start date should be less than End date');
            }
            
            let button = cmp.find('filterButtonId');
            button.set('v.disabled', false);
            if (((subject == '' || subject == undefined) &&
                (startDate == null || startDate == undefined) &&
                (endDate == null || endDate == undefined) &&
                (projectTitle == '' || projectTitle == null))|| startDate > formattoday || 
                endDate > formattoday || startDate > endDate || (((startDate != null || startDate != undefined) &&
                (endDate == null || endDate == undefined)) ||
                ((startDate == null || startDate == undefined) &&
                    (endDate != null || endDate != undefined))) ) {
                button.set('v.disabled', true);
            }
            else {
                button.set('v.disabled', false);
            }
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkUpdateHelper->changeFilter Function@@@@' + e);
        }
    },
    /*
	* @author      : Coforge
	* @date        : 16/06/2021
	* @description : This function is used to check all records
	* @params      : component, event, helper
	* @return      : NA
	*/
    checkAllRecords: function (component, event, helper) {
        try {
            var $ = jQuery.noConflict();
            var idx = event.target.id;
            var checkVal = false
            if ($('#' + idx).is(':checked')) {
                checkVal = true;
            }
            var selectcase = component.get("v.listOfSelectedRecords");
            let nextbutton = component.find('nextButtonId');
            var ele = document.getElementsByName('selectedCases');
            for (var i = 0; i < ele.length; i++) {
                if (ele[i].type == 'checkbox') {
                    ele[i].checked = checkVal;
                }
                if (checkVal) {
                    if (!selectcase.includes(ele[i].id)) {
                        selectcase.push(ele[i].id);
                    }
                }
                else if (selectcase.includes(ele[i].id) && !checkVal) {
                    const index = selectcase.indexOf(ele[i].id);
                    selectcase.splice(index, 1);
                }
            }

            if (selectcase.length > 0) {
                nextbutton.set('v.disabled', false);
            }
            else {
                nextbutton.set('v.disabled', true);
            }
            component.set("v.listOfSelectedRecords", selectcase);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkUpdateController->checkAllRecords Function@@@@' + e);
        }
    },
    /*
	* @author      : Coforge
	* @date        : 16/06/2021
	* @description : This function is used to set the selected case id in list
	* @params      : component, event, helper
	* @return      : NA
	*/
    addSelectedCaseID: function (component, event, helper) {
        try {
            var idx = event.target.id;
            var selectcase = component.get("v.listOfSelectedRecords");
            let nextbutton = component.find('nextButtonId');
            var $ = jQuery.noConflict();
            if ($('#' + idx).is(':checked')) {
                if (!selectcase.includes(idx)) {
                    selectcase.push(idx);
                }
            }
            else {
                for (var i = 0; i < selectcase.length; i++) {
                    var obj = selectcase[i];
                    if (idx == obj) {
                        const index = selectcase.indexOf(obj);
                        selectcase.splice(index, 1);
                    }
                }
            }
            if (selectcase.length > 0) {
                nextbutton.set('v.disabled', false);
            }
            else {
                nextbutton.set('v.disabled', true);
            }
            var allChecked = true;
            $('#caseTableId tbody tr').each(function () {
                $(this).find(':checkbox[name=selectedCases]').each(function () {
                    if (!$(this).is(':checked')) {
                        allChecked = false;
                    }
                });
            });
            $('#allSelectedCases').prop('checked', allChecked);
            component.set("v.listOfSelectedRecords", selectcase);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkUpdateController->addSelectedCaseID Function@@@@' + e);
        }
    },
    /*
	* @author      : Coforge
	* @date        : 16/06/2021
	* @description : This function is used show error message.
	* @params      : component, event, helper
	* @return      : NA
	*/
    showError: function (component, errorMessage) {
        try {
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title: 'Error',
                message: errorMessage,
                duration: '20000',
                key: 'info_alt',
                type: 'error',
                mode: 'dismissible'
            });
            toastEvent.fire();
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkUpdateHelper->showError Function@@@@' + e);
        }
    },
})