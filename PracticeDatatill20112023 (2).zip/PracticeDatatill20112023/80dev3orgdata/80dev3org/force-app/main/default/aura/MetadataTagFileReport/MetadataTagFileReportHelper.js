/*********************************************************************
# File....................: MetadataTagFileReportHelper
# Version.................: 1.0
# Created by..............: Coforge Technologies
# Created Date............: 16/06/2021
# Last Modified by........: 
# Last Modified Date......: 
# Description.............: This is a JS Controller of 'MetadataTagFileReport' Lightning component .   
# Lightning Component.....: MetadataTagFileReport
# Change Log..............: v1.0 Initial Version 
**********************************************************************/
({
    /*
    * @author      : Coforge
    * @date        : 16/06/2021
    * @description : This function call to get records after filtering data.
    * @params      : component, event, helper
    * @return      : NA
    */    
 	filterRecords: function (component,event,helper) {
        try {
            // To destroy previous table after changing filter
            $('#fileTableId').DataTable().destroy(); 
            component.set("v.spinner", true);
            component.set("v.errorString", '');
            var action = component.get("c.getContentVersionRecords");  
            action.setParams({
                "startDate": component.get('v.startDate'),
                "endDate": component.get('v.endDate'),
                "title": component.get('v.Title'),
            });
            action.setCallback(this, function (response){
                if(response.getState() == "SUCCESS"){
                    var resultRecords = response.getReturnValue();
                    console.log(resultRecords.length+'--resultRecords-->' + JSON.stringify(resultRecords));                                     
                    if(resultRecords.length  == 0){
                      component.set('v.contentVersionList',null);   
                      component.set("v.errorString", 'No Data Found');
                    } 
                    if(resultRecords.length > 0 && resultRecords.length <= 10000){
                        component.set('v.contentVersionList',resultRecords);                     
                     }
                     else if(resultRecords.length > 10000){
                        component.set("v.errorString", 'Please change filter criteria as it has data more than 10000');
                    }                   
                }else{
                    var errors = response.getError();
                    var message = "Error: Unknown error";
                    if (errors && Array.isArray(errors) && errors.length > 0){
                    	message = "Error: "+errors[0].message;                                                
                    } 
                    component.set("v.errorString", message);
                    component.set("v.spinner", false);
                }
                component.set("v.spinner", false);                 
            });              
            $A.enqueueAction(action);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('--Exception in CustomReport filterRecords-->' + e);
        }
    }, 
   /*
   * @author      : Coforge
   * @date        : 16/06/2021
   * @description : This function is used to initialize data table after loading of the script.
   * @params      : component, event, helper
   * @return      : NA
   */
	scriptsLoaded: function (component, event, helper) {
    	try{
         $(document).ready( function () {
             //It will initialize datatable
             var table = $('#fileTableId').DataTable({
             //To disable sorting of first column
             "columnDefs": [{
             "searchable": false,
             "orderable": false,
             "targets": 0
        	 }],
            "order": [[ 6, "desc" ]], //to get date in descending order after datatable initializes
    		});
            // To get Serial Number
            table.on( 'order.dt', function () {
                table.column(0, { order:'applied'}).nodes().each( function (cell, i) {
                    cell.innerHTML = i+1;
                });
            }).draw();
            });            
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('--Exception in CustomReport scriptsLoaded-->' + e);  
        }       
   }, 
    /*
    * @author      : Coforge
    * @date        : 16/06/2021
    * @description : This function is used to change filter value.
    * @params      : component, event, helper
    * @return      : NA
    */
   changeFilter: function (component, event, helper) {
        try{
            component.set('v.contentVersionList',null); // to remove table data on onchange event
            var startDate = component.get('v.startDate');
            var endDate = component.get('v.endDate');
            var today = new Date();
            var formattoday = $A.localizationService.formatDate(today, "yyyy-MM-dd");
            component.set('v.disableFilterBtn',true);
            
            if(startDate > formattoday || endDate > formattoday){
             this.showError(component,'Start/End date should be today or less than today');
            }else if(startDate > endDate){
                this.showError(component,'Start date should be less than End date');
            }else if((startDate != null || startDate != undefined) 
                   && (endDate != null || endDate != undefined)){
            	component.set('v.disableFilterBtn',false);
            }                       
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('--Exception in CustomReport changeFilter-->' + e);
        }
    }, 
    /*
    * @author      : Coforge
    * @date        : 16/06/2021
    * @description : This function is used show error message.
    * @params      : component, event, helper
    * @return      : NA
    */
    showError: function (component, errorMessage) {
        try {
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title: 'Error',
                message: errorMessage,
                duration: '20000',
                key: 'info_alt',
                type: 'error',
                mode: 'dismissible'
            });
            toastEvent.fire();
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('--Exception in CustomReport showError-->' + e);
        }
    },
   	/*
    * @author      : Coforge
    * @date        : 16/06/2021
    * @description : This function is used to export csv file.
    * @params      : component, event, helper
    * @return      : NA
    */
    convertArrayOfObjectsToCSV : function(component,objectRecords) {
        var csvStringResult,counter,lineDivider,columnDivider;
        if(objectRecords==null || !objectRecords.length){
            return null;         
        }
        columnDivider=',';
        lineDivider='\n';
        csvStringResult='';
        var keyArray = [];
        var valueArray = [];
        var columnValues = component.get('v.fieldLabelApiMap');
        console.log('Mapv--' + JSON.stringify(columnValues));
        for(var i=0;i<columnValues.length;i++){
           keyArray.push(columnValues[i]["key"]);
           valueArray.push(columnValues[i]["value"]);
        }
        csvStringResult+=keyArray.join(columnDivider); 
        csvStringResult+=lineDivider;
        for(var i=0;i<objectRecords.length;i++){
            counter=0;
            for(var sTempkey in valueArray) {
                var skey = valueArray[sTempkey] ;
                if(counter>0){
                    csvStringResult+=columnDivider;
                }
                if(skey =='LastModifiedDate'){ // to change date format
				 var dateTime = $A.localizationService.formatDateTime(objectRecords[i][skey], "dd/MM/yyyy, HH:mm");
                 csvStringResult += '"' + dateTime +'"';
                }
                else if(!skey.includes('.') && !$A.util.isUndefined(objectRecords[i][skey]) 
                && !$A.util.isEmpty(objectRecords[i][skey])) {
                    csvStringResult += '"' + objectRecords[i][skey] +'"';
                }
                else if(skey.includes('.')){
                	var skeySplitList = skey.split('.');
                    var fieldName=skeySplitList[0]; 
                    var mergeField=skeySplitList[1];
                   
                    if(!$A.util.isUndefined(objectRecords[i][fieldName]) 
                    && !$A.util.isUndefined(objectRecords[i][fieldName][mergeField]) 
                    && !$A.util.isEmpty(objectRecords[i][fieldName][mergeField])){
                    	csvStringResult += '"' + objectRecords[i][fieldName][mergeField] +'"';
                    }
                }             
                else{
                    csvStringResult += '"'+' '+'"';
                }
                counter ++;               
                }  
                csvStringResult+=lineDivider; 
            }    
        return csvStringResult;
    },
    /*
    * @author      : Coforge
    * @date        : 16/06/2021
    * @description : This function is used to get table label and api names.
    * @params      : component, event, helper
    * @return      : NA
    */
    getTableLabels : function(component, event, helper) {
       var action = component.get("c.getExportDataLabels");
       action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var mapData = [];
                var results = response.getReturnValue();
                for (var key in results) {
                	mapData.push({key:key,value:results[key]});
                }
                component.set("v.fieldLabelApiMap", mapData);                
            }
        });
        $A.enqueueAction(action);
    },
    
})