/*********************************************************************
# File....................: MetadataTagFileReportController
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............: 16/06/2021
# Last Modified by........: 
# Last Modified Date......: 
# Description.............: This is a JS Controller of 'MetadataTagFileReport' Lightning component .   
# Lightning Component.....: MetadataTagFileReport
# Change Log..............: v1.0 Initial Version 
**********************************************************************/
({      
    /*
	* @author      : Coforge
	* @date        : 16/06/2021
	* @description : This function call to refresh the table when data changes.
	* @params      : component, event, helper
	* @return      : NA
	*/
    refreshTable: function(component, event, helper){
      try{
            var data = component.get('v.contentVersionList');
            if(data != undefined && data.length > 0){
            	helper.scriptsLoaded(component, event, helper);
            }
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('Exception in CustomReport refreshTable' + e);
        }
    },
     /*
	* @author      : Coforge
	* @date        : 16/06/2021
	* @description : This function call to change date.
	* @params      : component, event, helper
	* @return      : NA
	*/
    changeFilter:function(component, event, helper){
        try{
        	helper.changeFilter(component);
        }
        catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('Exception in CustomReport changeFilter' + e);
        }
    },
    
    /*
	* @author      : Coforge
	* @date        : 16/06/2021
	* @description : This function call to get records after filtering data.
	* @params      : component, event, helper
	* @return      : NA
	*/
    doInit: function (component, event, helper) {   
        try{
           helper.getTableLabels(component,event, helper);	
        }
        catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('Exception in doInit' + e);
        }         
    },
    filterRecords: function(component, event, helper){
    	try{          
        	helper.filterRecords(component,event, helper);
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('Exception in CustomReport filterRecords' + e);
        }
    },    
    /*
	* @author      : Corforge
	* @date        : 16/06/2021
	* @description : This function is used to Navigate to Owner, Title of file and Source records.
	* @params      : component, event, heplper
	* @return      : NA
	*/
    navigateToRecord: function(component, event, helper){
        try{
            var recordId = event.target.id;
            console.log('recordId:::'+recordId);
            var navEvt = $A.get("e.force:navigateToSObject");
            navEvt.setParams({
                "recordId": recordId,
                "slideDevName": "detail"  
            });
            window.open('/' + navEvt.getParam('recordId')); //this will open the detail page in new window
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('Exception in CustomReport navigateToRecord' + e);
        }
    }, 
     /*
	* @author      : Corforge
	* @date        : 16/06/2021
	* @description : This function is used to download csv file.
	* @params      : component, event, heplper
	* @return      : NA
	*/
    exportData :function(component, event, helper){
		var csv = helper.convertArrayOfObjectsToCSV(component,component.get("v.contentVersionList"));
        var elementLink=document.createElement('a');
        elementLink.href='data:text/csv;charset=utf-8,'+encodeURI(csv);
        elementLink.target='_self';
        elementLink.download='FileExportData.csv';
        document.body.appendChild(elementLink);
        elementLink.click();
 	},    

})