/*********************************************************************
   # File....................: CaseBulkOperationComponentHelper
   # Version.................: 1.0
   # Created by..............: Coforge Technologies
   # Created Date............: 31/05/2021
   # Last Modified by........: 
   # Last Modified Date......: 
   # Description.............: This is a JS Helper of 'CaseBulkOperationComponent' Lightning component.   
   # VF Page.................: NA
   # VF Component............: NA
   # Lightning Component.....: CaseBulkOperationComponent
   # Test Class..............: NA
   # Change Log..............: v1.0 Initial Version 
   **********************************************************************/({
	/*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to redirect to the next step.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
	onSelectChange: function(component, event, helper) {
        try{
          var optionsVal = component.find("recordSize").get("v.value");
          var nagivateCompName;  
            if(optionsVal === 'Bulk Creation'){
                nagivateCompName='c:AccountSelectionComponent';
            }
            if(optionsVal === 'Bulk Update'){
                nagivateCompName='c:FilterCasesForBulkUpdate';            
            } 
            if(optionsVal === 'Bulk Cloning'){
                nagivateCompName='c:FilterCasesForBulkCloning';
            }
            if(optionsVal != 'None'){
                var evt = $A.get("e.force:navigateToComponent");
                evt.setParams({
                    componentDef: nagivateCompName
                });
                evt.fire();
            }
            else{
                helper.showError(component);
            }
     }
      catch (e) {
			alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
			console.log('@@@@Exception in onSelectChange Function in CaseBulkOperationComponentHelper@@@@' + e);
		} 
   },
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to Handle Error message.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
	showError: function (component, event, helper) {
		try {
			var toastEvent = $A.get("e.force:showToast");
			toastEvent.setParams({
				title: 'Error',
				message: 'Please select option',
				duration: '20000',
				key: 'info_alt',
				type: 'error',
				mode: 'dismissible'
			});
			toastEvent.fire();
		} catch (e) {
			alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
			console.log('@@@@Exception in showError Function in CaseBulkOperationComponentHelper@@@@' + e);
		}
	},
})