({
    /*
    * @author      : NIIT
    * @date        : 28/10/2019
    * @description : On load method which shows list of files records and set the values in other attributes to show the pagination.
    * @params      : component, event, helper
    * @return      : NA
    */
	doInit: function(component, event, helper) {
        helper.doInitHelper(component, event);
    },
    
    /*
    * @author      : NIIT
    * @date        : 09/09/2019
    * @description : This is javaScript function for pagination
    * @params      : component, event, helper
    * @return      : NA
    */
    navigation: function(component, event, helper) {
        var sObjectList = component.get("v.listOfAllFiles");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
        var whichBtn = event.getSource().get("v.name");
        // check if whichBtn value is 'next' then call 'next' helper method
        if (whichBtn == 'next') {
            component.set("v.currentPage", component.get("v.currentPage") + 1);
            helper.next(component, event, sObjectList, end, start, pageSize);
        }
        // check if whichBtn value is 'previous' then call 'previous' helper method
        else if (whichBtn == 'previous') {
            component.set("v.currentPage", component.get("v.currentPage") - 1);
            helper.previous(component, event, sObjectList, end, start, pageSize);
        }
    },
    
    /*
    * @author      : NIIT
    * @date        : 28/10/2019
    * @description : JavaScript function for selecting all records by clicking the checkbox on the header.
    * @params      : component, event, helper
    * @return      : NA
    */
    selectAllCheckbox: function(component, event, helper) {
        var selectedHeaderCheck = event.getSource().get("v.value");
        var updatedAllRecords = [];
        var updatedPaginationList = [];
        var listOfAllFiles = component.get("v.listOfAllFiles");
        var PaginationList = component.get("v.PaginationList");
        // play a for loop on all records list 
        for (var i = 0; i < listOfAllFiles.length; i++) {
            // check if header checkbox is 'true' then update all checkbox with true and update selected records count
            // else update all records with false and set selectedCount with 0  
            if (selectedHeaderCheck == true) {
                listOfAllFiles[i].isChecked = true;
                component.set("v.selectedCount", listOfAllFiles.length);
            } else {
                listOfAllFiles[i].isChecked = false;
                component.set("v.selectedCount", 0);
            }
            updatedAllRecords.push(listOfAllFiles[i]);
        }
        // update the checkbox for 'PaginationList' based on header checbox 
        for (var i = 0; i < PaginationList.length; i++) {
            if (selectedHeaderCheck == true) {
                PaginationList[i].isChecked = true;
            } else {
                PaginationList[i].isChecked = false;
            }
            updatedPaginationList.push(PaginationList[i]);
        }
        component.set("v.listOfAllFiles", updatedAllRecords);
        component.set("v.PaginationList", updatedPaginationList);
    },
    
    /*
    * @author      : NIIT
    * @date        : 28/10/2019
    * @description : Getting the count of selected records and set the header true if all checkboxes are selected.
    * @params      : component, event, helper
    * @return      : NA
    */
    checkboxSelect: function(component, event, helper) {
        // on each checkbox selection update the selected record count 
        var selectedRec = event.getSource().get("v.value");
        var getSelectedNumber = component.get("v.selectedCount");
        if (selectedRec == true) {
            getSelectedNumber++;
        } else {
            getSelectedNumber--;
            component.find("selectAllId").set("v.value", false);
        }
        component.set("v.selectedCount", getSelectedNumber);
        // if all checkboxes are checked then set header checkbox with true   
        if (getSelectedNumber == component.get("v.totalRecordsCount")) {
            component.find("selectAllId").set("v.value", true);
        }
    },
    
    /*
    * @author      : NIIT
    * @date        : 28/10/2019
    * @description : Get the list of records selected by the user. After gettting the list, downloading the selected files.
    * @params      : component, event, helper
    * @return      : NA
    */
    getSelectedRecords: function(component, event, helper) {
        var allRecords = component.get("v.listOfAllFiles");
        var selectedRecords = [];
        for (var i = 0; i < allRecords.length; i++) {
            if (allRecords[i].isChecked) {
                selectedRecords.push(allRecords[i].cvObj.Id);
            }
        } 
        //Calling controller method which return the URL for downloading the attachments in zip format.       
        var actionDownload = component.get("c.downloadFiles");        
        actionDownload.setParams({
            filesId: selectedRecords //Sending list of selected correspondence records to the controller method.
        });        
        
        actionDownload.setCallback(this, function(b){            
            var state = b.getState();
            if (state === "SUCCESS"){
                window.location.href = b.getReturnValue();                            
            }else{
                alert('There is some problem in downloading the attachments.');                
            }
        });
        $A.enqueueAction(actionDownload);
    },

    /*
    * @author      : NIIT
    * @date        : 28/10/2019
    * @description : Downloading the attachments in zip format.
    * @params      : component, event, helper
    * @return      : NA
    */
    NavigationRec : function(component, event, helper) {        
        window.open("/lightning/r/Satellite_Brific_Deadlines__c/" + component.get("v.parentRecordId") + "/view","_self");               
    }
})