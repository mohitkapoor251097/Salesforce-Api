/**
* @description : Controller file of osSensitiveCaseContainer component.
* File         : osSensitiveCaseContainerController
* Version      : 1.0
* Created by   : Coforge
* Created Date : March 31, 2023
* Last Modified by  : Coforge
*/
({
    doInit : function(component) {
        //call apex method to fetch case record
        var action = component.get("c.sensitivityStatus");
        action.setParams({ caseId : component.get("v.recordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.isModalOpen", response.getReturnValue().Is_Sensitive__c);
                component.set("v.category3", response.getReturnValue().Complaint_Category_3__c);
            }
        });
        $A.enqueueAction(action);
    },
    closeModel: function(component) {
        //close the opened case tab
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            workspaceAPI.closeTab({tabId: focusedTabId});
        })
        .catch(function(error) {
            console.log(error);
        });

        //set navigation to open a new tab
        var navService = component.find("navService");
        // Sets the route to /lightning/o/Case/home
        var pageReference = {
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Case',
                actionName: 'home'
            }
        };
        component.set("v.pageReference", pageReference);
        // Set the URL on the link or use the default if there's an error
        //var defaultUrl = "#";
        navService.generateUrl(pageReference);
        
        //var workspaceAPI = component.find("workspace");
        workspaceAPI.openTab({
            pageReference: pageReference,
            focus: true
        });
    },
   
    submitDetails: function(component) {
       // Set isModalOpen attribute to false
       component.set("v.isModalOpen", false);
    },
 })