/*********************************************************************
# File....................: FilterCasesForBulkCloningHelper
# Version.................: 1.0
# Created by..............: Coforge Technologies
# Created Date............: 31/05/2021
# Last Modified by........: 
# Last Modified Date......: 
# Description.............: This is a JS Helper of 'FilterCasesForBulkCloning' Lightning component .   
# VF Page.................: NA
# VF Component............: NA
# Lightning Component.....: FilterCasesForBulkCloning
# Test Class..............: NA
# Change Log..............: v1.0 Initial Version 
**********************************************************************/
({
    /*
	* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function is used to redirect to the next step.
	* @params      : component, event, helper
	* @return      : NA
	*/
    filterRecords: function (component){
        try{
            component.set("v.spinner", true);
            var fReqstSent = component.get('v.finalReqstSentVar');
            var subject = component.get('v.subjectVar');
            var status = component.get('v.statusVar');
            var action = component.get("c.getRecords");
            var nextbutton = component.find('nextButtonId');
            action.setParams({
                "filterMap": {
                    "Status" : status,
                    "Subject" : subject,
                    "Final_Request_Sent__c" : fReqstSent
                },
                "operationType": "clone"
            });
            action.setCallback(this, function (response) {
                if (response.getState() == "SUCCESS") {
                    var allRecords = response.getReturnValue();
                    component.set('v.data', []);
                    if (allRecords.length > 0 && allRecords.length <= 10000) {
                        let rowData = [];
                        var i = 0;
                        allRecords.forEach((row) => {
						   let rowData1 = {};
						   rowData1 = row;
						   if (row.Account) rowData1.AccountName = row.Account.Name;
						   rowData.push(rowData1);
						});
						component.set('v.data', rowData);
						component.set("v.errorString", '');
						component.set("v.spinner", false);
						component.set("v.displayDataTable", false);
					}
					else if (allRecords.length > 10000) {
						component.set("v.displayDataTable", true);
						component.set("v.errorString", 'Please change filter criteria as it has data more than 10000');
						component.set("v.spinner", false);
					}
					else {
						component.set("v.displayDataTable", true);
						component.set("v.errorString", 'No Data Found');
						component.set("v.spinner", false);
					}
				} else {
					var errors = response.getError();
					var message = "Error: Unknown error";
					if (errors && Array.isArray(errors) && errors.length > 0){
						message = "Error: "; 
					}
					component.set("v.error", message);
					component.set("v.spinner", false);
				}
			});
			$A.enqueueAction(action);
		} catch (e) {
			alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
			console.log('@@@@Exception in calling FilterCasesForBulkCloningHelper->filterRecords Function@@@@' + e);
		}
	},
    
    /*
	* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function is used to clone bulk cases.
	* @params      : component, event, helper
	* @return      : NA
	*/
	cloningBulkCases: function (component, caseListIds, noOfCloneCasesVar, cloningTypeVar) {
		try{
			var action = component.get("c.cloneMultipleRecords");
			action.setParams({
				"caseListClsObj": caseListIds,
				"noOfCloneCasesClsObj": noOfCloneCasesVar,
				"cloningTypeClsObj": cloningTypeVar
			});
			action.setCallback(this, function (response) {
				if (response.getState() == "SUCCESS") {
					var allRecords = response.getReturnValue();
					component.set("v.showBulkCloneInfo",true);
				} else {
					var errors = response.getError();
					var message = "Error: Unknown error";
					if (errors && Array.isArray(errors) && errors.length > 0)
						message = "Error: " + errors[0].message;
					component.set("v.error", message);
					console.log("Error: " + message);
					this.showError(component, message);
				}
			});
			$A.enqueueAction(action);
		} catch (e) {
			alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
			console.log('@@@@Exception in calling FilterCasesForBulkCloningHelper->cloningBulkCases Function@@@@' + e);
		}
	},
            
            
	/*
	* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function is used to validate data when user click on next button.
	* @params      : component, event, helper
	* @return      : NA
	*/
	validate: function (component, event, helper) {
		try {
			component.set("v.spinner", true);
			var caseListIds = component.get("v.listOfSelectedRecords");
			var optionsValue = component.find("recordSize").get("v.value");
			var noOfCases = component.get("v.noOfCloneCasesVar");
			console.log('@@@@@@@'+noOfCases);
			var nagivateCompName;
			
			if (optionsValue == 'None') {
				this.showError(component, 'Please select case clone options');
				component.set("v.spinner", false);
			}
			if(optionsValue === $A.get("$Label.c.BulkCloningSingleAccount")){
				if (noOfCases == null || noOfCases == '' || noOfCases == undefined) {
					this.showError(component, "For the selected case clone option , Please enter no. in # Cases to be cloned");
					component.set("v.spinner", false);
				}
				else if(isNaN(noOfCases) == true){
					this.showError(component, "For the selected case clone option , # Cases should be valid number only");
					component.set("v.spinner", false);
				}
					else if(noOfCases < 1 || noOfCases > 500){
						this.showError(component, "For the selected case clone option , # Cases can have number ranging from 1 to 500");
						component.set("v.spinner", false);
					}
					else if (caseListIds.length == 1) {
						component.set('v.showConfirmDialogNext', true);
						component.set("v.confirmationMsg", 'Are you sure you want to clone cases for selected cases?');
						nagivateCompName = $A.get("$Label.c.BulkCloningSingleAccount");
					} else if ( caseListIds.length > 1) {
						helper.showError(component, "For the selected case clone option , only 1 case can be selected");
						component.set("v.spinner", false);
					}
			}
		
			if (optionsValue === $A.get("$Label.c.BulkCloningMultipleAccount") && caseListIds.length == 1) {
				component.set('v.showConfirmDialogNext', true);
				component.set("v.confirmationMsg", 'Are you sure you want to move to next step to select the account for bulk cloning?');
				nagivateCompName = 'c:AccountSelectionComponent';
			} else if (optionsValue === $A.get("$Label.c.BulkCloningMultipleAccount") && caseListIds.length > 1) {
				helper.showError(component, "For the selected case clone option, only 1 case can be selected.");
				component.set("v.spinner", false);
			}
			if (optionsValue === $A.get("$Label.c.BulkCloningWithManyBusinessAccount") && caseListIds.length >= 1 && caseListIds.length <= 500) {
				component.set('v.showConfirmDialogNext', true);
				component.set("v.confirmationMsg", 'Are you sure you want to clone cases for selected cases?');
				nagivateCompName = $A.get("$Label.c.BulkCloningWithManyBusinessAccount");
			} else if (optionsValue === $A.get("$Label.c.BulkCloningWithManyBusinessAccount") && caseListIds.length > 500) {
				helper.showError(component, "For the selected case clone option, Number of Cases can be selected in between 1 to 500");
				component.set("v.spinner", false);
			}
			component.set("v.nagivateCompName", nagivateCompName);
			component.set("v.spinner", false);
		} catch (e) {
			alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
			console.log('@@@@Exception in calling FilterCasesForBulkCloningHelper->validate Function@@@@' + e);
		}
	},
                
	/* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function is used to call after validation and when user confirmed for next step.
	* @params      : component, event, helper
	* @return      : NA
	*/
	confirmation: function (component, event, helper) {
		try {
			var caseListIds = component.get("v.listOfSelectedRecords");
			console.log(caseListIds);
			var optionsValue = component.find("recordSize").get("v.value");
			var nagivateCompName = component.get("v.nagivateCompName");
			if (nagivateCompName == $A.get("$Label.c.BulkCloningWithManyBusinessAccount")) {
				helper.cloningBulkCases(component, caseListIds, caseListIds.length, $A.get("$Label.c.BulkCloningWithManyBusinessAccount"));
			}
			else if (nagivateCompName == $A.get("$Label.c.BulkCloningSingleAccount")) {
				helper.cloningBulkCases(component, caseListIds, component.get("v.noOfCloneCasesVar"), $A.get("$Label.c.BulkCloningSingleAccount"));
			}
				else {
					component.set("v.spinner", false);
					this.nextPage(component, event, helper, nagivateCompName, optionsValue, caseListIds);
				}
		} catch (e) {
			alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
			console.log('@@@@Exception in calling FilterCasesForBulkCloningHelper->confirmation Function@@@@' + e);
		}
	},
			
	/* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function is used for nagivating to next page based on selected bulk cloning option.
	* @params      : component, event, helper
	* @return      : NA
	*/
	nextPage: function (component, event, helper, nagivateCompName, optionsValue, caseListIds) {
		try {
			if (nagivateCompName != undefined) {
				var evt = $A.get("e.force:navigateToComponent");
				evt.setParams({
					componentDef: nagivateCompName,
					componentAttributes: {
						caseObjVar: caseListIds,
						bulkcloning: optionsValue
					}
				});
				evt.fire();
			}
		} catch (e) {
			alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
			console.log('@@@@Exception in calling FilterCasesForBulkCloningHelper->nextPage Function@@@@' + e);
		}
		
	},
                
	/*
	* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function is used to change filter value.
	* @params      : component, event, helper
	* @return      : NA
	*/
	changeFilter: function (cmp, event, helper) {
		try {
			let button = cmp.find('filterButtonId');
			var optionsVal = cmp.find("recordSize").get("v.value");
			var fReqstSent = cmp.get('v.finalReqstSentVar');
			var subject = cmp.get('v.subjectVar');
			var status = cmp.get('v.statusVar');
			button.set('v.disabled', false);
			let noOfCaseVar = cmp.find('noOfCases');
			cmp.set('v.instruction',''); 
			if (optionsVal != $A.get("$Label.c.BulkCloningMultipleAccount") && optionsVal != 'None') {
				cmp.set('v.instruction','Step 1 of 1'); 
			}
			else if(optionsVal == $A.get("$Label.c.BulkCloningMultipleAccount") && optionsVal != 'None'){
				 cmp.set('v.instruction','Step 1 of 2'); 
			}
			if (optionsVal === $A.get("$Label.c.BulkCloningSingleAccount")) {
				noOfCaseVar.set('v.disabled', false);
				cmp.set("v.IsCasesTobeClonedRequired",true);
				cmp.set('v.instruction','Step 1 of 1'); 
			}
			else {
				noOfCaseVar.set('v.disabled', true);
				noOfCaseVar.set('v.value', '');
				cmp.set("v.IsCasesTobeClonedRequired",false);
			}
			if ((subject == '' || subject == undefined) &&
				(fReqstSent == null || fReqstSent == undefined) &&
				(status == '' || status == null)) {
				button.set('v.disabled', true);
			}
			else {
				button.set('v.disabled', false);
			}
		} catch (e) {
			alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
			console.log('@@@@Exception in calling FilterCasesForBulkCloningHelper->changeFilter Function@@@@' + e);
		}
	},
	/*
	* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function is used show error message.
	* @params      : component, event, helper
	* @return      : NA
	*/
	showError: function (component, errorMessage) {
		try{
			var toastEvent = $A.get("e.force:showToast");
			toastEvent.setParams({
				title: 'Error',
				message: errorMessage,
				duration: '20000',
				key: 'info_alt',
				type: 'error',
				mode: 'dismissible'
			});
			toastEvent.fire();
		} catch (e) {
			alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
			console.log('@@@@Exception in calling FilterCasesForBulkCloningHelper->showError Function@@@@' + e);
		}
	},
	/*
	* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function is used to initialize data table after loading of the script.
	* @params      : component, event, helper
	* @return      : NA
	*/
	scriptsLoaded: function(component, event, helper){
		try{
			var $ = jQuery.noConflict();
			setTimeout(function(){
				jQuery('#caseTableId').DataTable({
					stateSave: false,
					responsive : true,
					selectAllPages : false,
					pageLength : 10,
					"fnDrawCallback": function( settings ) {
						var allChecked = true;
						$('#caseTableId tbody tr').each(function() {
							$(this).find(':checkbox[name=selectedCases]').each(function(){
								if (!$(this).is(':checked')) {
									allChecked = false;
								}
							});
						});
						$('#allSelectedCases').prop('checked', allChecked);
					},
					bDestroy: true,
					aoColumnDefs: [
						{ 
							"bSortable": false, 
							"aTargets": [ 0 ]
						} 
					]
				});
				jQuery( "#caseTableId_length" ).insertBefore( "#caseTableId_info" );
				component.set("v.spinner", false);
			}, 100);
		} catch (e) {
			alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
			console.log('@@@@Exception in FilterCasesForBulkCloningHelper->scriptsLoaded Function@@@@' + e);
		}
	},
	/*
	* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function is used to check all records
	* @params      : component, event, helper
	* @return      : NA
	*/
	checkAll: function(component, event, helper){
		try{
			var $ = jQuery.noConflict();
			var idx=event.target.id;
			var checkVal=false
			if($('#'+idx).is(':checked')){ 
				checkVal=true;  
			}
			/*if ($('#'+idx).prop("checked")) {
				$('#'+idx).prop("checked", true);
			} else {
				$('#'+idx).prop("checked", false);
			}*/
			var selectcase = component.get("v.listOfSelectedRecords");
			let nextbutton = component.find('nextButtonId');
			var ele=document.getElementsByName('selectedCases'); 
			
			for(var i=0; i<ele.length; i++){  
				if(ele[i].type=='checkbox'){			
					ele[i].checked=checkVal; 
				}
				if(checkVal){
					if (!selectcase.includes(ele[i].id)){
						selectcase.push(ele[i].id);
					} 
				}else if(selectcase.includes(ele[i].id) && !checkVal){
					const index = selectcase.indexOf(ele[i].id);
					selectcase.splice(index, 1);
				}
			}  
			if(selectcase.length > 0){    
				nextbutton.set('v.disabled',false); 
			}
			else{
				nextbutton.set('v.disabled',true); 
			}
			component.set("v.listOfSelectedRecords",selectcase);
		}catch(e){
			alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
			console.log('@@@@Exception in FilterCasesForBulkCloningHelper->checkAll Function@@@@' + e);
		}
	},
	/*
	* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function is used to set the selected case id in list
	* @params      : component, event, helper
	* @return      : NA
	*/
	 addSelectedCaseId: function(component, event, helper){
		 try{
			 var idx=event.target.id;
			 var selectcase = component.get("v.listOfSelectedRecords");
			 let nextbutton = component.find('nextButtonId');
			 var $ = jQuery.noConflict();
			 if($('#'+idx).is(':checked')){
				 if (!selectcase.includes(idx)){
					 selectcase.push(idx);
				 }
			 }
			 else{
				 for (var i = 0; i < selectcase.length; i++) {
					 var obj = selectcase[i];
					 if (idx==obj) {
						 const index = selectcase.indexOf(obj);
						 selectcase.splice(index, 1);
					 }
				 }
			 }
			 if(selectcase.length > 0){    
				 nextbutton.set('v.disabled',false); 
			 }
			 else{
				 nextbutton.set('v.disabled',true); 
			 }
			 var allChecked = true;
			 $('#caseTableId tbody tr').each(function() {
				 $(this).find(':checkbox[name=selectedCases]').each(function(){
					 if (!$(this).is(':checked')) {
						 allChecked = false;
					 }
				 });
			 });
			 $('#allSelectedCases').prop('checked', allChecked);
			 component.set("v.listOfSelectedRecords",selectcase);
		 }catch(e){
			 alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
			 console.log('@@@@Exception in FilterCasesForBulkCloningHelper->scriptsLoaded Function@@@@' + e);
		 }         
	 },
	/*
	* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function is used to get the record type id 
	* @params      : component, event, helper
	* @return      : NA
	*/
	getRecordTypeId: function(component, event, helper){
		try{
			var action = component.get("c.getRecordTypeId");
			action.setCallback(this, function (response) {
				if (response.getState() == "SUCCESS"){
					let recordTypeId = response.getReturnValue();
					component.set("v.recordTypeId",recordTypeId);
				}else{
					var errors = response.getError();
					var message = "Error: Unknown error";
					if (errors && Array.isArray(errors) && errors.length > 0){
						message = "Error: "; 
					}
					component.set("v.error", message);
				}
			});
			$A.enqueueAction(action);
		}
		catch(e){
			alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
			console.log('@@@@Exception in FilterCasesForBulkCloningHelper->getRecordTypeId Function@@@@' + e);
		}  
		
	}     
})