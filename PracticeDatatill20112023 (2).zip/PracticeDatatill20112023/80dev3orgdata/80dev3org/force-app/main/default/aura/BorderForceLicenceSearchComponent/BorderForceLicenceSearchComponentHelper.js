/*********************************************************************
# File....................: BorderForceLicenceSearchComponentController
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............: 18/08/2021 
# Last Modified by........: Coforge
# Last Modified Date......: 27/09/2021
# Description.............: This is a JS Controller of 'BorderForceLicenceSearchComponent'Lightning component.   
# VF Page.................: NA
# VF Component............: NA
# L Comp..................: BorderForceLicenceSearchComponent
# Test Class..............: NA
# Change Log..............: V1.0 : Initial version (Story No. W-002322) Added Ship Vessel and Person Business Section.
         					V1.1 : (Story No. W-002331) Added DPA Agreements/Terms and Conditions popup box for searching license data. 
							V1.2 : (Story No. W-002333) Added Display Query search results with lazy loading and sorting feature.
                            V1.3 : (Story No. W-002336) Download all search result in Excel format with having all detailed view columns.
                            V1.4 : (Story No. W-002334) Detailed preview pop up view for every search result record.
**********************************************************************/
({
    
    /**
    * @author      : Coforge
    * @date        : 18/08/2021 
    * @description : (Story No. W-002322) This method will disabled the org name textbox on page load.
    * @param1      : component, event, helper
    * @return      : Void
    */
    initHelper: function(component, event, helper) {
        //Disabled Organisation Name textbox for individual account type
        component.find("orgName").set("v.disabled", true);
    },
    /**
    * @author      : Coforge
    * @date        : 18/08/2021 
    * @description : (Story No. W-002322) This method is used to show and hide the input textboxes based on account type.
    * @params      : component, event, helper
    * @return      : Void
    */
    changeAccountTypeHelper: function(component, event, helper) {
        
        var accountType=component.find("accountTypePicklist").get("v.value");
        component.set("v.licenseSearchWrapper.accountType",accountType);
        if(accountType == 'Individual'){
            component.find("orgName").set("v.disabled", true);
            component.set("v.licenseSearchWrapper.organisationName","");
            component.find("firstName").set("v.disabled", false);
            component.find("lastName").set("v.disabled", false);
            component.find("telephoneNo").set("v.disabled", false);
            component.find("mobileNo").set("v.disabled", false);
        } else if(accountType == 'Organisation'){
            component.find("firstName").set("v.disabled", true);
            component.set("v.licenseSearchWrapper.licenseeFirstName","");
            component.find("lastName").set("v.disabled", true);
            component.set("v.licenseSearchWrapper.licenseeLastName","");
            component.find("orgName").set("v.disabled", false);
            component.find("telephoneNo").set("v.disabled", false);
            component.find("mobileNo").set("v.disabled", true);
            component.set("v.licenseSearchWrapper.licenseeMobileNo","");
        }else if(accountType == 'Both'){
            component.find("firstName").set("v.disabled", true);
            component.set("v.licenseSearchWrapper.licenseeFirstName","");
            component.find("lastName").set("v.disabled", true);
            component.set("v.licenseSearchWrapper.licenseeLastName","");
            component.find("orgName").set("v.disabled", true);
            component.set("v.licenseSearchWrapper.organisationName","");
            component.find("telephoneNo").set("v.disabled", true);
            component.set("v.licenseSearchWrapper.licenseeTelephoneNo","");
            component.find("mobileNo").set("v.disabled", true);
            component.set("v.licenseSearchWrapper.licenseeMobileNo","");
        }
    },
    /**
    * @author      : Coforge
    * @date        : 18/08/2021 
    * @description : (Story No. W-002322) This method is used to reset the section values once user collapse/hide the section.
    * @params      : component, event, helper
    * @return      : Void
    */
    sectionToggleHelper: function(component, event, helper) {
        
        helper.resetDataHelper(component, event, helper);
        var activeSectionName=component.get("v.activeSections");
        if(activeSectionName == 'personBusinessSection'){
            var accountType=component.find("accountTypePicklist").get("v.value");
            component.set("v.licenseSearchWrapper.accountType",accountType);
            component.set("v.isSearchExecuted",false);
        }
    },
    /**
    * @author      : Coforge
    * @date        : 31/08/2021 
    * @description : (Story No. W-002331) This method is used to display the DPA Agreements/Terms and Conditions popup box.
    * @params      : component, event, helper
    * @return      : Void
    */
    searchRecordHelper: function(component, event, helper) {
        
        //Fetch license filter values based on user input
        var accountType=component.find("accountTypePicklist").get("v.value");
        var activeSectionName=component.get("v.activeSections");
        var tName=component.get("v.licenseSearchWrapper.callSign");
        var mmsi=component.get("v.licenseSearchWrapper.mmsiNumber");
        var smallShipRegNo=component.get("v.licenseSearchWrapper.smallShipRegNumber");
        var vesselName=component.get("v.licenseSearchWrapper.vesselName");
        var firstName=component.get("v.licenseSearchWrapper.licenseeFirstName");
        var lastName=component.get("v.licenseSearchWrapper.licenseeLastName");
        var orgName=component.get("v.licenseSearchWrapper.organisationName");
        var address=component.get("v.licenseSearchWrapper.licenseeAddress");
        var city=component.get("v.licenseSearchWrapper.licenseeCity");
        var postCode=component.get("v.licenseSearchWrapper.licenseePostcode");
        var contactEmail=component.get("v.licenseSearchWrapper.licenseeEmail");
        var telephoneNo=component.get("v.licenseSearchWrapper.licenseeTelephoneNo");
        var mobileNo=component.get("v.licenseSearchWrapper.licenseeMobileNo");
        component.set("v.isSearchExecuted",false);
        var minCharErrorMsg='';
        
        //Remove Wildcard character % from vessel field
        if(vesselName && vesselName.includes('%')){
            vesselName= vesselName.replaceAll('%',' ');
            vesselName=vesselName.trim();
            if(vesselName.length==0){
                minCharErrorMsg="<br/>Please enter mininum 1 character excluding wildcard (%) character in vessel name.<br/>";
            }
        }
        
        //Remove Wildcard character % from address field
        if(address && address.includes('%')){
            address= address.replaceAll('%',' ');
            address=address.trim();
            if(address.length==0){
                minCharErrorMsg="<br/>Please enter mininum 5 characters excluding wildcard (%) character in Address.<br/>";
            }
        }
        
        //Remove Wildcard character % from postal code field
        if(postCode && postCode.includes('%')){
            postCode= postCode.replaceAll('%',' ');
            postCode=postCode.trim();
            if(postCode.length==0){
                if($A.util.isEmpty(minCharErrorMsg)){
                    minCharErrorMsg="<br/>Please enter mininum 3 characters excluding wildcard (%) character in Postcode.";
                }else{
                    minCharErrorMsg=minCharErrorMsg+"Please enter mininum 3 characters excluding wildcard (%) character in Postcode.";
                }
                component.set("v.requiredFieldMissingText",minCharErrorMsg);
                return;
            }
        }
        
        if(activeSectionName == 'personBusinessSection' && address && address.length<5){ // (Story No. W-002333) Minimum 5 Characters are required for address input filter
            minCharErrorMsg="<br/>Please enter mininum 5 characters excluding wildcard (%) character in Address.<br/>";
        }
        if(activeSectionName == 'personBusinessSection' && postCode && postCode.length<3){ // (Story No. W-002333) Minimum 3 Characters are required for post code input filter
            if($A.util.isEmpty(minCharErrorMsg)){
                minCharErrorMsg="<br/>Please enter mininum 3 characters excluding wildcard (%) character in Postcode.";
            }else{
                minCharErrorMsg=minCharErrorMsg+"Please enter mininum 3 characters excluding wildcard (%) character in Postcode.";
            }
        }
        if(!$A.util.isEmpty(minCharErrorMsg)){
            component.set("v.requiredFieldMissingText",minCharErrorMsg);
            return;
        }
        
        
        if(activeSectionName == 'shipVesselSection' && $A.util.isEmpty(tName) &&
           $A.util.isEmpty(mmsi) && $A.util.isEmpty(smallShipRegNo)
           && $A.util.isEmpty(vesselName)){// validate whether user fill any value in ship vessel section
            component.set("v.requiredFieldMissingText","<br/>Please fill atleast one field in ship/vessel query section.");
        }else if(activeSectionName == 'personBusinessSection' && accountType=='Individual' && $A.util.isEmpty(lastName)){// validate whether user fill last name value in case of individual account type for person business section
            component.set("v.requiredFieldMissingText","<br/>Please enter last name in person/business query section.");
        }else if(activeSectionName == 'personBusinessSection' && accountType=='Organisation' && $A.util.isEmpty(orgName) 
                 && $A.util.isEmpty(address) && $A.util.isEmpty(city) && $A.util.isEmpty(postCode)
                 && $A.util.isEmpty(contactEmail) && $A.util.isEmpty(telephoneNo) && $A.util.isEmpty(mobileNo)){ // validate whether user fill any value in case of Organisation account type for person business section
            component.set("v.requiredFieldMissingText","<br/>Please fill atleast one field in person/business query section.");
        }else if(activeSectionName == 'personBusinessSection' && accountType=='Both' 
                 && $A.util.isEmpty(address) && $A.util.isEmpty(city) && $A.util.isEmpty(postCode)
                 && $A.util.isEmpty(contactEmail)){ // validate whether user fill any value in case of Both account type for person business section
            component.set("v.requiredFieldMissingText","<br/>Please fill atleast one field in person/business query section.");
        }else{// (Story No. W-002331) display DPA Agreement Pop up screen to user
            component.set("v.requiredFieldMissingText","");
            component.set("v.isDPAModelBoxOpen", true); //(Story No. W-002331)
            component.set("v.isTermAndConditionOpen",true); //(Story No. W-002331)
            component.set("v.isSearchLicenseRecordOpen",false);
        }
    },
    /**
    * @author      : Coforge
    * @date        : 31/08/2021 
    * @description : (Story No. W-002331) This method is used to close/hide the DPA Agreements/Terms and Conditions popup box.
    * @param1      : component,event,helper
    * @return      : Void
    */
    closeModelHelper: function(component, event, helper) {
       
        component.set("v.isDPAModelBoxOpen", false);
        component.set("v.isDetailedRecModelBoxOpen", false);

        const modalCloseButton = component.find("exportButton");
        window.setTimeout(
            $A.getCallback(function() {
                // wait for element to render then focus
                modalCloseButton.focus();
            }), 100
        );
    },
    /**
    * @author      : Coforge
    * @date        : 31/08/2021 
    * @description : (Story No. W-002331) This method is used to show the error message and reset the license data to blank on click of decline button.
    * @param1      : component,event,helper
    * @return      : Void
    */
    declineDPAHelper: function(component, event, helper) {
        //component.find("displayMessageId").getElement().focus();
        component.set("v.isConditionAccepted",false);
        //This variable is used to bypass the terms and conditions error message on the screen.
        component.set("v.isSearchExecuted", true);
        component.set("v.isDPAModelBoxOpen", false);
        var data=[];
        component.set("v.licenseData",data);
    },
    /**
    * @author      : Coforge
    * @date        : 31/08/2021 
    * @description : (Story No. W-002322/002333) This method is used to reset the ship vessel and person/business section fields value.
    * @param1      : component,event,helper
    * @return      : Void
    */
    resetDataHelper: function(component, event, helper) {
        var resetMap={};
        component.set("v.licenseSearchWrapper",resetMap);
        component.set("v.isSearchExecuted",false);
        component.set("v.licenseData",resetMap);
        component.set("v.requiredFieldMissingText","");
    },
    /**
    * @author      : Coforge
    * @date        : 01/09/2021 
    * @description : (Story No. W-002331/002333) This method is used to display the searched license data based on user input.
    * @params      : component, event, helper
    * @return      : Void
    */
    acceptDPAHelper: function(component, event, helper) {
        component.set("v.isConditionAccepted",true);      //Story No. W-002331
        component.set("v.isSearchExecuted", true);        //Story No. W-002331
        helper.fetchDataColumn(component, event, helper); //Story No. W-002333
        helper.fetchLicenseData(component, event, helper);//Story No. W-002333
        component.set("v.isDPAModelBoxOpen", false);        //Story No. W-002331
    },
    /**
    * @author      : Coforge
    * @date        : 01/09/2021 
    * @description : (Story No. W-002333) This method is used to fetch the license data based on user input filter criteria.
    * @params      : component, event, helper
    * @return      : Void
    */
    fetchLicenseData : function(component, event, helper){
        var errorMessage=component.get("v.genericErrorMessage");
        component.set("v.hidespinner",true);
        var action = component.get("c.searchLicenseData");
        action.setParams({
            "initialRows" : component.get("v.initialLicenseRecordCount"), //how many rows to load during initialization
            "licenseInputWrapObj" : JSON.stringify(component.get("v.licenseSearchWrapper")) // license search input wrapper
        });
        action.setCallback(this,function(response){
            component.set("v.hidespinner",false);
            var state = response.getState();
            if(state == "SUCCESS"){
                var licenseWrapper = response.getReturnValue();
                if(licenseWrapper.success && licenseWrapper.licenseRecordList){
                    // set total rows count from response wrapper
                    component.set("v.totalLicenseRecordCount",licenseWrapper.totalRecords); // Used for total count for searched license record.
                    component.set("v.lazyRecordCount",licenseWrapper.totalRecords);// Used for lazy loading offset calculation.
                    component.set("v.isSearchExecuted",true);
                    var licenseList = licenseWrapper.licenseRecordList;
                    //Flattening Relationship Field for lightning data table.
                    helper.flattenRelationshipFieldHelper(component, event, helper,licenseList);
                    // set the updated response on licenseData aura attribute 
                    component.set("v.licenseData",licenseList);
					//reset the current license record count to re-initialize lazy loading for next search result. 
                    component.set("v.currentLicenseRecordCount",10);
                }
            }else if (state === "INCOMPLETE") {
                console.log("Error in Incomplete state");
                component.set("v.requiredFieldMissingText",errorMessage);
            }else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message in error state: " + 
                                    errors[0].message);
                        if(errors[0].message && errors[0].message.includes('heap size')){
                            component.set("v.requiredFieldMissingText",'<br/> To Many Records Found.Please add more search parameters.');
                            var resetMap={};
                            component.set("v.licenseData",resetMap);
                        }else if(errors[0].message && errors[0].message.includes('Too many query rows')){
                            component.set("v.requiredFieldMissingText",'<br/> To Many Records Found.Please add more search parameters.');
                            var resetMap={};
                            component.set("v.licenseData",resetMap);
                        }else{
                            component.set("v.requiredFieldMissingText",errorMessage);
                            var resetMap={};
                            component.set("v.licenseData",resetMap);
                        }
                    }
                } else {
                    component.set("v.requiredFieldMissingText",errorMessage);
                }
            }
        });
        $A.enqueueAction(action);
    },
    /**
    * @author      : Coforge
    * @date        : 01/09/2021 
    * @description : (Story No. W-002333) This method is used to fetch the license data table column name from custom metadata.
    * @params      : component, event, helper
    * @return      : Void
    */
    fetchDataColumn : function(component,helper,event){
		var columnNumberNameList=[];
        var errorMessage=component.get("v.genericErrorMessage");
        var action = component.get("c.fetchLightningDataColumns");
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state == "SUCCESS"){
                var dataColumnList=response.getReturnValue();
                console.log('dataColumnList-->'+JSON.stringify(dataColumnList));
                var columnList=[];
                var actionPreview={
                    id: 'previewRecord',
                    label: 'Preview',
                    type: 'button-icon',
                    //initialWidth: 70,
                    fixedWidth: 110,
                    typeAttributes: {
                        iconName: 'action:preview',
                        title: 'Click here to preview this record',
                        variant: 'border-filled',
                        alternativeText: 'View'
                    }};
                columnList.push(actionPreview);
                
                for(var key in dataColumnList){		
                    if(dataColumnList[key].Field_Type__c=='Number'){
                        if(dataColumnList[key].Field_API_Name__c && dataColumnList[key].Field_API_Name__c.includes(',')){
                            var dataColumnSplitList = dataColumnList[key].Field_API_Name__c.split(',');
                            columnNumberNameList.push(dataColumnSplitList[0]);
                            columnNumberNameList.push(dataColumnSplitList[1]);
                        }else{
                            columnNumberNameList.push(dataColumnList[key].Field_API_Name__c);
                        }
                    }
					
                    if(dataColumnList[key].Is_Summarized_View__c){
                        var fieldName=dataColumnList[key].Field_Label__c;
                        var fieldApiName=dataColumnList[key].Field_API_Name__c;
                        var fieldType=dataColumnList[key].Field_Type__c;
                        var isFieldSortable=dataColumnList[key].Is_Field_Sortable__c;
                        if(isFieldSortable=='false'){// remove the sorting functionality from Licence Number column.
                            isFieldSortable=null;
                        }
                        if(fieldApiName!=null && fieldApiName.includes('__r')){ //Flattening Relationship Field
                            fieldApiName=dataColumnList[key].DeveloperName;
                        }
                        var columnDetail={
                            label : fieldName,
                            //initialWidth: 180,
                            fixedWidth: 200,
                            fieldName : fieldApiName,
                            type : fieldType,
                            sortable:isFieldSortable,
                            hideDefaultActions : true,
                            typeAttributes: {
                                title: 'Click here to preview this record',
                                alternativeText: 'View'
                            }
                            /*cellAttributes: 
                            { class: 'focused focusable'}*/
                        }
                        columnList.push(columnDetail);
                    }
                }
                component.set("v.licenseDataColumns",columnList);
				component.set("v.columnNameList",columnNumberNameList);
            }else if (state === "INCOMPLETE") {
                console.log('Response is Incompleted');
				component.set("v.requiredFieldMissingText",errorMessage);
            }else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + 
                                    errors[0].message);
                         component.set("v.requiredFieldMissingText",errorMessage);
                    }
                } else {
                    console.log("Unknown error");
                    component.set("v.requiredFieldMissingText",errorMessage);
                }
            }
        });
        $A.enqueueAction(action);            
    },
    /**
    * @author      : Coforge
    * @date        : 01/09/2021 
    * @description : (Story No. W-002333) This method is used to fetch the next set of license searched record for lazy loading.
    * @params      : component, event, helper
    * @return      : Void
    */
    loadMoreData : function(component){
        return new Promise($A.getCallback(function(resolve){
            var limit = component.get("v.initialLicenseRecordCount");
            var offset = component.get("v.currentLicenseRecordCount");
            var totalRows = component.get("v.lazyRecordCount");
            if(limit + offset > totalRows){
                limit = totalRows - offset;
            }
            var action = component.get("c.searchQueryForLazyLoading");
            action.setParams({
                "licenseInputWrapObj" : JSON.stringify(component.get("v.licenseSearchWrapper")),
                "initialRows" :  limit,
                "rowOffset" : offset
            });
            action.setCallback(this,function(response){
                var state = response.getState();
                var newData = response.getReturnValue();
                resolve(newData.licenseRecordList);
                var currentCount = component.get("v.currentLicenseRecordCount");
                currentCount += component.get("v.initialLicenseRecordCount");
                // set the current count with number of records loaded 
                component.set("v.currentLicenseRecordCount",currentCount);
            });
            $A.enqueueAction(action);
        }));
    },
    /**
    * @author      : Coforge
    * @date        : 01/09/2021 
    * @description : (Story No. W-002333) This method is used to sort the lightning data column in ASC/DESC direction.
    * @params      : component, event, helper
    * @return      : Void
    */
    sortDataHelper : function(component,fieldName,sortDirection){
        var data = component.get("v.licenseData");
        //function to return the value stored in the field
        var key = function(a) { return a[fieldName]; }
        var reverse = sortDirection == 'asc' ? 1: -1;
 
        if((fieldName == 'Vessel_Gross_Tonage__c' || fieldName =='MMSI_number__c') && reverse==1){ // Number Field sorting in ASC order
            data.sort(function(a,b){
                var a = key(a) ? key(a) : '';
                var b = key(b) ? key(b) : '';
                return Number(a)-Number(b);
            }); 
        }else if((fieldName == 'Vessel_Gross_Tonage__c' || fieldName =='MMSI_number__c')  && reverse==-1){ // Number Field sorting in DESC order
            data.sort(function(a,b){
                var a = key(a) ? key(a) : '';
                var b = key(b) ? key(b) : '';
                return Number(b)-Number(a);
            }); 
        }else{// to handle text type fields 
            data.sort(function(a,b){ // Text Field sorting in ASC/DESC order
                var a = key(a) ? key(a).toLowerCase() : '';//To handle null values , uppercase records during sorting
                var b = key(b) ? key(b).toLowerCase() : '';
                return reverse * ((a>b) - (b>a));
            });    
        }
        //set sorted data to licenseData attribute
        component.set("v.licenseData",data);
    },
    /**
    * @author      : Coforge
    * @date        : 07/09/2021 
    * @description : (Story No. W-002336) This method is used to write the search result in CSV file.
    * @param1      : component,event,helper
    * @return      : Void
    */
    convertArrayOfObjectsToCSVHelper : function(component,objectRecords){
        // declare variables
        var csvStringResult, counter, keys, columnDivider, lineDivider; 
        var colNameList=component.get("v.columnNameList"); //numberTypeCols

        // check if "objectRecords" parameter is null, then return from function 
        if (objectRecords == null || !objectRecords.length) { 
            return null; 
        } 
        
        // store ,[comma] in columnDivider variabel for separate CSV values and  
        // for start next line use '\n' [new line] in lineDivider variable   
        columnDivider = ','; 
        lineDivider = '\n'; 
        
        // in the keys store fields API Names as a key  
        keys = ['Id','Licence_Number__c','MMSI_number__c','Vessel_Type_Value__c','Vessel_Intended_Use__c','Vessel_Gross_Tonage__c','Callsign__c'
                ,'Small_Ship_Registry_Number__c','Licence_Issued_Date__c','Licence_Status__c','Name_of_Vessel__c','csord__Account__r.Name' ,'Licensee_Street__c','Licensee_City__c','Licensee_Postal_Code__c','csord__Account__r.PersonMobilePhone','csord__Account__r.PersonHomePhone','csord__Account__r.Phone'
                ,'csord__Account__r.Email__c','csord__Account__r.PersonEmail','Licence_Contact__r.Contact_Name__c','Licence_Contact__r.Street__c'
                ,'Licence_Contact__r.City__c','Licence_Contact__r.PostalCode__c','Licence_Contact__r.Contact__r.PersonMobilePhone','Licence_Contact__r.Phone__c'
                ,'Licence_Contact__r.Email__c','Emergency_Contact_First_Name__c','Emergency_Contact_Last_Name__c','Emergency_Contact_Street__c','Emergency_Contact_City__c','Emergency_Contact_Postal_Code__c','Emergency_Contact_Phone_Number__c','Emergency_Contact_Email__c'];
        
        //this label use in CSV file header. Put them in same sequence as API Names 
        var keyLabel = ['Id','Licence Number','MMSI Number','Vessel Type','Vessel Intended Use','Vessel Gross Tonage','Callsign'
                        ,'Small Ship Registry Number','Licence Issued Date','Licence Status','Name of Vessel',
                        'Licence Holder Name' ,'Licensee Address','Licensee City','Licensee Postal Code','Licensee Mobile Number','Licensee (Person) Telephone Number','Licensee (Business) Telephone Number','Licensee (Business) Contact Email','Licensee (Person) Contact Email',
                        'Licence Contact Name','Licence Contact Address','Licence Contact City','Licence Contact Postal Code','Licence Contact Mobile Number','Licence Contact Telephone Number','Licence Contact Email',
                        'Emergency Contact First Name','Emergency Contact Last Name,Emergency Contact Address','Emergency Contact City','Emergency Contact Postal Code','Emergency Contact Mobile Number','Emergency Contact Email']; 
        csvStringResult = ''; 
        csvStringResult += keyLabel.join(columnDivider); 
        csvStringResult += lineDivider; 
        for(var i=0; i < objectRecords.length; i++){  
            counter = 0; 
            for(var sTempkey in keys) { 
                var skey = keys[sTempkey] ;  
                
                // add , [comma] after every String value [except first] 
                if(counter > 0){  
                    csvStringResult += columnDivider;  
                }    

                if(!skey.includes('__r') && !$A.util.isUndefined(objectRecords[i][skey]) && !$A.util.isEmpty(objectRecords[i][skey])) {// Adding subscription direct relationship fields 
               		
                    if(colNameList.includes(skey)){
                        csvStringResult += '="' + objectRecords[i][skey] +'"'; 
                    }else{
                        csvStringResult += '"'+ objectRecords[i][skey]+'"'; 
                    }
                }else if(skey.includes('__r')){// Adding relationship field in subscription object
                    var skeyList = skey.split('.');
                    var relationshipObjectName=skeyList[0];
                    var relationshipFieldName=skeyList[1];
                    if(relationshipFieldName && !relationshipFieldName.includes('__r') && objectRecords[i] && objectRecords[i][relationshipObjectName] && objectRecords[i][relationshipObjectName][relationshipFieldName] && !$A.util.isUndefined(objectRecords[i][relationshipObjectName][relationshipFieldName]) && !$A.util.isEmpty(objectRecords[i][relationshipObjectName][relationshipFieldName])){// For Single level parent to child relationship field
                        if(colNameList.includes(skey)){
                            var stringLength=objectRecords[i][relationshipObjectName][relationshipFieldName].length;
                             csvStringResult += '="' + objectRecords[i][relationshipObjectName][relationshipFieldName] +'"';
                        }else{
                            csvStringResult += '"'+ objectRecords[i][relationshipObjectName][relationshipFieldName]+'"';
                        }
                    }else if(relationshipFieldName && relationshipFieldName.includes('__r')){// For two level parent to child relationship field
                        var secondLevelRelationshipObjectName=skeyList[1];
                        var secondLevelRelationshipFieldName=skeyList[2];
                        if(objectRecords[i] && objectRecords[i][relationshipObjectName] &&  objectRecords[i][relationshipObjectName][secondLevelRelationshipObjectName] && objectRecords[i][relationshipObjectName][secondLevelRelationshipObjectName][secondLevelRelationshipFieldName])
                            if(colNameList.includes(skey)){
                                 csvStringResult += '="' + objectRecords[i][relationshipObjectName][secondLevelRelationshipObjectName][secondLevelRelationshipFieldName] +'"';
                            }else{
                                csvStringResult += '"'+ objectRecords[i][relationshipObjectName][secondLevelRelationshipObjectName][secondLevelRelationshipFieldName]+'"';
                            }
                    }else{                    
                        csvStringResult += '"'+' '+'"'; 
                    }
                }else { 
                    csvStringResult += '"'+' '+'"'; 
                } 
                counter++;  
            } // inner for loop close  
            csvStringResult += lineDivider; 
        }// outer main for loop close  
        // return the CSV formate String  
        return csvStringResult;          
    },
    /**
    * @author      : Coforge
    * @date        : 10/09/2021 
    * @description : (Story No. W-002333) This method is used to flattening Relationship Field for lightning data table.
    * @param1      : component,event,helper
    * @return      : Void
    */
    flattenRelationshipFieldHelper : function(component, event, helper,licenseData) {
        //Flattening Relationship Field for lightning data table.
        for (var i = 0; i < licenseData.length; i++) {
            var licenseRecord=licenseData[i];
            if (licenseRecord && licenseRecord.csord__Account__r && licenseRecord.csord__Account__r.Name) {
                licenseRecord.Licence_Holder_Name = licenseRecord.csord__Account__r.Name;
            }
        }
    }
})