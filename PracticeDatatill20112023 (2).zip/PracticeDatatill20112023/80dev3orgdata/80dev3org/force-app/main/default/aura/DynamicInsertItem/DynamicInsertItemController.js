/*********************************************************************
# File....................: DynamicInsertItemController
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............: 31/05/2021
# Last Modified by........: 
# Last Modified Date......:  
# Description.............: This is a JS Controller of 'DynamicInsertItem'Lightning component.   
# VF Page.................: NA
# VF Component............: NA
# L Comp..................: AccountSelectionComponent
# Test Class..............: NA
# Change Log..............: Intitial Version, 1.0
**********************************************************************/
({
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to load component.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    doInit : function(component, helper) {
        try{
            var objVar = component.get('v.instance');
            var fieldNameVar = component.get('v.fieldName');
            var outputText = component.find('outputTextId');
            if(typeof outputText != 'undefined'){
                if (fieldNameVar.indexOf(".") >= 0) {
                    var parentSobject = objVar[fieldNameVar.split(".")[0]];
                    if(parentSobject != undefined){
                        outputText.set("v.value",parentSobject[fieldNameVar.split(".")[1]]);
                    }
                }
                else{
                    outputText.set("v.value",objVar[fieldNameVar]);
                }
            }  
        }  
        catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling doInit in DynamicInsertItemController @@@@' + e);
        }
    }, 
    
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to delete new account.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    removeRow : function(component, event, helper){
        try{
            // fire the DeleteRowEvt Lightning Event and pass the deleted Row Index to Event parameter/attribute
            component.getEvent("DeleteRowEvt").setParams({"indexVar" : component.get("v.rowIndex") }).fire();
        }
        catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling removeRow in DynamicInsertItemController @@@@' + e);
        }
        
    },
    
    
    
})