/*********************************************************************
# File....................: DynamicCaseLayoutComponentHelper
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............: 31/05/2021
# Last Modified by........: 
# Last Modified Date......:  
# Description.............: This is a JS helper of 'DynamicCaseLayoutComponent'Lightning component.   
# VF Page.................: NA
# VF Component............: NA
# L Comp..................: DynamicCaseLayoutComponent
# Test Class..............: NA
# Change Log..............: Initial Version, 1.0
**********************************************************************/
({
    
    /*
     * @author      : Coforge
     * @date        : 31/05/2021
     * @description : This function is used to get all fields from meta data.
     * @params      : component, event, helper
     * @return      : NA
     */
    getSectionsAndFields: function (component, event, helper) {
        try{
            var getMetaDataAction = component.get("c.getMetaData");
            var creationFlag=false;
            var updationFlag=false;
            if(component.get('v.actionName')=='insert'){
                creationFlag=true;
            }
            else{
                updationFlag=true;
            }
            getMetaDataAction.setParams({
                "isCreation": creationFlag,
                "isUpdation": updationFlag,
                "recordtypename": 'IRMS'
            });
            getMetaDataAction.setCallback(this, function (response) {
                var state = response.getState();
                if (component.isValid() && (state === 'SUCCESS' || state === 'DRAFT')) {
                    var allRecords = response.getReturnValue();
                    component.set("v.metadataObj",allRecords);
                } else if (state === 'INCOMPLETE') {
                    this.showError(component, event, helper,response.getError());
                    console.log('Error==' + JSON.stringify(response.getError()));
                } else if (state === 'ERROR') {
                    this.showError(component, event, helper,response.getError());
                    console.log('Error==' + response.getError());
                } else {
                    this.showError(component, event, helper,response.getError());
                    console.log('Unknown error while making DML ' + response.getError());
                }
            });
            $A.enqueueAction(getMetaDataAction);
        }catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in getSectionsAndFields Function of DynamicCaseLayoutComponentHelper@@@@' + e);
        }
    },
    /*
     * @author      : Coforge
     * @date        : 31/05/2021
     * @description : This function is used to handle error.
     * @params      : component, event, helper
     * @return      : NA
     */
    showError : function(component, event, helper,errorMsg) {
        try{
            
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title : 'Error',
                message:errorMsg,
                duration:'20000',
                key: 'info_alt',
                type: 'error',
                mode: "dismissible"
            });
            toastEvent.fire();
        }
        catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in showError Function in DynamicCaseLayoutComponentHelper@@@@' + e);
        }
    },
    
    /*
     * @author      : Coforge
     * @date        : 31/05/2021
     * @description : This function is used to Create Case records.
     * @params      : component, event, helper
     * @return      : NA
     */
    onUpsertObject: function (component, event, helper, data) {
        try{
            var upsertObject = component.get("c.doUpsertObjectsCase");
            upsertObject.setParams({
               
                "objectDataId":data,
                "accList": component.get('v.accountArray')
                
            });
            upsertObject.setCallback(this, function (response) {
                var state = response.getState();
                if (component.isValid() && (state === 'SUCCESS' || state === 'DRAFT')) {
                    component.set('v.showSuccessMessage','Bulk creation process has been initiated successfully, you will receive an email once the transaction is completed');
                    component.set("v.showBulkInfo",true);
                } else if (state === 'INCOMPLETE') {
                    this.showError(component, event, helper,response.getError());
                    console.log('Error==' + JSON.stringify(response.getError()));
                } else if (state === 'ERROR') {
                    this.showError(component, event, helper,response.getError());
                    console.log('Error==' + response.getError());
                } else {
                    this.showError(component, event, helper,response.getError());
                    console.log('Unknown error while making DML ' + response.getError());
                }
                
                component.set('v.spinner', false);
            });
            $A.enqueueAction(upsertObject);
        }catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in onUpsertObject Function in DynamicCaseLayoutComponentHelper@@@@' + e);
        }
    },
    /*
     * @author      : Coforge
     * @date        : 31/05/2021
     * @description : This function is used to update Case records.
     * @params      : component, event, helper
     * @return      : NA
     */
    doUpdateCase: function (component, event, helper,data) {
        try{
            var doUpdateCase = component.get("c.doUpdateCases");
            doUpdateCase.setParams({
                "caseIds" :component.get("v.caseArray"),
                "casePrevObj": data
            });
            doUpdateCase.setCallback(this, function (response) {
                var state = response.getState();
                if (component.isValid() && (state === 'SUCCESS' || state === 'DRAFT')) {
                    component.set('v.showSuccessMessage','Bulk updation process has been initiated successfully, you will receive an email once the transaction is completed');
                    component.set("v.showBulkInfo",true);
                    
                } else if (state === 'INCOMPLETE') {
                    this.showError(component, event, helper,response.getError());
                    console.log('Error==' + JSON.stringify(response.getError()));
                } else if (state === 'ERROR') {
                    this.showError(component, event, helper,response.getError());
                    console.log('Error==' + response.getError());
                } else {
                    this.showError(component, event, helper,response.getError());
                    console.log('Unknown error while making DML ' + response.getError());
                }
                
                component.set('v.spinner',false);
            });
            $A.enqueueAction(doUpdateCase);
        }catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in doUpdateCase Function in DynamicCaseLayoutComponentHelper@@@@' + e);
        }
    },
    /*
     * @author      : Coforge
     * @date        : 31/05/2021
     * @description : This function is used to get recortypeID.
     * @params      : component, event, helper
     * @return      : String
     */
    getRecordType: function (component, event, helper) {
        try{
            var getRecorTypeIdAction = component.get("c.getRecordTypeId");
            getRecorTypeIdAction.setCallback(this, function (response) {
                var state = response.getState();
                if (component.isValid() && (state === 'SUCCESS' || state === 'DRAFT')) {
                    var recordtypeAttr = response.getReturnValue();
                    component.set("v.recordtypeAttr",recordtypeAttr);
                } else if (state === 'INCOMPLETE') {
                    this.showError(component, event, helper,response.getError());
                    console.log('Error==' + JSON.stringify(response.getError()));
                    
                } else if (state === 'ERROR') {
                    this.showError(component, event, helper,response.getError());
                    console.log('Error==' + response.getError());
                    
                } else {
                    this.showError(component, event, helper,response.getError());
                    console.log('Unknown error while making DML ' + response.getError());
                }
            });
            $A.enqueueAction(getRecorTypeIdAction);
        }catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in getRecordTypeId Function in DynamicCaseLayoutComponentHelper@@@@' + e);
        }
    },
    /*
     * @author      : Coforge
     * @date        : 31/05/2021
     * @description : This function is call to handle the previous  .
     * @params      : component, event, helper
     * @return      : NA
     */
    handlePrevious: function(component, event, helper) {
        try {
            
            if (component.get("v.actionName") == 'Update') {
                window.history.back();
            }
            else{
                var evt = $A.get("e.force:navigateToComponent");
                evt.setParams({
                    componentDef:"c:AccountSelectionComponent",
                    componentAttributes: {
                        lstSelectedRecords: component.get("v.accountArray"),
                        selectedRecordAdditionalToVar: component.get("v.accountArray")
                    }
                });
                evt.fire();
            }
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling handlePrevious Function in DynamicCaseLayoutComponentController@@@ ' + e);
        }
        
    },
    
})