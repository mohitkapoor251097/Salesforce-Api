({
    doInit: function (component, event, helper) {
        try{
            console.log('@@@@@@' + component.get('v.selectedRecord'));
            if(component.get('v.selectedRecord') != ''){
                var forclose = component.find("lookup-pill");
                $A.util.addClass(forclose, 'slds-show');
                $A.util.removeClass(forclose, 'slds-hide');
                
                var forclose = component.find("searchRes");
                $A.util.addClass(forclose, 'slds-is-close');
                $A.util.removeClass(forclose, 'slds-is-open');
                
                var lookUpTarget = component.find("lookupField");
                $A.util.addClass(lookUpTarget, 'slds-hide');
                $A.util.removeClass(lookUpTarget, 'slds-show'); 
            }
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling DOINIT Function@@@@' + e);
        }
    },
    onfocus : function(component,event,helper){
        try{
            // show the spinner, call helper function
            $A.util.addClass(component.find("mySpinner"), "slds-show");
            var forOpen = component.find("searchRes");
            $A.util.addClass(forOpen, 'slds-is-open');
            $A.util.removeClass(forOpen, 'slds-is-close');
            // Get Default 5 Records order by createdDate DESC  
            var getInputkeyWord = '';
            helper.searchHelper(component,event,getInputkeyWord);
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling onfocus Function@@@@' + e);
        }
    },
    onblur : function(component,event,helper){
        try{
            // on mouse leave clear the listOfSeachRecords 
            component.set("v.listOfSearchRecords", null );
            var forclose = component.find("searchRes");
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling onblur Function@@@@' + e);
        }
    },
    keyPressController : function(component, event, helper) {
        try{
            // get the search Input keyword
            console.log('in key press controller' + component.get("v.SearchKeyWord"));   
            var getInputkeyWord = component.get("v.SearchKeyWord");
            // check if getInputKeyWord size id more then 0 then open the lookup result List and 
            // call the helper 
            // else close the lookup result List part.   
            if( getInputkeyWord.length > 0 ){
                var forOpen = component.find("searchRes");
                $A.util.addClass(forOpen, 'slds-is-open');
                $A.util.removeClass(forOpen, 'slds-is-close');
                helper.searchHelper(component,event,getInputkeyWord);
            }
            else{  
                component.set("v.listOfSearchRecords", null ); 
                var forclose = component.find("searchRes");
                $A.util.addClass(forclose, 'slds-is-close');
                $A.util.removeClass(forclose, 'slds-is-open');
            }
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling keyPressController Function@@@@' + e);
        }
    },
    
    // function for clear the Record Selaction 
    clear :function(component,event,heplper){
        try{
            var pillTarget = component.find("lookup-pill");
            var lookUpTarget = component.find("lookupField"); 
            
            $A.util.addClass(pillTarget, 'slds-hide');
            $A.util.removeClass(pillTarget, 'slds-show');
            
            $A.util.addClass(lookUpTarget, 'slds-show');
            $A.util.removeClass(lookUpTarget, 'slds-hide');
            
            component.set("v.SearchKeyWord",null);
            component.set("v.listOfSearchRecords", null );
            component.set("v.selectedRecord", {} ); 
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling clear Function@@@@' + e);
        }
    },
    
    // This function call when the end User Select any record from the result list.   
    handleComponentEvent : function(component, event, helper) {
        try{
            // get the selected Account record from the COMPONETN event 	 
            var selectedAccountGetFromEvent = event.getParam("recordByEvent");
            component.set("v.selectedRecord" , selectedAccountGetFromEvent);
            
            var forclose = component.find("lookup-pill");
            $A.util.addClass(forclose, 'slds-show');
            $A.util.removeClass(forclose, 'slds-hide');
            
            var forclose = component.find("searchRes");
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
            
            var lookUpTarget = component.find("lookupField");
            $A.util.addClass(lookUpTarget, 'slds-hide');
            $A.util.removeClass(lookUpTarget, 'slds-show');
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling handleComponentEvent Function@@@@' + e);
        }
        
    },
})