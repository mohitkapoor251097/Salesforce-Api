/*********************************************************************
# File....................: BorderForceLicenceSearchComponentController
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............: 18/08/2021 
# Last Modified by........: Coforge
# Last Modified Date......: 27/09/2021
# Description.............: This is a JS Controller of 'BorderForceLicenceSearchComponent'Lightning component.   
# VF Page.................: NA
# VF Component............: NA
# L Comp..................: BorderForceLicenceSearchComponent
# Test Class..............: NA
# Change Log..............: V1.0 : Initial version (Story No. W-002322) Added Ship Vessel and Person Business Section.
         					V1.1 : (Story No. W-002331) Added DPA Agreements/Terms and Conditions popup box for searching license data.
							V1.2 : (Story No. W-002333) Added Display Query search results with lazy loading and sorting feature.
                            V1.3 : (Story No. W-002336) Download all search result in Excel format with having all detailed view columns.
                            V1.4 : (Story No. W-002334) Detailed preview pop up view for every search result record.
**********************************************************************/
({
    /**
    * @author      : Coforge
    * @date        : 18/08/2021 
    * @description : (Story No. W-002322) This method will called once the page intialized.
    * @param1      : component,event,helper
    * @return      : Void
    */
    onInit : function(component,event,helper){
        helper.initHelper(component,event,helper);       
    },
    /**
    * @author      : Coforge
    * @date        : 18/08/2021 
    * @description : (Story No. W-002322) This method is used to reset the section values once user collapse/hide the section.
    * @param1      : component,event,helper
    * @return      : Void
    */
    handleSectionToggle: function (component, event,helper) {
        helper.sectionToggleHelper(component, event,helper);
    },
    /**
    * @author      : Coforge
    * @date        : 31/08/2021 
    * @description : (Story No. W-002331) This method is used to display the DPA Agreements/Terms and Conditions popup box.
    * @params      : component, event, helper
    * @return      : Void
    */
    handleSearchRecord : function(component,event,helper){
        helper.searchRecordHelper(component,event,helper);
    },
    /**
    * @author      : Coforge
    * @date        : 01/09/2021 
    * @description : (Story No. W-002333) This method is used to fetch the license data in lazy loading way.
    * 				 It will provide us the next set of records to display on the lightning data table.
    * @params      : component, event, helper
    * @return      : Void
    */
    handleLoadMoreData : function(component,event,helper){
        
        if(!(component.get("v.currentLicenseRecordCount") >= component.get("v.lazyRecordCount"))){
            //To display the spinner
            event.getSource().set("v.isLoading", true); 
            //To handle data returned from Promise function
            helper.loadMoreData(component).then(function(data){ 
                var currentData = component.get("v.licenseData");
                //Flattening Relationship Field for lightning data table.
                helper.flattenRelationshipFieldHelper(component,event,helper,data);
                var newData = currentData.concat(data);
                component.set("v.licenseData", newData);
                //To hide the spinner
                event.getSource().set("v.isLoading", false); 
            });
        }
    },
    /**
    * @author      : Coforge
    * @date        : 01/09/2021 
    * @description : (Story No. W-002333) This method is used to sort the lightning data column in ASC/DESC direction.
    * @params      : component, event, helper
    * @return      : Void
    */
    handleSort : function(component,event,helper){
        //Return the field which has to be sorted
        var sortBy = event.getParam("fieldName");
        //return the direction of sorting like asc or desc
        var sortDirection = event.getParam("sortDirection");
        //Set the sortBy and SortDirection attributes
        component.set("v.sortBy",sortBy);
        component.set("v.sortDirection",sortDirection);
        // call sortData helper function
        helper.sortDataHelper(component,sortBy,sortDirection);
    },
    
    /**
    * @author      : Coforge
    * @date        : 07/09/2021 
    * @description : (Story No. W-002336) This method is used to download the search result in CSV file.
    * @param1      : component,event,helper
    * @return      : Void
    */
    downloadLicenseCsvFile : function(component,event,helper){

        component.set("v.hidespinner",true);
        var action = component.get("c.getAllLicenceRecords");
        action.setParams({
            "licenseInputWrapObj" : JSON.stringify(component.get("v.licenseSearchWrapper"))
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state == "SUCCESS"){
                // get the searched license records 
                var stockData = response.getReturnValue();
                // call the helper function which "return" the CSV data as a String   
                var csv = helper.convertArrayOfObjectsToCSVHelper(component,stockData);
                
                if (csv == null){return;} 

                var csvFile = new Blob(["\ufeff",csv]); 
                var downloadLink = document.createElement("a"); 
                downloadLink.download = 'ExportData.csv'; // CSV file Name* you can change it. [only name not .csv] 
                downloadLink.href = window.URL.createObjectURL(csvFile); 
                downloadLink.style.display = "none"; 
                downloadLink.target = '_blank';  
                document.body.appendChild(downloadLink); 
                downloadLink.click(); // using click() js function to trigger download csv file
                component.set("v.hidespinner",false);
            }
        });
        $A.enqueueAction(action);     
    }, 
    /**
    * @author      : Coforge
    * @date        : 31/08/2021 
    * @description : (Story No. W-002334) This method is used to open detailed licence record on popup box.
    * @param1      : component,event,helper
    * @return      : Void
    */
    handleRowAction : function(component,event,helper){
        
   

        var recordDetail=event.getParam("row");
               
        // Merging Emergency First Name and Last Name
        if(recordDetail && !$A.util.isEmpty(recordDetail.Emergency_Contact_Last_Name__c) && recordDetail.Emergency_Contact_First_Name__c && !recordDetail.Emergency_Contact_First_Name__c.includes(recordDetail.Emergency_Contact_Last_Name__c)){
            recordDetail.Emergency_Contact_First_Name__c=recordDetail.Emergency_Contact_First_Name__c +' '+recordDetail.Emergency_Contact_Last_Name__c;
        }
        
        component.set("v.rowSpecificLicenseRecord",recordDetail);
        component.set("v.isSearchLicenseRecordOpen",true);
        component.set("v.isDetailedRecModelBoxOpen", true);
        //document.getElementById("modal-heading-011").focus();
        //var x = document.getElementById("bodyId");
        //component.find("modal-heading-011").fontcolor("green");
        component.set("v.isTermAndConditionOpen",false);
        const modalCloseButton = component.find("buttonRedesign");
        window.setTimeout(
            $A.getCallback(function() {
                // wait for element to render then focus
                modalCloseButton.focus();
            }), 100
        );
    },
    /**
    * @author      : Coforge
    * @date        : 31/08/2021 
    * @description : (Story No. W-002331) This method is used to close/hide the DPA Agreements/Terms and Conditions popup box.
    * @param1      : component,event,helper
    * @return      : Void
    */
    closeModel : function(component,event,helper){
        helper.closeModelHelper(component,event,helper);
    },
    /**
    * @author      : Coforge
    * @date        : 01/09/2021 
    * @description : (Story No. W-002331/002333) This method is used to display the searched license data based on user input.
    * @params      : component, event, helper
    * @return      : Void
    */
    handleAccept : function(component,event,helper){
        helper.acceptDPAHelper(component,event,helper);
    },
    /**
    * @author      : Coforge
    * @date        : 31/08/2021 
    * @description : (Story No. W-002331) This method is used to show the error message and reset the license data to blank on click of decline button.
    * @param1      : component,event,helper
    * @return      : Void
    */
    handleDecline : function(component,event,helper){
        helper.declineDPAHelper(component,event,helper);
    },
    /**
    * @author      : Coforge
    * @date        : 31/08/2021 
    * @description : (Story No. W-002322/002333) This method is used to reset the ship vessel and person/business section fields value.
    * @param1      : component,event,helper
    * @return      : Void
    */
    handleReset: function(component,event,helper) {
        helper.resetDataHelper(component,event,helper);
    },
    /**
    * @author      : Coforge
    * @date        : 18/08/2021 
    * @description : (Story No. W-002322) This method is used to show and hide the input textboxes based on account type.
    * @params      : component, event, helper
    * @return      : Void
    */
    handleChangeAccountType: function(component, event, helper) {
        helper.changeAccountTypeHelper(component, event, helper);
    }
})