/*********************************************************************
# File....................: MultipleFileUploadsHelper
# Version.................: 1.0
# Created by..............: NIIT
# Created Date............: 12/08/2020 
# Last Modified by........: NIIT
# Last Modified Date......: 12/08/2020
# Description.............: This is a helper class of 'MultipleFileUploads'Lightning component.   
# VF Page.................: NA
# VF Component............: NA
# L Comp..................: MultipleFileUploads
# Test Class..............: NA
# Change Log..............: Intitial Version, 1.0
**********************************************************************/
({ 
    /**
	* @author      : NIIT
	* @date        : 12/08/2020
	* @description : Method invoked after uploading a File on sObject
	* @param       : component,event
	* @return      : Void
	*/      
    handleUploadFinished : function(component, event) {
        try{
            //get all attached files on sObject
            var sObjectAttachedFilesArr = [];           
            var uploadedFiles = event.getParam("files");
            [].forEach.call(uploadedFiles, function(file) {                               
                //get all uploaded files in an array to display on the UI
                sObjectAttachedFilesArr.push({'Id' : file.documentId,
                                              'Title': file.name});
            });                       
            component.set("v.sObjectAttachedFiles", sObjectAttachedFilesArr);
            if(!component.get("v.multiple")){
                component.set("v.disabled", true);
            }
        }catch(e){
            alert($A.get("{!$Label.c.MID_ContactAdminErrorMessage}"));
            console.log('Exception in calling handleUploadFinished-->' + e);
        }
    },
    
    /**
	* @author      : NIIT
	* @date        : 12/08/2020
	* @description : Method to handle cancel button functionality.
	* @param       : component
	* @return      : Void
	*/    
    handleCancelButton : function(component){
        try{           
            var confirmValue = confirm($A.get("$Label.c.FileUploadCancelMessage"));
            if (confirmValue == true) {                
                this.deleteUploadedfiles(component,[]);
                var navEvt = $A.get("e.force:navigateToSObject");
                navEvt.setParams({
                    "recordId": component.get("v.sObjectId"),
                    "slideDevName": "related"
                });
                navEvt.fire();
            } 
        }catch(e){
            alert($A.get("{!$Label.c.MID_ContactAdminErrorMessage}"));
            console.log('Exception in calling handleCancelButton-->' + e);
        }
    },
    
    /**
	* @author      : NIIT
	* @date        : 12/08/2020
	* @description : Method to handle done functionality
	* @param       : component
	* @return      : Void
	*/      
    handleDoneClick : function(component){
        try{
            var pageName = component.get("v.pageName");
            //redirect to page having page Name is pageName          
            if(pageName != '' && pageName != undefined){
                var returnUrl = window.location.protocol +'//'+ window.location.hostname + '/one/one.app#/alohaRedirect/apex/' + pageName + '?objId=' + component.get("v.sObjectId");           
                window.location.href = returnUrl;      		    
            }else{               
                var navEvt = $A.get("e.force:navigateToSObject");
                navEvt.setParams({
                    "recordId": component.get("v.sObjectId"),
                    "slideDevName": "related"
                });
                navEvt.fire();
            }
        }catch(e){
            alert($A.get("{!$Label.c.MID_ContactAdminErrorMessage}"));
            console.log('Exception in calling helper handleDoneClick-->' + e);
        }
    },
    
    /**
	* @author      : NIIT
	* @date        : 12/08/2020
	* @description : Method to handle Delete the file
	* @param       : component, documentId
	* @return      : Void
	*/     
    deleteUploadedfiles : function(component,documentId) {
        try{
            var uploadedFiles = component.get("v.sObjectAttachedFiles");
            var uploadedFileIdArr = [];
            if(uploadedFiles != null && uploadedFiles != undefined && uploadedFiles.length > 0){
                [].forEach.call(uploadedFiles, function(file) {
                    //get all uploaded File Ids in an Array
                    uploadedFileIdArr.push(file.Id);
                });
            }
            var action = component.get("c.deleteFiles");           
            action.setParams({
                "deleteDocumentId" : JSON.stringify(documentId) ,
                "allUploadedDocumentIds" : JSON.stringify(uploadedFileIdArr)
            });  
            action.setCallback(this,function(response){  
                var state = response.getState();  
                if(state=='SUCCESS'){                  
                    $A.get('e.force:refreshView').fire(); 
                    component.set("v.sObjectAttachedFiles", response.getReturnValue());
                    if(component.get("v.sObjectAttachedFiles").length==0 ){
                        component.set("v.disabled", false);    
                    }
                }  
            });  
            $A.enqueueAction(action);  
        }catch(e){
            alert($A.get("{!$Label.c.MID_ContactAdminErrorMessage}"));
            console.log('Exception in calling deleteUploadedfiles-->' + e);
        }
    },
    
})