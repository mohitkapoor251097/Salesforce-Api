/*********************************************************************
# File....................: paginationComponentController
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............:  01/04/2021
# Last Modified by........: 
# Last Modified Date......:  
# Description.............: This is a JS Controller of 'paginationComponent'Lightning component.   
# VF Page.................: NA
# VF Component............: NA
# L Comp..................: paginationComponent
# Test Class..............: NA
# Change Log..............: Intitial Version, 1.0
**********************************************************************/
({
    /*
	 * @author      : Coforge
	 * @date        : 01/04/2021
	 * @description : This function is call intially to intiallised the variables.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    doInit: function (component, event, helper) {
        try {
            // this function call on the component load first time     
            // get the page Number if it's not define, take 1 as default
            var page = component.get("v.page") || 1;
            // get the select option (drop-down) values.   
            var recordToDisply = component.find("recordSize").get("v.value");
            // call the helper function to get data based on page no   
            helper.getData(component, page, recordToDisply,false);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling paginationComponentController->doInit @@@@' + e);
        }
        
    },
    /*
	 * @author      : Coforge
	 * @date        : 01/04/2021
	 * @description : This function is call set values in variables when component get refresh.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    
    setValues: function (component, event, helper) {
        try {
            var total = component.get('v.dataArray').length;
            var recordToDisply = component.find("recordSize").get("v.value");// No of records to be display per page
            var current = component.get("v.page");// Store current page value
            component.set("v.total", total);
            component.set("v.pages", Math.ceil(total / recordToDisply));
            component.set("v.page", current);
            component.set('v.lstSelectedRecordsList', component.get('v.dataArray'));// store total data
            if (total > 0) {
                helper.getData(component, current, recordToDisply,false);
            }
            
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling paginationComponentController->setValues @@@@' + e);
        }
        
        
    },
    /*
	 * @author      : Coforge
	 * @date        : 01/04/2021
	 * @description : This function is called on the click of previous page or next page button to fetch data based on page no .
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    navigate: function (component, event, helper) {
        try {
            var page = component.get("v.page") || 1;
            var direction = event.getSource().get("v.label");
            var recordToDisply = component.find("recordSize").get("v.value");
            var pgName = "page" + page;
            
            page = direction === "Previous Page" ? (page - 1) : (page + 1);
            console.log(page);
            component.set("v.page", page);
            // Fetch data based on page no 
            helper.getData(component, page, recordToDisply,true);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling paginationComponentController->navigate @@@@' + e);
        }
        
        
    },
    /*
	 * @author      : Coforge
	 * @date        : 01/04/2021
	 * @description : This function is used to refresh the selected records on particular page.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    /*setSelectedValues: function (component, event, helper) {
        try {
            var page = component.get("v.page") || 1;
            var pgName = "page" + page;
            component.get("v.SelectedCase")[pgName] = component.get("v.SelectedCaseArray");
            helper.setSelectedRecords(component,pgName);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling paginationComponentController->setSelectedValues @@@@' + e);
        }
    },*/
    
    /*
	 * @author      : Coforge
	 * @date        : 01/04/2021
	 * @description : This function is called when page size change .
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    onSelectChange: function (component, event, helper) {
        try {
            // this function call on the select option change,	 
            var page = 1
            var recordToDisply = component.find("recordSize").get("v.value");
            component.set("v.page", 1);
            helper.getData(component, page, recordToDisply);
            
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling paginationComponentController->onSelectChange @@@@' + e);
        }
        
    },
    
})