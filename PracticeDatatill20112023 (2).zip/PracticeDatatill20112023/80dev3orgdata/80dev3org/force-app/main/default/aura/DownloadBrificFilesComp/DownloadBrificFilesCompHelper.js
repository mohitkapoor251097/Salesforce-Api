({
    /*
    * @author      : NIIT
    * @date        : 28/10/2019
    * @description : doInitHelper function to fetch all records, and set attributes value on component load.
    * @params      : component, event
    * @return      : NA
    */	
    doInitHelper : function(component,event){ 
        //Calling controller method which return the list of all files.
        var action = component.get("c.fetchCVWrapper");
        action.setParams({
            parentID : component.get("v.recordId") //Sending parent record id to the contrller method.
        });
        //If response is successful then setting values in attributes.
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var oRes = response.getReturnValue();
                if(oRes== null){
                    console.log('In Null');
                }
                if(oRes!= null && oRes.length > 0){
                    component.set('v.listOfAllFiles', oRes);
                    var pageSize = component.get("v.pageSize");
                    var totalRecordsList = oRes;
                    var totalLength = totalRecordsList.length ;
                    component.set("v.totalRecordsCount", totalLength);
                    component.set("v.startPage",0);
                    component.set("v.endPage",pageSize-1);
                    
                    var PaginationLst = [];
                    for(var i = 0; i < pageSize; i++){
                        if(component.get("v.listOfAllFiles").length > i){
                            PaginationLst.push(oRes[i]);    
                        } 
                    }
                    component.set('v.PaginationList', PaginationLst);
                    component.set("v.selectedCount" , 0);
                    //use Math.ceil() to Round a number upward to its nearest integer
                    component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));    
                }else{
                    // if there is no records then display message
                    component.set("v.bNoRecordsFound" , true);
                } 
            }
            else{
                alert('Error in fetching records....');
            }
        });
        $A.enqueueAction(action);  
    },
     
    /*
    * @author      : NIIT
    * @date        : 28/10/2019
    * @description : navigate to next pagination record set
    * @params      : component, event, sObject List, end page no., start page no., Size of the page 
    * @return      : NA
    */ 
    next : function(component,event,sObjectList,end,start,pageSize){
        var Paginationlist = [];
        var counter = 0;
        for(var i = end + 1; i < end + pageSize + 1; i++){
            if(sObjectList.length > i){ 
                if(component.find("selectAllId").get("v.value")){
                    Paginationlist.push(sObjectList[i]);
                }else{
                    Paginationlist.push(sObjectList[i]);  
                }
            }
            counter ++ ;
        }
        start = start + counter;
        end = end + counter;
        component.set("v.startPage",start);
        component.set("v.endPage",end);
        component.set('v.PaginationList', Paginationlist);
    },
   
   /*
    * @author      : NIIT
    * @date        : 28/10/2019
    * @description : navigate to previous pagination record set 
    * @params      : component, event, sObject List, end page no., start page no., Size of the page 
    * @return      : NA
    */  
    previous : function(component,event,sObjectList,end,start,pageSize){
        var Paginationlist = [];
        var counter = 0;
        for(var i= start-pageSize; i < start ; i++){
            if(i > -1){
                if(component.find("selectAllId").get("v.value")){
                    Paginationlist.push(sObjectList[i]);
                }else{
                    Paginationlist.push(sObjectList[i]); 
                }
                counter ++;
            }else{
                start++;
            }
        }
        start = start - counter;
        end = end - counter;
        component.set("v.startPage",start);
        component.set("v.endPage",end);
        component.set('v.PaginationList', Paginationlist);
    },
})