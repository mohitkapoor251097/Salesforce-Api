/*********************************************************************
   # File....................: CaseBulkOperationComponentController
   # Version.................: 1.0
   # Created by..............: Coforge Technologies
   # Created Date............: 31/05/2021
   # Last Modified by........: 
   # Last Modified Date......: 
   # Description.............: This is a JS Controller of 'CaseBulkOperationComponent' Lightning component .   
   # VF Page.................: NA
   # VF Component............: NA
   # Lightning Component.....: CaseBulkOperationComponent
   # Test Class..............: NA
   # Change Log..............: v1.0 Initial Version 
   **********************************************************************/
({	 
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function call to load component.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    doInit: function (component, event, helper) {   
        try{
            component.set('v.isOpen', true);
        }
        catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in doInit Function in CaseBulkOperationComponentController @@@@' + e);
        } 
        
    },
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to redirect to the next step.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    onSelectChange: function(component, event, helper) {
        try{
            helper.onSelectChange(component, event, helper);
        }
        catch (e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in onSelectChange Function in CaseBulkOperationComponentController@@@@' + e);
        } 
        
    },
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function call on the select options change,.
	 * @params      : component, event, helper
	 * @return      : NA
	 */ 
    handleCancel: function (component, event, helper) {
        try{
            location.href = '/lightning/page/home';
        }
        catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in handleCancel Function in CaseBulkOperationComponentController@@@@' + e);
        }  
        
    },
    
})