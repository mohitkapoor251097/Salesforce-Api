/***********************************************************************
# File....................: AccountSelectionComponentController
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............: 31/05/2021
# Last Modified by........: 
# Last Modified Date......:  
# Description.............: This is a JS Controller of 'AccountSelectionComponent'Lightning component.   
# VF Page.................: NA
# VF Component............: NA
# L Comp..................: AccountSelectionComponent
# Test Class..............: NA
# Change Log..............: Initial Version, 1.0
**********************************************************************/
({
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is call intially when component is loaded first time.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    init: function (component, event, helper) {
        try{
            component.set("v.accountList", '');
            if(component.get('v.bulkcloning') != undefined){
                component.set('v.actionName','Select accounts for bulk cloning ');
                component.set('v.instruction','Step 2 of 2');
            }
            else{
                component.set('v.actionName','Select accounts for bulk creation');
                component.set('v.instruction','Step 1 of 2');	
            } 
            
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling AccountSelectionController->init Function@@@@' + e);
        }
    },
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is call to load JQUERY Datatable.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    afterScriptLoaded: function (component, event, helper) {
        try{
            setTimeout(function(){
                jQuery('#tableId').DataTable({
                    bDestroy: true,
                    stateSave: true
                });
            }, 100);
            
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling AccountSelectionController->afterScriptLoaded Function@@@@' + e);
        }
    },
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to handle oSelectedRecordEvent event.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    handleComponentEvent: function (component, event, helper) {
        try {   
            var listSelectedItems = component.get("v.lstSelectedRecords");
            var selectedAccountGetFromEvent = event.getParam("recordByEvent");
            
            listSelectedItems.push(selectedAccountGetFromEvent);
            component.set("v.lstSelectedRecords", listSelectedItems);
            component.set("v.spinner", false);
            helper.handlePagination(component);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling AccountSelectionController->handleComponentEvent@@@@' + e);
        }
    },
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to handle DeleteRowEvt event.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    updatePill: function (component, event, helper) {
        try {
            
            var itemIdForDeletion =event.getParam("indexVar"); 
            component.set('v.confirmPopupMsg','Are you sure you want to delete selected account?');
            component.set('v.showConfirmDialog', true);
            component.set('v.deleteFlag', true);
            component.set('v.itemIdForDeletion', itemIdForDeletion);
            
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling AccountSelectionController->updatePill Function@@@@' + e);
        }
    },
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to display confirm dialog.
	 * @params      : component, event, heplper
	 * @return      : NA
	 */
    handleConfirmDialog: function (component, event, helper) {
        try{
            var direction = event.getSource().get("v.label");
            component.set('v.confirmActionType',direction);
            if(direction=='Reset'){
                component.set('v.confirmPopupMsg','Are you sure you want to remove all the selected account?');
                component.set('v.showConfirmDialog', true);
            }
            else{
                var action = component.get('c.handleNextConfirmDialog');
                $A.enqueueAction(action);	
            } 
        }
        catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling AccountSelectionController->handleConfirmDialog Function@@@@' + e);
        }
    },
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to handle confirm dialog Yes Button.
	 * @params      : component, event, heplper
	 * @return      : NA
	 */
    handleConfirmDialogYes: function (component, event, helper) {
        try{
            component.set('v.showConfirmDialog', false);
            if(component.get('v.deleteFlag')){
                helper.updatePillVal(component, event,helper);
            }
            else{
                var actionType= component.get('v.confirmActionType');
                if(actionType=='Reset'){
                    location.reload();
                }
                else{
                    var action = component.get('c.handleNextConfirmDialogYes');
                    $A.enqueueAction(action);
                }
            }
        }
        catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling AccountSelectionController->handleConfirmDialogYes Function@@@@' + e);
        }
    },
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to handle confirm dialog No Button.
	 * @params      : component, event, heplper
	 * @return      : NA
	 */
    handleConfirmDialogNo: function (component, event, helper) {
        try{
            component.set('v.showConfirmDialog', false);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling AccountSelectionController->handleConfirmDialogNo Function@@@@' + e);
        }
    },
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to display Next confirm dialog.
	 * @params      : component, event, heplper
	 * @return      : NA
	 */
    handleNextConfirmDialog: function (component, event, helper) {
        try {
            var accountList = component.get("v.selectedRecordAdditionalToVar");
            if (accountList.length > 500) {
                helper.showError(component, event, helper, 'Please select records less than or equal to 500');
            } else {	
                component.set('v.confirmPopupMsg','Are you sure you want to create cases for selected accounts');
                component.set('v.showConfirmDialog', true);
            }
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling AccountSelectionController->handleNextConfirmDialog Function@@@@' + e);
        }
    },
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to handle confirm dialog Yes Button.
	 * @params      : component, event, heplper
	 * @return      : NA
	 */
    handleNextConfirmDialogYes: function (component, event, helper) {
        try {
            component.set("v.spinner", true);
            if (component.get('v.bulkcloning') != undefined) {
                helper.handleCloning(component, event, helper);
            } else {
                helper.validate(component, event, helper);
            }
            component.set("v.spinner", false);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling AccountSelectionController->handleNextConfirmDialogYes Function@@@@' + e);
        }
    }, 
    /*
	 * @author      : Corforge
	 * @date        : 01/04/2021
	 * @description : This function is used to handle Sorting on the basis of AccountName.
	 * @params      : component, event, heplper
	 * @return      : NA
	 */
    sortByName: function (component, event, helper) {
        component.set("v.selectedTabsoft", 'AccountName');
        helper.sortData(component, "Name");
    },
    /*
	 * @author      : Corforge
	 * @date        : 01/04/2021
	 * @description : This function is used to handle Sorting on the basis of CFN.
	 * @params      : component, event, heplper
	 * @return      : NA
	 */
    sortByCFN: function (component, event, helper) {
        component.set("v.selectedTabsoft", 'CFN');
        helper.sortData(component, "Customer_Reference_Number__c");
    },
    /*
	 * @author      : Corforge
	 * @date        : 01/04/2021
	 * @description : This function is used to redirect to home page.
	 * @params      : component, event, heplper
	 * @return      : NA
	 */
    redirectToHome: function(component, event, helper){
        component.set("v.showBulkInfo",false);
        location.href = '/lightning/page/home';
    }
})