/*********************************************************************
# File....................: FilterCasesForBulkCloningController
# Version.................: 1.0
# Created by..............: Coforge Technologies
# Created Date............: 31/05/2021
# Last Modified by........: 
# Last Modified Date......: 
# Description.............: This is a JS Controller of 'FilterCasesForBulkCloning' Lightning component .   
# VF Page.................: NA
# VF Component............: NA
# Lightning Component.....: FilterCasesForBulkCloning
# Test Class..............: NA
# Change Log..............: v1.0 Initial Version 
**********************************************************************/
({
    /*
	* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function call to load component.
	* @params      : component, event, helper
	* @return      : NA
	*/
    init: function (cmp, event, helper) {
        try{
            let nextbutton = cmp.find('nextButtonId');
            let noOfCaseVar = cmp.find('noOfCases');
            let filerButton = cmp.find('filterButtonId');
            cmp.set('v.spinner', true);
            cmp.set('v.displayDataTable', false);
            filerButton.set('v.disabled',true);
            nextbutton.set('v.disabled',true);
            noOfCaseVar.set('v.disabled',true);
            helper.getRecordTypeId(cmp, event, helper);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkCloningController->init Function@@@@' + e);
        }
    },
    /*
	* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function call to refresh the table when data changes.
	* @params      : component, event, helper
	* @return      : NA
	*/
    refreshTable: function(component, event, helper){
        try{
            helper.scriptsLoaded(component, event, helper);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkCloningController->tableClear Function@@@@' + e);
        }
    },
    
    /*
	* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function is used to Checked/Unchecked all checbox.
	* @params      : component, event, heplper
	* @return      : NA
	*/
    checkAll: function (component, event, helper) {
        try{
            helper.checkAll(component, event, helper);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkCloningController->checkAll Function@@@@' + e);
        }
    },
    
    /*
	* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function call to change filter option.
	* @params      : component, event, helper
	* @return      : NA
	*/
    changeFilter: function(cmp, event, helper){
        try{
            helper.changeFilter(cmp);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkCloningController->changeFilter Function@@@@' + e);
        }
    },
    
    /*
	* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function call to get records after filtering data.
	* @params      : component, event, helper
	* @return      : NA
	*/
    filterRecords: function(cmp, event, helper){
        try{
            helper.filterRecords(cmp);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkCloningController->filterRecords Function@@@@' + e);
        }
    },
    
    /*
	* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function is used to add the case record id when its selected, if its deselect then remove.
	* @params      : component, event, heplper
	* @return      : NA
	*/    
    addSelectedCaseID:function(component, event, helper){
        try{
            helper.addSelectedCaseId(component, event, helper);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkCloningController->addSelectedCaseID Function@@@@' + e);
        }
    },
    
    /*
	* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function is used to display Next confirm dialog.
	* @params      : component, event, heplper
	* @return      : NA
	*/    
    handleNextConfirmDialog: function (component, event, helper) {
        try{
            var direction = event.getSource().get("v.label");
            component.set('v.confirmActionType',direction);
            if(direction=='Reset'){
                component.set('v.confirmationMsg','Are you sure you want to remove all the selected case and clear all the filters?');
                component.set('v.showConfirmDialogNext', true);
            }
            else{
                helper.validate(component, event, helper);
            } 
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkCloningController->handleNextConfirmDialog Function@@@@' + e);
        }
    },
    
    /*
	* @author      : Corforge
	* @date        : 31/05/2021
	* @description : This function is used to handle confirm dialog Yes Button.
	* @params      : component, event, heplper
	* @return      : NA
	*/
    handleNextConfirmDialogYes: function (component, event, helper) {
        try{
            var typeVal=component.get('v.confirmActionType');
            if(typeVal=='Reset'){
                component.set('v.showConfirmDialogNext', false);
                location.reload();
            }
            else{
                component.set('v.showConfirmDialogNext', false);
                component.set("v.spinner", true);
                helper.confirmation(component, event, helper);
            } 
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkCloningController->handleNextConfirmDialogYes Function@@@@' + e);
        }
    },
    
    /*
	* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function is used to handle confirm dialog No Button.
	* @params      : component, event, heplper
	* @return      : NA
	*/
    handleNextConfirmDialogNo: function (component, event, helper) {
        try{
            component.set('v.showConfirmDialogNext', false);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkCloningController->handleNextConfirmDialogNo Function@@@@' + e);
        }
    },
    /*
	* @author      : Coforge
	* @date        : 31/05/2021
	* @description : This function is call on load .
	* @params      : component, event, helper
	* @return      : NA
	*/
    handleLoad: function(component, event, helper) {
        try {  
            component.set('v.spinner', false);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkCloningController->handleLoad Function@@@@' + e);
        }
    },    
    
    /*
	* @author      : Corforge
	* @date        : 31/05/2021
	* @description : This function is used to Navigate to Case and Account records.
	* @params      : component, event, heplper
	* @return      : NA
	*/
    navigateToRecord: function(component, event, helper){
        try{
            var recordId = event.target.id;
            var navEvt = $A.get("e.force:navigateToSObject");
            navEvt.setParams({
                "recordId": recordId,
                "slideDevName": "detail"  
            });
            window.open('/' + navEvt.getParam('recordId'));
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkCloningController->navigateToRecord Function@@@@' + e);
        }
    },
    
    /*
	* @author      : Corforge
	* @date        : 31/05/2021
	* @description : This function is used to redirect the page after user confirmation.
	* @params      : component, event, heplper
	* @return      : NA
	*/
    redirectToHome: function(component, event, helper){
        try{
            component.set("v.showBulkCloneInfo",false);
            location.href = '/lightning/page/home';
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkCloningController->redirectToHome Function@@@@' + e);
        }
    }
})