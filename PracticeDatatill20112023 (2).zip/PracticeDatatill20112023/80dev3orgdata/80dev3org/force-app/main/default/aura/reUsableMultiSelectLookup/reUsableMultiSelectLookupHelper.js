/*********************************************************************
# File....................: reUsableMultiSelectLookup
# Version.................: 1.0
# Created by..............: NIIT Technologies
# Created Date............: 17/12/2019
# Last Modified by........: NIIT Technologies
# Last Modified Date......: 11/06/2021
# Description.............: This is a JS helper of 'reUsableMultiSelectLookup'Lightning component. .   
# VF Page.................: NA
# VF Component............: NA
# Lightning Component.....: reUsableMultiSelectLookup
# Test Class..............: NA
# Change Log..............: v1.0 Initial Version 
# Change Log..............: v1.1  11/06/2021 - Fix for W-002142
**********************************************************************/
({
    searchHelper : function(component,event,getInputkeyWord) {
        try{
            // call the apex class method 
            var action = component.get("c.fetchLookUpValues");
            // Start Fix for W-002141
            var limitVal=5;
            if(!component.get("v.pillSectionFlag"))
             {
                   limitVal= 20;         
             }
            // End Fix for W-002141
            // set param to method  
            
            action.setParams({
                'searchKeyWord': getInputkeyWord,
                'ObjectName' : component.get("v.objectAPIName"),
                'ExcludeitemsList' : component.get("v.lstSelectedRecords"),
                'limitVal' : limitVal // Fix for W-002141
            });
            
            //Start Fix for W-002141 
            var data=component.get("v.lstSelectedRecords") ;
            var isDataExist=false;
            data.forEach((row) => 
           {  
					if(row.Name==getInputkeyWord ||row.Customer_Reference_Number__c==getInputkeyWord)
                    {
                              isDataExist=true;
                    }
             })
            // End Fix for W-002141 
           // set a callBack 
            action.setCallback(this, function(response) {
                $A.util.removeClass(component.find("mySpinner"), "slds-show");
                var state = response.getState();
                if (state === "SUCCESS") {
                    var storeResponse = response.getReturnValue();
                    // if storeResponse size is equal 0 ,display No Records Found... message on screen.                }
                    console.log('storeResponse '+storeResponse);
                    if (storeResponse.length == 0) {
                        component.set("v.Message", 'No Records Found...');
                    } else {
                        component.set("v.Message", '');
                        // set searchResult list with return value from server.
                    }
                     //Start code for W-002141 
                    if(storeResponse.length == 0 && isDataExist && !component.get("v.pillSectionFlag"))
                    {
                        component.set("v.Message", 'Account is already added');                      
                    }
                    //End code for W-002141 
                    component.set("v.listOfSearchRecords", storeResponse); 
                }
            });
            // enqueue the Action  
            $A.enqueueAction(action);
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling DOINIT Function@@@@' + e);
        }
    },
})