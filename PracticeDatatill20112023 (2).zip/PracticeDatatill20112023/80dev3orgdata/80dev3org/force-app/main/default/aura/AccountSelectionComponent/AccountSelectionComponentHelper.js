/*********************************************************************
# File....................: AccountSelectionComponentHelper
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............: 31/05/2021
# Last Modified by........: 
# Last Modified Date......:  
# Description.............: This is a JS helper of 'AccountSelectionComponent'Lightning component.   
# VF Page.................: NA
# VF Component............: NA
# L Comp..................: AccountSelectionComponent
# Test Class..............: NA
# Change Log..............: Initial Version, 1.0
**********************************************************************/
({
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to add new account record.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    addAccountRecord: function (component, event) {
        try {
            //get the account List from component  
            var accountList = component.get("v.accountList");
            //Add New Account Record
            accountList.push({
                'sobjectType': 'Account',
                'Name': '',
                'AccountNumber': '',
                'Phone': ''
            });
            component.set("v.accountList", accountList);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling AccountSelectionComponentHelper->addAccountRecord Function@@@@' + e);
        }
    },
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to Handle Cloning.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    handleCloning: function (component, event, helper) {
        try {
            var accountList = component.get("v.selectedRecordAdditionalToVar");
            let accIds = [];
            for (var i = 0; i < accountList.length; i++) {
                accIds.push(accountList[i].Id);
            }
            var caseObj = component.get('v.caseObjVar');
            var cloneMultipleRecords = component.get("c.cloneMultipleRecords");
            cloneMultipleRecords.setParams({
                "caseListClsObj": caseObj,
                "noOfCloneCasesClsObj": 1,
                "cloningTypeClsObj":$A.get("$Label.c.BulkCloningMultipleAccount"),                
                "accList": accIds
            });
            cloneMultipleRecords.setCallback(this, function (response) {
                var state = response.getState();
                if (component.isValid() && (state === 'SUCCESS' || state === 'DRAFT')) {
                    component.set('v.showSuccessMessage','Bulk cloning process has been initiated successfully, you will receive an email once the transaction is completed');
                    component.set("v.showBulkInfo",true);
                } else if (state === 'INCOMPLETE') {
                    this.showError(component, event, helper, response.getError());
                    console.log('Error==' + JSON.stringify(response.getError()));
                } else if (state === 'ERROR') {
                    this.showError(component, event, helper, response.getError());
                    console.log('Error==' + response.getError());
                } else {
                    this.showError(component, event, helper, response.getError());
                    console.log('Unknown error while making DML ' + response.getError());
                }
            });
            $A.enqueueAction(cloneMultipleRecords);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in AccountSelectionComponentHelper handleCloning Function@@@@' + e);
        }
    },
    
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to Handle Error message.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    showError: function (component, event, helper, errorMsg) {
        try {
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title: 'Error',
                message: errorMsg,
                duration: '20000',
                key: 'info_alt',
                type: 'error',
                mode: 'dismissible'
            });
            toastEvent.fire();
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in AccountSelectionComponentHelper showError Function@@@@' + e);
        }
    },
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to validate.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    validate: function (component, event, helper) {
        try {			
            var accountList = component.get("v.selectedRecordAdditionalToVar");
            console.log('accountList++++++++'+accountList);
            var evt = $A.get("e.force:navigateToComponent");
            evt.setParams({
                componentDef: "c:DynamicCaseLayoutComponent", 
                componentAttributes: {
                    "actionName": "insert",
                    "accountArray": accountList 
                }
            });
            evt.fire();
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling AccountSelectionComponentHelper ->validate @@@@' + e);
        }
    },
    /*
	 * @author      : Coforge
	 * @date        : 31/05/2021
	 * @description : This function is used to handle DeleteRowEvt event.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    updatePillVal: function (component, event, helper) {
        try {
            var index = component.get("v.itemIdForDeletion");
            var allPillsList = component.get("v.lstSelectedRecords");
            for (var i = 0; i < allPillsList.length; i++) {
                var obj = allPillsList[i];
                if (index==obj.Id) {
                    allPillsList.splice(i, 1);
                }
            }
            component.set("v.lstSelectedRecords", allPillsList);
            component.set("v.selectedRecordAdditionalToVar", allPillsList);
            component.set('v.deleteFlag',false);
            helper.handlePagination(component);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling AccountSelectionComponentHelper->updatePill Function@@@@' + e);
        }
    },
    /*
	 * @author      : Corforge
	 * @date        : 01/04/2021
	 * @description : This function is used to call pagination .
	 * @params      : component, event, heplper
	 * @return      : NA
	 */
    handlePagination: function (component, event, helper) {
        try{
            var paginationcmp = component.find('pagination');
            if (typeof paginationcmp !== "undefined") {
                paginationcmp.callChild();
            }
            
        }
        catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in handlePagination Function@@@@' + e);
        }
    },
    /*
	 * @author      : Corforge
	 * @date        : 01/04/2021
	 * @description : This function is used to Handle sorting.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    sortData: function (component, fieldName) {
        try {
            var data = component.get("v.lstSelectedRecords");
            var sortDirection;
            var currentDir = component.get("v.arrowDirection");
            if (currentDir == 'arrowdown') {
                // set the arrowDirection attribute for conditionally rendred arrow sign  
                component.set("v.arrowDirection", 'arrowup');
                // set the isAsc flag to true for sort in Assending order.  
                component.set("v.isAsc", true);
                sortDirection = 'asc';
            } else {
                component.set("v.arrowDirection", 'arrowdown');
                component.set("v.isAsc", false);
                sortDirection = 'dsc';
            }
            var reverse = sortDirection !== 'asc';
            data.sort(this.sortBy(fieldName, reverse))
            component.set("v.lstSelectedRecords", data);
            var paginationcmp = component.find('pagination');
            if (typeof paginationcmp !== "undefined") {
                paginationcmp.callChild();
            }
            
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling AccountSelectionComponentHelper->sortData Function@@@@' + e);
        }
        
    },
    /*
	 * @author      : Corforge
	 * @date        : 01/04/2021
	 * @description : This function is used to Handle sorting.
	 * @params      : component, event, helper
	 * @return      : NA
	 */
    sortBy: function (field, reverse, primer) {
        var key = primer ?
            function (x) {
                return primer(x[field])
            } :
        function (x) {
            return x[field]
        };
        reverse = !reverse ? 1 : -1;
        return function (a, b) {
            return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
        }
    },
    
})