/*********************************************************************
# File....................: CustomReportsController
# Version.................: 1.0
# Created by..............: Coforge Technologies
# Created Date............: 16/06/2021
# Last Modified by........: 
# Last Modified Date......: 
# Description.............: This is a Controller of CustomReports 
# VF Page.................: NA
# VF Component............: NA
# Lightning Component.....: CustomReports
# Test Class..............: NA
# Change Log..............: v1.0 Initial Version 
**********************************************************************/
({  
    linkHandler:function(component, event, helper){
        var nagivatetoChildComponent;
        var reportId = event.currentTarget.id;
        if(reportId == 'metadataReportId'){
        	 nagivatetoChildComponent='c:MetadataTagFileReport';  
        }
        if(reportId == 'historyTrackingReportId'){
        	 nagivatetoChildComponent='c:historyTracking';  
        }        
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef: nagivatetoChildComponent
        });
        evt.fire();       
    }   
})