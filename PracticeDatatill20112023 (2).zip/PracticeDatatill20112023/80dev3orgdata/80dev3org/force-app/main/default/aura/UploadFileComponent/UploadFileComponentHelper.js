/*********************************************************************
# File....................: UploadFileComponentHelper
# Version.................: 1.0
# Created by..............: NIIT
# Created Date............: 12/08/2020 
# Last Modified by........: NIIT
# Last Modified Date......: 12/08/2020
# Description.............: This JS Controller used to call 'getNumberOfAttachedFile' function of 
                            apex controller 'FileUploadController'.   
# VF Page.................: NA
# VF Component............: NA
# L Comp..................: UploadFileComponent
# Test Class..............: NA
# Change Log..............: Intitial Version, 1.0
**********************************************************************/
({
    /**
    * @author      : NIIT
    * @date        : 12/08/2020
    * @description : This method calls 'getNumberOfAttachedFile' function of apex controller 
                     'FileUploadController' to count the no of attached files and set renderedComponent attribute of lightning component.
    * @return      : Void
    */
    getNumOfFiles : function(component,event) {
        try{
            var action = component.get("c.getNumberOfAttachedFile");  //used to call 'getNumberOfAttachedFile' function of apex controller.
            action.setParams({
                "recordId":component.get("v.recordId")
            });     
            action.setCallback(this,function(response){
                var state = response.getState();
                if(state == 'SUCCESS'){
                    var res = response.getReturnValue();
                    var sObjectName = res[0];   
                    var countOfFiles = res[1]; 
                    if(res.length > 2){                     
                        component.set("v.pageName",res[2]);
                    	component.set("v.multiple",(res[3].toUpperCase() === 'TRUE'));
                    }                                                         
                    //Fire toast event in case of any file attached on record
                    if(countOfFiles > 0){
                        var toastEvent = $A.get("e.force:showToast");   // used to get 'toast event'
                        toastEvent.setParams({
                            title : 'Error',
                            message: 'You can have only one attachment. Please delete the existing attachment and then attach a new one.',
                            type: 'error',
                            mode: 'dismissible',
                            duration: '500'
                        });
                        toastEvent.fire(); 
                        $A.get("e.force:closeQuickAction").fire();
                    }
                    //set 'renderedComponent' attributes values in case of no file attached to current record
                    else{
                        component.set("v.renderedComponent",true);  
                    }
                }
            });
            $A.enqueueAction(action);
        }catch(e){
            alert($A.get("{!$Label.c.MID_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling getNumOFFiles@@@@' + e);
        }
    }
})