/*********************************************************************
# File....................: DynamicCaseLayoutComponentController
# Version.................: 1.0
# Created by..............: Coforge
# Created Date............: 31/05/2021
# Last Modified by........: 
# Last Modified Date......:  
# Description.............: This is a JS Controller of 'DynamicCaseLayoutComponent'Lightning component.   
# VF Page.................: NA
# VF Component............: NA
# L Comp..................: DynamicCaseLayoutComponent
# Test Class..............: NA
# Change Log..............: Initial Version, 1.0
**********************************************************************/
({
    /*
     * @author      : Coforge
     * @date        : 31/05/2021
     * @description : This function is call intially to fetch fields from meta data.
     * @params      : component, event, helper
     * @return      : NA
     */
    doInit: function(cmp, event, helper) {
        try {
            cmp.set('v.spinner', true);
            if (cmp.get("v.actionName") != 'Update') {
                cmp.set('v.heading','New Case: IRMS');
            } 
            else {
                console.log('@@@@in edit case in do init of dynamic case layout@@@@@@@@');
                cmp.set('v.heading','Edit Case');
                var recordlist=cmp.get('v.caseArray');
                cmp.set('v.recordId',recordlist[0]);
            }
            cmp.set('v.isOpen',true);
            helper.getSectionsAndFields(cmp, event, helper);
            helper.getRecordType(cmp, event, helper);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling doInit Function in DynamicCaseLayoutComponentController @@@@' + e);
        }
    },
   
    
    /*
     * @author      : Coforge
     * @date        : 31/05/2021
     * @description : This function is call to handle the form sumit  .
     * @params      : component, event, helper
     * @return      : NA
     */
    handleSubmit: function(component, event, helper) {
        try {
            component.set('v.isButtonActive',true);
            component.set('v.spinner', true);
            event.preventDefault(); 
            var dataVal = component.find("formFieldToValidate");
            var fields = component.get("v.metadataObj");
            
            var errorFlag=false;
            fields.forEach(function (field) {
                var rowData=field.Fields;
                rowData.forEach(function (t){
                    dataVal.forEach(function (dataField) {
                        if(t.Required__c && dataField.get('v.fieldName')=== t.Label && (dataField.get('v.value')==undefined||dataField.get('v.value')=='')){
                            $A.util.addClass(dataField, 'highlight');
                            dataField.focus();
                            errorFlag=true;
                        }
                    });          
                });
            });
            
            component.set('v.spinner', false);
            
            if(errorFlag && component.get("v.actionName") != 'Update'){
                component.set('v.isButtonActive',false);
            }
            
            if(!errorFlag && component.get("v.actionName") != 'Update'){
                component.find('myform').submit(); 
            }
            else if(component.get("v.actionName") == 'Update'){
                helper.doUpdateCase(component, event, helper,event.getParams('detail').fields);

            }
            
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling handleSubmit Function in DynamicCaseLayoutComponentController@@@@' + e);
        }
    },
    /*
     * @author      : Coforge
     * @date        : 31/05/2021
     * @description : This function is call to handle the Success after form submition  .
     * @params      : component, event, helper
     * @return      : NA
     */
    handleSuccess: function(component, event, helper) {
        try {
            var payload = event.getParams().response;
            component.set('v.spinner', false);
            if (component.get("v.actionName") != 'Update') {
                helper.onUpsertObject(component, event, helper, payload.id);
            } 
				  
															  
			 
            
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling handleSuccess Function in DynamicCaseLayoutComponentController@@@ ' + e);
        }
        
    },
    
    /*
     * @author      : Coforge
     * @date        : 31/05/2021
     * @description : This function is call to handle the Error on page .
     * @params      : component, event, helper
     * @return      : NA
     */
    handleOnError: function(cmp, event, helper,errorMesssage) {
        try{
            cmp.set('v.isButtonActive',false);
            cmp.set('v.spinner', false);
            var errorFlag=false;
            var errormessg;
            if(errorMesssage!=null){
                errormessg=errorMesssage;
            }
            else if(event!=undefined){
                var obj = JSON.parse(JSON.stringify(event.getParams()));
                var fielderror=obj["error"]["body"]["output"]["fieldErrors"];
                if(fielderror != null && fielderror != undefined){
                    for(var k in fielderror) {  
                        if((fielderror[k][0]["field"]=='Final_Request_Sent__c' || fielderror[k][0]["field"]=='Draft_Question_Sent__c') && cmp.get("v.actionName") != 'Update'){
                            errorFlag=true;
                            helper.showError(cmp, event, helper,'This status is not valid for a bulk process, please select another status');
                        }  
                    }
                }
                var toperror=obj["error"]["body"]["output"];
                if(toperror != null && toperror != undefined){
                    for(var k in toperror){  
                        if(toperror[k][0]!=undefined){    
                            errorFlag=true;
                            errormessg= toperror[k][0]["message"];
                            helper.showError(cmp, event, helper,errormessg);
                        }
                    }
                }
            }
            if(!errorFlag){
                helper.showError(cmp, event, helper,"Review the errors on this page");
            }
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling handleOnError Function in DynamicCaseLayoutComponentController@@@ ' + e);
        }
    },
    /*
     * @author      : Coforge
     * @date        : 31/05/2021
     * @description : This function is call to handle the Confirm popup  .
     * @params      : component, event, helper
     * @return      : NA
     */
    handleConfirmDialog: function(component, event, helper) {
        try{
            component.set('v.showConfirmDialog', true);
            var direction = event.getSource().get("v.label");
            component.set('v.confirmActionType',direction);
            if(direction=='Cancel'){
                component.set('v.confirmPopupMsg', 'Are you sure you want to cancel this item?');
            }
            else if(direction=='Previous'){
                component.set('v.confirmPopupMsg', 'Are you sure you want to go back?');
            }
                else if(direction=='Save'){
                    component.set('v.confirmPopupMsg', 'Are you sure you want to save?');
                }
                    else{
                        component.set('v.confirmPopupMsg', 'Are you sure you want to close?');
                    }
        } 
        catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling handleConfirmDialog Function in DynamicCaseLayoutComponentController@@@ '  + e);
        }
    },
    
    /*
     * @author      : Coforge
     * @date        : 31/05/2021
     * @description : This function is call to handle the Confirm popup  .
     * @params      : component, event, helper
     * @return      : NA
     */
    handleClose: function(component, event, helper) {
        try {  
            component.set('v.isOpen', false);
        }
        catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling handleClose Function in DynamicCaseLayoutComponentController@@@ ' + e);
        }
    },
    
    /*
     * @author      : Coforge
     * @date        : 31/05/2021
     * @description : This function is call when user click on Yes button of  Confirm popup  .
     * @params      : component, event, helper
     * @return      : NA
     */
    handleConfirmDialogYes: function(component, event, helper) {
        try {  
            component.set('v.showConfirmDialog', false);
            var actionType=component.get('v.confirmActionType');
            if (actionType=='Previous'){
                helper.handlePrevious(component, event, helper);
            }
            else if(actionType=='Save'){
                var action = component.get('c.handleSubmit');
                $A.enqueueAction(action);
            }
                else{
                    var navigateVal='c:FilterCasesForBulkUpdate';
                    if (component.get("v.actionName")!= 'Update') {
                        navigateVal='c:AccountSelectionComponent';
                    }
                    var evt = $A.get("e.force:navigateToComponent");
                    evt.setParams({
                        componentDef: navigateVal,//"c:AccountSelectionComponent",    
                    });
                    evt.fire();
                }
        }
        catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling handleConfirmDialogYes Function in DynamicCaseLayoutComponentController@@@ ' + e);
        }
    },
    
    /*
     * @author      : Coforge
     * @date        : 31/05/2021
     * @description : This function is call when user click on No button of Confirm popup  .
     * @params      : component, event, helper
     * @return      : NA
     */
    handleConfirmDialogNo: function(component, event, helper) {
        try {  
            component.set('v.showConfirmDialog', false);
        }
        catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling handleConfirmDialogNo Function in DynamicCaseLayoutComponentController@@@ ' + e);
        }
    },
    
    /*
     * @author      : Coforge
     * @date        : 31/05/2021
     * @description : This function is call on load .
     * @params      : component, event, helper
     * @return      : NA
     */
    handleLoad: function(component, event, helper) {
        try { 
            component.find('formFieldToValidate').forEach(function(f) {
                if(f.get('v.value')===undefined)
                {
                    f.set('v.value','');  
                }
                if(f.get('v.value')=='false'){
                    f.set('v.value',false); 
                }
            }); 
            component.set('v.spinner', false);
        }
        catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling handleLoad Function in DynamicCaseLayoutComponentController@@@ ' + e);
        }
    },
    /*
     * @author      : Coforge
     * @date        : 31/05/2021
     * @description : This function is call to redirect to home page .
     * @params      : component, event, helper
     * @return      : NA
     */
    redirectToHome: function(component, event, helper){
        component.set("v.showBulkInfo",false);
        location.href = '/lightning/page/home';
    },
    /*
     * @author      : Coforge
     * @date        : 22/06/2021
     * @description : This function is call to highlight mandatory fields .
     * @params      : component, event, helper
     * @return      : NA
     */
    toggleClass : function(component, event, helper){
        let sourceField = event.getSource();
        if($A.util.hasClass(sourceField,'highlight')){
            $A.util.toggleClass(sourceField,'highlight');
        }
    }
})