({
    /*
    * @author      : NIIT
    * @date        : 03/01/2020
    * @description : This function will call on click of Send Button to send an email and setting parameter which is required to call this method.
    * @params      : component
    * @return      : NA
    */
    sendHelper: function (component)
    {         
        try{
            component.set("v.spinner", true);
            // call the server side controller method 	
            var action = component.get("c.sendMailMethod");
            // set the params to sendMailMethod method   
            action.setParams({
                'emailWrapper' : component.get("v.emailWrapperVar"),
                'accObj': component.get("v.toAddressVar"),
                'selectedRecordAdditionalTols': component.get("v.selectedRecordAdditionalToVar"),
                'selectedRecordCCls': component.get("v.selectedRecordCCVar"),
                'selectedRecordBCCls': component.get("v.selectedRecordBCCVar"),
                'fromAddress': component.get("v.fromAddressVar")
            });
            action.setCallback(this, function (response) {
                var state = response.getState();
                if (state === "SUCCESS"){
                    var storeResponse = response.getReturnValue();
                    console.log('@@storeResponse@@ ' + storeResponse);
                    // if state of server response is comes "SUCCESS",
                    // display the success message box by set mailStatus attribute to true            }
                    if(storeResponse == 'SUCCESS'){                  
                        component.set("v.mailStatus", true);
                    }else if(storeResponse == 'BLANK'){        
                        alert($A.get("{!$Label.c.Person_Email_Blank}"));
                    }else{
                        alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
                    }
                    component.set("v.spinner", false);          
                }
            });        
            $A.enqueueAction(action);    
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling sendHelper@@@@' + e);
        }
    },
    /*
    * @author      : NIIT
    * @date        : 03/01/2020
    * @description : This function is used to display email template at the time of On Load on page.
    * @params      : component
    * @return      : NA
    */
    onloadDisplayEmailTemplate : function (component) {
        try{    
            console.log('@@@component.get("v.toAddressVar")@@ '+ component.get("v.toAddressVar"));
            var actionGetEmailTemplateInfo = component.get("c.getEmailTemplate");                        
            actionGetEmailTemplateInfo.setParams({
                'templateNameC': component.get("v.templateNameVar"),
                'recordIdC': component.get("v.recordIdVar")
            });  
            actionGetEmailTemplateInfo.setCallback(this, function (response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    if (response.getReturnValue() != null && response.getReturnValue() != "" && response.getReturnValue() != undefined) {
                        component.set("v.emailWrapperVar", response.getReturnValue());
                    }
                }
            });
            $A.enqueueAction(actionGetEmailTemplateInfo);  
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling onloadDisplayEmailTemplate@@@@' + e);
        }
    },
    /*
    * @author      : NIIT
    * @date        : 03/01/2020
    * @description : This function is used to close the current page.
    * @params      : component
    * @return      : NA
    */
    fireEventToCallVf: function(component, event) {
        try{
            var myEvent = $A.get("e.c:lightningAppExternalEvent");
            myEvent.setParams({"data":"Coming From LC "});
            myEvent.fire();
        }catch(e){
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling fireEventToCallVf@@@@' + e);
        }
    }
})