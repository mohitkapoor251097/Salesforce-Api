({
    /*
    * @author      : NIIT
    * @date        : 09/09/2019
    * @description : On load method which shows list of Correspondence records and set the values in other attributes to show the pagination.
    * @params      : component, event, helper
    * @return      : NA
    */
	doInit: function(component, event, helper) {
        helper.doInitHelper(component, event);
    },
    
    /*
    * @author      : NIIT
    * @date        : 09/09/2019
    * @description : This is javaScript function for pagination
    * @params      : component, event, helper
    * @return      : NA
    */
    navigation: function(component, event, helper) {
        var sObjectList = component.get("v.listOfAllCorrespondance");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
        var whichBtn = event.getSource().get("v.name");
        // check if whichBtn value is 'next' then call 'next' helper method
        if (whichBtn == 'next') {
            component.set("v.currentPage", component.get("v.currentPage") + 1);
            helper.next(component, event, sObjectList, end, start, pageSize);
        }
        // check if whichBtn value is 'previous' then call 'previous' helper method
        else if (whichBtn == 'previous') {
            component.set("v.currentPage", component.get("v.currentPage") - 1);
            helper.previous(component, event, sObjectList, end, start, pageSize);
        }
    },
    
    /*
    * @author      : NIIT
    * @date        : 09/09/2019
    * @description : JavaScript function for selecting all records by clicking the checkbox on the header.
    * @params      : component, event, helper
    * @return      : NA
    */
    selectAllCheckbox: function(component, event, helper) {
        var selectedHeaderCheck = event.getSource().get("v.value");
        var updatedAllRecords = [];
        var updatedPaginationList = [];
        var listOfAllCorrespondance = component.get("v.listOfAllCorrespondance");
        var PaginationList = component.get("v.PaginationList");
        // play a for loop on all records list 
        for (var i = 0; i < listOfAllCorrespondance.length; i++) {
            // check if header checkbox is 'true' then update all checkbox with true and update selected records count
            // else update all records with false and set selectedCount with 0  
            if (selectedHeaderCheck == true) {
                listOfAllCorrespondance[i].isChecked = true;
                component.set("v.selectedCount", listOfAllCorrespondance.length);
            } else {
                listOfAllCorrespondance[i].isChecked = false;
                component.set("v.selectedCount", 0);
            }
            updatedAllRecords.push(listOfAllCorrespondance[i]);
        }
        // update the checkbox for 'PaginationList' based on header checbox 
        for (var i = 0; i < PaginationList.length; i++) {
            if (selectedHeaderCheck == true) {
                PaginationList[i].isChecked = true;
            } else {
                PaginationList[i].isChecked = false;
            }
            updatedPaginationList.push(PaginationList[i]);
        }
        component.set("v.listOfAllCorrespondance", updatedAllRecords);
        component.set("v.PaginationList", updatedPaginationList);
    },
    
    /*
    * @author      : NIIT
    * @date        : 09/09/2019
    * @description : Getting the count of selected records and set the header true if all checkboxes are selected.
    * @params      : component, event, helper
    * @return      : NA
    */
    checkboxSelect: function(component, event, helper) {
        // on each checkbox selection update the selected record count 
        var selectedRec = event.getSource().get("v.value");
        var getSelectedNumber = component.get("v.selectedCount");
        if (selectedRec == true) {
            getSelectedNumber++;
        } else {
            getSelectedNumber--;
            component.find("selectAllId").set("v.value", false);
        }
        component.set("v.selectedCount", getSelectedNumber);
        // if all checkboxes are checked then set header checkbox with true   
        if (getSelectedNumber == component.get("v.totalRecordsCount")) {
            component.find("selectAllId").set("v.value", true);
        }
    },
    
    /*
    * @author      : NIIT
    * @date        : 09/09/2019
    * @description : Get the list of records selected by the user. After gettting the list, downloading the attachments of seleced records.
    * @params      : component, event, helper
    * @return      : NA
    */
    getSelectedRecords: function(component, event, helper) {
        var allRecords = component.get("v.listOfAllCorrespondance");
        var selectedRecords = [];
        for (var i = 0; i < allRecords.length; i++) {
            if (allRecords[i].isChecked) {
                selectedRecords.push(allRecords[i].objCorrespodance.Id);
            }
        } 
        //Calling controller method which return the URL for downloading the attachments in zip format.       
        var actionDownload = component.get("c.downloadAttachment");        
        actionDownload.setParams({
            corresPondanceIDs: selectedRecords //Sending list of selected correspondence records to the controller method.
        });        
        
        actionDownload.setCallback(this, function(b){            
            var state = b.getState();
            if (state === "SUCCESS"){
               window.location.href = b.getReturnValue();                                
            }else{
                alert('There is some problem in downloading the attachments.');                
            }
        });
        $A.enqueueAction(actionDownload);
    },

    /*
    * @author      : NIIT
    * @date        : 09/09/2019
    * @description : Downloading the attachments in zip format.
    * @params      : component, event, helper
    * @return      : NA
    */
    NavigationRec : function(component, event, helper) {        
        window.open("/lightning/r/Satellite_Brific_Deadlines__c/" + component.get("v.parentRecordId") + "/view","_self");                  
    }
})