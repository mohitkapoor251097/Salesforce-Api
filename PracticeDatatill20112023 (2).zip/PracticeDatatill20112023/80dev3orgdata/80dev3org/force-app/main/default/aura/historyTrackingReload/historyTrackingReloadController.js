({
    show : function(component) {
        
        var recordId = component.get("v.recordId");
        var navEvt = $A.get("e.force:navigateToSObject");
       
        navEvt.setParams({
            "recordId": recordId,
            "slideDevName": "detail"
        });
        navEvt.fire();
    }
})