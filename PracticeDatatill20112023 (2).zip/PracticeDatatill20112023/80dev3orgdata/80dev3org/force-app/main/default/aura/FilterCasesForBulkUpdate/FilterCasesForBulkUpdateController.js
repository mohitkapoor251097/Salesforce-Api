/*********************************************************************
# File....................: FilterCasesForBulkUpdateController
# Version.................: 1.0
# Created by..............: Coforge Technologies
# Created Date............: 16/06/2021
# Last Modified by........: 
# Last Modified Date......: 
# Description.............: This is a JS Controller of 'FilterCasesForBulkupdate' Lightning component .   
# VF Page.................: NA
# VF Component............: NA
# Lightning Component.....: FilterCasesForBulkUpdate
# Test Class..............: NA
# Change Log..............: v1.0 Initial Version 
**********************************************************************/
({
    /*
	* @author      : Coforge
	* @date        : 16/06/2021
	* @description : This function call to load component.
	* @params      : component, event, helper
	* @return      : NA
	*/
    init: function (cmp, event, helper) {
        try{
            
            cmp.set('v.displayDataTable', false);
            let nextbutton = cmp.find('nextButtonId');
            nextbutton.set('v.disabled',true);
            let filterbutton = cmp.find('filterButtonId');
            filterbutton.set('v.disabled',true);
            
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkupdateController->init Function@@@@' + e);
        }
    },
    /*
	* @author      : Coforge
	* @date        : 16/06/2021
	* @description : This function call to refresh the table when data changes.
	* @params      : component, event, helper
	* @return      : NA
	*/
    refreshTable: function(component, event, helper){
        try{
            helper.scriptsLoaded(component, event, helper);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkupdateController->tableClear Function@@@@' + e);
        }
    },
    /*
	* @author      : Coforge
	* @date        : 16/06/2021
	* @description : This function is used to Checked/Unchecked all checbox.
	* @params      : component, event, heplper
	* @return      : NA
	*/
    checkAll: function (component, event, helper) {
        try{
            helper.checkAllRecords(component, event, helper);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkupdateController->checkAll Function@@@@' + e);
        }
    },
    /*
	* @author      : Coforge
	* @date        : 16/06/2021
	* @description : This function call to change filter option.
	* @params      : component, event, helper
	* @return      : NA
	*/
    changeFilter: function(cmp, event, helper){
        try{
            helper.changeFilter(cmp);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkupdateController->changeFilter Function@@@@' + e);
        }
    },
    
    /*
	* @author      : Coforge
	* @date        : 16/06/2021
	* @description : This function call to get records after filtering data.
	* @params      : component, event, helper
	* @return      : NA
	*/
    filterRecords: function(cmp, event, helper){
        try{
            helper.filterRecords(cmp);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkupdateController->filterRecords Function@@@@' + e);
        }
    },
    
    /*
	* @author      : Coforge
	* @date        : 16/06/2021
	* @description : This function is used to add the case record id when its selected, if its deselect then remove.
	* @params      : component, event, heplper
	* @return      : NA
	*/    
    addSelectedCaseID:function(component, event, helper){
        try{
            helper.addSelectedCaseID(component, event, helper);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkupdateController->addSelectedCaseID Function@@@@' + e);
        }
    },
    
    /*
	* @author      : Coforge
	* @date        : 16/06/2021
	* @description : This function is used to display Next confirm dialog.
	* @params      : component, event, heplper
	* @return      : NA
	*/    
    handleNextConfirmDialog: function (component, event, helper) {
        try{
            component.set("v.spinner", true);
            var direction = event.getSource().get("v.label");
            component.set('v.confirmActionType',direction);
            if(direction=='Reset'){
                component.set('v.confirmationMsg','Are you sure you want to remove all the selected case and clear all the filters?');
                component.set('v.showConfirmDialogNext', true);
            }
            else{
                var noOfCases = component.get("v.listOfSelectedRecords");	
                if(noOfCases.length > 500){
                    component.set("v.spinner", false); 
                    helper.showError(component, "Please select records less than 500");
                    
                }
                else
                {
                    component.set('v.confirmationMsg','Are you sure you want to update data for selected cases?');
                    component.set('v.showConfirmDialogNext', true);
                    component.set("v.spinner", false);
                }
                
            } 
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkupdateController->handleNextConfirmDialog Function@@@@' + e);
        }
    },
    
    /*
	* @author      : Corforge
	* @date        : 16/06/2021
	* @description : This function is used to handle confirm dialog Yes Button.
	* @params      : component, event, heplper
	* @return      : NA
	*/
    handleNextConfirmDialogYes: function (component, event, helper) {
        try{
            var typeVal=component.get('v.confirmActionType');
            if(typeVal=='Reset'){
                component.set('v.showConfirmDialogNext', false);
                location.reload();
            }
            else{
                component.set('v.showConfirmDialogNext', false);
                helper.next(component, event, helper);
            } 
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkupdateController->handleNextConfirmDialogYes Function@@@@' + e);
        }
    },
    
    /*
	* @author      : Coforge
	* @date        : 16/06/2021
	* @description : This function is used to handle confirm dialog No Button.
	* @params      : component, event, heplper
	* @return      : NA
	*/
    handleNextConfirmDialogNo: function (component, event, helper) {
        try{
            component.set('v.spinner',false);
            component.set('v.showConfirmDialogNext', false);
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkupdateController->handleNextConfirmDialogNo Function@@@@' + e);
        }
    },   
    
    /*
	* @author      : Corforge
	* @date        : 16/06/2021
	* @description : This function is used to Navigate to Case and Account records.
	* @params      : component, event, heplper
	* @return      : NA
	*/
    navigateToRecord: function(component, event, helper){
        try{
            var recordId = event.target.id;
            console.log('recordId:::'+recordId);
            var navEvt = $A.get("e.force:navigateToSObject");
            navEvt.setParams({
                "recordId": recordId,
                "slideDevName": "detail"  
            });
            window.open('/' + navEvt.getParam('recordId'));
        } catch (e) {
            alert($A.get("{!$Label.c.NMS_ContactAdminErrorMessage}"));
            console.log('@@@@Exception in calling FilterCasesForBulkupdateController->navigateToRecord Function@@@@' + e);
        }
    }, 
})