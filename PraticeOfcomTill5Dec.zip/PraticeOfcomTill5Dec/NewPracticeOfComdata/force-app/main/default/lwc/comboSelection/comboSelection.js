import { LightningElement,track } from 'lwc';

export default class ComboSelection extends LightningElement {
    @track value = '';
    @track showCalculator=false;
    @track showContact=false;
    @track showValue=false;
    @track hidebtn=false;
    spinnerStatus=false;
get options() {
    return [
             { label: 'Calculator', value: 'Calculator' },
             { label: 'Contact', value: 'Contact' }
             
           ];
}
handleReset(event){
    var operationRecieve = event.target.label;
    if(operationRecieve==='Reset'){
    console.log('enter');
    this.value='';
    this.showCalculator=false;
    this.showContact=false;
    this.showValue=false;
    this.hidebtn=false;
    
    }
}
handleChange(event) {
    this.value = event.detail.value;
    this.spinnerStatus=true;
    setTimeout(() => {
    switch (this.value) {
      case 'Calculator':
        this.spinnerStatus=false;
        this.showCalculator = true;
        this.showContact = false;
        break;
      case 'Contact':
        this.showCalculator = false;
        this.showContact = true;
        this.spinnerStatus=false;
        break;
      default:
        this.showCalculator = false;
        this.showContact = false;
        break;
    }

    this.showValue = true;
    this.hidebtn = true;
   
  }, 3000);
  }

}