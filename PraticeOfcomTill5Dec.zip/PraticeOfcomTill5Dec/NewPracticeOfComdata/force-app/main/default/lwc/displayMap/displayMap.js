import { LightningElement,api } from 'lwc';

export default class DisplayMap extends LightningElement {
 @api street;
 @api city;
 @api country;
 @api title;
 @api description;
 @api postalCode;
 @api state;
   get mapMarkers (){
    [
        {
            location: {
                City: this.city,
                Country: this.country,
                Street: this.street,
            },
            title: this.title,
            description:this.description
               
        },
    ];
}
get isMapLoaded(){
     if(this.street && this.country && this.city){
        return true;
     }
     else{
        return false;
     }
}
}