import { LightningElement, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
//getting the custom label
import DivideByZero from '@salesforce/label/c.DivideByZero';
import BothNumbers from '@salesforce/label/c.BothNumbers';
export default class SimpleCalculator extends LightningElement {
 
     //image for loading
     url="https://media.tenor.com/28DFFVtvNqYAAAAC/loading.gif"

    headertitle="simple calculator";
    @track num1; //store num1 value
    @track num2; //store num2 value
    @track result;  //store result
    @track operation; 
    @track loadCheck=false;
    @track check=false;
    onInputChangeHandler(event) {
        //In the code this[event.target.name] = event.target.value, event.target refers to the DOM element that triggered the event. event.target.name returns the name attribute of this element, which is set to either 'num1' or 'num2' in the lightning-input elements.
        //this[event.target.name] retrieves the value of the property on the component instance that has the same name as the name attribute of the element. In this case, it accesses the num1 or num2 properties based on whether the event was fired by the first or second input fields respectively.
        this[event.target.name] = event.target.value;
        console.log(this.num1);
        console.log(this.num2);
        /* if(event.target.name=="num1"){
            console.log(event.target.value);
            this.num1=parseInt(event.target.value);
         }
         else if(event.target.name=="num2"){
          console.log(event.target.value);
          this.num2=parseInt(event.target.value);
         }*/
    }

    //when any button is pressed
    handleOperation(event) {
        this.check=false;
        this.loadCheck=true;
        //&convert value into Float 
        this.num1 = parseFloat(this.num1);
        this.num2 = parseFloat(this.num2);
        //&geeting the label
        var operationRecieve = event.target.label;
       
        //~checking value is Empty or Not ?
        if (isNaN(this.num1)  || isNaN(this.num2)) {
            this.check=false;
            this.loadCheck=false;
            this.showErrorMessage(BothNumbers);
            return;
        }
          //~checking value is a Number
          setTimeout(()=>{
        if (!isNaN(this.num1) && !isNaN(this.num2)) {
           // var storeTempResult=0;
             //~checking Operation is Add then I perform Add Operation
             switch (operationRecieve) {
                case 'Add':
                    this.result = this.num1 + this.num2;
                    this.operation = operationRecieve;
                    this.check = true;
                    break;
                case 'Substract':
                    this.result = this.num1 - this.num2;
                    this.operation = operationRecieve;
                    this.check = true;
                    break;
                case 'Multiply':
                    this.result = this.num1 * this.num2;
                    this.operation = operationRecieve;
                    this.check = true;
                    break;
                case 'Divide':
                   if (this.num2 == 0) {
                    this.showErrorMessage(DivideByZero );
                    this.check = false;
                    this.loadCheck = false;
                    return;
                   }
                    this.result = this.num1 / this.num2;
                    this.operation = operationRecieve;
                    this.check = true;
                    break;
                case 'Reset':
                    this.num1 = '';
                    this.num2 = '';
                    this.check = false;
                    this.loadCheck = false;
                    break;
                default:
                    break;
            }
          /* if (operationRecieve === 'Add') {
                this.result = this.num1 + this.num2;
                this.operation = operationRecieve;
                this.check = true;
                console.log(this.result);
                console.log(operation);
            }
            else if (operationRecieve === 'Substract') {
                this.result = this.num1 - this.num2;
                this.operation = operationRecieve;
                this.check = true;
                console.log(this.result);
            }
            else if (operationRecieve === 'Multiply') {
                this.result = this.num1 * this.num2;
                this.operation = operationRecieve;
                this.check = true;
                console.log(this.result);
            }
            else if (operationRecieve === 'Divide') {
               if(this.num2==0){
                this.showErrorMessage(DivideByZero );
                this.check = false;
                this.loadCheck=false;
                return;
               }
                this.result = this.num1 / this.num2;
                this.operation = operationRecieve;
                this.check = true;
                console.log(this.result);
                
            }
            else if(operationRecieve === 'Reset'){
                this.num1='';
                this.num2='';
                this.check=false;
                this.loadCheck=false;
            }*/
           /* if (storeTempResult !== null && storeTempResult !== '' && storeTempResult !== undefined && !isNaN(storeTempResult)) {

                this.result = storeTempResult;

            }*/
        }
    },3000);
  
    }
    //^Showing the Toast Error Message 
    showErrorMessage(message) {
        const event = new ShowToastEvent({
            title: 'Error',
            message: message,
            variant: 'error',
        });
        this.dispatchEvent(event);
    }
    //&Geeting the title and display in html file
    get title(){
        return `${this.headertitle.toUpperCase()}`;
    }
}