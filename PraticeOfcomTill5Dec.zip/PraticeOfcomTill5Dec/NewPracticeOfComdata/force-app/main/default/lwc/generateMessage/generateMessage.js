import { LightningElement } from 'lwc';

export default class GenerateMessage extends LightningElement {
    firstName = "";
    lastName = "";
    changleHandler(event) {
        let { name, value } = event.target;
        if (name === 'fname') {
            this.firstName = value;
        }
        else if (name === 'lname') {
            this.lastName = value;
        }
    }

    clickHandler() {
        let fullName = `${this.firstName} ${this.lastName}`.toUpperCase();
        // 1 Create custom Event
        let myCustomEvent = new CustomEvent("message", {
            detail: {
                fullName: fullName
            }
        });

        //dispatch the event
        this.dispatchEvent(myCustomEvent);
    }
}