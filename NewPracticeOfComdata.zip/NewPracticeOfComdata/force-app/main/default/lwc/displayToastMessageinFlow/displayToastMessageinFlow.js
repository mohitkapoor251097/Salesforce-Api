import { LightningElement } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class DisplayToastMessageinFlow extends LightningElement {

    statusChangeHandler(event){
      if(event.detail.status==='FINISHED'){
        const event = new ShowToastEvent({
            title: 'Success!',
            message: 'Record Created Successfully!',
            variant:"Success"
            
        });
        this.dispatchEvent(event);
      }
    }
}