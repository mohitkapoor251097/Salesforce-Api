import { LightningElement,wire,api} from 'lwc';
import getParentAccount from '@salesforce/apex/AccountHelper.getParentAccount';
import { getObjectInfo, getPicklistValues } from 'lightning/uiObjectInfoApi';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import ACCOUNT_ID_FIELD from '@salesforce/schema/Account.Id';
import ACCOUNT_INDUSTRY_FIELD from '@salesforce/schema/Account.Industry';
import ACCOUNT_PARENT_FIELD from '@salesforce/schema/Account.ParentId';
import ACCOUNT_NAME_FIELD from '@salesforce/schema/Account.Name';
import ACCOUNT_NumberOfLocation_FIELD from '@salesforce/schema/Account.NumberOfEmployees';
import ACCOUNT_DESCRIPTION_FIELD from '@salesforce/schema/Account.Description';
import { createRecord, getFieldValue, getRecord,updateRecord,deleteRecord } from 'lightning/uiRecordApi';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
const fieldsToLoad=[ACCOUNT_INDUSTRY_FIELD,ACCOUNT_NAME_FIELD,ACCOUNT_NumberOfLocation_FIELD,ACCOUNT_PARENT_FIELD,ACCOUNT_DESCRIPTION_FIELD];

export default class UpdateRecord extends NavigationMixin(LightningElement) {
 
    

    parentoptions=[];
    selectedParentACc='';
    selectedAccName='';
    selectednoOfLocation="1";
    slsExpDate=null;
    selSlaType='';
    selDescription='';
    @api recordId;
    @wire(getRecord,{
        recordId: '$recordId',
        fields:fieldsToLoad
    })wiredgetRecord_Function({data,error}){    
          if(data){
            this.selectedParentACc=getFieldValue(data,ACCOUNT_PARENT_FIELD);
          this.selectedAccName=getFieldValue(data,ACCOUNT_NAME_FIELD);
          this.selSlaType=getFieldValue(data,ACCOUNT_INDUSTRY_FIELD);
          this.selectednoOfLocation=getFieldValue(data,ACCOUNT_NumberOfLocation_FIELD);
          this.selDescription=getFieldValue(data,ACCOUNT_DESCRIPTION_FIELD);
          }
          else if(error){
            console.log('error OUTPUT : ',error);
          }
    
    }

    @wire(getParentAccount) wire_getParentAccount({error,data}){
        this.parentoptions=[];
        if(data){
            this.parentoptions=data.map((curritem)=>({
                 label:curritem.Name,
                 value:curritem.Id
           }));
        }
        else if(error){
           console.log('OUTPUT : ',error);
        }
    }

   @wire(getObjectInfo,{
    objectApiName:ACCOUNT_OBJECT
   }) accountobjectinfo;

   @wire(getPicklistValues,{
    recordTypeId:'$accountobjectinfo.data.defaultRecordTypeId',
    fieldApiName:ACCOUNT_INDUSTRY_FIELD
   }) slapicklist;

    handleChange(event){
            let {name,value}=event.target;
            if(name==='parentacc'){
             this.selectedParentACc=value;
            }
            else if(name==='accname'){
             this.selectedAccName=value;
            }
            else if(name==='slaexpdt'){
                this.slsExpDate=value;
            }
            else if(name==='slatype'){
                this.selSlaType=value;
            }   
            else if(name==='nooflocation'){
              this.selectednoOfLocation=value;
            }
            else if(name==='description'){
                 this.selDescription=value;
            }


    }


    saveRecord(){
       if(this.validateInput){
        let inputfields={};
        inputfields[ACCOUNT_NAME_FIELD.fieldApiName]=this.selectedAccName;
        inputfields[ACCOUNT_PARENT_FIELD.fieldApiName]=this.selectedParentACc;
        inputfields[ACCOUNT_INDUSTRY_FIELD.fieldApiName]=this.selSlaType;
        inputfields[ACCOUNT_NumberOfLocation_FIELD.fieldApiName]=this.selectednoOfLocation;
        inputfields[ACCOUNT_DESCRIPTION_FIELD.fieldApiName]=this.selDescription;

        if(this.recordId){
            //update record
            inputfields[ACCOUNT_ID_FIELD.fieldApiName]=this.recordId;
            let recordInput={
                fields:inputfields

            };
            updateRecord(recordInput).then((result)=>{
               console.log('updated OUTPUT : ',result);
               this.showToast();
            })
            .catch((error)=>{
                console.log('fail updated OUTPUT : ',error);
            })

        }
        else {
            let recordInput={

                apiName:ACCOUNT_OBJECT.objectApiName,
                fields:inputfields
            }
              createRecord(recordInput).then(result=>{
                  console.log('OUTPUT REULT : ',result);
                  let pageRef={
                    type: 'standard__recordPage',
                    attributes: {
                        recordId: result.Id,
                        objectApiName:ACCOUNT_OBJECT.objectApiName,
                        actionName: 'view'
                    }
            };
            this[NavigationMixin.Navigate](pageRef);
              })
              .catch(error=>{
                console.log('OUTPUT : ',error);
              })
        }
       
       }
       else{
           console.log('Inavlid Inputs');
       }
    }

    validateInput(){
       let fields=Array.from( this.template.querySelectorAll('.validateme'));
       let isValid=fields.every((curritem) => curritem.checkValidity());
       return isValid;
    }

    get formTitle(){
            if(this.recordId){
                return 'Edit Account'
            }
            else{
                return 'Create Account'
            }
    }

    get isDeleteAvailable(){
        if(this.recordId){
            return true;
        }
        else{
            return false;
        }
    }
    showToast() {
        const event = new ShowToastEvent({
            title: 'Success',
            message:
                'Record Updated Successfully.',
                variant:'success'
        });
        this.dispatchEvent(event);
    }

    deleteRecord(){
        deleteRecord(this.recordId).then((result)=>{
            console.log('record is deleted');
            let pageRef=// Navigates to account list with the filter set to Recent.
            {
                type: 'standard__objectPage',
                attributes: {
                    objectApiName: ACCOUNT_OBJECT.objectApiName,
                    actionName: 'list'
                },
                state: {
                    filterName: 'Recent'
              }
             
            };
            this[NavigationMixin.Navigate](pageRef);
        }).catch((error)=>{
            console.log('delete fail OUTPUT : ',error);
        })
    }
}