import { LightningElement,wire } from 'lwc';
import getParentAccount from '@salesforce/apex/AccountHelper.getParentAccount';
import { getObjectInfo, getPicklistValues } from 'lightning/uiObjectInfoApi';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import ACCOUNT_INDUSTRY_FIELD from '@salesforce/schema/Account.Industry';
import ACCOUNT_PARENT_FIELD from '@salesforce/schema/Account.ParentId';
import ACCOUNT_NAME_FIELD from '@salesforce/schema/Account.Name';
import ACCOUNT_NumberOfLocation_FIELD from '@salesforce/schema/Account.NumberOfEmployees';
import ACCOUNT_DESCRIPTION_FIELD from '@salesforce/schema/Account.Description';
import { createRecord } from 'lightning/uiRecordApi';
import { NavigationMixin } from 'lightning/navigation';

export default class AccountDetails extends NavigationMixin(LightningElement) {
 
    parentoptions=[];
    selectedParentACc='';
    selectedAccName='';
    selectednoOfLocation="1";
    slsExpDate=null;
    selSlaType='';
    selDescription='';
    @wire(getParentAccount) wire_getParentAccount({error,data}){
        this.parentoptions=[];
        if(data){
            this.parentoptions=data.map((curritem)=>({
                 label:curritem.Name,
                 value:curritem.Id
           }));
        }
        else if(error){
           console.log('OUTPUT : ',error);
        }
    }

   @wire(getObjectInfo,{
    objectApiName:ACCOUNT_OBJECT
   }) accountobjectinfo;

   @wire(getPicklistValues,{
    recordTypeId:'$accountobjectinfo.data.defaultRecordTypeId',
    fieldApiName:ACCOUNT_INDUSTRY_FIELD
   }) slapicklist;

    handleChange(event){
            let {name,value}=event.target;
            if(name==='parentacc'){
             this.selectedParentACc=value;
            }
            else if(name==='accname'){
             this.selectedAccName=value;
            }
            else if(name==='slaexpdt'){
                this.slsExpDate=value;
            }
            else if(name==='slatype'){
                this.selSlaType=value;
            }   
            else if(name==='nooflocation'){
              this.selectednoOfLocation=value;
            }
            else if(name==='description'){
                 this.selDescription=value;
            }


    }


    saveRecord(){
       if(this.validateInput){
        let inputfields={};
        inputfields[ACCOUNT_NAME_FIELD.fieldApiName]=this.selectedAccName;
        inputfields[ACCOUNT_PARENT_FIELD.fieldApiName]=this.selectedParentACc;
        inputfields[ACCOUNT_INDUSTRY_FIELD.fieldApiName]=this.selSlaType;
        inputfields[ACCOUNT_NumberOfLocation_FIELD.fieldApiName]=this.selectednoOfLocation;
        inputfields[ACCOUNT_DESCRIPTION_FIELD.fieldApiName]=this.selDescription;

        let recordInput={

            apiName:ACCOUNT_OBJECT.objectApiName,
            fields:inputfields
        }
          createRecord(recordInput).then(result=>{
              console.log('OUTPUT REULT : ',result);
              let pageRef={
                type: 'standard__recordPage',
                attributes: {
                    recordId: result.Id,
                    objectApiName:ACCOUNT_OBJECT.objectApiName,
                    actionName: 'view'
                }
        };
        this[NavigationMixin.Navigate](pageRef);
          })
          .catch(error=>{
            console.log('OUTPUT : ',error);
          })
       }
       else{
           console.log('Inavlid Inputs');
       }
    }

    validateInput(){
       let fields=Array.from( this.template.querySelectorAll('.validateme'));
       let isValid=fields.every((curritem) => curritem.checkValidity());
       return isValid;
    }
}