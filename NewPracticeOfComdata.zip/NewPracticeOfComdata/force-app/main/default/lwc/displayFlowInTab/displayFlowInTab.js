import { LightningElement } from 'lwc';

export default class DisplayFlowInTab extends LightningElement {}