import { LightningElement,api } from 'lwc';

export default class EmbedFlowinLwc extends LightningElement {
@api recordId;
accountId;
accountType;
    get inputVariables(){
     return   [
             {name:'AccountId',type:"String",value:this.recordId},
             {name:'operationType',type:"String",value:"Create Record"}
        ]
    }

    statusChangeHandler(event){
        if(event.detail.status=='FINISHED'){
            let ouputValues=event.detail.outputVariables;
            for(let i=0;i<ouputValues.length;i++){
                let outputItem=ouputValues[i];
                if(outputItem.name=='outputAccountId'){
                     this.accountId=outputItem.value;
                     console.log('Account Id',outputItem.value);
                }
                else if(outputItem.name=='outputOperationType'){
                    this.accountType=outputItem.value;
                    console.log('Operation TYpe',outputItem.value);
                }
            }
        }
    }
}