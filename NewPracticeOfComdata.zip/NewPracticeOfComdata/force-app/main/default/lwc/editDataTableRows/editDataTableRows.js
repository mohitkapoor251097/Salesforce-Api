import { LightningElement,wire,api} from 'lwc';
import getContactListForDataTable from '@salesforce/apex/ContactLwcController.getContactBasedOnAccount';
import { deleteRecord, updateRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import {refreshApex} from '@salesforce/apex';
import LEAD_SOURCE from '@salesforce/schema/Contact.LeadSource';
import { getObjectInfo, getPicklistValues } from 'lightning/uiObjectInfoApi';
import CONTACT_OBJECT from '@salesforce/schema/Contact';
const actions=[
    {
        label:"View",
        name:"view"
    },
    {
        label:"Edit",
        name:"edit"
    },
    {
        label:"Delete",
        name:"delete"
    }
];
const DEAULT_ACTION=[{
    label:'All',
    checked:true,
    name:"all"

}]
 const  columns=[
    { label: 'First Name', fieldName: 'FirstName',editable:true,hideDefaultActions:true},
    { label: 'Last Name', fieldName: 'LastName',editable:true,hideDefaultActions:true},
    { label: 'Title', fieldName: 'Title',editable:true,hideDefaultActions:true },
    { label: 'Phone', fieldName: 'Phone', type: 'phone',editable:true,hideDefaultActions:true },
    { label: 'Email', fieldName: 'Email', type: 'email',editable:true,hideDefaultActions:true },
   {
    label:"Lead Source",
    fieldName:"LeadSource",
    type:"customPickList",
    editable:true,
    typeAttributes:{
        options:{fieldName:"pickListOptions"},
        value:{fieldName:"LeadSouce"},
        context:{fieldName:"Id"}
    },
    hideDefaultActions:true,
    actions:DEAULT_ACTION
   },
   {type:"action",typeAttributes:{rowActions:actions}}

];

export default class EditDataTableRows extends LightningElement {
@api recordId;
contactAllData=[];
contactRefreshProp;
draftValues=[];
leadSourceOptions=[];
columns= columns;
contactData=[];
isDisplayMode=false;
isEditMode=false;
recordInputId;
loadActionCompleted=false;
isModalOpen=false;
leadSourceActions=[];

@wire(getContactListForDataTable,{
    accountId:"$recordId",pickList:"$leadSourceOptions"
})
getContactOutput(result){
    this.contactRefreshProp=result;
    if(result.data){
     //this.contactData=result.data;
    this.contactData= result.data.map((currItem)=>{
        let pickListOptions=this.leadSourceOptions;
        return {
            ...currItem,
            pickListOptions:pickListOptions
        };
     });
     this.contactAllData=[...this.contactData];
    }
    else if(result.error){
        console.log("error While Loading Records");
    }
}
@wire(getObjectInfo,{
    objectApiName:CONTACT_OBJECT
})
objectInfo;

@wire(getPicklistValues,{
    recordTypeId:"$objectInfo.data.defaultRecordTypeId",
    fieldApiName:LEAD_SOURCE
})wirePicklist({data,error}){
    if(data){
       this.leadSourceOptions=data.values;
       this.leadSourceActions=[];
       data.values.forEach((currItem)=>{
        this.leadSourceActions.push({
            label:currItem.label,
            checked:false,
            name:currItem.value
        });
       });

       this.columns.forEach((currItem)=>{
       if(currItem.fieldName==='LeadSource'){
        currItem.actions=[...currItem.actions,...this.leadSourceActions]
       }
       });
       this.loadActionCompleted=true;
    }
    else if(error){
        console.log('error loading',error);
    }
}
 async handleSave(event){
   let records=event.detail.draftValues;
  let updateRecordsArray= records.map(currItem=>{
    let fieldInput={...currItem};
    return {
        fields:fieldInput
    };
   });

   this.draftValues=[]
  let updateRecordsArrayPromise=updateRecordsArray.map(currItem=> updateRecord(currItem));

   await  Promise.all(updateRecordsArrayPromise);

   const toastevent = new ShowToastEvent({
    title: 'Success',
    message:
        'Records Updated Successfully!',
        variant:'success'
});
this.dispatchEvent(toastevent);
await refreshApex(this.contactRefreshProp);
}

rowActionHandler(event){
  const action=event.detail.action;
  const row=event.detail.row;
  this.isDisplayMode=false;
  this.isEditMode=false;
  this.isModalOpen=false;
  this.recordInputId=row.Id;
   switch (action.name){
    case "view":
        this.isDisplayMode=true;
        this.isEditMode=false;
        this.isModalOpen=true;
        break;
    case  "edit":
        this.isDisplayMode=false;
        this.isEditMode=true;
        this.isModalOpen=true;
        break;
    case "delete":
        this.deleteRecordHandler(this.recordInputId);
   }
}
async closeModalHandler(){
   this.isModalOpen=false;
   if(this.isEditMode){
   await refreshApex(this.contactRefreshProp);
   }
}
async deleteRecordHandler(idForDelete){
  try{
   await deleteRecord(idForDelete);
   const event = new ShowToastEvent({
    title: 'success',
    message:
        'Record Deleted Succesfully',
        variant:'success'
});
this.dispatchEvent(event);
await refreshApex(this.contactRefreshProp);
  }
  catch(error){
   console.log('Error'+error);
   const event = new ShowToastEvent({
    title: 'error',
    message:
        error.body.message,
        variant:'error'
});
this.dispatchEvent(event);
  }
}

headerActionHandler(event){
let actionName=event.detail.action.name;
const colDef=event.detail.columnDefinition;
const cols=[...this.columns];

console.log('actionName',actionName);
console.log('colDef',colDef);

if(actionName==='all'){
    this.contactData=[...this.contactAllData];
}
else{
    this.contactData=this.contactAllData.filter(
        (currItem)=> actionName===currItem["LeadSource"]
        
        );
}

cols.find(currItem=>currItem.fieldName==='LeadSource').actions.forEach(currItem=>{
    if(currItem.name===actionName){
        currItem.checked=true;
    }
    else{
        currItem.checked=false; 
    }
});
this.columns=[...cols];
}

get displayData(){
   if(this.contactData && this.loadActionCompleted===true){
         return true;
   }
   else{
    return false;
   }

}
}