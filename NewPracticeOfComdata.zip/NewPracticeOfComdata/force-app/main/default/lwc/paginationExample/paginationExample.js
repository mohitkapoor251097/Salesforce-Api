import { LightningElement, track, wire } from 'lwc';
import getAccounts from '@salesforce/apex/AccountControllerLwc.getAccounts';
import { getRecord,getFieldValue } from 'lightning/uiRecordApi';
import CONTACT_ISCorrect_Field from '@salesforce/schema/Contact.isCorrect__c';
import  getContactDetails from '@salesforce/apex/AccountControllerLwc.getContactDetails';
const PAGE_SIZE = 1;

export default class PaginationExample extends LightningElement {
  @track currentPage = 1;
  @track displayedAccounts = [];
  contactList;
  @track box;
  showResult=false;
  selectedContactId;
  checkValue=false;
  currentAccountName;
  currentContactName;
  historyArray = [];
  historyMap = new Map();
  resultValue;
//   @wire(getAccounts, { pageNumber: '$currentPage', pageSize: PAGE_SIZE })
//   wiredAccounts({ error, data }) {
//     if (data) {
//       this.displayedAccounts = data;
//       this.contactList=data.Contacts.map(contact=>({
//         label:contact.Name,
//         value:contact.Id,
//       }));
//     } else if (error) {
//       console.error('Error retrieving accounts:', error);
//     }
//   }

@wire(getAccounts, { pageNumber: '$currentPage', pageSize: PAGE_SIZE })
wiredAccounts({ error, data }) {
  if (data) {
   // this.displayedAccounts = data;
   this.displayedAccounts = data.map(account => ({
    ...account,
    Name: 'Q'+this.currentPage +': '+ account.Name,
  }));
 console.log('----------------');
    this.contactList = data.reduce((acc, account) => {

      if (account.Contacts) {
        acc.push(...account.Contacts.map(contact => ({
          label: contact.Name,
          value: contact.Id,
          isCorrect__c:contact.isCorrect__c,
          accountId: account.Id,
          accountName: account.Name,
        })));
      }
      return acc;
    }, []);
  } else if (error) {
    console.error('Error retrieving accounts:', error);
  }
  console.log('contactList'+JSON.stringify(this.contactList));
}

  get radioGroupOptions(){
    return this.contactList || [];
  }

//   @wire(getRecord,{recordId:'$selectedContactId',fields:[CONTACT_ISCorrect_Field]})
//   wiredContact({data,error}){
//     if(data){
//         console.log('checkvalue'+getFieldValue(data,CONTACT_ISCorrect_Field));
//         this.checkValue=getFieldValue(data,CONTACT_ISCorrect_Field);
        
//     }
//     else if(error){
//         console.log('error');
//     }
//   }

loadContactData() {
    getContactDetails({ contactId: this.selectedContactId })
        .then(result => {
            console.log('result'+JSON.stringify(result));
            this.checkValue = result.isCorrect__c;
            console.log('checkvalue: ' + this.checkValue);
            if(this.checkValue){
                console.log('correct');
                this.resultValue='Correct';
                this.box = 'box-color';
             }
             else{
                console.log('incorrect');
                this.resultValue='InCorrect';
                this.box = 'box-border';
             }

              // Store the current account and contact names
              
                  this.currentAccountName = result.Account.Name;
                  this.currentContactName = result.Name;
                  console.log('Select Acc'+this.currentAccountName);
                  console.log('Selected con'+this.currentContactName);

                                  // Push the names into the history array
                // this.historyArray.push({
                //     accountName: this.currentAccountName,
                //     contactName: this.currentContactName,
                //     finalResult:this.resultValue,
                // });

                // Store the current account and contact names in the map
               const key='Q'+this.currentPage +' '+this.currentAccountName; // You can define this function based on your use case
               this.historyMap.set(key, `${this.currentContactName} : ${this.resultValue}`);
                 // this.historyMap.set(key,this.resultValue);
                console.log('History Map', this.historyMap.get(key));

                this.historyArray = Array.from(this.historyMap, ([accountName, contactName]) => ({
                    key: accountName,
                    accountName: accountName,
                    contactName: contactName,
                    
                }));
              
        })
        .catch(error => {
            console.error('Error fetching contact data', JSON.stringify(error));
        });
}
  handleRadioChange(event){
    this.selectedContactId= event.detail.value;
    this.loadContactData();
    this.showResult=false;

  }

  
  handleNextClick() {
    this.currentPage += 1;
  }

  handlePreClick(){
    this.currentPage -= 1;
  }

  finalResult(){
    this.showResult=true;
  }
}