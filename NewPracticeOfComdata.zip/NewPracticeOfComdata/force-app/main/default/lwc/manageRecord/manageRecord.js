import { LightningElement,api } from 'lwc';

export default class ManageRecord extends LightningElement {
@api inputRecordId;
}