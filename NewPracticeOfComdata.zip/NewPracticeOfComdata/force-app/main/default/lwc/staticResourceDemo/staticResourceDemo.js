import { LightningElement,wire} from 'lwc';
import LOGO from '@salesforce/resourceUrl/logo';
import VfLabel from '@salesforce/label/c.VfLabel';
import Id from '@salesforce/user/Id';
import { getFieldValue, getRecord } from 'lightning/uiRecordApi';
import NAME_FIELD from '@salesforce/schema/User.Name';
import DISPLAY_TEXT from '@salesforce/userPermission/displayText';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import ANIMATE from '@salesforce/resourceUrl/ThirdPartyCss';
import MOMENT from '@salesforce/resourceUrl/ThirdPartyJs';
export default class StaticResourceDemo extends LightningElement {
    displayDate='';
    isFirstLoad=true;
 myLogo=LOGO;
 name;
 label={
    VfLabel:VfLabel
 };

 userId=Id;

 @wire(getRecord,{
    recordId:Id,
    fields:NAME_FIELD
 }) wire_user_output({data,error}){
    if(data){
        console.log('OUTPUT : ',data);
       this.name=getFieldValue(data,NAME_FIELD);
    }
    else if(error){
        console.log('error OUTPUT : ',error);
    }
 }
 renderedCallback(){
   if(this.isFirstLoad){
    this.isFirstLoad=false;
    Promise.all([
        loadStyle(this,ANIMATE),
        loadScript(this,MOMENT)
    ])
     .then(()=>{
        console.log('File is loaded');
        this.fetchDate();
      

    }).catch(error=>{
        console.log('error is loaded',error);
    });

   }
 }


 get checkPermission(){
    return DISPLAY_TEXT;
 }

 fetchDate(){
    this.displayDate=moment().format('LLLL');
 }
}