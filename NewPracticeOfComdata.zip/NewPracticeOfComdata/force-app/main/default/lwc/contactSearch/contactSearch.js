import { LightningElement, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import searchContacts from '@salesforce/apex/ContactController.searchContacts';
const actions = [
    { label: 'View', name: 'view' },
    { label: 'Edit', name: 'edit' },
];
export default class ContactSearch extends NavigationMixin(LightningElement) {
    url = "https://media.tenor.com/28DFFVtvNqYAAAAC/loading.gif"
    @track contactRow = {};
    @track modalContainer = false;
    @track loadCheck = false; // Declare boolean variables to indicate whether data is currently being loaded and the search feature is active
    @track searchKey;
    @track contacts;
    @track errors;
    @track searchContact = false;
    @track isSearchAvailable = false;
    @track customFormModal = false; // Declare boolean variable for modal popup
    spinnerStatus = false;
      

    @track columnsName = [ // Declare an array of objects defining the columns for the datatable component
        {
            label: 'View',
            type: 'button-icon',
            initialWidth: 65,
            typeAttributes: {
                iconName: 'action:preview',
                title: 'Preview',
                variant: 'border-filled',
                alternativeText: 'View'
            }
        },
        {
            label: 'Contact Name',
            fieldName: 'Id',
            sortable: true,
            type: 'url',
            typeAttributes: {
                label: { fieldName: 'Name' },
                target: '_blank'
            }
        },
        {
            label: 'Related Account',
            fieldName: 'Account.Name'
        },
        {
            label: 'Phone',
            fieldName: 'Phone',
        },
        {
            label: 'Email',
            fieldName: 'Email',
            type: 'email'
        },
        {
            label: 'Action',
            type: 'action',
            typeAttributes: { rowActions: actions },
        },
    ];

    handleKeyChange(event) { // Define a function that runs whenever a key is pressed in the search input box
        //store the input value in variable
        //The keyword this refers to the current object or instance of a class where this code is being executed.
        this.searchKey = event.target.value.toLowerCase();

        if (this.searchKey.length > 0) { // Set searchContact and isSearchAvailable to true if the user has entered a search string
            this.searchContact = true;
            this.searchContact = true;
        }
        else if ((this.searchKey.length == 0)) { // Set all search-related track bindings to false if no search string is present
            this.searchContact = false;
            this.isSearchAvailable = false;
            this.contacts = false;
        }


    }

    handleRowAction(event) {  // Define a function to handle row actions in the datatable i.e clicking on a cell brings up the record detail page
        // const row = event.detail.row;
        // this[NavigationMixin.Navigate]({
        //     type: 'standard__recordPage',
        //     attributes: {
        //         recordId: row.Id,
        //         objectApiName: 'Contact', // objectApiName is optional
        //         actionName: 'view'
        //     }
        // });
        const actionName = event.detail.action.name;
        const row = event.detail.row;
        window.console.log('dataRow@@ ' + row);
        if(actionName!='view' && actionName!='edit'){
        this.contactRow = row;
        window.console.log('contactRow## ' +this.contactRow);
        this.modalContainer = true;
        }
        else{

            this.modalContainer = false;
   
        switch (actionName) {
            case 'view':
                this[NavigationMixin.Navigate]({
                    type: 'standard__recordPage',
                    attributes: {
                        recordId: row.Id,
                        actionName: 'view'
                    }
                });
                break;
            case 'edit':
                this[NavigationMixin.Navigate]({
                    type: 'standard__recordPage',
                    attributes: {
                        recordId: row.Id,
                        objectApiName: 'Account',
                        actionName: 'edit'
                    }
                });
                break;
            default:
        }
    }

    }

    handleContactSearch() { // Define a function to handle when the "Search" button is clicked
        // Declare an error message
        let fieldErrorMsg = "Please Enter the Name";
        this.template.querySelectorAll("lightning-input").forEach(item => {
            let fieldValue = item.value;
            //let fieldLabel=item.label;            
            if (!fieldValue) { // If the field is empty, display the error message
                item.setCustomValidity(fieldErrorMsg);
            }
            else {
                item.setCustomValidity(""); // Else clear the error message and call the Apex method using searchContacts(), which searches for Contacts based on the given search string
                setTimeout(() => {
                    this.loadCheck = true;
                    this.spinnerStatus=true;
                    console.log('Button is Clicked');
                    searchContacts({ searchKey: this.searchKey })
                        .then((result) => {

                            console.log('Result is' + JSON.stringify(result));
                            /*
this.contacts = result.map(... creates a new array of objects where each object in the original result array is transformed according to the function passed as an argument to the map() method.

The function takes one argument, record, which represents each object in the result array. Within the function body, there's a call to Object.assign(), which returns a new object that merges two other objects: the first object contains a property "Account.Name" whose value is either record.Account.Name or an empty string based on whether record.AccountId is not null and not an empty string; the second object is simply record.

Putting it all together means that for each record object in the result array, we create a new object with the same properties as record, but if record.AccountId is not null and not an empty string, we add a new property "Account.Name" with the value of record.Account.Name, otherwise the property is assigned an empty string. The resulting array of objects is assigned to this.contacts.
                            */
                            // After retrieving data, map it to include the Account name 
//The Object.assign() copies all enumerable and own properties from the source objects to the target object. It returns the target object.
//Object.assign() can be used to clone an object or merge objects.
//The Object.assign() invokes the getters on the source objects and setters on the target. It assigns properties only, not copying or defining new properties.
                            this.contacts = result.map(
                                record => Object.assign( //Object.assign(), which returns a new object that merges two other objects: 
                                    // the first object contains a property "Account.Name" whose value is either record.Account.Name or an empty string based on whether record.AccountId is not null and not an empty string; the second object is simply record
                                    { "Account.Name": (record.AccountId != null && record.AccountId != '') ? record.Account.Name : '' },
                                    record
                                )
                            );
                            if (this.contacts.length > 0) { // If there are results, set isSearchAvailable and loadCheck to false and log that search is available
                                this.isSearchAvailable = false;
                                this.loadCheck = false;
                                this.spinnerStatus=false;
                                console.log("Search is Avl");
                            }
                            else {  // Else if the search returns nothing, set isSearchAvailable to true and log that search isn't available. Also simulate a button click
                                this.isSearchAvailable = true;
                                this.loadCheck = false;
                                this.spinnerStatus=false;
                                console.log("Search is not Avl");
                                const myButton = this.template.querySelector('.my-button-class');
                                myButton.click();
                            }
                        })
                        .catch((errors => {  // Catch errors if there are any
                            this.errors = error.message;
                            this.isSearchAvailable = false;
                            this.loadCheck = false;
                            this.spinnerStatus=false;
                            console.log(this.errors);

                        }))
                }, 3000);
            }
            item.reportValidity(); // Report validity of each input field

        });

    }
    customHideModalPopup() { // Define function to handle hiding of modal popup

        this.customFormModal = false;
    }
    display1() { // Define function to handle display of modal popup
        console.log('Display is Working');
        this.customFormModal = true;
    }
    closeModalAction() {
        this.modalContainer = false;
    }

}