import { LightningElement ,api} from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class LoadModal extends LightningElement {
    @api isDisplayMode=false;
    @api isEditMode=false;
    @api recordInputId;
    get label(){
      if(this.isDisplayMode) return 'Display Contact Details';
      else if(this.isEditMode) return "Edit Contact Details";
      else return "";
  }
  closeHandler(){
      this.fireEventToCloseModal();
  }
  successHandler(){
    const event = new ShowToastEvent({
        title: 'Success',
        message:
            'Record Edit Successfully',
            variant:'success'
    });
    this.dispatchEvent(event);
    this.fireEventToCloseModal();
  }
  fireEventToCloseModal(){
    let myEvent=new CustomEvent("closemodal");
    this.dispatchEvent(myEvent);
  }
}