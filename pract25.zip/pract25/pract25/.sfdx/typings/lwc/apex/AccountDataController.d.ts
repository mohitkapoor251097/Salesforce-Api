declare module "@salesforce/apex/AccountDataController.getAccounts" {
  export default function getAccounts(): Promise<any>;
}
