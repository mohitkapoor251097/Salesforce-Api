declare module "@salesforce/apex/UserDetailsController.getUserData" {
  export default function getUserData(): Promise<any>;
}
