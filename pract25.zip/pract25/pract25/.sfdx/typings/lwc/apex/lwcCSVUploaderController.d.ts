declare module "@salesforce/apex/lwcCSVUploaderController.saveFile" {
  export default function saveFile(param: {base64Data: any}): Promise<any>;
}
