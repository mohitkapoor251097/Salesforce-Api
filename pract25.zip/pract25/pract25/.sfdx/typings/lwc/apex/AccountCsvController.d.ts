declare module "@salesforce/apex/AccountCsvController.getAccountFields" {
  export default function getAccountFields(): Promise<any>;
}
declare module "@salesforce/apex/AccountCsvController.insertAccounts" {
  export default function insertAccounts(param: {accounts: any}): Promise<any>;
}
