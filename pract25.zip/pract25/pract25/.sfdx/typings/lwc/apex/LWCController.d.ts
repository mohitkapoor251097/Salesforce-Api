declare module "@salesforce/apex/LWCController.getAccounts" {
  export default function getAccounts(): Promise<any>;
}
declare module "@salesforce/apex/LWCController.getRecordName" {
  export default function getRecordName(param: {recordId: any}): Promise<any>;
}
