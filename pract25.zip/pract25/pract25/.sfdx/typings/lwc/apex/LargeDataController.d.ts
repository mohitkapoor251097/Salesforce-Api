declare module "@salesforce/apex/LargeDataController.fetchLargeData" {
  export default function fetchLargeData(param: {offset: any, limitSize: any}): Promise<any>;
}
