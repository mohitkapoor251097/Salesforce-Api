declare module "@salesforce/apex/AccountController.AcountCreation" {
  export default function AcountCreation(param: {accountData: any}): Promise<any>;
}
declare module "@salesforce/apex/AccountController.getAccounts" {
  export default function getAccounts(): Promise<any>;
}
declare module "@salesforce/apex/AccountController.getAccountsData" {
  export default function getAccountsData(): Promise<any>;
}
declare module "@salesforce/apex/AccountController.getContacts" {
  export default function getContacts(param: {accId: any}): Promise<any>;
}
declare module "@salesforce/apex/AccountController.getRatingAccounts" {
  export default function getRatingAccounts(param: {ratingVal: any}): Promise<any>;
}
declare module "@salesforce/apex/AccountController.getAccountsList" {
  export default function getAccountsList(): Promise<any>;
}
