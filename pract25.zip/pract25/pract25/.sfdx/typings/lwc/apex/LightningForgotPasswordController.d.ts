declare module "@salesforce/apex/LightningForgotPasswordController.forgotPassword" {
  export default function forgotPassword(param: {username: any, checkEmailUrl: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningForgotPasswordController.setExperienceId" {
  export default function setExperienceId(param: {expId: any}): Promise<any>;
}
