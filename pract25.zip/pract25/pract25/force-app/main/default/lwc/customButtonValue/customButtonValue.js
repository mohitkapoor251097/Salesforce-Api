import { LightningElement, api } from 'lwc';

export default class CustomButtonValue extends LightningElement {
    @api recordId;
    @api NewContact;
    @api Delete;

    handleNewContact() {
        if (this.onNewContact) {
            this.onNewContact(this.recordId);
        }
    }

    handleDelete() {
        if (this.onDelete) {
            this.onDelete(this.recordId);
        }
    }
}
