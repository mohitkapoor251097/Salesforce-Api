import { LightningElement,api } from 'lwc';
import LAST_NAME from '@salesforce/schema/Contact.LastName';
//import ACCOUNTID from '@salesforce/schema/Contact.AccountId';
import LEADSOURCE from '@salesforce/schema/Contact.LeadSource';
import {CloseActionScreenEvent} from 'lightning/actions';
export default class QuickActiondemo extends LightningElement {

    @api recordId;
    fieldList={
        LastName:LAST_NAME,
        LeadSource:LEADSOURCE
    }

    submitHandler(event){
        event.preventDefault(); 
        const fields = event.detail.fields;
        if(!fields.AccountId){
            fields.AccountId=this.recordId
        }
        this.template.querySelector('lightning-record-edit-form ').submit(fields);
        this.closeHandler();
    }

    closeHandler(){
         this.dispatchEvent(new CloseActionScreenEvent());
    }
}