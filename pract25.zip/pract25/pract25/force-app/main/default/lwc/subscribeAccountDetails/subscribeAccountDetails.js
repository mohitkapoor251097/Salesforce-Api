import { LightningElement, wire } from 'lwc';
import messageChannel from '@salesforce/messageChannel/accountdetails__c';
import { APPLICATION_SCOPE, MessageContext, subscribe, unsubscribe } from 'lightning/messageService';
export default class SubscribeAccountDetails extends LightningElement {

    recordId = null;

    @wire(MessageContext)
    messageContext;

    subscription = null;
    connectedCallback() {
        this.subscribeToMessageChannel();
    }
    subscribeToMessageChannel() {
        if (!this.subscription) {

            this.subscription = subscribe(this.messageContext, messageChannel, (message) => this.recievedata(message), { scope: APPLICATION_SCOPE });
        }
    }
    recievedata(event) {
        console.log('message recieved' + event.recordId);
        this.recordId = event.recordId;

    }

    disconnectedCallback() {
        unsubscribe(this.subscription);
        this.subscription = null;
    }
}