import { LightningElement, wire } from 'lwc';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import ACCOUNT_RATING from '@salesforce/schema/Account.Rating';
import { getObjectInfo, getPicklistValues } from 'lightning/uiObjectInfoApi';
import getAccounts from '@salesforce/apex/AccountController.getRatingAccounts';

export default class DisplayAccountusingRating extends LightningElement {
    accountList=[];

    columns=[
        {label:'Name', fieldName:'Name'},
        {label:'Owner Name',fieldName:'OwnerName'}
    ]

    @wire(getObjectInfo, { objectApiName: ACCOUNT_OBJECT })
    accountInfo;

    @wire(getPicklistValues, {
        recordTypeId: '$accountInfo.data.defaultRecordTypeId',
        fieldApiName: ACCOUNT_RATING
    })
    ratingInfo;

    async changleHandler(event) {
        console.log('OUTPUT : ', event.target.value);

        let result= await getAccounts({ ratingVal: event.target.value });
        this.accountList=result.map(item=>({
            ...item,OwnerName:item.CreatedBy?.Name
        }))
    }
    get checkRecord(){
        return this.accountList.length>0 ? false :true;
   }

    clickHandler(){
        //selected
        let selectedRows=[];
        let downloadRecords=[];
        selectedRows=this.template.querySelector("lightning-datatable").getSelectedRows()

        //records are not selected
        if(selectedRows.length>0){
            downloadRecords=[...selectedRows];
        }
        else 
        {
            downloadRecords=[...this. accountList];
        }

        //convert array into csv
       let csvFile= this.convertArrayToCsv(downloadRecords);
        this.createLinkForDownload(csvFile)

    }
    // convertArrayToCsv(downloadRecords){
    //     let csvHeader=Object.keys(downloadRecords[0]).toString();
    //     let csvBody=downloadRecords.map((currItem) => Object.values(currItem).toString());
    //     let csvFile=csvHeader + '\n' + csvBody.join('\n');
    //     return csvFile;
    // }
    convertArrayToCsv(downloadRecords) {
        // Exclude the unwanted fields
        const excludeFields = ['CreatedById', 'CreatedBy'];
        
        // Get the headers by excluding the unwanted fields
        let csvHeader = Object.keys(downloadRecords[0])
            .filter(field => !excludeFields.includes(field))
            .toString();
    
        // Get the body by excluding the unwanted fields
        let csvBody = downloadRecords.map(currItem => 
            Object.keys(currItem)
                .filter(field => !excludeFields.includes(field))
                .map(field => currItem[field])
                .toString()
        );
    
        // Combine header and body
        let csvFile = csvHeader + '\n' + csvBody.join('\n');
        return csvFile;
    }
    

    createLinkForDownload(csvFile){
        const downLink=document.createElement("a");
        downLink.href="data:text/csv;charset=utf-8," + encodeURI(csvFile);
        downLink.target='_blank';
        downLink.download='Account_Data.csv';
        downLink.click();
    }
}