import { LightningElement } from 'lwc';

export default class ParentData extends LightningElement {

    name;
    recieveName;
    handlerChange(event){
    this.name=event.target.value;
    }
   
    recieveHandler(event){
      this.recieveName=event.detail;
      console.log(event.detail);
      
    }
}