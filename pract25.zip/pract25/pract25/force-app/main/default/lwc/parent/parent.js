import { LightningElement } from 'lwc';

export default class Parent extends LightningElement {
    value;
    recieveHandler(event){
           this.value=event.detail.message;   
    }
}