import { LightningElement } from 'lwc';

export default class FlowCaller extends LightningElement {
    // handleStartFlow() {
    //     // Define flow input parameters
    //     const flowParams = {
    //         inputParam1: 'Value 1',
    //         inputParam2: 'Value 2'
    //     };

    //     // Get the flow component
    //     const flow = this.template.querySelector('lightning-flow');
    //     if (flow) {
    //         flow.startFlow('My_Auto_Launched_Flow', flowParams);
    //     }
    // }

    handleStartFlow() {
        const flowParams = {
            inputParam1: 'Value 1',
            inputParam2: 'Value 2'
        };
    
        const flow = this.template.querySelector('lightning-flow');
        if (flow) {
            flow.startFlow('My_Auto_Launched_Flow', flowParams)
                .then(() => {
                    console.log('Flow started successfully!');
                })
                .catch((error) => {
                    console.error('Error starting flow:', error);
                    // Optionally, show a custom error message
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error',
                            message: 'An error occurred while processing the flow.',
                            variant: 'error'
                        })
                    );
                });
        }
    }
    
}