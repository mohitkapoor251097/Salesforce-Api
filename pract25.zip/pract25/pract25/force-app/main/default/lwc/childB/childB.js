import { LightningElement,api } from 'lwc';
export default class ChildB extends LightningElement {

    @api recordId;

    connectedCallback(){
        console.log('ChildB connected'+this.recordId);
    }

    renderedCallback(){
        console.log('ChildB rendered'+this.recordId);
    }

    errorHandler(event){
        console.log('Error in ChildB'+event.detail.message);
    }
}