import { LightningElement, wire } from 'lwc';
import getAccounts from '@salesforce/apex/AccountRelatedContactController.getAccounts';
import getRelatedContacts from '@salesforce/apex/AccountRelatedContactController.getRelatedContacts';
import {refreshApex} from '@salesforce/apex';
import { deleteRecord } from 'lightning/uiRecordApi';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';

const actions=[
    {label:'Edit',name:'Edit'},
    {label:'Delete',name:'Delete'},
]
export default class AccountwithRealtedCntact extends LightningElement {

    accountOption=[];
    selectedAccount;
    displayModal=false;
    conRecordId;
    @wire(getAccounts)
    getAccountResult({data,error}){
        if(data){
    this.accountOption=data.map(item=>({
        label:item.Name,
        value:item.Id
    }))
        }
        else if(error){
            console.log('error'+error);
            
        }
    }

    get columns(){
        return [
            {label:'First Name',fieldName:'FirstName'},
            {label:'Last Name',fieldName:'LastName'},
            {type:'action',typeAttributes:{rowActions:actions}}

        ]
    }



    changeHandler(event){
        this.selectedAccount=event.target.value;
        console.log('id'+event.target.value);
        
    }
    @wire(getRelatedContacts,{selectedAccId:'$selectedAccount'})
    contacts;

    get isData(){
        return this.contacts.data && this.contacts.data.length>0 && this.selectedAccount!=null || ''
    }

    rowActionHandler(event){
        const action=event.detail.action;
        const row=event.detail.row;
        switch(action.name){
            case 'Edit':{
                 // alert('edit');
                  this.editContact(row);
                  break;
            }
            case 'Delete':{
                // alert('Delete')
                 this.deleteContact(row);
                 break;
            }
        }
    }

    editContact(row){
      this.displayModal=true;
      this.conRecordId=row.Id;
    }
    async deleteContact(row){
     try{
        await deleteRecord(row.Id);
        this.showMessage('success','Delete Successfully !','success');
        await refreshApex(this.contacts);
     }catch(error){
        console.log(JSON.stringify(error));
        
        this.showMessage('error',error.body.message,'error');
     }
    }
    async closeModal(){
        await refreshApex(this.contacts);
        this.displayModal=false;
        this.showMessage('success','updated Successfully !','success');

    }

    showMessage(title,message,variant){
        this.dispatchEvent(new ShowToastEvent({
            variant:variant,
            message:message,
            title:title
        }))
    }
}