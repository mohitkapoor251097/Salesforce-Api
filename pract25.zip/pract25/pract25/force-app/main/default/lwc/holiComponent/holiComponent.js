import { LightningElement } from 'lwc';

export default class HoliComponent extends LightningElement {
    colors = ['red', 'blue', 'green', 'yellow', 'pink', 'purple', 'orange'];
    splashes = [];

    handleSplash() {
        const color = this.colors[Math.floor(Math.random() * this.colors.length)];
        const splash = {
            id: Date.now(),
            color,
            x: Math.random() * 100,
            y: Math.random() * 100
        };
        this.splashes = [...this.splashes, splash];
    }
}