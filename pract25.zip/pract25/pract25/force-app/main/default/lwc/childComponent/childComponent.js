import { LightningElement } from 'lwc';

export default class ChildComponent extends LightningElement {
  dispatchCustomEvent() {
    const customEvent = new CustomEvent('customevent', {
      bubbles: true, // Allows bubbling up the DOM
      composed: true, // Allows crossing the shadow DOM boundary
      detail: { message: 'Hello from Child Component!' }
    });

    this.dispatchEvent(customEvent);
  }
}