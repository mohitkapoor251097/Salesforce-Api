import { LightningElement } from 'lwc';

export default class GrandParent extends LightningElement {

   value;
    recieveHandler(event){
           this.value=event.detail.message;   
    }
}