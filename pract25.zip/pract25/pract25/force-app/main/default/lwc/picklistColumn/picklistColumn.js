import  LightningDataTable from 'lightning/datatable';
import customPickListEditTemplate from "./customPickListEdit.html";
import customPickListTemplate from "./customPickList.html";
export default class PicklistColumn  extends LightningDataTable {

    static customTypes={
         customPickList:{
            template:customPickListTemplate,
            editTemplate:customPickListEditTemplate,
            standardCellLayout:true,
            typeAttributes:["options","value","context"]
        }
    };
}