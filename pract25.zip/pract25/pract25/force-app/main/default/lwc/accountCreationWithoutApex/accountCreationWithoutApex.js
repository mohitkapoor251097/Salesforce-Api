import { LightningElement, wire } from 'lwc';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import ACCOOUNT_RATING from '@salesforce/schema/Account.Rating';
import ACCOOUNT_NAME from '@salesforce/schema/Account.Name';
import ACCOOUNT_TYPE from '@salesforce/schema/Account.Type';
import ACCOOUNT_PARENT from '@salesforce/schema/Account.ParentId';
import { getObjectInfo, getPicklistValuesByRecordType, getPicklistValues } from 'lightning/uiObjectInfoApi';
import { createRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';

export default class AccountCreationWithoutApex extends NavigationMixin(LightningElement) {

    accoutDetails = {
        accName: '',
        accRating: '',
        accType: '',
        parentAcc: ''
    }
    @wire(getObjectInfo, { objectApiName: ACCOUNT_OBJECT })
    accountInfo;

    @wire(getPicklistValues, {
        recordTypeId: '$accountInfo.data.defaultRecordTypeId',
        fieldApiName: ACCOOUNT_RATING
    })
    ratingInfo;

    @wire(getPicklistValuesByRecordType, {
        recordTypeId: '$accountInfo.data.defaultRecordTypeId',
        objectApiName: ACCOUNT_OBJECT
    })
    accountPickListValues;

    get TypePickList() {
        return this.accountPickListValues?.data?.picklistFieldValues?.Type.values || [];
    }
    changleHandler(event) {
        const { name, value } = event.target;

        this.accoutDetails = {
            ...this.accoutDetails, [name]: name === 'parentAcc' ? event.detail.recordId : value.trim(),
        };
        console.log('accName' + this.accoutDetails.accName);
        console.log('accRating' + this.accoutDetails.accRating);
        console.log('accType' + this.accoutDetails.accType);
        console.log('parent acc' + this.accoutDetails.parentAcc);
    }

    createAccountHandler() {

        const fieldError = 'Please Enter';
        let isValid = true;

        // Validate all fields in a single loop
        this.template.querySelectorAll('lightning-input, lightning-combobox,lightning-record-picker').forEach(item => {
            const fieldValue = item.name === 'accName' ? item.value?.trim() : item.value;
            const errorMessage = !fieldValue ? `${fieldError} ${item.label}` : '';

            item.setCustomValidity(errorMessage);
            item.reportValidity();

            if (errorMessage) isValid = false;
        });

        if (isValid) {
            // Create Account   
            let inputFieds = {};
            inputFieds[ACCOOUNT_NAME.fieldApiName] = this.accoutDetails.accName;
            inputFieds[ACCOOUNT_RATING.fieldApiName] = this.accoutDetails.accRating;
            inputFieds[ACCOOUNT_TYPE.fieldApiName] = this.accoutDetails.accType;
            inputFieds[ACCOOUNT_PARENT.fieldApiName] = this.accoutDetails.parentAcc

            let recordInput = {
                fields: inputFieds,
                apiName: ACCOUNT_OBJECT.objectApiName
            }
            createRecord(recordInput).then((result) => {
                this.showmessage('success', 'success', 'Account Created Successfully !');
                this.resetHandler();
                console.log('OUTPUT : ', result.id);
                this.navigateToRecordPage(result.id);

            }).catch((error) => {
                this.showmessage('error', 'error', 'something went wrong on server');
                console.log('Error' + error);
            })
        }


    }
    showmessage(title, variant, message) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            variant: variant,
            message: message
        }));
    }

    navigateToRecordPage(accId) {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: accId,
                objectApiName: 'Account',
                actionName: 'view'
            },

        })
    }

    resetHandler() {

        this.template.querySelectorAll('lightning-input, lightning-combobox,lightning-record-picker').forEach(item => {
            item.value = '';
            item.setCustomValidity(''); // Clear error messages
            item.reportValidity();
        });


    }

    // get ratingValues() {
    //     return this.ratingInfo?.data?.values || [];
    // }

    // accountInfo;
    // ratingInfo;
    // error;

    // recordTypeId;

    // // Wire to fetch Object Info
    // @wire(getObjectInfo, { objectApiName: ACCOUNT_OBJECT })
    // wiredAccountInfo({ error, data }) {
    //     if (data) {
    //         this.accountInfo = data;
    //         // Fetch the specific record type ID, e.g., 'Business Record Type'
    //         const recordTypeDetails = Object.values(data.recordTypeInfos).find(
    //             recordType => recordType.name === 'Business' // Change 'Business' to your desired record type
    //         );
    //         if (recordTypeDetails) {
    //             this.recordTypeId = recordTypeDetails.recordTypeId;
    //         }
    //     } else if (error) {
    //         this.error = error;
    //         this.accountInfo = undefined;
    //     }
    // }

    // // Wire to fetch Picklist Values
    // @wire(getPicklistValues, { recordTypeId: '$recordTypeId', fieldApiName: ACCOUNT_RATING })
    // wiredRatingPicklist({ error, data }) {
    //     if (data) {
    //         this.ratingInfo = data;
    //         this.error = undefined;
    //     } else if (error) {
    //         this.error = error;
    //         this.ratingInfo = undefined;
    //     }
    // }


    //     import { LightningElement, wire } from 'lwc';
    // import { getObjectInfo, getPicklistValues } from 'lightning/uiObjectInfoApi';
    // import ACCOUNT_OBJECT from '@salesforce/schema/Account';
    // import ACCOUNT_RATING from '@salesforce/schema/Account.Rating';

    // export default class FetchPicklistValues extends LightningElement {
    //     recordTypeId;
    //     ratingInfo;
    //     error;

    //     @wire(getObjectInfo, { objectApiName: ACCOUNT_OBJECT })
    //     handleObjectInfo({ data, error }) {
    //         if (data) {
    //             this.recordTypeId = Object.values(data.recordTypeInfos)
    //                 .find(rt => rt.name === 'Business')?.recordTypeId; // Replace 'Business' with your record type name
    //         }
    //         this.error = error;
    //     }

    //     @wire(getPicklistValues, { recordTypeId: '$recordTypeId', fieldApiName: ACCOUNT_RATING })
    //     handlePicklistValues({ data, error }) {
    //         this.ratingInfo = data;
    //         this.error = error;
    //     }
    // }

    //     createAccountHandler(){
    //         // let fieldError='Please Enter';
    //         // let isValid=true;
    //         // this.template.querySelectorAll('lightning-input,lightning-combobox').forEach(item=>{
    //         //     let fieldValue=item.name==='accName'? item.value.trim() : item.value;
    //         //     if(!fieldValue){
    //         //         isValid=false;
    //         //         item.setCustomValidity(fieldError+' '+item.label);
    //         //     }
    //         //     else{
    //         //         item.setCustomValidity('')
    //         //     }
    //         //     item.reportValidity();
    //         // })
    // }
}