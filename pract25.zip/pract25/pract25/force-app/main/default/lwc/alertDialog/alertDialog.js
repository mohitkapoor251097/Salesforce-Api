import { LightningElement, api } from 'lwc';

import {
    getModalClasses,
    getModalBgClasses,
    modalWindowKeyUp,
    modalWindowKeyDown,
    modalKeyDown,
    modalCloseFocus
} from 'c/modalUtils';

// Replace these with Custom Label
const CloseLabel = 'Close';
const AcceptLabel = 'Accept';
const HeaderTitle = 'Modal Header';
const FormattedMessage = 'Some modal body content.';

export default class X7sAlertDialog extends LightningElement {
    isModalOpen = false;
    handleWindowKeyDownEvent;
    handleWindowKeyUpEvent;
    handleKeyDownEvent;
    
    headerTitle = HeaderTitle;
    formattedMessage = FormattedMessage;
    closeLabel = CloseLabel;
    acceptLabel = AcceptLabel;

    connectedCallback() {
        this.handleWindowKeyDownEvent = this.handleWindowKeyDown.bind(this);
        this.handleWindowKeyUpEvent = this.handleWindowKeyUp.bind(this);
        this.handleKeyDownEvent = this.handleKeyDown.bind(this);

        window.addEventListener('keydown', this.handleWindowKeyDownEvent);
        window.addEventListener('keyup', this.handleWindowKeyUpEvent);
        this.addEventListener('keydown', this.handleKeyDownEvent);
    }

    renderedCallback() {
        if (this.isModalOpen) {
            modalCloseFocus(this.template);
        }
    }

    disconnectedCallback() {
        window.removeEventListener('keydown', this.handleWindowKeyDownEvent);
        window.removeEventListener('keyup', this.handleWindowKeyUpEvent);
        this.removeEventListener('keydown', this.handleKeyDownEvent);
    }

    get modalClasses() {
        return getModalClasses(this.isModalOpen, 'medium');
    }

    get modalBgClasses() {
        return getModalBgClasses(this.isModalOpen);
    }

    handleModalOpen() {
        this.isModalOpen = true;
    }

    handleModalClose() {
        this.isModalOpen = false;
    }

    handleWindowKeyUp(event) {
        modalWindowKeyUp(event);
    }

    handleWindowKeyDown(event) {
        modalWindowKeyDown(event);
    }

    handleKeyDown(event) {
        modalKeyDown(event, this.template);
    }
    
    handleModalAccept() {
        // Insert Accept action
        
        this.handleModalClose();
    }
}