import LightningDataTable from 'lightning/datatable';
import customButtonTemplate from './customButtonTemplate.html';

export default class CustomButtonColumn1 extends LightningDataTable {
    static customTypes = {
        customButtonColumn1: {
            template: customButtonTemplate,
            standardCellLayout: true,
            typeAttributes: ['recordId', 'onNewContact', 'onDelete']
        }
    };
}
