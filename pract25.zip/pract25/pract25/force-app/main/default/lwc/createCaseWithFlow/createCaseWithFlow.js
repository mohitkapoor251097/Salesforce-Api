import { LightningElement,track } from 'lwc';
import { ShowToastEvent } from "lightning/platformShowToastEvent";

export default class CreateCaseWithFlow extends LightningElement {

    flowName = '';
   @track caseDetail={
        subject:'',
        description:''
    }
    handleCreate() {
        let isValid = true;
        let FieldError='Please Enter'
        this.template.querySelectorAll('lightning-input').forEach(item=>{
            const fieldValue=item.value?.trim();
           const errorMessage=!fieldValue ? `${FieldError} ${item.label}` :'';
           item.setCustomValidity(errorMessage);
           item.reportValidity();

           if(errorMessage) isValid=false;
        });
        
        if(isValid) { 
            this.flowName = 'My_Auto_Launched_Flow';
        }        
    }

    handleStatusChange(event) {
        this.flowName = '';
        if (event.detail.status === "FINISHED_SCREEN") {    
            this.caseDetail.subject = '';
            this.caseDetail.description = '';        
            const evt = new ShowToastEvent({
                title: 'Success',
                message: 'Case created successfully.!',
                variant: 'success',
            });
            this.dispatchEvent(evt);
        } else if (event.detail.status === "ERROR") {            
            console.log('Error...!!!');
        }
    }
    handleChange(event){
        this.caseDetail[event.target.name] = event.detail.value;
    }

    get inputVariables() {
        return [
            {
                name: 'inputParam1',
                type: 'String',
                value: this.caseDetail.subject
            },
            {
                name: 'inputParam2',
                type: 'String',
                value: this.caseDetail.description
            }
        ];
    }
}


// handleCreate() {
//     let isValid = true;
//     let fields = this.template.querySelectorAll('lightning-input');
//     fields.forEach(field => {
//         if(!fields.checkValidity()) {
//             field.reportValidity();
//             isValid = false;
//         }
//     });
//     if(isValid) { 
//         this.flowName = 'My_Auto_Launched_Flow';
//     }        
// }