import { LightningElement ,wire} from 'lwc';
import getAccountWithOpp from '@salesforce/apex/AccountWithOppController.getAccountWithOpp';
import { NavigationMixin } from 'lightning/navigation';
import { encodeDefaultFieldValues } from 'lightning/pageReferenceUtils';
import deleteAccountWithNoOpenOpp from '@salesforce/apex/AccountWithOppController.deleteAccountWithNoOpenOpp';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import {refreshApex} from '@salesforce/apex';

export default class DisplayAccWithOpp extends NavigationMixin(LightningElement)  {

 columns = [
        { label: 'Account Name', fieldName: 'nameUrl',type:'url',typeAttributes:{
            label: { fieldName: 'accountName' },
            target: '_blank'
        } },
        { label: 'Type', fieldName: 'type', type: 'text' },
        { label: 'Billing Country', fieldName: 'country', type: 'text' },
        { label: 'Total Opportunities', fieldName: 'numberofOpp', type: 'number' },
        { 
              type:'button',
              typeAttributes:{
                label:'Create Contact',
                name:'Create Contact',
                variant:'brand',
                iconPosition:'left'
              }
    
        },
        { 
            type:'button',
            typeAttributes:{
              label:'Delete Account',
              name:'Delete Account',
              variant:'destructive',
              iconPosition:'left'
            }
  
      }
    ];

@wire(getAccountWithOpp)
accounts;

get isRecordAvailable(){
    return this.accounts.data ? true : false;
}

handleRowAction(event){
    const action = event.detail.action;
    const row = event.detail.row;
    switch (action.name) {
        case 'Create Contact':
                this.createContact(row.accountId);
            break;
        case 'Delete Account':
           this.deleteAccount(row.accountId);
            break;
}
}

createContact(accountId){
const defaultValues=encodeDefaultFieldValues({
    AccountId:accountId
})
this[NavigationMixin.Navigate]({
    type: "standard__objectPage",
    attributes: {
      objectApiName: "Contact",
      actionName: "new",
    },
    state: {
      defaultFieldValues: defaultValues,
    },
  });
}

async deleteAccount(accountId){
   try{
   await deleteAccountWithNoOpenOpp({accountId:accountId})
   await refreshApex(this.accounts);
   this.showMessage('Success','success','Account Deleted Successfully !');
   }
   catch(error){
    console.error(error);
    this.showMessage('error','error',error.body.message);
   }
}

showMessage(title,variant,message){
    this.dispatchEvent(new ShowToastEvent({
            title:title,
            variant:variant,
            message:message
        }
    ))
}

}