import { LightningElement } from 'lwc';

export default class DisplayAccountDetails extends LightningElement {

    accountId;
    changleHandler(event){
      this.accountId=event.detail.recordId;
      console.log('OUTPUT : ',this.accountId);
    }
}