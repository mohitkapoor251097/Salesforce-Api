import { LightningElement, wire, track } from 'lwc';
import { subscribe, unsubscribe, onError } from 'lightning/empApi';
import getAccounts from '@salesforce/apex/AccountController.getAccountsList';

export default class AccountDataTable extends LightningElement {
    @track accounts = [];
    subscription = {};

    columns = [
        { label: 'Name', fieldName: 'Name', type: 'text' },
        { label: 'Phone', fieldName: 'Phone', type: 'phone' }
    ];

    connectedCallback() {
        this.loadAccounts();
        this.subscribeToPlatformEvent();
    }

    loadAccounts() {
        getAccounts()
            .then(result => { this.accounts = result; })
            .catch(error => { console.error('Error fetching accounts', error); });
            
    }

    subscribeToPlatformEvent() {
        const eventChannel = '/event/Account_Update_Event__e';
//subscribe(eventChannel, replayId, callbackFunction)
//Platform Events in Salesforce use a Replay ID to keep track of events. This ID allows clients (like your LWC) to subscribe to events from a specific point in the event stream.
        subscribe(eventChannel, -1, (response) => {
            console.log('Platform event received:', response);
            this.handlePlatformEvent(response);
        }).then(subscription => {
            this.subscription = subscription;
        });

        onError(error => {
            console.error('EMP API error:', error);
        });
    }

    handlePlatformEvent(response) {
        const eventData = response.data.payload;
        const updatedId = eventData.AccountId__c;

        this.accounts = this.accounts.map(acc => 
            acc.Id === updatedId ? { ...acc, Name: eventData.UpdatedName__c, Phone: eventData.UpdatedPhone__c } : acc
        );
    }

    disconnectedCallback() {
        unsubscribe(this.subscription, () => {
            console.log('Unsubscribed from platform event');
        });
    }
}
