import { LightningElement } from 'lwc';

export default class DisplayrecordpickerAccount extends LightningElement {
    accountId;
    changeHandler(event){
        console.log('Account Id :'+ event.detail.recordId);
        this.accountId=event.detail.recordId;
    }
}