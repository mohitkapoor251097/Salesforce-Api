import { LightningElement,wire } from 'lwc';
import getAccountsData from '@salesforce/apex/AccountController.getAccountsData';
export default class ChildA extends LightningElement {

    get columns(){
        return [
            {label:'Account Name',fieldName:'Name'}
        ];
    }
    @wire(getAccountsData)
    accountsList;

    accountRecordId;
    
    handleSelection(event){
        if(event.detail.selectedRows.length>0){
            this.accountRecordId=event.detail.selectedRows[0].Id;
            console.log('OUTPUT : ',event.detail.selectedRows[0].Id);
            this.dispatchEvent(new CustomEvent('send',{
                detail:event.detail.selectedRows[0].Id
            }));
        }
    }

}