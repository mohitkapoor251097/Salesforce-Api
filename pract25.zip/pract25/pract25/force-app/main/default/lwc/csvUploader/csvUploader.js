import { LightningElement, track } from 'lwc';

export default class CsvUploader extends LightningElement {
    @track data = [];
    @track columns = [];

    handleFileUpload(event) {
        const file = event.target.files[0];
        if (file) {
            let reader = new FileReader();
            reader.onload = (e) => {
                const csv = e.target.result;
                this.processCSV(csv);
            };
            reader.readAsText(file);
        }
    }

    processCSV(csv) {
        const lines = csv.split(/\r\n|\n/);
        const headers = lines[0].split(',');

        // Set table columns dynamically
        this.columns = headers.map((header) => ({
            label: header.trim(),
            fieldName: header.trim(),
            type: 'text'
        }));

        // Process rows
        const rowData = [];
        for (let i = 1; i < lines.length; i++) {
            const row = lines[i].split(',');
            if (row.length === headers.length) {
                let rowObject = {};
                headers.forEach((header, index) => {
                    rowObject[header.trim()] = row[index].trim();
                });
                rowData.push(rowObject);
            }
        }

        this.data = rowData;
    }
}