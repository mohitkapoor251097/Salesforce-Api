import { LightningElement, api } from 'lwc';
import  LightningDataTable from 'lightning/datatable';
import customPickListEditTemplate from "./customButtons.html";
export default class CustomButtonColumn  extends LightningDataTable{
    
    static customTypes={
        customPickList:{
                            template:customPickListEditTemplate,
                            standardCellLayout:true,
                            typeAttributes: ['recordId']
               
            }
        };


       

       
}
