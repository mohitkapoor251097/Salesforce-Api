import { LightningElement, wire } from 'lwc';
import getAccountsDetails from '@salesforce/apex/AccountDetailsController.getAccountDetails'
import messageChannel from '@salesforce/messageChannel/accountdetails__c';
import { MessageContext, publish } from 'lightning/messageService';
export default class DisplayAccountWithOpp extends LightningElement {

    @wire(getAccountsDetails)
    accountDetails;

    @wire(MessageContext)
    messageContext;

    get columns(){
        return [
           {
            label:'Account Name', fieldName:'nameUrl',type:'url',
            typeAttributes:{
                label:{fieldName:'accountName'},
                target:'_blank'
            }
           },
           {
            label:'Account Type',fieldName:'accountType',type:'text'
           },
           {
            label:'Billing Country',fieldName:'accountBillingCountry',type:'text'
           },
           {
            label:'Total Opportunities',fieldName:'totalOpportunities',type:'text',sortable:true
           },
        ]
    }

    handleSelection(event){
        if(event.detail.selectedRows.length>0){
            const selectRows=event.detail.selectedRows[0].accountId;
            console.log('Selected Account Id:',selectRows);

            const payLoad={
                recordId:selectRows
            }
            publish(this.messageContext,messageChannel,payLoad);
            
        }
        
    }
}