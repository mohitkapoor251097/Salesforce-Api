import { LightningElement, track, wire } from 'lwc';
import { subscribe, unsubscribe, onError } from 'lightning/empApi';
import getAccounts from '@salesforce/apex/AccountController.getAccountsList';
import { refreshApex } from '@salesforce/apex';

export default class AccountDataTable extends LightningElement {
    @track accounts = [];
    subscription = null;
    wiredAccountsResult; // Stores the wired data for refresh
    debounceTimeout; // Timeout for debouncing

    columns = [
        { label: 'Name', fieldName: 'Name', type: 'text' },
        { label: 'Phone', fieldName: 'Phone', type: 'phone' }
    ];

    // Wire Apex method to get accounts
    @wire(getAccounts)
    wiredAccounts(result) {
        this.wiredAccountsResult = result;
        if (result.data) {
            this.accounts = result.data;
        } else if (result.error) {
            console.error('Error fetching accounts:', result.error);
        }
    }

    // Subscribe to platform events on component load
    connectedCallback() {
        this.subscribeToPlatformEvent();
    }

    subscribeToPlatformEvent() {
        const eventChannel = '/event/Account_Update_Event__e';

        subscribe(eventChannel, -1, (response) => {
            console.log('Platform event received:', response);
            this.debouncedRefresh(); // Debounced refresh to handle multiple updates
        }).then(subscription => {
            this.subscription = subscription;
        });

        onError(error => {
            console.error('EMP API Error:', error);
        });
    }

    // Debounce refreshApex to prevent excessive updates
    debouncedRefresh() {
        clearTimeout(this.debounceTimeout);
        this.debounceTimeout = setTimeout(() => {
            refreshApex(this.wiredAccountsResult);
        }, 2000); // Refresh after 2 seconds to handle multiple updates together
    }

    // Unsubscribe from platform events when component is removed
    disconnectedCallback() {
        if (this.subscription) {
            unsubscribe(this.subscription, () => {
                console.log('Unsubscribed from Platform Event');
            });
            this.subscription = null;
        }
    }
}
