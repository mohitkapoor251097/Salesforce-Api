import { LightningElement, track } from 'lwc';
import AccountData from '@salesforce/apex/AccountController.AcountCreation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
export default class AccountCreationWithApex extends NavigationMixin(LightningElement) {

    accountDetails = {
        accName: '',
        accNumber: ''
    }
    changeHandler(event) {
        //    this.accountDetails[event.target.name]=event.target.value;
        //    this.accountDetails.accNumber= this.accountDetails.accNumber.replace(/[^0-9]/g, '');
        //    event.target.value = this.inputValue;
        //   console.log('accName: ',this.accountDetails.accName); 
        //   console.log('accNumber: ',this.accountDetails.accNumber); 

        const { name, value } = event.target;

        // Assign and validate in a single step
        this.accountDetails = {
            ...this.accountDetails,
            [name]: name === 'accNumber' ? value.replace(/[^0-9]/g, '').trim() : value.trim(),
        };
        console.log('accName: ', this.accountDetails.accName);
        console.log('accNumber: ', this.accountDetails.accNumber);
    }

    createAccount() {
        let fieldError = 'Please Enter';
        let isValid = true; // Track the overall validity of fields

        // Validate all fields
        this.template.querySelectorAll('lightning-input').forEach(item => {
            let fieldLabel = item.label;
            let fieldValue = item.value;

            if (!fieldValue) {
                item.setCustomValidity(fieldError + ' ' + fieldLabel);
                isValid = false; // Mark as invalid if any field is empty
            } else {
                item.setCustomValidity(''); // Clear any previous error
            }

            item.reportValidity();
        });

        // Proceed only if all fields are valid
        if (isValid) {
            AccountData({ accountData: this.accountDetails })
                .then(result => {
                    console.log('Account Created Successfully' + JSON.stringify(result));
                    this.showMessage('success', 'Account Created Successfully', 'success');
                    this[NavigationMixin.Navigate]({
                        type: 'standard__recordPage',
                        attributes: {
                            recordId: result.Id,
                            objectApiName: 'Account',
                            actionName: 'view'
                        },

                    })
                })
                .catch(error => {
                    console.log('Error while creating account'+JSON.stringify(error));
                    this.showMessage('error', 'Something went wrong', 'error');
                });
        }
    }


    // createAccount(){
    //         let fieldError='Please Enter';
    //          this.template.querySelectorAll('lightning-input').forEach(item=>{
    //             let fieldLabel=item.label;
    //             let fieldValue=item.value;
    //             if(!fieldValue){
    //                 item.setCustomValidity(fieldError+' '+fieldLabel);
    //             }
    //             else{
    //                 item.setCustomValidity('');
    //                 console.log('vale filled');

    //                  AccountData({accountData:this.accountDetails}).then(result=>{
    //                     console.log('Account Created Successfully');
    //                     this.showMessage('success','Account Created Successfully','success');
    //                  }).catch(error=>{
    //                     console.log('Error while creating account');
    //                     this.showMessage('error','something went wrong','error');
    //                  }) 
    //             }
    //             item.reportValidity();
    //          }) 
    //     }

    showMessage(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        }));
    }

    resetHandler(){
        //this.template.querySelectorAll('lightning-input').forEach((item)=> item.value='');
      // this.template.querySelectorAll('lightning-input[data-id="inputField"]').forEach((item) =>  item.value = '');
      this.template.querySelectorAll('lightning-input[data-id="inputField"]').forEach((item) => {
        item.value = ''; // Clear the value
        item.setCustomValidity(''); // Remove the custom validity message
        item.reportValidity(); // Refresh the validity state to clear any visual styles
    })
    }

    handleFocus(event) {
        event.target.classList.add('focus-orange');
    }

    handleBlur(event) {
        event.target.classList.remove('focus-orange');
    }
}