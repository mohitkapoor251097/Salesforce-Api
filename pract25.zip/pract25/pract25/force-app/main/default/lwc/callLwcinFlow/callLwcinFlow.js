import { api, LightningElement } from 'lwc';
import {FlowAttributeChangeEvent} from 'lightning/flowSupport';
export default class CallLwcinFlow extends LightningElement {
    @api fname;
    @api lname;
    changerHandler(event){
        this.dispatchEvent(new FlowAttributeChangeEvent(event.target.name,event.target.value));
    }
}