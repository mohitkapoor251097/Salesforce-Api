import { LightningElement, track, wire } from 'lwc';
import getContacts from '@salesforce/apex/ContactDataController.getContacts';

const columns = [
    { label: 'Row Number', fieldName: 'rowNumber', type: 'number' },
    { label: 'Name', fieldName: 'Name', type: 'text' },
    { label: 'Email', fieldName: 'Email', type: 'email' }
];

export default class DatatablePagination extends LightningElement {
    @track displayedRecords = [];
    @track currentPage = 1;
    @track pageSize = 10;
    totalRecords = 0;
    allRecords = [];

    columns = columns;
    isLoading = true;

    @wire(getContacts)
    wiredContacts({ error, data }) {
        if (data) {
            this.allRecords = data;
            this.totalRecords = data.length;
            this.updateDisplayedRecords();
            this.isLoading = false;
        } else if (error) {
            console.error('Error fetching contacts:', error);
            this.isLoading = false;
        }
    }

    get totalPages() {
        return Math.ceil(this.totalRecords / this.pageSize);
    }

    updateDisplayedRecords() {
        const startIndex = (this.currentPage - 1) * this.pageSize;
        const endIndex = startIndex + this.pageSize;

        this.displayedRecords = this.allRecords.slice(startIndex, endIndex).map((record, index) => ({
            ...record,
            rowNumber: startIndex + index + 1 // Dynamic row numbering
        }));
    }

    handleNext() {
        if (this.currentPage < this.totalPages) {
            this.currentPage++;
            this.updateDisplayedRecords();
        }
    }

    handlePrevious() {
        if (this.currentPage > 1) {
            this.currentPage--;
            this.updateDisplayedRecords();
        }
    }
}
