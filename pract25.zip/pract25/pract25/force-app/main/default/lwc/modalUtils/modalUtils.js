let isShiftKeyDown = false;

/**
 * Toggle show/hide modal classes
 * @param {boolean} showModal
 * @param {undefined|'small'|'medium'|'large'}size
 * @returns {string}
 */
export const getModalClasses = (showModal, size = undefined) => {
    let classes = 'slds-modal';
    classes += showModal ? ' slds-fade-in-open' : '';
    classes += size === 'small' ? ' slds-modal_small' : '';
    classes += size === 'medium' ? ' slds-modal_medium' : '';
    classes += size === 'large' ? ' slds-modal_large' : '';
    return classes;
};

/**
 * Toggle show/hide backdrop modal classes
 * @param showModal
 * @returns {string}
 */
export const getModalBgClasses = (showModal) => {
    const defaultClass = 'slds-backdrop';
    return showModal ? `${defaultClass} slds-backdrop_open` : defaultClass;
};

export const modalWindowKeyUp = (event) => {
    // Shift
    if (event.key === 'Shift') {
        isShiftKeyDown = false;
    }
};

export const modalWindowKeyDown = (event) => {
    // Shift
    if (event.key === 'Shift') {
        isShiftKeyDown = true;
    }
};

export const modalKeyDown = (event, template) => {
    /** @type {HTMLElement} */
    const activeEl = template.activeElement;

    /** @type {HTMLElement} */
    const closeEl = template.querySelector('.slds-modal__close');

    /** @type {HTMLElement[]} */
    const focusEls = template.querySelectorAll(
        'a[href], button, input, textarea, select, details, [tabindex]:not([tabindex="-1"])'
    );

    /** @type {HTMLElement} */
    const lastEl =
        focusEls?.length > 0 ? focusEls[focusEls.length - 1] : closeEl;

    // Escape
    if (event.key === 'Escape') {
        this.close();
    }

    // Tab
    if (event.key === 'Tab' && activeEl) {
        if (!isShiftKeyDown && activeEl === lastEl) {
            event.preventDefault();
            closeEl.focus();
        } else if (isShiftKeyDown && activeEl === closeEl) {
            event.preventDefault();
            lastEl.focus();
        }
    }
};

/**
 * Focus the Close Button
 * @param template
 */
export const modalCloseFocus = (template) => {
    /** @type {HTMLElement} */
    const closeEl = template.querySelector('.slds-modal__close');

    if (closeEl) {
        closeEl.focus();
    }
};