import { LightningElement } from 'lwc';

export default class GoogleBooksDetail extends LightningElement {

    endPoint = 'https://www.googleapis.com/books/v1/volumes?q=';
    books = [];
    bookName;
    isLoading = false;
    handleChange(event) {

        this.bookName = event.target.value.trim();
        this.books = this.bookName.length ? this.books : [];

    }

    async fetchBooks() {
        console.log('OUTPUT : ', `${this.endPoint}${this.bookName}`);
        let fieldError = 'Please Enter';
        let isValid = true;
        this.template.querySelectorAll('lightning-input').forEach(item => {
            let fieldValue = item.value?.trim();
            let errorMessage = !fieldValue ? `${fieldError} ${item.label}` : '';
            item.setCustomValidity(errorMessage);
            item.reportValidity();
            if (errorMessage) isValid = false;
        });
        if (isValid) {
            this.isLoading = true;
            const data = await this.fetchData(`${this.endPoint}${this.bookName}`, 'GET');
            if (data) {
                console.log('data item' + data.items);
                try {
                    // this.books=data.items || []; 
                    this.books = data.items?.map(book => ({
                        id: book.id,
                        title: book.volumeInfo?.title || 'No Title Available',
                        publisher: book.volumeInfo?.publisher || 'Unknown Publisher',
                        thumbnail: book.volumeInfo?.imageLinks?.smallThumbnail || 'http://books.google.com/books/content?id=Je7LtAEACAAJ&printsec=frontcover&img=1&zoom=5&source=gbs_api'
                    })) || [];
                }
                finally {
                    this.isLoading = false;
                }
            }
        }
    }

    async fetchData(url, methodType) {
        try {
            const response = await fetch(url, {
                method: methodType,
                headers: { 'Content-Type': 'application/json' },
            });
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return await response.json();
        } catch (error) {
            console.error(`Error fetching data from ${url}:`, error);
            // this.error = error.message;
            return null;
        }
    }
}



// import { LightningElement, track } from 'lwc';

// export default class GoogleBooksDetail extends LightningElement {
//     endPoint = 'https://www.googleapis.com/books/v1/volumes?q=';
//     @track books = [];
//     @track bookName;
//     @track isLoading = false; // Spinner control
//     @track error;

//     handleChange(event) {
//         this.bookName = event.target.value;
//         this.books = this.bookName.length ? this.books : [];
//     }

//     async fetchBooks() {
//         let fieldError = 'Please Enter';
//         let isValid = true;

//         this.template.querySelectorAll('lightning-input').forEach(item => {
//             let fieldValue = item.value?.trim();
//             let errorMessage = !fieldValue ? `${fieldError} ${item.label}` : '';
//             item.setCustomValidity(errorMessage);
//             item.reportValidity();
//             if (errorMessage) isValid = false;
//         });

//         if (isValid) {
//            // this.isLoading = true; // Show spinner

//             try {
//                 const data = await this.fetchData(`${this.endPoint}${this.bookName}`, 'GET');
//                 if (data) {
//                     this.books = data.items || [];
//                 }
//             } 
//             catch(error){
//                 console.error('Error fetching data:', error.message);
//                 this.error = error.message;
//             }
//             finally {
//                // this.isLoading = false; // Hide spinner
//             }
//         }
//     }

//     async fetchData(url, methodType) {
//         try {
//             const response = await fetch(url, {
//                 method: methodType,
//                 headers: { 'Content-Type': 'application/json' },
//             });
//             if (!response.ok) {
//                 throw new Error(`HTTP error! Status: ${response.status}`);
//             }
//             return await response.json();
//         } catch (error) {
//             console.error(`Error fetching data from ${url}:`, error);
//             this.error = error.message;
//             return null;
//         }
//     }
// }
