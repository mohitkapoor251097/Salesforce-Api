({
    doin : function(component, event, helper){
        var action = component.get("c.getAccounts");
        var self = this;
        action.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set("v.currentObject", actionResult.getReturnValue());
            }            
        });
        $A.enqueueAction(action);
    },
    
   /*    handleClick : function(component, event, helper) {
    component.set('v.visibile','true');
    var a = component.get('v.it1');
    var b = component.get('v.it2'); 
    var c = component.set('v.it1',b);  
    var d = component.set('v.it2',b+2);  
       // alert(a);
        if(a==2){
            component.set('v.visibile11','true');
    
        }
        console.log('is ki jcb ki ',component.find('inputCmp')[0].set('v.value','cdddf'));
        component.set('v.progress',"step2")
       
}*/
        
 
 })