({
    doInit : function(component, event, helper) {
        var strArray = ['Single', 'Bulk' , 'Cancel'];
        component.set('v.recVal',strArray);
        let urlString = window.location.href;
        console.log('urlString '+urlString);
        var lastItem = urlString.split("/").pop();
console.log('lastItem'+lastItem); 
var getUrl = component.get('c.getmydomain');
     $A.enqueueAction(getUrl);

    },
    launchFlow : function(component, event, helper) {
        
         var myPageRef = component.get("v.pageReference");
        console.log('myPageRef:  ',myPageRef.state);
        console.log('event',event);
        console.log('event',event.target.name);
        console.log('event',event.target.title);
        console.log('event',event.target.type);
        var maximus =document.getElementById("maximus");
        maximus.style.display = 'block';
        var inputVariables = [];
        if(event.target.name == 'Single Scam'){
            /* var flow = component.find("flow");
            flow.startFlow("Test_Radio", inputVariables);*/
            var divCmp = component.find("MainDiv");
            
            
            $A.createComponent("lightning:flow",
                               {
                                   "aura:id":"Flow" ,
                                   "class" : "flowClass"
                               }, 
                               function(newTB){
                                   var body = divCmp.get("v.body");
                                    newTB.startFlow("Test_Radio", inputVariables);
                                   body.push(newTB);
                                   console.log('newTB',newTB);
                                  
                                   divCmp.set("v.body", body);
                               });
            
            console.log('flow clsss',document.getElementsByClassName('flowClass'));
            var flow = document.getElementsByClassName('flowClass');
            console.log('floe ',flow);
          //  var flow = component.find("Flow");
            //flow.startFlow("Test_Radio", inputVariables);
            
        }
    },
    
    closeFlow :  function(component, event, helper) {
         var inputVariables = [];
        var divCmp = component.find("MainDiv");
        divCmp.set("v.body", []);
        $A.createComponent("lightning:flow",
                           {
                               "aura:id":"Flow"                     
                           }, 
                           function(newTB){
                                newTB.startFlow("name_test_Flow", inputVariables);
                               var body = divCmp.get("v.body");
                               body.push(newTB);
                               divCmp.set("v.body", body);
                           });
        
        /*var flow = component.find("Flow");
        var inputVariables = [];
        flow.startFlow("name_test_Flow", inputVariables);*/
        
        
        
    }
    
})