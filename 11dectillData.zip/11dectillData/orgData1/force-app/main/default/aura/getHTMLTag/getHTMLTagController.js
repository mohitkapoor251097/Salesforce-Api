({
	handleClick : function(component, event, helper) {
		console.log(component); 
	}
})