({
    add : function(component, event){
        var h1 = component.find('myTimer'),
            seconds = 0, minutes = 0, hours = 0,
            t;
            
        console.log(h1);
        
        function adder() {
            seconds++;
            if (seconds >= 60) {
                seconds = 0;
                minutes++;
                if (minutes >= 60) {
                    minutes = 0;
                    hours++;
                }
            } 
            
            h1.textContent = (hours ? (hours > 9 ? hours : "0" + hours) : "00") + ":" + (minutes ? (minutes > 9 ? minutes : "0" + minutes) : "00") + ":" + (seconds > 9 ? seconds : "0" + seconds);
            component.set("v.runningTimer",h1.textContent);      
            timer();
        } 
        function timer() {
            t = setTimeout(adder, 1000);
          component.set("v.stopTimer",t);
        }
        timer();
        
        var mydate1 = new Date();
        var h = mydate1.getHours();
        var m = mydate1.getMinutes();
        var s = mydate1.getSeconds();
        
        component.set('v.StartTime',h  +':'+ m + ':' + s); 
        
       
        /* Start button 
        start.onclick = timer;
        
        /* Stop button 
        stop.onclick = function() {
            clearTimeout(t);
        }runningTimer
        
        /* Clear button 
        clear.onclick = function() {
            h1.textContent = "00:00:00";
            seconds = 0; minutes = 0; hours = 0;
        }*/
    },
     remove : function(component, event){
         var btnmsg = component.get('v.stopTimer');
         clearTimeout(btnmsg);
         var mydate1 = new Date();
         var h = mydate1.getHours();
         var m = mydate1.getMinutes();
         var s = mydate1.getSeconds();
         component.set('v.StopTime',h  +':'+ m + ':' + s); 
     }
})