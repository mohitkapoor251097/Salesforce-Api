({
    clickStart: function(component, event, helper) {
          
           helper.add(component, event);
    },
    clickStop: function(component, event, helper) {
       
           helper.remove(component, event);

    },
    openUtility : function(component, event, helper) {
        var utilityAPI = component.find("utilitybar");
        utilityAPI.openUtility();
    }
})