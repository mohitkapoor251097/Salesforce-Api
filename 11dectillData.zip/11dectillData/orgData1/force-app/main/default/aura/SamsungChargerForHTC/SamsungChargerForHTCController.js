({
  createHTC : function(component, event,helper) {
    var newHtc = component.get("v.HTCport");
    var action = component.get("c.insertHTC");
    var idOfsamsung = component.get("v.recordId");

    action.setParams({ 
        "objHtc": newHtc,
        "SamsungId": idOfsamsung
    });
    
    action.setCallback(this, function(a) {
           var state = a.getState();
            if (state === "SUCCESS") {
                var name = a.getReturnValue();
               alert("hello from here"+name);
               
            }
        });
     
      // window.open("/c/SamsungChargerForHTCApp.app?recordId=a0Y7F000003qPea&Type=12334", '_blank');
   	//helper.getSamsungid(component, idOfsamsung);
    $A.enqueueAction(action)
},
    navigate : function(component, event, helper) {
	  var root = location.protocol + '//' + location.host;
    //Find the text value of the component with aura:id set to "address"
    //var address = component.find("address").get("v.value");
        window.open("/c/helloExpensesApp.app", '_blank');
  /*  var urlEvent = $A.get("e.force:navigateToURL");
        console.log(urlEvent.setParams);
    urlEvent.setParams({
      "url": "skbteqforce:helloExpenses"
    });
    urlEvent.fire();*/
}
})