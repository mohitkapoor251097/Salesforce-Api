({
	getSamsungid : function(component, id) {
		 var setIdsam = component.get("v.id");
         var action = component.get("c.getSamsungId");
        action.setParams({ 
            "samsungId": setIdsam
        });
		console.log(setIdsam);        
        action.setCallback(this, function(a) {
               var state = a.getState();
                if (state === "SUCCESS") {
                    var name = a.getReturnValue();
                   alert("hello from here"+name);
                }
            });
        $A.enqueueAction(action)
        }
})