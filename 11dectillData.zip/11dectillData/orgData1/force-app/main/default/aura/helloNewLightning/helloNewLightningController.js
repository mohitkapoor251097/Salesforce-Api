({
    update : function(component,event,helper) {
        component.find("editForm").submit();
        component.set('v.editForm' , false);
        component.set('v.viewForm' , true);
    },
    visibilty : function(component,event,helper){
        component.set('v.viewForm' , false);
        component.set('v.editForm',true);
    }
})