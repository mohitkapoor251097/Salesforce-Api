({
	hidePopup : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        console.log('evt'+evt);
        evt.setParams({
            componentDef: "c:Utility"
            //componentAttributes :{ }
        });
        
        evt.fire();
    }
	
})