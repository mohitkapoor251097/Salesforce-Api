({
	doInit : function(component) {
        console.log("relRecordTiles is starting up...");
        
        var action = component.get('c.getResults');
        //Set the variables for the server side controller
        console.log('currentID'+component.get("v.currentID"));
        action.setParams({
            currentID : component.get("v.currentID"),
            objectName : component.get("v.objectName"),
            lookupField : component.get("v.lookupField"),
            field1 : component.get("v.field1"),
            field2 : component.get("v.field2"),
            field3 : component.get("v.field3")
            
        });        
        // Set up the callback
        action.setCallback(this, $A.getCallback(function (response) {
           
            var state = response.getState();
            var resultsToast = $A.get("e.force:showToast");
            if(state === "SUCCESS"){
                 
                //if successful stores query results in serverResult
                component.set('v.serverResult', response.getReturnValue());
                component.set('v.count', response.getReturnValue().length);
                /*var svgRichText = component.find("svgRichText");
                var count = component.get('v.count');
                var strCount = "<b>Contacts("+count+")</b>";
                svgRichText.set("v.value",strCount);
                var richTextagain = svgRichText.get("v.value");
                console.log('richTextagain'+strCount);
                console.log('currency data is:' + response.getReturnValue().length);
                console.log('currency data is:' + JSON.stringify(response.getReturnValue()));*/
                // $A.get('e.force:refreshView').fire();
                component.set("v.currentObject",' ');
            } else if (state === "ERROR") {
                //otherwise write errors to console for debugging
                resultsToast.setParams({
                    "title": "Error",
                    "message": "relRecordTiles failed to load due to: " 
                });
                resultsToast.fire();
                var errors = response.getError();
                console.error(errors);
            }
        }));
        
        $A.enqueueAction(action);
    },
})