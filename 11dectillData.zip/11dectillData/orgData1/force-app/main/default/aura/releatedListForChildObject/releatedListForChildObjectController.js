({
    doInit : function(component, event, helper) {
        console.log("relRecordTiles is starting up...");   
        var action = component.get('c.getResults');
        //Set the variables for the server side controller
        console.log('currentID'+component.get("v.currentID"));
        action.setParams({
            currentID : component.get("v.currentID"),
            objectName : component.get("v.objectName"),
            lookupField : component.get("v.lookupField"),
            field1 : component.get("v.field1"),
            field2 : component.get("v.field2"),
            field3 : component.get("v.field3")
            
        });        
        // Set up the callback
        action.setCallback(this, $A.getCallback(function (response) {
            var state = response.getState();
            var resultsToast = $A.get("e.force:showToast");
            if(state === "SUCCESS"){
                alert(response);
            console.log('maximum ',response);
                //if successful stores query results in serverResult
                component.set('v.serverResult', response.getReturnValue());
                component.set('v.count', response.getReturnValue().length);
                /*var svgRichText = component.find("svgRichText");
                var count = component.get('v.count');
                var strCount = "<b>Contacts("+count+")</b>";
                svgRichText.set("v.value",strCount);
                var richTextagain = svgRichText.get("v.value");
                console.log('richTextagain'+strCount);
                console.log('currency data is:' + response.getReturnValue().length);
                console.log('currency data is:' + JSON.stringify(response.getReturnValue()));*/
            } else if (state === "ERROR") {
                //otherwise write errors to console for debugging
                resultsToast.setParams({
                    "title": "Error",
                    "message": "relRecordTiles failed to load due to: " 
                });
                resultsToast.fire();
                var errors = response.getError();
                console.error(errors);
            }
        }));
        
        $A.enqueueAction(action);
    },
    
    showPopup : function(component, event, helper){
        
        var getParentObjectName = component.get('c.getParentObjectName');
        
        getParentObjectName.setParams({
            parentObjectId : component.get("v.parentObjectId"),
            parentObjectName : component.get("v.parentObjectName"),
            valueofparentObjectId : component.get("v.currentID")
        });
        
        getParentObjectName.setCallback(this, $A.getCallback(function (response) {
            var state = response.getState();
            var resultsToast = $A.get("e.force:showToast");
            if(state === "SUCCESS"){
                //if successful stores query results in serverResult
                console.log('accountname'+response.getReturnValue());
                var accID = response.getReturnValue();
                var Accountname = component.find('Accountname');
                Accountname.set('v.value', accID);
                
            } else if (state === "ERROR") {
                //otherwise write errors to console for debugging
                resultsToast.setParams({
                    "title": "Error",
                    "message": "relRecordTiles failed to load due to: "
                });
                resultsToast.fire();
                var errors = response.getError();
                console.error(errors);
            }
        }));
        component.set("v.showCmp", 'block');
         $A.enqueueAction(getParentObjectName);
     },
    hidePopup : function(component, event, helper){
        
        var insertContact = component.get('c.insertContact');
        
        insertContact.setParams({
            
            
            objContact : component.get("v.currentObject"),
            accountId : component.get("v.currentID")
            
        });
        
        insertContact.setCallback(this, $A.getCallback(function (response) {
            console.log(response.getState());
           // $A.get('e.force:refreshView').fire();
            //var state = response.getState();
            //var resultsToast = $A.get("e.force:showToast");
            //if(state === "SUCCESS"){
                //if successful stores query results in serverResult
               //var aa = component.get(response.getReturnValue());
                //alert('aa');
                
            //} 
            
            /*else if (state === "ERROR") {
                //otherwise write errors to console for debugging
                resultsToast.setParams({
                    "title": "Error",
                    "message": "relRecordTiles failed to load due to: "
                });
                //resultsToast.fire();
             //   var errors = response.getError();
                //console.error(errors);
            }*/
            
            helper.doInit(component);
        }));
        component.set("v.showCmp", 'none');
        
        $A.enqueueAction(insertContact);
     },
    
    hidePopupCancel : function(component, event, helper){
        
        component.set("v.showCmp", 'none');
    }
   
})