({
  init : function (cmp) {
    var flow = cmp.find("flowData");
    flow.startFlow("Survey_customers");
  }
})