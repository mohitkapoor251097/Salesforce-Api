({
    doInit : function(component, event, helper) {
        
        var action = component.get("c.getPositionRecords");
        
        //Setting the Callback
        action.setCallback(this,function(a){
            //get the response state
            var state = a.getState();
            
            //check if result is successfull
            if(state == "SUCCESS"){
                var result = a.getReturnValue();
                if(!$A.util.isEmpty(result) && !$A.util.isUndefined(result))
                    component.set("v.lstPositions",result);
            } else if(state == "ERROR"){
                var errors = response.getError();
                var errorMessage ;
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        errorMessage = "Error message: " + errors[0].message ;
                        console.log(errorMessage);
                        
                    }
                } else {
                    errorMessage = 'Unknown error.Please Contact your System Admin.'
                    console.log("errorMessage");
                }
            }
        });
        
        $A.enqueueAction(action);
    },
    
    /*onrender : function(component, event, helper) {
           component.find("lastname").set("v.label",'LastName');
           component.find("firstname").set("v.label",'FirstName');
           use handler = render for after page reload remains same as doinit handler
    },*/
    
    handleClick : function(component, event, helper) {
        
        /* var a = component.get('v.it1');
    var b = component.get('v.it2'); 
    var c = component.set('v.it1',b);  
    var d = component.set('v.it2',b+1);
    var e = component.get('v.it3');
    var f = component.get('v.it4'); 
    var g = component.set('v.it3',f);  
    var h = component.set('v.it4',f+1);*/    
        var wrap = component.get('v.lstPositions');
        //var a = component.get('v.ind1');
        var b = component.get('v.ind2');   
        //var c = component.set('v.ind1',a+2);
        //var d = component.set('v.ind2',b+2);
        component.set('v.progress',"step2") ;
        // alert(component.get('v.lstPositions')[b].flabel + '----'+ b) ;
        var abc = component.get('v.lstPositions')[b].flabel ;
        console.log('----abc'+abc) ;
        for(var i = 0 ; i < 2 ; i++)

        {
            // if(b != 0)
            //b = b + 1 ;
            alert(component.get('v.lstPositions')[b].flabel + '----'+ b) ;
            
            $A.createComponent('lightning:input',
                               {
                                   label : component.get('v.lstPositions')[b+1].flabel,
                                   value : component.get('v.lstPositions')[b]//,
                                   // label : component.get('v.lstPositions')[a].flabel,
                                   // value : component.get('v.lstPositions')[a] 
                               },
                               
                               function(newInput, status, errorMessage){
                                   //Add the new button to the body array
                                   if (status === "SUCCESS") {
                                       var body = component.get("v.body");
                                       body.push(newInput);
                                       component.set("v.body", body);
                                   }
                                   else if (status === "INCOMPLETE") {
                                       console.log("No response from server or client is offline.")
                                       // Show offline error
                                   }
                                       else if (status === "ERROR") {
                                           console.log("Error: " + errorMessage);
                                           // Show error message
                                       }
                               }) ;
            b = b + 1 ;
            component.set('v.ind2',b) ;
            //if(b == 0)
            
            
            
        }
        component.set('v.loaded', !component.get('v.loaded'));
       
    },
    
    delete : function(component, event, helper) {
    console.log('errorMessage');
     var lstPositions = component.get("v.lstPositions");
       
       // if(!$A.util.isEmpty(lstPositions) && !$A.util.isUndefined(lstPositions)){
             // var wrapper = new object();
              var check = component.find('index');
      
             var positionRecords = JSON.stringify(lstPositions);
            var action = component.get("c.Del");
                                  
            action.setParams({
                positionRecords : positionRecords
            });
            
            action.setCallback(this,function(a){
              
                var state = a.getState();
                
                //check if result is successfull
                if(state == "SUCCESS"){
                    
                    alert('Success in calling server side action');
                    
                } else if(state == "ERROR"){
                    alert('Error in calling server side action');
                }
            });
                 
            $A.enqueueAction(action);
            
        //}
        
        
    },
        checkk : function(component, event, helper) {

            var checkbox = event.getSource();
            console.log('checkbox',checkbox);
    		console.log(checkbox.get("v.value"));

            if(checkbox.get("v.value")) {
                var index = checkbox.get('v.label');
                console.log('index'+index+1);
                let checkboxs = component.find('index');
                checkboxs.forEach(function(e,i) { 
                    
                    //console.log('fffff'+i);
                    if(index == i){
                        checkboxs = e.set('v.value',true);
                        
                    }else{
                        checkboxs = e.set('v.value',false);
                    }
                
                })
            
            }  
              
            },
                
               /* checkkk : function(component, event, helper) {
                    var checkboxType = event.target.getAttribute('data-target');
                    var checkboxVal = event.target.checked;
                   /*if(checkboxVal === true) {
                        var index =  event.target.getAttribute('data-text');
                        console.log('index'+index);
                         console.log('checkboxType'+checkboxType);
                    }*/
                    /*if(checkboxType == 'plaid') {
                        if(checkboxVal === true) {
                        $(".plaid-chk1").prop("checked", false);
                        $(".plaid-chk2").prop("checked", false);
                    }
                    }
                    else if(checkboxType == 'plaid1'){
                        if(checkboxVal === true) {
                          $(".plaid-chk").prop("checked", false);
                         $(".plaid-chk2").prop("checked", false);   
                        }
                    }
                        else{
                            if(checkboxType == 'plaid2'){
                        if(checkboxVal === true) {
                          $(".plaid-chk").prop("checked", false);
                         $(".plaid-chk1").prop("checked", false);   
                        }
                    }
                            
                        }
                    }*/
            
 
});
        
        /* insert whole object by sending it to class
  var objVetterLead = component.get('v.objvetterLead');
        objVetterLead.Employment_Status__c = component.find("status").get("v.value");
        objVetterLead.Branch_of_Service__c = component.find("branch").get("v.value");
        objVetterLead.Current_Mili__c = component.find("Current").get("v.value");
        objVetterLead.Current_Rank__c = component.find("rank").get("v.value");
        objVetterLead.State__c = component.find("State").get("v.value");
        objVetterLead.Country__c = component.find("Country").get("v.value");
        objVetterLead.Primary_Country__c = component.find("Primary").get("v.value");
        objVetterLead.Secondary_Country__c = component.find("Secondary").get("v.value");
        
        var action = component.get("c.insertVetterRecord");
     	console.log('>>>>>>>>>>objVetterLead>>',objVetterLead);
        action.setParams({ objLead : objVetterLead,dateofbirth :component.get("v.dateofbirth")
                        });*/
        
        //window.open(window.location.origin+'/c/SignupFormApp.app','_blank');
        /*<div class="slds-p-bottom_xx-small"></div>
        <lightning:card title="">
            <div class="slds-hide" aura:id="newButtonDiv">
                <c:GPS_COMP_AdvancedProvider></c:GPS_COMP_AdvancedProvider>
            </div>           
        </lightning:card>*/
        /*advancedSearch : function (component,event,helper) {
    var newButton = c.find("newButtonDiv");
    $A.util.toggleClass(newButton, "slds-show");      
}advancedSearch = button which run on onclick eventDisplayPositionRecords
 */
        // $A.get('$label.c.labelname'+'/apex/abc')
        // ------------CHECKBOX_--------------------------------
/*
window.setTimeout(
    $A.getCallback(function() {
        // smth after two seconds
        // check component.isValid() if you want to work with component
    }), 2000
);
}

 executePlaidApi :  function(component,event,helper,varPublicId){
      console.log('executePlaidApi');
        console.log(varPublicId);
        var action = component.get('c.plaidAccountDetails');
     	action.setParams({ strPublicId : varPublicId});
		action.setCallback(component, function(response){
            console.log('----abc') ;
            var state = response.getState(); 
            console.log(state) ;
               console.log('>>>>>>>>>>>>>>>>>>',response.getReturnValue());
            if(state == 'SUCCESS') {
               var records = response.getReturnValue();
                console.log('records>>>>>>>>>>',records) ;
                if(records != null && records != '' && records != undefined) {
                 console.log('>>>>>>>>>>>>>>>>>>',records);
                 var timeout = window.setTimeout($A.getCallback(function(){
                component.set('v.objFunding',records);
            	}), 1000);
                    
                }
           
            }});
        
                    
         $A.enqueueAction(action) ;  
        
    }
})*/