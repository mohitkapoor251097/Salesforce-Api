import { LightningElement, wire, track,api } from 'lwc';
import getContactList from '@salesforce/apex/getAccountRecord.getContactList';
import { deleteRecord } from 'lightning/uiRecordApi';
import { refreshApex } from '@salesforce/apex';

export default class CoustimizeAllRecords extends LightningElement {
    @track options;
    @api options1;
    @track fields = ['Name','Phone','Rating','Industry'];
    @track createRcTrue = false;
    @track getVal = 'wow';
    
    @wire(getContactList)
    opptiesOverAmount;
    
   
    
    constructor() {
        super();
        
       getContactList().then(result => {
            console.log(' result : ',result);
            //this.options = result;
            this.options1 = result;
        })
        .catch(error => {
            this.error = error;
            console.log(' error : ',error);
        });
    }

    getFilterValue(event){
        console.log('Name '+event.target.value);
        if(event.target.value.trim() == ''){
            console.log('Name ok :'+event.target.value);
           this.opptiesOverAmount.data = this.options1;
        }else{
            
         this.opptiesOverAmount.data = this.options1.filter(item => (item.Name.toUpperCase()).includes((event.target.value).toUpperCase()));//fields.Name.value.includes(event.target.value))
        }
    }


  /* DeleteAccount(event){
        console.log('this updat : event ',event.target.dataset.index);
        console.log('this updat : event ',this.options1[event.target.dataset.index].Id);
        console.log('this updat : event ',this.options1);
        const recordId = this.options[event.target.dataset.index].Id;
        this.options = this.options.filter(item => !item.Id.includes(recordId));
        this.options1 = this.options1.filter(item => !item.Id.includes(recordId));
        deleteRecord(recordId);


       
        console.log('this updat : event ', typeof this.options1 );
        
    }*/

    deletAllAccount(){
        
        const inputFields =  this.template.querySelectorAll('.clsCheckbox');
        const getId = [];
        inputFields.forEach(field => {
            
            if(field.checked == true){
                getId.push(this.opptiesOverAmount.data[field.dataset.index].Id);//field.dataset.index);
                console.log(' if true red ',this.opptiesOverAmount.data[field.dataset.index].Name);
                console.log(' if true red ',this.opptiesOverAmount.data[field.dataset.index].Id);
            }
        });

        console.log('getId ',getId);
        getId.forEach( item => {
           
            const recordId = item;
            this.opptiesOverAmount.data = this.opptiesOverAmount.data.filter(recId => !recId.Id.includes(recordId));
            this.options1 = this.options1.filter(recId => !recId.Id.includes(recordId));
            deleteRecord(recordId);
        })
       
    }
    showForm(){
        this.createRcTrue = true;
    }
    createRecord(event){
      
        this.template.querySelector('lightning-record-edit-form').submit(event.detail.fields);
        
      
       this.createRcTrue = false;

      
       
    }
   
    refreshData(){
      console.log('bye');
      refreshApex(this.opptiesOverAmount);
       
    }

maximum(){
    return refreshApex(this.opptiesOverAmount);;
}
    intervalFun(event){
       
        console.log('init');
        this.maximum()
        .then(result => {
            console.log('1st then');
            
            /* or any other function that returns promise */
            console.log('init',event);
            return this.promiseFunc(5000);
        })
        .then(value => {
            console.log('2nd then executes after 3 seconds , value: ' + value);
            //refreshApex(this.opptiesOverAmount);
            this.intervalFun(event);
        })
        .catch(error => {
            this.error = error;
        })
        .finally(() => {
            this.isLoaded = true;
        });

            
    }

    promiseFunc(x) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                resolve('foo');
            }, x);
        });
    }
}