/* eslint-disable no-console */
import { LightningElement, wire, track } from 'lwc';
import { getListUi } from 'lightning/uiListApi';
import CONTACT_OBJECT from "@salesforce/schema/Contact";

export default class ContactAllListViews extends LightningElement {
    showLists;
    mylist = this.template.querySelector("#myList");
    @track options;
    @track listVal;
    @track listViewApiName;

    @wire(getListUi, { objectApiName: CONTACT_OBJECT }) listView({error, data}){
        if(error){
            console.log('error',error);
        }   
        if(data){
            this.showLists = data;
            console.log(data);
            console.log('count ',data.lists);
            this.options = data.lists;
            this.listVal = data.lists;
            /*this.options = this.showLists.lists.map((v) => {
                return {
                    id: v.id,
                    name: v.apiName
                }
            });*/
        }
        this.listViewApiName = 'AllContacts';
    }
    
    listViewRecord(event) {
        console.log('this.listViewApiName : ', event.target.value)
        this.listViewApiName = event.target.value;
        console.log('2this.listViewApiName : ', this.listViewApiName)
    }
    @wire(getListUi, { objectApiName: CONTACT_OBJECT, listViewApiName : '$listViewApiName',pageSize: 1332 }) listViewData;
}