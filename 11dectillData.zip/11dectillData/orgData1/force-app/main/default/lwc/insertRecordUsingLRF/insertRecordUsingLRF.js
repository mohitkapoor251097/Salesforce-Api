import { LightningElement } from 'lwc';

/**
 * Creates Account records.
 */
export default class InsertRecordUsingLRF extends LightningElement {

    accountObject = 'Account';
    accountFields = ['Name', 'Phone'];
}