/* eslint-disable no-console */
import { LightningElement, track } from 'lwc';
import { createRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import NAME_FIELD from '@salesforce/schema/Account.Name';
import PHONE_FIELD from '@salesforce/schema/Account.Phone';

export default class CreateNewAccountLWC extends LightningElement {
    @track name;
    @track phone;
    @track accountId;

 onchangeHandle(event){
     if(event.target.label === 'Name'){
        this.name = event.target.value;
     }
     if(event.target.label === 'Phone'){
        this.phone = event.target.value;
     }
        
    console.log('event',event.target.label);
 }
    createAccount() {
        
        console.log('name ',this.name);
        console.log('phone ',this.phone);

        const fields = {};
        fields[NAME_FIELD.fieldApiName] = this.name;
        fields[PHONE_FIELD.fieldApiName] = this.phone;

        const recordInput = { apiName: ACCOUNT_OBJECT.objectApiName, fields };
        createRecord(recordInput)       
            .then(account => {
                console.log('account n ',account);
                this.accountId = account.id;
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Account created',
                        variant: 'success',
                    }),
                );
            })
            .catch(error => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error creating record',
                        message: error.body.message,
                        variant: 'error',
                    }),
                );
            });
            console.log('Account',ACCOUNT_OBJECT);
    }
}