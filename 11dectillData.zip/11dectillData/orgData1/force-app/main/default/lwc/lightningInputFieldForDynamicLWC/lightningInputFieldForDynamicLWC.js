/* eslint-disable no-console */
import { LightningElement, wire, track } from 'lwc';
import accounFields from "@salesforce/apex/dynamicFieldForLwc.lstField";

export default class LightningInputFieldForDynamicLWC extends LightningElement {
     
    @track objectName = 'Account';
    @track allFieldArray = [];
    @track limitedField = [];
    @track countVar = 1;
    @track accountId = [];
    @track colorName = '{color: red}';
    @wire(accounFields, { objectName : '$objectName'})allfield({error, data}){
        if(error){
            console.log('error',error);
        }   
        if(data){
            this.allFieldArray = data;
            console.log('error',data);
            this.limitedField.push(this.allFieldArray[0]);
        }
    }
    addRow(){
        
        this.limitedField.push(this.allFieldArray[this.countVar]);
        this.countVar++;
    }
    handleSubmit(event){
       
        // eslint-disable-next-line no-console console.log('currentUrl',this.urlVal);
        console.log('form ',this.template.querySelectorAll('lightning-record-edit-form'))
        const inputFields =  this.template.querySelectorAll('lightning-record-edit-form');
        inputFields.forEach(field => {
            field.submit(event.detail.fields);
            console.log('event.detail.fields',field);
        });
        console.log('value of ',event);
    }

    
   handleSuccess(event) {
       this.accountId.push(event.detail.id);
       console.log('accountId',this.accountId);
       console.log('type of this accountID',typeof this.accountId);
   }
}