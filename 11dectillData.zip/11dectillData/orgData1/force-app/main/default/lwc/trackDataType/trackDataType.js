import { LightningElement, track } from 'lwc';

export default class TrackDataType extends LightningElement {
    @track getNum;
   isNumber(event){
        console.log(' set '+event.target.value);
        this.getNum = event.target.value;
    }

   

    checkVal(){
        var regex = new RegExp('^[0-9]*$');
        console.log(this.getNum);
        console.log(regex.test(this.getNum));
        const classVal = this.template.querySelector('.getName');
        classVal.style.display = 'block';
        console.log('classVal'+classVal);
    }
}