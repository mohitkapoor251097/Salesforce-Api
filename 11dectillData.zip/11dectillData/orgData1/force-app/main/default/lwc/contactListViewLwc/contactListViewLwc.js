/* eslint-disable no-console */
import { LightningElement, wire ,track} from "lwc";
import { NavigationMixin } from "lightning/navigation";
import { getListUi, MRU } from "lightning/uiListApi";
import CONTACT_OBJECT from "@salesforce/schema/Contact";
import pageSize from "@salesforce/apex/ContactController.getContactList";

export default class ContactListViewLwc extends NavigationMixin(
  LightningElement
) {
    @track pageLength;
    showPageValue;
    @wire(pageSize) pageValue({ error, data }) {
    if (error) {
      console.log("noOfRecords", error);
    }
    if (data) {
        this.pageLength = data;
        console.log("noOfRecords", data);
    }
    this.showPageValue = data;
  }
  //@track noOfRecords = this.pageValue.data;
  @wire(getListUi, {
    objectApiName: CONTACT_OBJECT,
    listViewApiName: MRU,
    fields: ["Name", "Email", "Phone"],
    pageSize: '$pageLength'
  })
  listView;
  viewContact(event) {
    this[NavigationMixin.Navigate]({
      type: "standard__recordPage",
      attributes: {
        recordId: event.target.dataset.id,
        objectApiName: "Contact",
        actionName: "view"
      }
    });
    // eslint-disable-next-line no-console
    // eslint-disable-next-line no-undef
    console.log("noOfRecords"+this.pageLength);
  }
}