/* eslint-disable guard-for-in */
/* eslint-disable no-undef */
/* eslint-disable no-console */
import { LightningElement, wire, track } from "lwc";
import accounFields from "@salesforce/apex/dynamicFieldsInsertionOfObject1.returnAllFields";
import { createRecord } from "lightning/uiRecordApi";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import ACCOUNT_OBJECT from "@salesforce/schema/Account";
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import Type_FIELD from '@salesforce/schema/Account.Active__c';

export default class DynamicFieldsInsertionOfObject extends LightningElement {
  @track allFieldsLst = [];
  @track mapTemp = [];
  @track setPickVal = '';
  @track getPickVal;
  @track typePick;
  @track typeText;

  /*@wire(getObjectInfo, { objectApiName: ACCOUNT_OBJECT })
  objectInfo;

  @wire(getPicklistValues, {  recordTypeId: '$objectInfo.data.defaultRecordTypeId', fieldApiName: '$setPickVal'})
  TypePicklistValues({ error, data}){
    if(error){
      console.log("noOfRecords", error);
    }
    if(data){
      console.log('pick val ',data.values);
      this.getPickVal = data.values;
    }
  }*/
  @wire(accounFields) pageValue({ error, data }) {
    if (error) {
      console.log("noOfRecords", error);
    }
    if (data) {
      console.log('date',data);
      data.map((v) => {
        console.log('key fieldApiName',v.fieldApiName);
        this.allFieldsLst.push(v.fieldApiName);
        if(v.fieldType === 'Picklist'){
          console.log('key fieldApiName',v.fieldTypePicklist);
         
           this.mapTemp.push({ label: v.fieldApiName, type: v.fieldType, value: v.fieldTypePicklist, pickList: true,text: false});
         }else{
           this.typeText = true;
           this.typePick = false;
           this.mapTemp.push({ label: v.fieldApiName, type: v.fieldType, value: v.fieldTypePicklist, pickList: false,text: true});
         }
         return {

         }
    });
      /*for (let key in data) {
        // Preventing unexcepted dataP\\
        console.log('key',key);
          console.log('data[fieldApiName]',key.fieldApiName);
        if(key1 === 'Picklist'){
              
           this.setPickVal = key;
           this.typePick = true;
           this.typeText = false;
           console.log("select ", this.getPickVal);
           this.mapTemp.push({ label: key, type: key1, value: data[key1], pickList: true,text: false});
         }else{
           this.typeText = true;
           this.typePick = false;
           this.mapTemp.push({ label: key, type: key1, value: data[key1], pickList: false,text: true});
         }
        if (data.hasOwnProperty(key)) {
          // Filtering the data in the loop
          console.log('key',key);
          console.log('data[key]',data[key]);
          this.allFieldsLst.push(key);
          /*for (let key1 in data[key]) {
            console.log('key1',key1);
            console.log('key',key);
            console.log('data[key1]',data[key1]);
            
            
          }
          
          
          console.log("no of record" + key);
        }
      }*/
    }
  }
  


  @track mapOFValue = new Map();

  handelChange(event) {
    if (event.target.type === "checkbox") {
      this.mapOFValue.set(event.target.label, event.target.checked);
    }
    if (event.target.type === "text") {
      this.mapOFValue.set(event.target.label, event.target.value);
    }
    if (event.target.type === "select-one") {
      console.log("picklist type ", event.target.type);
      console.log("picklist value", event.target.name);
      this.mapOFValue.set(event.target.name, event.target.value);
    }
    console.log("checkbox type", event.target.type);
    console.log("mapOFValue change", this.mapOFValue);
  }
  createAccount() {
    var fields = {};
    var fields1 = {};
    var mapOFValue2 = this.mapOFValue;
    fields1 = this.allFieldsLst;
    fields1.forEach(function(element, i) {
      console.log("element", element);
      console.log("index", i, fields1[i]);

      if (mapOFValue2.has(fields1[i])) {
        fields[fields1[i]] = mapOFValue2.get(fields1[i]);
      }
    });
    console.log("Namel", fields);
    const recordInput = { apiName: ACCOUNT_OBJECT.objectApiName, fields };
    createRecord(recordInput)
      .then(account => {
        console.log("account n ", account);

        this.dispatchEvent(
          new ShowToastEvent({
            title: "Success",
            message: "Account created",
            variant: "success"
          })
        );
      })
      .catch(error => {
        console.log("error", error);
        this.dispatchEvent(
          new ShowToastEvent({
            title: "Error creating record",
            message: "ngfhgh",
            variant: "error"
          })
        );
      });
    console.log("Account", ACCOUNT_OBJECT);
  }
}