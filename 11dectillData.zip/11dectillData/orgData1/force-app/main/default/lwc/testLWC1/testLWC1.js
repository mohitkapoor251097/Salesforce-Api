/* eslint-disable no-console */
import { LightningElement, track, wire, api } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation';
import accName from '@salesforce/schema/Account.Name';
import accPhone from '@salesforce/schema/Account.Phone';
import apexMethodName from '@salesforce/apex/wrapformiltipleParserRec.getAllRec';

export default class TestLWC1 extends LightningElement {
    @track objectName = 'Contact';
    @api height;
    @api background;
    @api color;
    @track warpList = [];
    @track newarray = ["red", "green"];

    
    constructor() {
        super();

        apexMethodName().then(result => {
            const newWraplst = result;
            result.forEach(element => {
                console.log('element', element);
                console.log('element', element.name);
                var newNum = "telepone";
                var newVal = "cc";
               // result[element]  = element.push('');
               console.log('elem ',JSON.stringify(element).replace('}',',"telepone":"ccc"}'));
               //var jsonNew = {"name" :element.name,"Phone":element.Phone,}
               var stringjson = JSON.stringify(element).replace('}',',"telepone":"ccc"}');
              var jsval = JSON.parse(stringjson);
              //jsval[newNum] = newVal;
                console.log('elem ',jsval);
                this.warpList.push(jsval);
            });
            var movie_json = {
            "id": 100,
            };

            //to insert new key/value to movie_json
            movie_json['name'] = 'Harry Potter';
            console.log("new key: " , movie_json);
            console.log('done', result);


        })
            .catch(error => {
                this.error = error;
                console.log(' error : ', error);
            });
    }


    @wire(CurrentPageReference) currentUrl;
    demo() {
        console.log('currentUrl', accName);
        console.log('currentUrl', accPhone);
        console.log('currentUrl', this.currentUrl.attributes.recordId);
    }




    
}