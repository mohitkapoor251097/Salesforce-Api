import { LightningElement } from 'lwc';

export default class Todo extends LightningElement {

}