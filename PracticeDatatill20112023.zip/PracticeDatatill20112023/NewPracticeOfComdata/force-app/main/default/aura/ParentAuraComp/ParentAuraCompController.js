({
    handleClick: function (component, event, helper) {
        component.find("childLwc").showMessage('Welcome to learn Lwc')
    }
})