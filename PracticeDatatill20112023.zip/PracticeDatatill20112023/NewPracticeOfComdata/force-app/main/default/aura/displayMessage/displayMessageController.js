({
    handleMessage: function (component, event, helper) {
        let fullName = event.getParam("fullName");
        alert('fullName' + fullName);
    }
})