import { LightningElement,api,wire } from 'lwc';
import ACCOUNT_NAME from '@salesforce/schema/Account.Name';
import ACCOUNT_TICKER from '@salesforce/schema/Account.TickerSymbol';
import { getFieldValue, getRecord, notifyRecordUpdateAvailable } from 'lightning/uiRecordApi';
import updateTickerSymbol from '@salesforce/apex/AccountHelper.updateTickerRecord';
export default class ImperativeApexForm extends LightningElement {
  @api recordId;
  accountname='';
  accticker='';
    @wire(getRecord,{
        recordId:"$recordId",
        fields:[ACCOUNT_NAME,ACCOUNT_TICKER]
    }) 
 
    outputFunction({data,error}){
        if(data){
             console.log('Get Record OUTPUT : ',data);
             this.accountname=getFieldValue(data,ACCOUNT_NAME);
             this.accticker=getFieldValue(data,ACCOUNT_TICKER);
            
        }
        else if(error){
              console.log('error OUTPUT : ',error);
        }
    }
    changeHandler(event){
             this.accticker=event.target.value;
    }

    updateTicker(){
      updateTickerSymbol({
        recordId:this.recordId,
        newTicker:this.accticker
      }).then(result=>{
        console.log('Record Updte success',result);
        notifyRecordUpdateAvailable([{recordId:this.recordId}]);
      }).catch(error=>{
        console.log('error OUTPUT : ',error);
      })
        
      
    }
}