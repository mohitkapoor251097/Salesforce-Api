import { LightningElement } from 'lwc';
import LightningAlert from 'lightning/alert';
import LightningConfirm from 'lightning/confirm';
import LightningPrompt from 'lightning/prompt';
export default class DialogBoxDemo extends LightningElement {
    async alertHandler() {
        await LightningAlert.open({
            message: 'this is the alert message',
            theme: 'error', // a red theme intended for error states
            label: 'Error!', // this is the header text
        });

    }
    async confirmHandler() {
        const result = await LightningConfirm.open({
            message: 'this is the confirm message',
            variant: 'header',
            label: 'Are you sure',
            theme: "success"
            // setting theme would have no effect
        });
        console.log(result);
    }
    promptHandler() {
        LightningPrompt.open({
            message: 'Enter you fav Channel',
            //theme defaults to "default"
            theme: "warning",
            label: 'Please Respond', // this is the header text
            defaultValue: 'Tech', //this is optional
        }).then((result) => {
            //Prompt has been closed
            //result is input text if OK clicked
            //and null if cancel was clicked
            console.log(result);
        });
    }
}