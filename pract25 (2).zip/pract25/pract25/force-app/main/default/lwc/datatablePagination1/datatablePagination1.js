import { LightningElement, track, wire } from 'lwc';
import getContacts from '@salesforce/apex/ContactDataController.getContacts';

// Column definitions
const columns = [
    { label: 'Name', fieldName: 'Name', type: 'text' },
    { label: 'Email', fieldName: 'Email', type: 'email' }
];

export default class DatatablePagination extends LightningElement {
    @track displayedRecords = [];
    @track currentPage = 1;
    @track pageSize = 10;
    totalRecords = 0;
    allRecords = [];

    columns = columns;
    isLoading = true;

    // Fetch data from Apex
    @wire(getContacts)
    wiredContacts({ error, data }) {
        if (data) {
            this.allRecords = data;
            this.totalRecords = data.length;
            this.updateDisplayedRecords();
            this.isLoading = false;
        } else if (error) {
            console.error('Error fetching contacts:', error);
            this.isLoading = false;
        }
    }

    // Calculate total pages
    get totalPages() {
        return Math.ceil(this.totalRecords / this.pageSize);
    }

    // Calculate row offset for correct numbering
    get rowNumberOffset() {
        return (this.currentPage - 1) * this.pageSize;
    }

    // Update displayed records based on pagination
    updateDisplayedRecords() {
        const startIndex = this.rowNumberOffset;
        this.displayedRecords = this.allRecords.slice(startIndex, startIndex + this.pageSize);
    }

    // Navigate to next page
    handleNext() {
        if (this.currentPage < this.totalPages) {
            this.currentPage++;
            this.updateDisplayedRecords();
        }
    }

    // Navigate to previous page
    handlePrevious() {
        if (this.currentPage > 1) {
            this.currentPage--;
            this.updateDisplayedRecords();
        }
    }
}
