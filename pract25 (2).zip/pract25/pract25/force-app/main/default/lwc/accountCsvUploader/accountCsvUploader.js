// import { LightningElement, track, wire } from "lwc";
// import getAccountFields from "@salesforce/apex/AccountCsvController.getAccountFields";
// import insertAccounts from "@salesforce/apex/AccountCsvController.insertAccounts";

// export default class AccountCsvUploader extends LightningElement {
//     @track csvHeaders = [];
//     @track csvData = [];
//     @track accountFieldOptions = [];
//     @track fieldMappings = {}; // Store CSV Column -> Account Field Mapping

//     // Fetch Account object fields for mapping
//     @wire(getAccountFields)
//     wiredAccountFields({ error, data }) {
//         if (data) {
//             this.accountFieldOptions = data.map(field => ({ label: field, value: field }));
//         } else if (error) {
//             console.error("Error fetching Account fields", error);
//         }
//     }

//     // Handle CSV file upload
//     handleFileUpload(event) {
//         if (event.target.files.length > 0) {
//             const file = event.target.files[0];
//             const reader = new FileReader();

//             reader.onload = () => {
//                 const csvContent = reader.result;
//                 this.processCSV(csvContent);
//             };

//             reader.readAsText(file);
//         }
//     }

//     // Process CSV content
//     processCSV(csvContent) {
//         const rows = csvContent.split("\n");
//         this.csvHeaders = rows[0].split(",").map(header => header.trim());
//         this.csvData = rows.slice(1).map(row => row.split(",").map(value => value.trim()));
//     }

//     // Handle Mapping Selection
//     handleFieldMapping(event) {
//         const csvColumn = event.target.dataset.id;
//         const accountField = event.detail.value;
//         this.fieldMappings[csvColumn] = accountField;
//     }

//     // Handle Save: Convert CSV data to Account records
//     handleSave() {
//         if (!this.csvData.length) {
//             alert("No data to save!");
//             return;
//         }
       
       
//         let accountsToInsert = this.csvData.map(row => {
//             let account = {};
//             this.csvHeaders.forEach((csvColumn, index) => {
//                 let accountField = this.fieldMappings[csvColumn];
//                 if (accountField) {
//                     account[accountField] = row[index];
//                 }
//             });
//             return account;
//         });
//         console.log('OUTPUT : ',JSON.stringify(accountsToInsert));
//         insertAccounts({ accounts: accountsToInsert })
//             .then(() => {
//                 alert("Accounts successfully inserted!");
//                 this.csvHeaders = [];
//                 this.csvData = [];
//                 this.fieldMappings = {};
//             })
//             .catch(error => {
//                 console.error("Error inserting accounts:", error);
//                 alert("Error inserting records.");
//             });
//     }
// }


import { LightningElement, track, wire } from "lwc";
import getAccountFields from "@salesforce/apex/AccountCsvController.getAccountFields";
import insertAccounts from "@salesforce/apex/AccountCsvController.insertAccounts";
import { ShowToastEvent } from "lightning/platformShowToastEvent";

export default class AccountCsvUploader extends LightningElement {
    @track csvHeaders = [];
    @track csvData = [];
    @track accountFieldOptions = [];
    @track fieldMappings = {};

    @wire(getAccountFields)
    wiredAccountFields({ error, data }) {
        if (data) {
            this.accountFieldOptions = data.map(field => ({ label: field, value: field }));
        } else if (error) {
            console.error("Error fetching Account fields", error);
        }
    }

    handleFileUpload(event) {
        if (event.target.files.length > 0) {
            const file = event.target.files[0];
            const reader = new FileReader();

            reader.onload = () => {
                const csvContent = reader.result;
                this.processCSV(csvContent);
            };

            reader.readAsText(file);
        }
    }

    processCSV(csvContent) {
        const rows = csvContent.split("\n");
        this.csvHeaders = rows[0].split(",").map(header => header.trim());
        this.csvData = rows.slice(1).map(row => row.split(",").map(value => value.trim()));
    }

    handleFieldMapping(event) {
        const csvColumn = event.target.dataset.id;
        const accountField = event.detail.value;
        this.fieldMappings[csvColumn] = accountField;
    }

    // handleSave() {
    //     if (!this.csvData.length) {
    //         this.showToast("Error", "No data to save!", "error");
    //         return;
    //     }

    //     let accountsToInsert = this.csvData.map(row => {
    //         let account = {};
    //         this.csvHeaders.forEach((csvColumn, index) => {
    //             let accountField = this.fieldMappings[csvColumn];
    //             if (accountField) {
    //                 account[accountField] = row[index];
    //             }
    //         });
    //         return account;
    //     });
    //     console.log('OUTPUT : ',JSON.stringify(accountsToInsert));
    //     insertAccounts({ accounts: accountsToInsert })
    //         .then((result) => {
    //             if (result === "Success") {
    //                 this.showToast("Success", "Accounts inserted successfully!", "success");
    //                 this.csvHeaders = [];
    //                 this.csvData = [];
    //                 this.fieldMappings = {};
    //             } else {
    //                 this.showToast("Error", result, "error");
    //             }
    //         })
    //         .catch((error) => {
    //             console.error("Error inserting accounts:", error);
    //             this.showToast("Error", "Failed to insert records: " + error.body.message, "error");
    //         });
    // }

    // handleSave() {
    //     if (!this.csvData.length) {
    //         this.showToast("Error", "No data to save!", "error");
    //         return;
    //     }
    
    //     let accountsToInsert = this.csvData.map(row => {
    //         let account = {};
    //         this.csvHeaders.forEach((csvColumn, index) => {
    //             let accountField = this.fieldMappings[csvColumn];
    //             if (accountField) {
    //                 account[accountField] = row[index].trim();  // Trim spaces
    //             }
    //         });
    //         return account;
    //     });
    
    //     // ❗ Filter out records with empty required fields like Name
    //     accountsToInsert = accountsToInsert.filter(acc => acc.Name && acc.Name.trim() !== "");
    
    //     if (accountsToInsert.length === 0) {
    //         this.showToast("Error", "No valid records to insert!", "error");
    //         return;
    //     }
    
    //     console.log('OUTPUT : ', JSON.stringify(accountsToInsert));  // Debugging
    
    //     insertAccounts({ accounts: accountsToInsert })
    //         .then((result) => {
    //             if (result === "Success") {
    //                 this.showToast("Success", "Accounts inserted successfully!", "success");
    //                 this.csvHeaders = [];
    //                 this.csvData = [];
    //                 this.fieldMappings = {};
    //             } else {
    //                 this.showToast("Error", result, "error");
    //             }
    //         })
    //         .catch((error) => {
    //             console.error("Error inserting accounts:", error);
    //             this.showToast("Error", "Failed to insert records: " + error.body.message, "error");
    //         });
    // }
    
    handleSave() {
        if (!this.csvData.length) {
            this.showToast("Error", "No data to save!", "error");
            return;
        }
        // let accountsToInsert = this.csvData.map(row => {
        //     let account = {};
            
        //     this.csvHeaders.forEach((csvColumn, index) => {
        //         let accountField = this.fieldMappings[csvColumn];  // Get mapped Salesforce field
        //         if (accountField) {
        //             account[accountField] = row[index]?.trim() || null;  // Assign value or null
        //         }
        //     });
        
        //     return account;
        // });
        
        // // 🔥 Ensure required fields are present (e.g., any field that must have data)
        // accountsToInsert = accountsToInsert.filter(acc => {
        //     return Object.values(acc).some(value => value !== null && value !== ""); // At least one field should have a value
        // });
        // ❗ Remove empty rows before processing
// this.csvData = this.csvData.filter(row => row.some(cell => cell.trim() !== ""));

// let accountsToInsert = this.csvData.map(row => {
//     let account = {};

//     this.csvHeaders.forEach((csvColumn, index) => {
//         let accountField = this.fieldMappings[csvColumn];
//         if (accountField) {
//             account[accountField] = row[index]?.trim() || null;
//         }
//     });

//     return account;
// });

// // 🔥 Ensure at least one field has data before inserting
// accountsToInsert = accountsToInsert.filter(acc => Object.values(acc).some(value => value));

// if (accountsToInsert.length === 0) {
//     this.showToast("Error", "No valid records to insert!", "error");
//     return;
// }

// console.log('Filtered Accounts:', JSON.stringify(accountsToInsert));

        
//         if (accountsToInsert.length === 0) {
//             this.showToast("Error", "No valid records to insert!", "error");
//             return;
//         }
        
//         console.log('OUTPUT:', JSON.stringify(accountsToInsert));  // Debugging
        
//         // Call Apex method to insert accounts
//         insertAccounts({ accounts: accountsToInsert })
//             .then(result => {
//                 if (result === "Success") {
//                     this.showToast("Success", "Accounts inserted successfully!", "success");
//                     this.resetData();
//                 } else {
//                     this.showToast("Error", result, "error");
//                 }
//             })
//             .catch(error => {
//                 console.error("Error inserting accounts:", error);
//                 this.showToast("Error", "Failed to insert records: " + error.body.message, "error");
//             });
    
//         // let accountsToInsert = this.csvData.map(row => {
//         //     let account = {};
//         //     this.csvHeaders.forEach((csvColumn, index) => {
//         //         let accountField = this.fieldMappings[csvColumn];
//         //         if (accountField) {
//         //             account[accountField] = row[index].trim();  // Trim spaces
//         //         }
//         //     });
//         //     return account;
//         // });
    
//         // // ❗ Filter out records with empty required fields like Name
//         // accountsToInsert = accountsToInsert.filter(acc => acc.Name && acc.Name.trim() !== "");
    
//         // if (accountsToInsert.length === 0) {
//         //     this.showToast("Error", "No valid records to insert!", "error");
//         //     return;
//         // }
    
//         // console.log('OUTPUT : ', JSON.stringify(accountsToInsert));  // Debugging
    
//         insertAccounts({ accounts: accountsToInsert })
//             .then((result) => {
//                 if (result === "Success") {
//                     this.showToast("Success", "Accounts inserted successfully!", "success");
//                     this.csvHeaders = [];
//                     this.csvData = [];
//                     this.fieldMappings = {};
//                 } else {
//                     this.showToast("Error", result, "error");
//                 }
//             })
//             .catch((error) => {
//                 console.error("Error inserting accounts:", error);
//                 this.showToast("Error", "Failed to insert records: " + error.body.message, "error");
//             });

let accountsToInsert = this.csvData.map(row => {
    let account = {};

    this.csvHeaders.forEach((csvColumn, index) => {
        let accountField = this.fieldMappings[csvColumn];  // Get mapped Salesforce field
        if (accountField) {
            account[accountField] = row[index]?.trim() || null;  // Assign value or null
        }
    });

    return account;
});

// ❗ Filter out empty objects (ensuring valid fields exist)
accountsToInsert = accountsToInsert.filter(acc => Object.values(acc).some(value => value));

if (accountsToInsert.length === 0) {
    this.showToast("Error", "No valid records to insert!", "error");
    return;
}

// 🚀 Debugging: Check final account list before sending to Apex
console.log('Final Accounts to Insert:', JSON.stringify(accountsToInsert));
insertAccounts({ accounts: accountsToInsert })
    .then(result => {
        if (result === "Success") {
            this.showToast("Success", "Accounts inserted successfully!", "success");
            this.resetData();
        } else {
            this.showToast("Error", result, "error");
        }
    })
    .catch(error => {
    });

    }
    showToast(title, message, variant) {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant
        });
        this.dispatchEvent(event);
    }
}