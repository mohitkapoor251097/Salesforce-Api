import { LightningElement, wire } from 'lwc';
import getAccounts from '@salesforce/apex/AccountRelatedContactController.getAccounts';
import getRelatedContacts from '@salesforce/apex/AccountRelatedContactController.getRelatedContacts';
import {refreshApex} from '@salesforce/apex';
import { deleteRecord } from 'lightning/uiRecordApi';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';

const actions=[
    {label:'Edit',name:'Edit'},
    {label:'Delete',name:'Delete'},
]
export default class AccountwithRealtedCntact extends LightningElement {

    accountOption=[];
    selectedAccount;
    displayModal=false;
    conRecordId;
    @wire(getAccounts)
    getAccountResult({data,error}){
        if(data){
    this.accountOption=data.map(item=>({
        label:item.Name,
        value:item.Id
    }))
        }
        else if(error){
            console.log('error'+error);
            
        }
    }

    get columns(){
        return [
            {label:'First Name',fieldName:'FirstName'},
            {label:'Last Name',fieldName:'LastName'},
            {type:'action',typeAttributes:{rowActions:actions}}

        ]
    }



    changeHandler(event){
        this.selectedAccount=event.target.value;
        console.log('id'+event.target.value);
        
    }
    @wire(getRelatedContacts,{selectedAccId:'$selectedAccount'})
    contacts;

    get isData(){
        return this.contacts.data && this.contacts.data.length>0 && this.selectedAccount!=null || ''
    }

    rowActionHandler(event){
        const action=event.detail.action;
        const row=event.detail.row;
        switch(action.name){
            case 'Edit':{
                 // alert('edit');
                  this.editContact(row);
                  break;
            }
            case 'Delete':{
                // alert('Delete')
                 this.deleteContact(row);
                 break;
            }
        }
    }

    editContact(row){
      this.displayModal=true;
      this.conRecordId=row.Id;
    }
    async deleteContact(row){
     try{
        await deleteRecord(row.Id);
        this.showMessage('success','Delete Successfully !','success');
        await refreshApex(this.contacts);
     }catch(error){
        console.log(JSON.stringify(error));
        
        this.showMessage('error',error.body.message,'error');
     }
    }
    async closeModal(){
        await refreshApex(this.contacts);
        this.displayModal=false;
        this.showMessage('success','updated Successfully !','success');

    }

    showMessage(title,message,variant){
        this.dispatchEvent(new ShowToastEvent({
            variant:variant,
            message:message,
            title:title
        }))
    }
}


// /*





// <!--###########################################################################
// # File............................: IRLightningOutCmp
// # Version......................: 1.0
// # Created by.................: Coforge
// # Created Date..............:  01/02/2024
// # Last Modified by.........: Coforge
// # Last Modified Date......: 26/02/2025
// # Description.................: Common Navigation tab component for all pages
// # Change Log ................ Version 1.0 :ADO- 25224 Login page development for IR community Portal
// # Change Log ................ Version 1.1 :ADO- 22349 Validation of Contact details
// # Change Log ................ Version 1.2 :ADO- 27687 Functionality to edit IR Contact Personal Details.
// # Change Log ................ Version 1.3 :ADO-22343 Auto creation of person account based on new org role contact 
// # Change Log ................ Version 1.4 :ADO 27824 Feedback User Story Sprint 1&2
// # Change Log ................ Version 1.5 :ADO-27683 Functionality for "View" and "Edit/Delete" buttons for IR Regulatory Contacts and General IR Contacts Table.
// #############################################################################
// -->
// <apex:component controller="IRLightningOutCmpController" >
//     <apex:attribute name="sectionType" type="String" description="Used to display conditional LWC"/>
//     <apex:attribute name="editPersonAccountDataTarget" type="String" default="#personAccountPopup" description="Used to display conditional LWC"/>
//     <apex:attribute name="createContactDataTarget" type="String" default="#orgRolePopupComponent" description="Used to display conditional LWC"/>
//     <apex:includeLightning />
//     <style>
//         /* Absolute Center Spinner */
//         .loading {
//           position: fixed;
//           z-index: 1099;
//           height: 2em;
//           width: 2em;
//           overflow: show;
//           margin: auto;
//           top: 0;
//           left: 0;
//           bottom: 0;
//           right: 0;
//           font-size: 30px;
//         }

//         /* Transparent Overlay */
//         .loading:before {
//           content: '';
//           display: block;
//           position: fixed;
//           top: 0;
//           left: 0;
//           width: 100%;
//           height: 100%;
//           background-color: rgba(0,0,0,0.3);
//         }
//     </style>
//     <apex:outputpanel id="lwcPanel">
//         <div id="spinnerId" aria-label="loading content" class="loading">
//             <center>
//                 <i class="icon-spin6 animate-spin"/>
//             </center>
//         </div>
//     </apex:outputpanel>
//     <div id="iRDashboardDisplay"></div> 
        
//     <apex:actionFunction name="spinnerLoad" reRender="lwcPanel" status="renderSpinner"/>
//     <!--ADO-22349 Start to add popup on load -->
//     <apex:actionFunction name="assignSelectedContact" reRender="accountPopup" action="{!deserializePersonAccount}" status="renderSpinner" oncomplete="clickPersonAccountPopup();"> <!--BUG-39105 Fix-->
//         <apex:param value="" name="userpersonaccount" assignTo="{!personAccountJson}"/>
//         <apex:param value="" name="personflag" assignTo="{!isPersonAccountFlag}"/> <!--ADO 27824 param added-->
//         <apex:param value="" name="setVerifyButtonName" assignTo="{!setButtonName}"/> <!--ADO 22357 added param to change button name -->
//     </apex:actionFunction>
//     <!--ADO-22349 End-->
//     <!--ADO-27687 Start-->
//     <apex:actionFunction name="assignBusinessAccount" reRender="businessAccountPopup" action="{!deserializeBusinessAccount}" status="renderSpinner" oncomplete="clickBusinessAccountPopup();">  <!--BUG-39105 Fix-->
//         <apex:param value="" name="LicenseeAccount" assignTo="{!businessAccountJson}"/>
//     </apex:actionFunction>
//     <!--ADO-27687 End-->
//     <!--ADO-22343 Start-->
//     <apex:actionFunction name="createContactPopup" reRender="irContactPopup" action="{!setOrgRoleAndPARecord}" status="renderSpinner" oncomplete="clickIRContactPopup();">
//         <apex:param value="" name="selectedLicenseeRecordId" assignTo="{!selectedLicenseeId}"/>
//         <apex:param value="" name="selectedContactRecord" assignTo="{!selectedContact}"/>
//         <apex:param value="" name="selectedContactType" assignTo="{!selectedContactType}"/>
//     </apex:actionFunction>
//     <!--ADO-22343 End-->
//     <!--ADO-27687 Start-->
//     <apex:outputPanel id="accountPopup" rendered="{!if(sectionType == 'dashboardScreen', true, false)}">
//         <c:LicensingComUpdateAccount personAccountRecord="{!personAccountRecord}" modalPopupDivId="personAccountPopup" isPersonAccountFlag="{!isPersonAccountFlag}" setButtonName="{!setButtonName}"/> <!--ADO 27824 pass the value in attribute-->
//     </apex:outputPanel>
//     <apex:outputPanel id="businessAccountPopup" rendered="{!if(sectionType == 'dashboardScreen', true, false)}">
//         <c:IRComUpdateBusinessAccount businessAccountRecord="{!businessAccountRecord}" />
//     </apex:outputPanel>
//     <!--ADO-27687 End-->
//     <!--ADO-22343 Start--> 
//     <apex:outputPanel id="irContactPopup" rendered="{!if(sectionType == 'dashboardScreen', true, false)}">
//         <c:LicensingComSelectOrgRole orgAccountId="{!selectedLicenseeId}" type="{!selectedContactType}" selectedContact="{!selectedContact}" irPersonAccount="{!personAccount}" irOrgRole="{!orgRole}"/> <!--ADO-27683 added attribute-->
//     </apex:outputPanel>
    
//     <!--ADO-22343 End--> 
//     <!--ADO-22349 Start to add popup on load -->
//     <input id="selectLicenceContactButton" class="btn btn-default"  
//                value="Create New Contact"
//                data-target="{!editPersonAccountDataTarget}" data-toggle="modal" type="hidden"/>
//      <!--ADO-22349 End-->
//     <!--ADO-27687 Start-->
//     <input id="updateBusinessAccountButton" class="btn btn-default"  
//                value="Create New Contact"
//                data-target="#businessAccountPopup" data-toggle="modal" type="hidden"/>
//     <!--ADO-27687 End-->
//     <!--ADO-22343 Start-->
//     <input id="createIRContactButton" class="btn btn-default"  
//                value="Create New Contact"
//                data-target="{!createContactDataTarget}" data-toggle="modal" type="hidden"/>
//     <!--ADO-22343 Start-->
    
//     <script>
//     $Lightning.use("c:IRLightningApplication", function() {             /* Using Lightning aura app as a container */ 
//         if("{!JSENCODE(sectionType)}"=="loginscreen"){ 
//             $Lightning.createComponent("c:iRLoginScreen", 
//                                     {},/* Calling Lightning web component */
//                                     "iRDashboardDisplay",                                   /* Displaying the LWC inside element with this id */    
//                                     function(component) {
//                                         var loadingDivElement = document.getElementById("spinnerId");
//                                         loadingDivElement.style.display = 'none';
//                                     });
//         }
//         else if("{!JSENCODE(sectionType)}"=="dashboardScreen"){
//             $Lightning.createComponent("c:iRComDashboardScreen", 
//                                     {},/* Calling Lightning web component */
//                                     "iRDashboardDisplay",                                   /* Displaying the LWC inside element with this id */    
//                                     function(component) {
//                                        closeSpinner();
//                                                                                //ADO-22349 Start to add popup on load
//                                         document.querySelector('c-i-r-com-dashboard-screen').addEventListener('openUpdateMandatoryDetailsPopup', function(event){
//                                             assignSelectedContact(JSON.stringify(event.detail.personaccountdata),event.detail.issetcpflag,event.detail.setVerifyButtonName);   // ADO-27824                                          
//                                         });
//                                         //ADO-22349 End 
//                                         //ADO-27687 Start to add popup on Edit Address button
//                                         document.querySelector('c-i-r-com-dashboard-screen').addEventListener('openBusinessAccountPopup', function(event){
//                                             assignBusinessAccount(JSON.stringify(event.detail.businessAccountdata));                                               
//                                         });
//                                         //ADO-27687 End
//                                         //ADO-22343 Start Start to add popup on Create IR Contact Button
//                                         document.querySelector('c-i-r-com-dashboard-screen').addEventListener('openIRContactPopup', function(event){
// 											createContactPopup(event.detail.licenseeId,JSON.stringify(event.detail.selectedContact),event.detail.contactType);
//                                        });
//                                         //ADO-22343 End
                                        
//                      });

//         }    
//         });
//         //ADO-22349 Start to add popup on load
//         function clickPersonAccountPopup(){
//             document.getElementById("selectLicenceContactButton").click(); // Opens modal popup 
//             closeSpinner();  
//         }
//         //ADO-22349 End
//         function clickBusinessAccountPopup(){
//             document.getElementById("updateBusinessAccountButton").click(); // Opens modal popup 
//             closeSpinner();  
//         }
//         //ADO-22343 Start
//         function clickIRContactPopup(){
//             document.getElementById("createIRContactButton").click(); // Opens modal popup 
//             closeSpinner();  
//         }
//         //ADO-22343 End
//         function closeSpinner(){
//             var loadingDivElement = document.getElementById("spinnerId");
//             loadingDivElement.style.display = 'none';  
//         }
//     </script>
    
// </apex:component>