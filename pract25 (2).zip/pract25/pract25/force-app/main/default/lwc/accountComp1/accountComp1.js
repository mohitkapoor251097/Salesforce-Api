import { LightningElement, track } from 'lwc';
import ACCOUNT_DATA from '@salesforce/apex/AccountController.getAccounts'; // Fetch accounts

export default class AccountComp extends LightningElement {
    @track accounts = [];
    columns = [
        { label: 'Account Name', fieldName: 'Name', type: 'text' },
        {
            label: 'Actions',
            type: 'customButtonColumn1', // Custom column type
            fieldName: 'Id',
            typeAttributes: { 
                recordId: { fieldName: 'Id' }, 
                onNewContact: this.handleNewContact.bind(this),
                onDelete: this.handleDelete.bind(this)
            }
        }
    ];

    connectedCallback() {
        ACCOUNT_DATA()
            .then(data => {
                this.accounts = data;
            })
            .catch(error => {
                console.error(error);
            });
    }

    handleNewContact(recordId) {
        console.log('New Contact clicked for record:', recordId);
        alert('New Contact for ID: ' + recordId);
    }

    handleDelete(recordId) {
        console.log('Delete clicked for record:', recordId);
        alert('Delete ID: ' + recordId);
    }
}
