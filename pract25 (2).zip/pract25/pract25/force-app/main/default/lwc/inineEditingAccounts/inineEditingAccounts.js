// import { LightningElement, wire } from 'lwc';
// import getAccounts from '@salesforce/apex/AccountFetchController.getAccounts';
// import updateAccount from '@salesforce/apex/AccountFetchController.updateAccount';
// import { ShowToastEvent } from 'lightning/platformShowToastEvent';
// import { refreshApex } from "@salesforce/apex";
// export default class InineEditingAccounts extends LightningElement {

//     draftValues = [];
//     columns = [
//         { label: 'Account Name', fieldName: 'Name', editable: true },
//         { label: 'Account Phone', fieldName: 'Phone', editable: true, type: 'phone' },
//         { label: 'Account Industry', fieldName: 'Industry', editable: true}
//     ]

    
//     @wire(getAccounts)
//     accounts;

//     async handleSave(event) {
//         const updatedFields = event.detail.draftValues;
        
//         try {
//             const result = await updateAccount({acc:updatedFields});
//             this.showMessage('success', 'Account Updated Successfully !', 'success');
//             refreshApex(this.accounts).then(() => {
//                 this.draftValues = [];
//             })
//         }
//         catch (error) {
//             console.log("###Error : " + JSON.stringify(error));
//             this.showMessage('error', 'something went wrong!', 'error');
//         }

//     }
//     showMessage(variant, message, title) {
//         this.dispatchEvent(new ShowToastEvent({
//             title: title,
//             variant: variant,
//             message: message
//         }));
//     }

// }

import { LightningElement, wire, track } from 'lwc';
import getAccounts from '@salesforce/apex/AccountFetchController.getAccounts';
import updateAccount from '@salesforce/apex/AccountFetchController.updateAccount';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';
import { getPicklistValues, getObjectInfo } from 'lightning/uiObjectInfoApi';
import { deleteRecord, updateRecord } from 'lightning/uiRecordApi';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import INDUSTRY_FIELD from '@salesforce/schema/Account.Industry';

export default class InlineEditingAccounts extends LightningElement {
    draftValues = [];
   @track leadSourceOptions=[];
    leadSourceActions=[];
    @track industryOptions = [];
    wiredAccounts;

    contactRefreshProp;
contactData;
@wire(getAccounts,{pickList:"$leadSourceOptions"})
getContactOutput(result){
    this.contactRefreshProp=result;
    if(result.data){
     //this.contactData=result.data;
    this.contactData= result.data.map((currItem)=>{
        let pickListOptions=this.leadSourceOptions;
        console.log('OUTPUT : ',JSON.stringify(this.leadSourceOptions));
        return {
            ...currItem,
            pickListOptions:pickListOptions
        };
     });
  
    }
    else if(result.error){
        console.log("error While Loading Records");
    }
}



    // Fetch Account Object Info
    @wire(getObjectInfo, { objectApiName: ACCOUNT_OBJECT })
    accountInfo;

    // Fetch Picklist Values for Industry
    @wire(getPicklistValues, { recordTypeId: '$accountInfo.data.defaultRecordTypeId', fieldApiName: INDUSTRY_FIELD })
    wiredPicklistValues({ error, data }) {
        if (data) {
            console.log('vles--'+JSON.stringify(data.values));
                this.leadSourceOptions=data.values;
                console.log('vles--'+JSON.stringify(this.leadSourceOptions));
         
        } else if (error) {
            console.error('Error fetching picklist values:', error);
        }
    }

    get columns() {
        return [
            { label: 'Account Name', fieldName: 'Name', editable: true },
            { label: 'Account Phone', fieldName: 'Phone', editable: true, type: 'phone' },
            { 
                label: 'Industry', 
                fieldName: 'Industry', 
                type:"customPickList", 
                editable: true, 
                typeAttributes: { 
                    placeholder: 'Choose Industry', 
                    options:{fieldName:"pickListOptions"},
                    value: { fieldName: 'Industry' },
                    context: { fieldName: 'Id' } 
                    
                }
            }
        ];
    }

    async handleSave(event){
        let records=event.detail.draftValues;
       let updateRecordsArray= records.map(currItem=>{
         let fieldInput={...currItem};
         return {
             fields:fieldInput
         };
        });
     
        this.draftValues=[]
       let updateRecordsArrayPromise=updateRecordsArray.map(currItem=> updateRecord(currItem));
     
        await  Promise.all(updateRecordsArrayPromise);
     
        const toastevent = new ShowToastEvent({
         title: 'Success',
         message:
             'Records Updated Successfully!',
             variant:'success'
     });
     this.dispatchEvent(toastevent);
     await refreshApex(this.contactRefreshProp);
     }

    }//     async handleSave(event) {
//         const updatedFields = event.detail.draftValues;
        
//         try {
//             await updateAccount({ acc: updatedFields });
//             this.showMessage('success', 'Account Updated Successfully!', 'success');
//             refreshApex(this.contactRefreshProp).then(() => {
//                 this.draftValues = [];
//             });
//         } catch (error) {
//             console.error('Error:', JSON.stringify(error));
//             this.showMessage('error', 'Something went wrong!', 'error');
//         }
//     }

//     // Show Toast Messages
//     showMessage(variant, message, title) {
//         this.dispatchEvent(new ShowToastEvent({
//             title: title,
//             variant: variant,
//             message: message
//         }));
//     }
// }