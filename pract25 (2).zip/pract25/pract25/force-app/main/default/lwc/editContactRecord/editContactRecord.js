import { api, LightningElement } from 'lwc';

export default class EditContactRecord extends LightningElement {

    @api conRecordId;
    closeModel(){
    this.dispatchEvent(new CustomEvent('closemodal'));
    }

    handleSuccess(){
       this.closeModel();
    }
}