import { LightningElement, track } from 'lwc';

export default class CustomDateTimePicker extends LightningElement {
    @track selectedDate;
    @track selectedTime;
    @track formattedTime;

    handleDateChange(event) {
        this.selectedDate = event.target.value;
    }

    handleTimeChange(event) {
        this.selectedTime = event.target.value;
        this.formatTime();
    }

    formatTime() {
        if (this.selectedTime) {
            const [hours, minutes] = this.selectedTime.split(':');
            let formattedHours = hours % 12 || 12;
            let period = hours >= 12 ? 'PM' : 'AM';
            this.formattedTime = `${formattedHours}:${minutes} ${period}`;
        }
    }
}
