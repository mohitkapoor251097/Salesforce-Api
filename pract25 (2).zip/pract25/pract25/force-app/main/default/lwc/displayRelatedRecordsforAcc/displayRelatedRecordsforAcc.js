import { LightningElement, wire } from 'lwc';
import getAccounts from '@salesforce/apex/AccountWithRelatedCaseorOpp.getAccounts';
import getRelatedRecords from '@salesforce/apex/AccountWithRelatedCaseorOpp.getRelatedRecords';
export default class DisplayRelatedRecordsforAcc extends LightningElement {

    cases=[];
    opportunities=[];
    showCases=false;
    showOpp=false;


    @wire(getAccounts)
    accounts;

    get columns(){
        return [
            {
                label:'Account Name',fieldName:'nameUrl', type:'url',
                typeAttributes:{
                    label:{
                        fieldName: 'name'
                    },
                    target:'_blank'
                }
            },
            {label:'Industry', fieldName:'industry',type:'text'}

        ]
    }

    get oppcolumns(){
        return [
            {
                label:'Account Name',fieldName:'accNameUrl', type:'url',
                typeAttributes:{
                    label:{
                        fieldName: 'accName'
                    },
                    target:'_blank'
                }
            },
            {
                label:'Opportunity Name',fieldName:'oppNameUrl', type:'url',
                typeAttributes:{
                    label:{
                        fieldName: 'oppName'
                    },
                    target:'_blank'
                }
            },
        {label:'Stage Name', fieldName:'StageName',type:'text'}

        ]
    }
    
    get casecolumns(){
        return [
            {
                label:'Account Name',fieldName:'accNameUrl', type:'url',
                typeAttributes:{
                    label:{
                        fieldName: 'accName'
                    },
                    target:'_blank'
                }
            },
            {
                label:'Case Number',fieldName:'caseNumberUrl', type:'url',
                typeAttributes:{
                    label:{
                        fieldName: 'caseNumber'
                    },
                    target:'_blank'
                }
            },
            {label:'Priority', fieldName:'Priority',type:'text'}

        ]
    }



    getRelatedData(event){
     const selectRows=event.detail.selectedRows;
     let selectedAccId=selectRows.map(row=> row.accountId);
     console.log('selectAccId '+selectedAccId);
     this.getCasesAndOpp(selectedAccId);
     
    }

//     async getCasesAndOpp(selectedaccId){
//         const relateddata=await getRelatedRecords({accountIdList:selectedaccId});
//        console.log('OUTPUT : ',JSON.stringify(relateddata));
//       try{

//         this.cases=relateddata.reduce((acc,accountData)=>{
//              if(accountData.caseList && accountData.caseList.length>0){
//                let processedData= accountData.caseList.map(caseRecord=({
//                     accNameUrl:'/'+caseRecord.Account?.Id,
//                     accName:caseRecord.Account?.Name,
//                     caseNumberUrl:'/'+caseRecord?.Id,
//                     caseNumber:caseRecord?.CaseNumber,
//                     caseId:caseRecord?.Id,
//                     Priority:caseRecord?.Priority,
                   
//                 }))
//                 acc.push(...processedData)
//              }
//              return acc;
//         },[])

//         // this.opportunities=relateddata.reduce((acc,accountData)=>{
//         //     if(accountData.opportunityList && accountData.opportunityList.length>0){
//         //           let processData=accountData.oppList.map(oppRecord=>({
//         //             accNameUrl:'/'+oppRecord.Account.Id,
//         //             accName:oppRecord.Account.Name,
//         //             oppNameUrl:'/'+oppRecord.Id,
//         //             oppName:oppRecord.Name,
//         //             oppId:oppRecord.Id,
//         //             Stage:oppRecord.StageName,
//         //           }))
//         //           acc.push(...processData)
//         //     }
//         //     return acc;
//         // },[])

//         this.showCases=this.cases.length>0;
//         this.showOpp=this.opportunities.length>0;
//         console.log('---'+this.showCases);
// }
// catch(error){
//     console.log('Error : ',JSON.stringify(error));
// }
    
//     }


async getCasesAndOpp(selectedaccId){
    try {
        const relateddata = await getRelatedRecords({ accountIdList: selectedaccId });
        console.log('OUTPUT : ', JSON.stringify(relateddata));

        this.cases = relateddata.reduce((acc, accountData) => {
            if (accountData.caseList && accountData.caseList.length > 0) {
                let processedData = accountData.caseList.map(caseRecord => ({
                    accNameUrl: '/' + caseRecord.Account?.Id,
                    accName: caseRecord.Account?.Name,
                    caseNumberUrl: '/' + caseRecord?.Id,
                    caseNumber: caseRecord?.CaseNumber,
                    caseId: caseRecord?.Id,
                    Priority: caseRecord?.Priority,
                }));
                acc.push(...processedData);
            }
            return acc;
        }, []);

       
        this.opportunities = relateddata.reduce((acc, accountData) => {     
            if (accountData.opportunityList && accountData.opportunityList.length > 0) {
                let processData = accountData.opportunityList.map(oppRecord => ({
                    accNameUrl: '/' + oppRecord.Account?.Id,
                    accName: oppRecord.Account?.Name,
                    oppNameUrl: '/' + oppRecord.Id,
                    oppName: oppRecord.Name,
                    oppId: oppRecord.Id,
                   StageName: oppRecord.StageName,
                }));
                acc.push(...processData);
            }
            return acc;
        }, []);

        this.showCases = this.cases.length > 0;
        this.showOpp = this.opportunities?.length > 0;
        console.log('---' + this.showCases);
        console.log('---' + this.showOpp);
    } catch (error) {
        console.log('Error : ', JSON.stringify(error));
    }
}

    
}