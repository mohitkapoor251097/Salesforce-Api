import { LightningElement,api } from 'lwc';

export default class CustomPic extends LightningElement {
    @api recordId;

    handleDelete(){
        //alert('delete called');
        this.dispatchEvent(new CustomEvent('delete',{
            detail:this.recordId,
            bubbles:true,
            composed:true
        }))
       
    }

    handleNewContact(){
       // alert('contact click');
        this.dispatchEvent(new CustomEvent('contact',{
            detail:this.recordId,
            bubbles:true,
            composed:true
        }))
    }
}