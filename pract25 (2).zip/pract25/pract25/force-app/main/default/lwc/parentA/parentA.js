import { LightningElement } from 'lwc';

export default class ParentA extends LightningElement {

   accountId;
    recieveData(event){
        console.log('ParentA recieveData method called');
        console.log('Received data from child: ', event.detail);
        this.accountId=event.detail;
    }
}