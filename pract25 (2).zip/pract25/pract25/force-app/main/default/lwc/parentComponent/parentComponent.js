import { LightningElement } from 'lwc';

export default class ParentComponent extends LightningElement {
  handleParentClick(event) {
    if (event.detail) {
      alert('Parent received event: ' + event.detail.message);
      // Stop the event from propagating to the grandparent
      event.stopPropagation();
    }
  }
}