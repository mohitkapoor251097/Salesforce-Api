import { LightningElement, wire } from 'lwc';
import getAccountsData from '@salesforce/apex/AccountController.getAccountsData';
export default class PaginationDemo extends LightningElement {

    totalRecords = [];
    displayRecords = [];
    totapPages = 0;
    currentPage = 1;
    recordSize = 10;
    get columns() {
        return [
            { label: 'Account Name', fieldName: 'Name' },
            { label: 'Rating', fieldName: 'Rating' }
        ];
    }

    @wire(getAccountsData)
    accounts({ data, error }) {
        if (data) {
            this.totalRecords = data.map(acc => {
                let updatedObject = {};
                if (!acc.hasOwnProperty('Rating')) {
                    updatedObject = { ...acc, Rating: 'Hot' }
                }
                else {
                    updatedObject = { ...acc }
                }
                return updatedObject;
            })
            this.recordSize = Number(this.recordSize);
            this.totapPages = Math.ceil(data.length / this.recordSize);
            this.updateAccount();
        }
        else if (error) {
            console.error(error);
        }
    }

    updateAccount() {
        let start = (this.currentPage - 1) * this.recordSize;
        let end = this.recordSize * this.currentPage;
        this.displayRecords = this.totalRecords.slice(start, end);
    }

    get disablePrevious() {
        return this.currentPage <= 1;
    }

    get disableNext() {
        return this.currentPage >= this.totapPages;
    }

    previousHandler() {
        if (this.currentPage > 1) {
            this.currentPage = this.currentPage - 1;
            this.updateAccount();
        }
    }

    nextHandler() {
        if (this.currentPage < this.totapPages) {
            this.currentPage = this.currentPage + 1;
            this.updateAccount();
        }
    }
}