import { LightningElement, track, api } from 'lwc';
import createAccountRecords from '@salesforce/apex/AccountDataCreateByCSV.createAccountRecords';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
const columns = [
    { label: 'Name', fieldName: 'Name' },
    { label: 'Phone', fieldName: 'Phone'},
    { label: 'Account Number', fieldName: 'AccountNumber' }
];
export default class CSVFileUploaderLWC extends LightningElement {
    @api recordid;
    @track columns = columns;
    @track data;
    @track fileName = '';
    @track UploadFile = 'Upload CSV File';
    @track showSpinner = false;
    @track isTrue = false;
    selectedRecords;
    filesUploaded = [];
    file;
    fileContents;
    fileReader;
    content;
    MAX_FILE_SIZE = 1500000;
    handleFilesChange(event) {
        if (event.target.files.length > 0) {
            this.filesUploaded = event.target.files;
            this.fileName = event.target.files[0].name;
        }
    }
    handleSave() {
        if (this.filesUploaded.length > 0) {
            this.uploadHelper();
        } else {
            this.fileName = 'Please select a CSV file to upload!!';
        }
    }
    uploadHelper() {
        this.file = this.filesUploaded[0];
        if (this.file.size > this.MAX_FILE_SIZE) {
            console.log('File Size is to long');
            return;
        }
        this.showSpinner = true;
        this.fileReader = new FileReader();
        this.fileReader.onloadend = (() => {
            this.fileContents = this.fileReader.result;
            this.saveToFile();
        });
        this.fileReader.readAsText(this.file);
    }
    saveToFile() {
        createAccountRecords({ base64Data: JSON.stringify(this.fileContents), cdbId: this.recordid })
            .then(result => {
                console.log(result);
                this.data = result;
                this.fileName = this.fileName + ' - Uploaded Successfully';
                this.isTrue = false;
                this.showSpinner = false;
                this.showToast('Success', this.file.name + ' - Uploaded Successfully!!!', 'success', 'dismissable');
            })
            .catch(error => {
                console.log(error);
                this.showToast('Error while uploading File', error.body.message, 'error', 'dismissable');
            });
    }
    showToast(title, message, variant, mode) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(evt);
    }
}

// import { LightningElement, track, api } from 'lwc';
// import createAccountRecords from '@salesforce/apex/AccountDataCreateByCSV.createAccountRecords';
// import { ShowToastEvent } from 'lightning/platformShowToastEvent';

// const columns = [
//     { label: 'Name', fieldName: 'Name' },
//     { label: 'Phone', fieldName: 'Phone' },
//     { label: 'Account Number', fieldName: 'AccountNumber' }
// ];

// export default class CSVFileUploaderLWC extends LightningElement {
//     @api recordid;
//     @track columns = columns;
//     @track data;
//     @track fileName = 'No file selected';
//     @track showSpinner = false;
//     filesUploaded = [];
//     file;
//     fileReader;
//     MAX_FILE_SIZE = 1500000; // 1.5MB Limit

//     handleFilesChange(event) {
//         if (event.target.files.length > 0) {
//             this.filesUploaded = event.target.files;
//             this.fileName = event.target.files[0].name;
//         }
//     }

//     handleSave() {
//         if (this.filesUploaded.length > 0) {
//             this.uploadHelper();
//         } else {
//             this.showToast('Error', 'Please select a CSV file to upload!', 'error', 'dismissable');
//         }
//     }

//     uploadHelper() {
//         this.file = this.filesUploaded[0];
//         if (this.file.size > this.MAX_FILE_SIZE) {
//             this.showToast('Error', 'File size exceeds the 1.5MB limit!', 'error', 'dismissable');
//             return;
//         }
//         this.showSpinner = true;
//         this.fileReader = new FileReader();
//         this.fileReader.onloadend = (() => {
//             let fileContents = this.fileReader.result;
//             this.processCSV(fileContents);
//         });
//         this.fileReader.readAsText(this.file);
//     }

//     processCSV(fileContents) {
//         try {
//             let csvData = fileContents.trim();
//             if (!csvData) {
//                 throw new Error("CSV file is empty.");
//             }

//             let csvLines = csvData.split(/\r?\n/);
//             if (csvLines.length < 2) { 
//                 throw new Error("CSV file must have at least one data row.");
//             }

//             // Send data to Apex
//             this.saveToFile(csvLines);
//         } catch (error) {
//             console.error('CSV Processing Error:', error);
//             this.showToast('Error', error.message, 'error', 'dismissable');
//             this.showSpinner = false;
//         }
//     }

//     saveToFile(csvLines) {
//         createAccountRecords({ base64Data: JSON.stringify(csvLines), cdbId: this.recordid })
//             .then(result => {
//                 console.log('Upload Success:', result);
//                 this.data = result;
//                 this.fileName += ' - Uploaded Successfully';
//                 this.showToast('Success', this.file.name + ' - Uploaded Successfully!!!', 'success', 'dismissable');
//             })
//             .catch(error => {
//                 console.error('Upload Error:', error);
//                 let errorMsg = error.body ? error.body.message : 'Unknown error';
//                 this.showToast('Error while uploading File', errorMsg, 'error', 'dismissable');
//             })
//             .finally(() => {
//                 this.showSpinner = false;
//             });
//     }

//     showToast(title, message, variant, mode) {
//         this.dispatchEvent(new ShowToastEvent({
//             title: title,
//             message: message,
//             variant: variant,
//             mode: mode
//         }));
//     }
// }