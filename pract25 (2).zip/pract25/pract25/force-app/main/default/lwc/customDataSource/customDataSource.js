import { LightningElement, track } from 'lwc';
import saveDataSource from '@salesforce/apex/DataSourceController.saveDataSource';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import * as XLSX from 'xlsx';

export default class CustomDataSource extends LightningElement {
    @track name = '';
    @track description = '';
    @track fileData = [];
    @track insertedRecords = [];

    handleInputChange(event) {
        const field = event.target.name;
        if (field === 'name') {
            this.name = event.target.value;
        } else if (field === 'description') {
            this.description = event.target.value;
        }
    }

    handleFileUpload(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                const sheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[sheetName];
                const jsonData = XLSX.utils.sheet_to_json(worksheet);

                this.fileData = jsonData.map(row => ({
                    team: row.TeamName,
                    latitude: row.Latitude,
                    longitude: row.Longitude
                }));
            };
            reader.readAsArrayBuffer(file);
        }
    }

    handleSave() {
        if (!this.name || !this.description || this.fileData.length === 0) {
            this.showToast('Error', 'Please provide Name, Description, and upload a valid file', 'error');
            return;
        }
        
        saveDataSource({
            name: this.name,
            description: this.description,
            data: this.fileData
        })
        .then(() => {
            this.showToast('Success', 'Data Source saved successfully!', 'success');
            this.insertedRecords = [...this.fileData];
            this.clearForm();
        })
        .catch(error => {
            this.showToast('Error', error.body.message, 'error');
        });
    }

    clearForm() {
        this.name = '';
        this.description = '';
        this.fileData = [];
        this.template.querySelector('form').reset();
    }

    showToast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({
            title,
            message,
            variant
        }));
    }
}