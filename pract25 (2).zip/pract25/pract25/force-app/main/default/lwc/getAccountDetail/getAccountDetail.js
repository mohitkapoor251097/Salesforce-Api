import { LightningElement,wire,api } from 'lwc';
import { getFieldValue, getRecord } from 'lightning/uiRecordApi';
import ACCOUNT_NAME from '@salesforce/schema/Account.Name';
import ACCOUNT_RATING from '@salesforce/schema/Account.Rating';
export default class GetAccountDetail extends LightningElement {

@api recordId;
    @wire(getRecord,{recordId:'$recordId',fields:[ACCOUNT_NAME,ACCOUNT_RATING]})
    account;

    get accountName(){
        return this.account.data.fields.Name.value;
    }

    get accRating(){
        return getFieldValue(this.account.data,ACCOUNT_RATING);
    }
    // const isInputsCorrect = [...this.template.querySelectorAll('lightning-input')]
    // .reduce((validSoFar, inputField) => {
    //     inputField.reportValidity();
    //     return validSoFar && inputField.checkValidity();
    // }, true);
}