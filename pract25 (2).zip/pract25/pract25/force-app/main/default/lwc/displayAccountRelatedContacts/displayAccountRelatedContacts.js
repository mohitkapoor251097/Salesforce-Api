import { LightningElement, wire } from 'lwc';
import getAccounts from '@salesforce/apex/AccountController.getAccounts';
import getContacts from '@salesforce/apex/AccountController.getContacts';

export default class DisplayAccountRelatedContacts extends LightningElement {

    columns=[
        {label:'Contact Name',fieldName:'Name'},
        {label:'Email',fieldName:'Email',type:'email'},
        {label:'Account Name',fieldName:'AccountName'}
    ]
    accountId;
    accountList=[];
    contactList=[];
    connectedCallback(){
        getAccounts().then((account)=>{
            this.accountList=account.map((currItem)=>({
                label:currItem.Name,
                value:currItem.Id
            }))
        })
    }

    changleHandler(event){
        this.accountId=event.target.value;
        console.log(event.target.value);
    }

    @wire(getContacts,{accId:'$accountId'})
    contacts({data,error}){
        if(data){
            this.contactList=data.map((currItem)=>{
                let updatedObject={};
                if(!currItem.hasOwnProperty('Email')){
                    updatedObject={...currItem,AccountName:currItem.Account?.Name,Email:'test@gmail.com'};
                }
                else{
                    updatedObject={...currItem,AccountName:currItem.Account?.Name};
                }
                return updatedObject;
            });

        //     this.contactList=data.map((contact)=>({
        //   ...contact,
        //         AccountName:contact.Account?.Name
        //     }))
        }
        else if(error){
               console.log('OUTPUT : ',JSON.stringify(error));
        }
    }
}