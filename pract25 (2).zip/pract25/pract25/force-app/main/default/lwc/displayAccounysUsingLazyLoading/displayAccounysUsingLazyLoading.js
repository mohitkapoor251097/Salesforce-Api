import { LightningElement } from 'lwc';
import getAccounts from '@salesforce/apex/AccountLazyLoadingController.getAccounts';
import getAccountsOnLoadMore from '@salesforce/apex/AccountLazyLoadingController.getAccountsOnLoadMore';
import totalAccounts from '@salesforce/apex/AccountLazyLoadingController.countOfAccounts';
export default class DisplayAccounysUsingLazyLoading extends LightningElement {


    accountData = [];
    totalRecord;
    loadedRecord;
    get Columns() {
        return [
            { label: 'Account Name', fieldName: 'Name' },
            { label: 'Rating', fieldName: 'Rating' }
        ]
    }

    connectedCallback() {
        this.getAccounts();
    }


    async getAccounts() {
        try {
            this.accountData = await getAccounts();
            this.totalRecord = await totalAccounts();
            this.loadedRecord = this.accountData.length;
        }
        catch (ex) {
            console.log(`error loading accounts: ${ex}`);
        }
    }

    async loadMoreData(event) {
        try {
            console.log('OUTPUT load : ');
            const { target } = event;
            target.isLoading = true;
            let currentRecord = this.accountData;
            let lastRecord = currentRecord[currentRecord.length - 1];
            let newRecord = await getAccountsOnLoadMore({ lastId: lastRecord.Id });
            this.accountData = [...currentRecord, ...newRecord];
            this.loadedRecord = this.accountData.length;
            target.isLoading = false;
        }
        catch (ex) {
            console.log(`error loading more accounts: ${ex}`);
        }
    }

}