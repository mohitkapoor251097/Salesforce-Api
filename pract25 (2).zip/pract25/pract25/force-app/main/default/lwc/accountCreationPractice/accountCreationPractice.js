import { LightningElement,track,wire} from 'lwc';
import ACCOUNT_NAME from '@salesforce/schema/Account.Name';
import ACCOUNT_RATING from '@salesforce/schema/Account.Rating';
import ACCOUNT_INDUSTRY from '@salesforce/schema/Account.Industry';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import { createRecord } from 'lightning/uiRecordApi';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import getAccountDetails from '@salesforce/apex/AccountDetails.getAccounts';
import { getObjectInfo, getPicklistValues, getPicklistValuesByRecordType } from 'lightning/uiObjectInfoApi';
export default class AccountCreationPractice extends LightningElement {

   @track accdetails={
        AccountName: "",
        accrating:'',
        industry:''
    }

    @wire(getObjectInfo,{objectApiName:ACCOUNT_OBJECT})
    accountInfo;

    @wire(getPicklistValues,{
        recordTypeId:'$accountInfo.data.defaultRecordTypeId',
        fieldApiName:ACCOUNT_RATING
    })
    ratingvalues;

    @wire(getPicklistValuesByRecordType,{
        recordTypeId:'$accountInfo.data.defaultRecordTypeId',
        objectApiName:ACCOUNT_OBJECT
    })
    industryvalues;

    get IndustryData(){
        return this.industryvalues?.data?.picklistFieldValues.Industry.values;
    }

    handleChange(event){
        this.accdetails[event.target.name]=event.target.value.trim();
        console.log('AccountName'+this.accdetails.AccountName);
        console.log('AccountName'+this.accdetails.accrating);
        console.log('AccountName'+this.accdetails.industry);
        
    }

    @wire(getAccountDetails,{accRating:'$accdetails.accrating'})
    accountData({data,error}){
        if(data){
            console.log('Account Data'+ JSON.stringify(data));
            
        }
        else if(error){
           console.log('error');
           
        }
    }

    handleClick(event){
        let fieldError='Please Enter';
        let isValid=true;
        this.template.querySelectorAll('lightning-input').forEach((item)=>{
           let fieldValue=item.value.trim();
           let errorMessage=!fieldValue ? `${fieldError} ${item.label}` :'';
           item.setCustomValidity(errorMessage);
           item.reportValidity();
           if(errorMessage) isValid=false;

        });
        if(isValid){
            let inputfields={};
            inputfields[ACCOUNT_NAME.fieldApiName]=this.accdetails.AccountName;
            inputfields[ACCOUNT_RATING.fieldApiName]=this.accdetails.accrating;
            inputfields[ACCOUNT_INDUSTRY.fieldApiName]=this.accdetails.industry;

            let recordInput={
                fields:inputfields,
                apiName:ACCOUNT_OBJECT.objectApiName
            }

            createRecord(recordInput).then((result)=>{
               console.log('Account cReated Successfully !');
               this.showMessage('success','success',`Account created Successfully ! ${result.id}`);
            }).catch((error)=>{
                this.showMessage('error','error','Something went wrong on server side.')
            })
        }

    }

    showMessage(variant,message,title){
       this.dispatchEvent(new ShowToastEvent({
        title:title,
        message:message,
        variant:variant
       }));
    }
    
}