import { LightningElement } from 'lwc';

export default class Child extends LightningElement {

    changeHandler(event){
        this.dispatchEvent(new CustomEvent('senddata',{
            detail:{
                message:event.target.value
            },
            bubbles:true,
            composed:true
        }))
    }
}