import { LightningElement } from 'lwc';

export default class Checkmodeltest extends LightningElement {}