import { LightningElement,wire,track } from 'lwc';
import getContacts from '@salesforce/apex/AccountFetchController.getContacts';
import{ refreshApex } from '@salesforce/apex';
import { deleteRecord } from 'lightning/uiRecordApi';
const colums=[
    {label:'Contact Name',fieldName:'LastName'},
    {label:'Account Name',fieldName:'AccountName'}
]
export default class GetContacts extends LightningElement {

    userDetails=[
        {id:'1',name:'Jai'},
        {id:'2',name:'Viay'},
        {id:'3',name:'Sohan'},
        {id:'4',name:'Raj'},
    ]
colums=colums
@track mainResult;
@track data;
error;
@track selectedRecord;
    @wire(getContacts)
    contacts(result){
        this.mainResult=result;
        if(result.data){
            console.log(JSON.stringify(result.data));
            this.data=result.data.map(con=>({
                ...con,AccountName:con.Account?.Name
            }));
        }
        else if(result.error){
            console.log(JSON.stringify(result.error));
            this.error=result.error;
        }
        //refreshApex(this.mainResult);
    }
    handelSelection(event) {
        if (event.detail.selectedRows.length > 0) {
          this.selectedRecord = event.detail.selectedRows[0].Id;
          console.log(this.selectedRecord);
        }
      }
      deleteRecord() {
        console.log('innser');
        deleteRecord(this.selectedRecord)
          .then(() => {
            console.log('innser');
            
            refreshApex(this.mainResult);
          })
          .catch(error => {
            console.error('Error deleting record: ' + JSON.stringify(error));
          })
      }
   
}