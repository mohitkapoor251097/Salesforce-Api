// import { LightningElement, wire } from 'lwc';
// import getAccounts from '@salesforce/apex/AccountLwcCtrl.getAccounts';
// import totalOppCountByAccount from '@salesforce/apex/AccountLwcCtrl.totalOppCountByAccount';
// export default class AccountComp extends LightningElement {

//     get columns(){
//         return [
//             {label:'Name',type: 'url',fieldName:'idLink',typeAttributes:{label:{fieldName:'Name'}}},
//             {label:'Rating',fieldName:'Rating'},
//             {label:'Opp Count',fieldName:'oppC'},
//         ]
//     }
//     mainResult=[];
//     accountlist=[];
//     @wire(getAccounts)
//     accountData(result){
//         this.mainResult=result;
//         if(result.data){
//            this.accountlist=result.data.map(item=>{
//             var obj=Object.assign({},item);
//             obj.idLink='/'+item.Id;
//             return obj;
//            });
//         }
//         else if(result.error){
//             console.error(result.error);
//         }
//     }

//    @wire(totalOppCountByAccount,{})
// totalopp({ data, error }) {
//     if (data) {
//         console.log('Received data: ', JSON.stringify(data));

//         // If accountlist is undefined, initialize it
//         if (!this.accountlist || this.accountlist.length === 0) {
//             this.accountlist = Object.keys(data).map(accountId => ({
//                 accountId, 
//                 oppC: data[accountId] || 0
//             }));
//             console.log('Initialized account list:', JSON.stringify(this.accountlist));
//         } else {
//             // Update existing accountlist with opportunity counts
//             this.accountlist = this.accountlist.map(acc => ({
//                 ...acc,
//                 oppC: data[acc.Id] || 0
//             }));
//             console.log('Updated existing account list:', JSON.stringify(this.accountlist));
//         }
//     } else if (error) {
//         console.error('Error fetching Opportunity counts by account: ', JSON.stringify(error));
//     }
// }

// }




// import { LightningElement, wire } from 'lwc';
// import getAccounts from '@salesforce/apex/AccountLwcCtrl.getAccounts';
// import totalOppCountByAccount from '@salesforce/apex/AccountLwcCtrl.totalOppCountByAccount';
// import { refreshApex } from '@salesforce/apex';

// export default class AccountComp extends LightningElement {
//     accountlist = [];
//     oppCountMap = {}; // Store opportunity count data separately

//     get columns() {
//         return [
//             { label: 'Name', type: 'url', fieldName: 'idLink', typeAttributes: { label: { fieldName: 'Name' } } },
//             { label: 'Rating', fieldName: 'Rating' },
//             { label: 'Total Opportunities', fieldName: 'oppC' }
//         ];
//     }

//     @wire(getAccounts)
//     accountData({ data, error }) {
//         if (data) {
//             console.log('Received Account Data:', JSON.stringify(data));

//             this.accountlist = data.map(item => ({
//                 ...item,
//                 idLink: '/' + item.Id,
//                 oppC: this.oppCountMap[item.Id] || 0 // Merge opportunity count if available
//             }));

//             console.log('Updated Account List:', JSON.stringify(this.accountlist));
//         } else if (error) {
//             console.error('Error fetching accounts:', JSON.stringify(error));
//         }
//     }

//     @wire(totalOppCountByAccount)
//     totalopp({ data, error }) {
//         if (data) {
//             console.log('Received Opportunity Counts:', JSON.stringify(data));

//             // Store opportunity counts separately
//             this.oppCountMap = data;

//             // If accountlist is already populated, update it immediately
//             if (this.accountlist.length > 0) {
//                 this.accountlist = this.accountlist.map(acc => ({
//                     ...acc,
//                     oppC: this.oppCountMap[acc.Id] || 0
//                 }));
//                 console.log('Updated Account List with Opportunity Counts:', JSON.stringify(this.accountlist));
//             }
//         } else if (error) {
//             console.error('Error fetching opportunity counts:', JSON.stringify(error));
//         }
//     }
// }



import { LightningElement, wire, track } from 'lwc';
import getAccounts from '@salesforce/apex/AccountLwcCtrl.getAccounts';
import totalOppCountByAccount from '@salesforce/apex/AccountLwcCtrl.totalOppCountByAccount';
import { NavigationMixin } from 'lightning/navigation';
import deleteAccountData from '@salesforce/apex/AccountLwcCtrl.deleteAccountData';
import { refreshApex } from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getAccountsOnLoadMore from '@salesforce/apex/AccountLazyLoadingController.getAccountsOnLoadMore';
import totalAccounts from '@salesforce/apex/AccountLazyLoadingController.countOfAccounts';

export default class AccountComp extends NavigationMixin(LightningElement) {
    @track accountlist = [];
    oppCountMap = {};
    @track wiredAccountsResult;
    totalRecord;
    loadedRecord;


    columns = [
        { label: 'Name', type: 'url', fieldName: 'idLink', typeAttributes: { label: { fieldName: 'Name' } } },
        { label: 'Rating', fieldName: 'Rating' },
        { label: 'Total Opportunities', fieldName: 'oppC' },
        {
            label: 'Actions',
            type: 'customPickList',
            fieldName: 'Id',
            typeAttributes: { recordId: { fieldName: 'Id' } }
        }
    ];
    connectedCallback() {
        this.getTotalAccountRecord();
    }

    async getTotalAccountRecord() {
        try {
            this.totalRecord = await totalAccounts();
        }
        catch (error) {
            console.error('Error fetching total account record:', JSON.stringify(error));
        }
    }
    handleContact(event) {
      //  alert('Contact called' + event.detail);
        this.navigateToNewContact(event.detail);
    }
    // Navigate to Contact standard create page
    navigateToNewContact(accountId) {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Contact',
                actionName: 'new'
            },
            state: {
                defaultFieldValues: `AccountId=${accountId}`
            }
        });
    }

    @wire(getAccounts)
    wiredAccounts(result) {
        this.wiredAccountsResult = result;
        if (result.data) {
            this.accountlist = result.data.map(item => ({
                ...item,
                idLink: '/' + item.Id,
                oppC: this.oppCountMap[item.Id] || 0
            }));
            this.loadedRecord = result.data.length;
            console.log('Updated Account List:', JSON.stringify(this.accountlist));
        } else if (result.error) {
            console.error('Error fetching accounts:', JSON.stringify(result.error));
        }
    }

    @wire(totalOppCountByAccount)
    wiredOppCount({ data, error }) {
        if (data) {
            console.log('Received Opportunity Counts:', JSON.stringify(data));
            this.oppCountMap = data;
            if (this.accountlist.length > 0) {
                this.accountlist = this.accountlist.map(acc => ({
                    ...acc,
                    oppC: this.oppCountMap[acc.Id] || 0
                }));
                console.log('Updated Account List with Opportunity Counts:', JSON.stringify(this.accountlist));
            }
        } else if (error) {
            console.error('Error fetching opportunity counts:', JSON.stringify(error));
        }
    }

    // handleNewContact(event) {
    //     const accountId = event.detail;
    //     this.dispatchEvent(
    //         new ShowToastEvent({
    //             title: 'New Contact',
    //             message: `Create new contact for Account ID: ${accountId}`,
    //             variant: 'info'
    //         })
    //     );
    // }

    handleDelete(event) {
       // alert('delete called' + event.detail);
        let filterAccount = this.accountlist.filter((acc) => acc.Id === event.detail);
        console.log('filter Account' + JSON.stringify(filterAccount));

        deleteAccountData({ acc: filterAccount })
            .then(() => {
                this.showMessage('Success', 'Account deleted successfully!', 'success');
                this.accountlist = this.accountlist.filter((acc) => acc.Id !== event.detail);
                this.totalRecord--;
                return refreshApex(this.wiredAccountsResult);
            })
            .catch(error => {
                console.error('Error deleting account:', JSON.stringify(error));
                this.showMessage('Error', error.body.message, 'error');
            });
    }

    showMessage(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        }));

    }

    async loadMoreData(event) {
        let { target } = event;
        target.isLoading = true;

        if (!this.accountlist || this.accountlist.length === 0) {
            target.isLoading = false;
            return;
        }

        let lastRecord = this.accountlist[this.accountlist.length - 1]; // Get the last record correctly
        let newRecords = await getAccountsOnLoadMore({ lastId: lastRecord.Id });

        if (newRecords && newRecords.length > 0) {
            this.accountlist = [...this.accountlist, ...newRecords].map(acc => ({
                ...acc,
                idLink: '/' + acc.Id, // Corrected variable reference
                oppC: this.oppCountMap[acc.Id] || 0
            }));
        }

        this.loadedRecord = this.accountlist.length;
        target.isLoading = false;
    }
}


