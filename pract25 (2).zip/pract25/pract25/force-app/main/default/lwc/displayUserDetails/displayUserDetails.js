import { LightningElement } from 'lwc';
import getUserData from '@salesforce/apex/UserDetailsController.getUserData';
export default class DisplayUserDetails extends LightningElement {
    userDetails = [];
    recordsize = 5;
    totalPages = 0;
    currentPage = 1;
    displayData = [];
    get columns() {
        return [
            { label: 'UserId', fieldName: 'UserId' },
            { label: 'Id', fieldName: 'Id' },
            { label: 'Title', fieldName: 'title' },
            {
                label: 'body',
                fieldName: 'body',
                wrapText: true,
                initialWidth: 400
            }
        ]
    }
    connectedCallback() {
        this.loadUserData();
    }

    async loadUserData() {
        try {
            let data = await getUserData();
            this.userDetails = data.map((item) => {
                return {
                    UserId: item.userId,
                    Id: item.id,
                    title: item.title,
                    body: item.body
                }
            });
            this.totalPages = Math.ceil(this.userDetails.length / this.recordsize);
            this.updateData();
            console.log('user data' + JSON.stringify(this.userDetails));

        }
        catch (error) {
            console.error('error occur during load user data', error);
        }
    }

    updateData() {
        let start = (this.currentPage - 1) * this.recordsize;
        let end = start + this.recordsize;
        this.displayData = this.userDetails.slice(start, end);

    }

    get disablePrevious() {
        return this.currentPage === 1;
    }

    get disableNext() {
        return this.currentPage >= this.totalPages;
    }

    get disableFirst() {
        return this.currentPage === 1;
    }

    get disableLast() {
        return this.currentPage >= this.totalPages;
    }

    previousHandler() {
        this.currentPage--;
        this.updateData();
    }

    nextHandler() {
        this.currentPage++;
        this.updateData();
    }
    firstHandler() {
        this.currentPage = 1;
        this.updateData();
    }
    lastHandler() {
        this.currentPage = this.totalPages;
        this.updateData();
    }
}