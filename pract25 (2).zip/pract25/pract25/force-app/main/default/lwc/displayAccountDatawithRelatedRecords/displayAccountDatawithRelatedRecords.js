import { LightningElement } from 'lwc';
import getAccounts from '@salesforce/apex/AccountDisplayController.getAccounts';
export default class DisplayAccountDatawithRelatedRecords extends LightningElement {
    accounts=[]
    accountId;
    get columns(){

        return [
            {label: 'Account Name', fieldName: 'Name',type:'text'},
    ]
    }
connectedCallback(){
    this.showAccounts();

}

async showAccounts(){

this.accounts = await getAccounts();

}

selectionHandler(event){
    alert('dubug'+ event.detail.selectedRows.length);
    this.accountId= event.detail.selectedRows[0].Id;
   // alert('Id'+this.accountId);
}

}