import { LightningElement } from 'lwc';
export default class ParentCsvUploader extends LightningElement {
    objectName = 'Custom_Data_Sources__c';
    connectedCallback() {
        console.log('objectName in parent:', this.objectName); // Log to ensure it's defined
    }
}