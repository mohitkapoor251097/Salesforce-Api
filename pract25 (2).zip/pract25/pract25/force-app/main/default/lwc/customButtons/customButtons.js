import { LightningElement, api } from 'lwc';

export default class CustomButtons extends LightningElement {
    @api recordId; // ✅ Ensure recordId is received

    handleNewContact(event) {
        console.log(`Creating Contact for Account ID: ${this.recordId}`);
        // Implement your logic
    }

    handleDelete(event) {
        console.log(`Deleting Account ID: ${this.recordId}`);
        // Implement your logic
    }
}
