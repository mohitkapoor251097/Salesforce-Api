import { LightningElement } from 'lwc';

export default class ParentComp extends LightningElement {

    enteredNumber;
    handleChange(event) {
        this.enteredNumber = event.target.value;
    }
}