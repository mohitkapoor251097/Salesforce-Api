import Name from '@salesforce/schema/Contact.Name';
import { LightningElement,api } from 'lwc';

export default class ChildData extends LightningElement {

    @api nameValue;
    clickHandler(){
        let name=this.nameValue;
        this.dispatchEvent(new CustomEvent('send',{
            detail:this.nameValue.toUpperCase()
        }));
    }

}