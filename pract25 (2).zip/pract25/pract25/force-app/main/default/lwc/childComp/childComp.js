import { LightningElement, api } from 'lwc';

export default class ChildComp extends LightningElement {

   isEven;

    @api 
    set number(value) {
        this.isEven = value % 2 === 0;
    }

    get number() {
        return this.isEven;
    }
}