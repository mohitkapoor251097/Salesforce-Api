import { LightningElement, wire } from 'lwc';
import getCases from '@salesforce/apex/CaseDashboardController.getCases';
import CASE_OBJECT from '@salesforce/schema/Case';
import STATUS_FIELD from '@salesforce/schema/Case.Status';
import { getObjectInfo, getPicklistValues } from 'lightning/uiObjectInfoApi';

export default class CaseDashboard extends LightningElement {
    statusOptions = [];
    ownerOptions = [];
    columns = [];
    cases = [];
    filterCases = [];
    statasValue;
    ownerValue;

    columns = [
        { label: 'Case Number', fieldName: 'CaseNumber', type: 'text' },
        { label: 'Subject', fieldName: 'Subject', type: 'text' },
        { label: 'Priority', fieldName: 'Priority', type: 'text' },
        { label: 'Status', fieldName: 'Status', type: 'text' },
        { label: 'Owner', fieldName: 'Owner', type: 'text' }
    ];

    handleChange(event) {
        const { name, value } = event.target;

        if (name === 'status') {
            this.statusValue = value;
        } else if (name === 'owner') {
            this.ownerValue = value;
        }

         // Apply the filter based on the selection.
// 1. Save the result from the Apex
let result = [...this.filteredCases];

// 2. Apply status filter if selected
if (this.statusValue) {
    result = result.filter(item => item.Status === this.statusValue);
}

// 3. Apply owner filter if selected
if (this.ownerValue) {
    result = result.filter(item => item.OwnerId === this.ownerValue);
}

// Update the displayed cases
this.cases = [...result];

    }


    @wire(getObjectInfo, {
        objectApiName: CASE_OBJECT
    })
    objectInfo;

    @wire(getPicklistValues, {
        recordTypeId: '$objectInfo.data.defaultRecordTypeId',
        fieldApiName: STATUS_FIELD
    })
    statusFunction({ data, error }) {
        if (data) {
            const statusOptionsList = data.values.map(item => ({
                label: item.label,
                value: item.value
            }));

            const allOption = [{ label: 'All', value: '' }];
            this.statusOptions = [...allOption, ...statusOptionsList];
        } else if (error) {
            console.error('Error while fetching picklist data:', error);
        }
    }


    get isCases() {
        return this.cases.length > 0;
    }

    connectedCallback() {
        this.fetchCases();
    }

    async fetchCases() {
        try {
            const caseData = await getCases();
            this.cases = caseData.map(currItem => ({
                Id: currItem.Id,
                CaseNumber: currItem.CaseNumber,
                Subject: currItem.Subject,
                Priority: currItem.Priority,
                Status: currItem.Status,
                OwnerId: currItem.OwnerId,
                Owner: currItem.Owner.Name
            }));

            this.setOwnerOptions();
            this.filterCases = [...this.cases];
        } catch (error) {
            console.error('Error fetching cases: ', error);
        }
    }

    setOwnerOptions() {
        const ownerIds = this.cases.map(caseRec => caseRec.OwnerId);
        const uniqueOwnerIds = [...new Set(ownerIds)];

        const ownerOptions = uniqueOwnerIds.map(ownerId => {
            const matchedCase = this.cases.find(caseRec => caseRec.OwnerId === ownerId);
            const ownerName = matchedCase?.Owner || 'Unknown';
            return {
                label: ownerName,
                value: ownerId
            };
        });

        const allOption = [{ label: 'All', value: '' }];
        this.ownerOptions = [...allOption, ...ownerOptions];

        console.log('this.ownerOptions:', this.ownerOptions);
    }

}
