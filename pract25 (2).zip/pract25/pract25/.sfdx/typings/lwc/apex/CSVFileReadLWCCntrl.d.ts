declare module "@salesforce/apex/CSVFileReadLWCCntrl.csvFileRead" {
  export default function csvFileRead(param: {contentDocumentId: any}): Promise<any>;
}
