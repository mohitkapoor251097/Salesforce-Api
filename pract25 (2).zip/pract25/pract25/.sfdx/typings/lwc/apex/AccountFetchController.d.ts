declare module "@salesforce/apex/AccountFetchController.getContacts" {
  export default function getContacts(): Promise<any>;
}
declare module "@salesforce/apex/AccountFetchController.getAccounts" {
  export default function getAccounts(): Promise<any>;
}
declare module "@salesforce/apex/AccountFetchController.updateAccount" {
  export default function updateAccount(param: {acc: any}): Promise<any>;
}
