declare module "@salesforce/apex/AccountDataCreateByCSV.createAccountRecords" {
  export default function createAccountRecords(param: {base64Data: any}): Promise<any>;
}
