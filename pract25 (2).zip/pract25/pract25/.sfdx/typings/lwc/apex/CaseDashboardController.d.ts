declare module "@salesforce/apex/CaseDashboardController.getCases" {
  export default function getCases(): Promise<any>;
}
