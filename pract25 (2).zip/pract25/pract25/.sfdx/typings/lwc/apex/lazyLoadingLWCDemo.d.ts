declare module "@salesforce/apex/lazyLoadingLWCDemo.getAccounts" {
  export default function getAccounts(param: {limitSize: any, offset: any}): Promise<any>;
}
