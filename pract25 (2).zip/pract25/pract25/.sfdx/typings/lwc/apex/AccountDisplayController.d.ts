declare module "@salesforce/apex/AccountDisplayController.getAccounts" {
  export default function getAccounts(): Promise<any>;
}
declare module "@salesforce/apex/AccountDisplayController.getContacts" {
  export default function getContacts(param: {accId: any}): Promise<any>;
}
