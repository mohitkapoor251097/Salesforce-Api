declare module "@salesforce/apex/AccountLazyLoadingController.getAccounts" {
  export default function getAccounts(): Promise<any>;
}
declare module "@salesforce/apex/AccountLazyLoadingController.getAccountsOnLoadMore" {
  export default function getAccountsOnLoadMore(param: {lastId: any}): Promise<any>;
}
declare module "@salesforce/apex/AccountLazyLoadingController.countOfAccounts" {
  export default function countOfAccounts(): Promise<any>;
}
