declare module "@salesforce/apex/ContactController.fetchContacts" {
  export default function fetchContacts(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/ContactController.dmlOnContacts" {
  export default function dmlOnContacts(param: {data: any, removeContactIds: any}): Promise<any>;
}
