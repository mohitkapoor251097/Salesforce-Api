declare module "@salesforce/apex/DataSourceController.saveDataSource" {
  export default function saveDataSource(param: {name: any, description: any, data: any}): Promise<any>;
}
