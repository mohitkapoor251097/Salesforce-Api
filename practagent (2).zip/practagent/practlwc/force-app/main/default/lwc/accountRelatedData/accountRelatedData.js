import { LightningElement, wire } from 'lwc';
import getAcounts from '@salesforce/apex/AccountRelatedDataController.getAccounts';
import getRelatedRecords from '@salesforce/apex/AccountRelatedDataController.getRelatedRecords';
export default class AccountRelatedData extends LightningElement {
  accountsOptions;
  error;
  contacts=[];
  cases=[];

  get casesColumn(){
    return [
        {label: 'Case Number', fieldName: 'CaseNumber'},
        {label: 'Case Subject', fieldName: 'Subject'},
        {label: 'Case Status', fieldName: 'Status'},

    ]
  }
  get contactsColumn(){
    return [
        {label: 'Fitst Name', fieldName: 'FirstName'},
        {label: 'Last Name', fieldName: 'LastName'},
        {label: 'Phone', fieldName: 'Phone',type:'phone'},
        {label: 'Email', fieldName: 'Email',type:'email'},
    ]
  }
    @wire(getAcounts)
    accounts({data,error}){
        if(data){
            this.accountsOptions= data.map((currItem)=>({
               label:currItem.Name,
               value:currItem.Id
            }));
        }
        else if(error){
            this.error=error;
            console.error(error);
        }
    }
   async  handleChange(event){
        let accountId=event.target.value;
       console.log('OUTPUT : ',event.target.value);
      try{
           let result =await getRelatedRecords({accountId:accountId});
           console.log('OUTPUT : ',JSON.stringify(result));
           this.cases=result.cases;
           this.contacts=result.contacts;
      }catch(error){
        console.error(error);
      }
    }
}