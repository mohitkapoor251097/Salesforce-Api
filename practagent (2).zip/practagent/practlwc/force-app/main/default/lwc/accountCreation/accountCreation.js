import { LightningElement } from "lwc";
import createAccount from "@salesforce/apex/AccountController.createAccount";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import ACCOUNT_NAME from '@salesforce/schema/Account.Name';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import { createRecord } from "lightning/uiRecordApi";
export default class AccountCreation extends LightningElement {
    accDetail = {
        accName: ""
    };
    handleChangle(event) {
        this.accDetail[event.target.name] = event.target.value;
        console.log("OUTPUT : ", this.accDetail.accName);
    }

    async handleSave() {
        let isValid = true;
        let fieldMsg = "Please Enter";
        this.template.querySelectorAll("lightning-input").forEach((item) => {
            let fieldValue = item.value.trim();
            let errorMessage = !fieldValue ? `${fieldMsg} ${item.label}` : "";
            if (errorMessage) isValid = false;

            item.setCustomValidity(errorMessage);
            item.reportValidity();
        });
        if(isValid){
        let inputFields={};
        inputFields[ACCOUNT_NAME.fieldApiName]=this.accDetail.accName;

        let recordInput={
            apiName:ACCOUNT_OBJECT.objectApiName,
            fields:inputFields
        }

        createRecord(recordInput).then((result)=>{
              this.showMessage(
                        "success",
                        `Account Created Successfull ! ${result.id}`,
                        "success"
                    );
        }).catch(()=>{
              this.showMessage(
                    "error",
                    `something went wrong on server side`,
                    "error"
                );
                console.log("Error while creating Account : ", JSON.stringify(error));
        })
        }
       /* if (isValid) {
            console.log("valid Account Details : ", this.accDetail.accName);
            try {
                await createAccount({ accMap: this.accDetail }).then(() => {
                    this.showMessage(
                        "success",
                        `Account Created Successfull !`,
                        "success"
                    );
                });
            } catch (error) {
                this.showMessage(
                    "error",
                    `something went wrong on server side`,
                    "error"
                );
                console.log("Error while creating Account : ", JSON.stringify(error));
            }
        }*/
    }

    showMessage(variant, message, title) {
        this.dispatchEvent(
            new ShowToastEvent({
                variant: variant,
                message: message,
                duration: 3000,
                title: title
            })
        );
    }
}
