import { LightningElement, wire } from 'lwc';
import getAccounts from '@salesforce/apex/AccountData.getAccounts';
import { deleteRecord } from 'lightning/uiRecordApi';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import {refreshApex} from '@salesforce/apex';
export default class Dislayaccountswithaction extends LightningElement {
 actions=[
    {label:'View',name:'view'},
    {label:'Edit',name:'edit'},
    {label:'Delete',name:'delete'}
 ]
    @wire(getAccounts)
    accounts;


    get columns(){
        return [
            {label:'Account Name',fieldName:'Name',type:'text'},
            {label:'Phone',fieldName:'Phone',type:'phone'},
            {type:'action',typeAttributes:{rowActions:this.actions}},
            {type:'button',
                typeAttributes:{
                label:'Delete',
                name:'delete',
                variant:'brand',
                title:'Delete',
                iconPosition:'left'
            }
            }
        ]
    }
    get isAccounts(){
        return this.accounts.data && this.accounts.data.length> 0  || [];
    }

    handleAction(event){
        const action=event.detail.action;
        const row=event.detail.row;
        switch (action.name){
            case 'view':{
                alert('in view'+row.Id);
                break;
            }
            case 'edit':{
                alert('in edit'+row.Id);
                break;
            }
            case 'delete':{
                this.deleteAccountRecord(row.Id);
                break;
            }
        }
    }

    async deleteAccountRecord(accountId){
         await deleteRecord(accountId).then(()=>{
               this.showMessage('success','success','Account Deleted Successfully !');
               refreshApex(this.accounts);
         }).catch((error)=>{
           this.showMessage('error','error',error.body.message);
         })
    }

    showMessage(title,variant,message){
    this.dispatchEvent(new ShowToastEvent({
        title:title,
        variant:variant,
        message:message,
        mode:'dismissable'

    }))
    }
}