import { LightningElement } from 'lwc';

export default class Checkval extends LightningElement {

      accountDetails={
        fname:'',
        lname:''
      }

    handleChange(event){
        const {name,value} =event.target;
        this.accountDetails={
            ...this.accountDetails,[name]:value.trim()
        }
        console.log('fname : ',this.accountDetails.fname);
        console.log('lname : ',this.accountDetails.lname);
    }

    userDetail=[
        {id:'1',fname:'John',lname:'Doe'},
        {id:'2',fname:'Jane',lname:'Doe'} ,
    ]
}