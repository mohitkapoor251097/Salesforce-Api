import { LightningElement } from 'lwc';

export default class Parent1 extends LightningElement {}