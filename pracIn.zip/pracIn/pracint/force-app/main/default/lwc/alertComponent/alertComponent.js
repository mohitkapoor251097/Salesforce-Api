import { LightningElement, track } from 'lwc';

export default class AlertComponent extends LightningElement {
    @track showAlert = false;

    connectedCallback() {
        // Show the alert when the component is initialized
        this.showAlert = true;
    }

    closeAlert() {
        this.showAlert = false;
    }
}