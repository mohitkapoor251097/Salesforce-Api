import { LightningElement,api} from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
export default class RecordForm extends NavigationMixin(LightningElement) {
    
    @api recordId;
    @api objectApiName;


    navigateToRecordPage(event){
        let pageRef={
          type: 'standard__recordPage',
          attributes: {
              recordId: event.detail.id,
              objectApiName:this.objectApiName,
              actionName: 'view'
          }
      };
      this[NavigationMixin.Navigate](pageRef);
          }
        }