import { LightningElement,wire } from 'lwc';
import getContactList from '@salesforce/apex/ContactController.getContactList';
export default class ContactList extends LightningElement {

 @wire(getContactList) 
 contacts;
 selectedContacts;

 selectionHandler(event){
    const selectionContactId=event.detail;
    console.log("-------"+selectionContactId);
    this.selectedContacts=this.contacts.data.find((currItem)=> currItem.Id===selectionContactId);
 }

}