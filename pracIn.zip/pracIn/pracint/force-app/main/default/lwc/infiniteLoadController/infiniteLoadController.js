import { LightningElement } from 'lwc';

export default class InfiniteLoadController extends LightningElement {}