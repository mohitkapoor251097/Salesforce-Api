import { LightningElement, wire } from 'lwc';
import { MessageContext, publish} from 'lightning/messageService';
import channelName from '@salesforce/messageChannel/sendmessage__c';
export default class PubCompnent extends LightningElement {

    @wire(MessageContext)
    messageContext;

    publishData(){
       const payload={
        firstName:'Mohit',
        lastName:'Kapoor'
       }
       publish(this.messageContext,channelName,payload);
    }
}