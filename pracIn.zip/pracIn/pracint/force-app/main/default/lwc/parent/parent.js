import { LightningElement } from 'lwc';

export default class Parent extends LightningElement {
    greeting="Welcome Mohit";
    userDetail={
        firstname:'jai',
        lastname:'Kumar',
        age:26
    };

    message='User Detail';
}