
import { LightningElement } from 'lwc';

export default class ChildCustomEventDemo extends LightningElement {
    
}