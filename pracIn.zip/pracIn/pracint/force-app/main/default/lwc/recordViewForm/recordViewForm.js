import { LightningElement, api } from 'lwc';
import ACCOUNT_NAME from '@salesforce/schema/Account.Name';
import ACCOUNT_RATING from '@salesforce/schema/Account.Rating';
import ACCOUNT_INDUSTRY from '@salesforce/schema/Account.Industry';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent'
export default class RecordViewForm extends NavigationMixin(LightningElement) {
    @api recordId;
    @api objectApiName;

    fieldsList={
         Name:ACCOUNT_NAME,
         Rating:ACCOUNT_RATING
    }
    fields={
        name:ACCOUNT_NAME,
        industry:ACCOUNT_INDUSTRY
    };

    sucessHandler(event){
        let pageRef={
            type: 'standard__recordPage',
            attributes: {
                recordId: event.detail.id,
                objectApiName:this.objectApiName,
                actionName: 'view'
            }
        };
        this[NavigationMixin.Navigate](pageRef);
    }

    errorHandler(event){
         console.log(event.detail.message);
         const cusevent = new ShowToastEvent({
            title: 'Error',
            message:event.detail.message,
            variant:"error"
                
        });
        this.dispatchEvent(cusevent);
    }

    submitHandler(event){
        event.preventDefault();
        const fields=event.detail.fields;
        if(!fields.Industry){
            fields.Industry='Energy';
        }
        this.template.querySelector('lightning-record-edit-form').submit(fields);
    }

    clickHandler(){
        console.log('rest');
         let inputFields=this.template.querySelectorAll('lightning-input-field');
         inputFields.forEach((currItem)=> currItem.reset());
    }

//     submitHandler(event){
//    event.preventDefault();
//    const fields=event.detail.fields;
//    console.log('fields'+fields);
//      this.template.querySelector('lightning-record-edit-form').submit(fields);
//     }

//     resetHandler(){
//     //    const inputFieds=this.template.querySelectorAll('lightning-input-field');
//     //    inputFieds.forEach((currItem)=> currItem.reset());

//     let inputFields=this.template.querySelectorAll('lightning-input-field');
//          inputFields.forEach((currItem)=> currItem.reset());
//     }
    
}