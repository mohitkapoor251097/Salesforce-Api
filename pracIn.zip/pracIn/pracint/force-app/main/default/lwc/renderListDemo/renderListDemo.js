import { LightningElement } from 'lwc';

export default class RenderListDemo extends LightningElement {

    fruits=["Apple","Mango","Banana"];

    contactData=[
    {
        id:1,
        firstName:'Ram',
        lastName:'Kumar'
    },
    {
        id:2,
        firstName:'Raj',
        lastName:'singh'
    },
    {
        id:3,
        firstName:'sham',
        lastName:'lal'
    }
    ];
}