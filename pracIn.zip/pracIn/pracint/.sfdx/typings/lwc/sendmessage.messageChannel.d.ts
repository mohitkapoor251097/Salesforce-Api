declare module "@salesforce/messageChannel/sendmessage__c" {
    var sendmessage: string;
    export default sendmessage;
}