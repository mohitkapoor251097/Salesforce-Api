import { LightningElement,api } from 'lwc';

export default class Child extends LightningElement {
     @api display;
     @api user;
     
     messageData;
     @api
     get msg(){
         return this.messageData;
     }
     set msg(value){
         let cloneData=value.toUpperCase();
         this.messageData=cloneData;
  
     }
     
    
}