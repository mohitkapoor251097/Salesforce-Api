import { LightningElement, wire } from 'lwc';
import getAccountList from '@salesforce/apex/AccountHelper.getAccountList1';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import ACCOUNT_INDUSTRY from '@salesforce/schema/Account.Industry';
import { getObjectInfo, getPicklistValues, getPicklistValuesByRecordType } from 'lightning/uiObjectInfoApi';
const columns=[
    {label:'Name',fieldName:'Name'},
    {label:'Rating',fieldName:'Rating'},
    {label:'Industry',fieldName:'Industry'},
];
export default class ImperativeApexDemo extends LightningElement {

    @wire(getObjectInfo,{objectApiName:ACCOUNT_OBJECT})
    accountInfo;

    @wire(getPicklistValues,{
        recordTypeId:'$accountInfo.data.defaultRecordTypeId',
        fieldApiName:ACCOUNT_INDUSTRY

    })
    accountIndustryPickList;

    @wire(getPicklistValuesByRecordType,{
        objectApiName:ACCOUNT_OBJECT,
        recordTypeId:'$accountInfo.data.defaultRecordTypeId'
    })
    accountInfopickList;

    columns=columns
    accounts;
    error;
    value;
    clickHandler(){
        getAccountList({accIndustry:this.value}).then((result)=>{
        this.accounts=result;
        }).catch((error)=>{
          this.error=error;
        })
    }

    changeHandler(event){
      this.value=event.target.value;
    }
}