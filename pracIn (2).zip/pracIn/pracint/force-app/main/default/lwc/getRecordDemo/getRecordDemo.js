import { LightningElement,api,wire } from 'lwc';
import ACCOUNT_NAME from '@salesforce/schema/Account.Name';
import ACCOUNTINDUSTRY from '@salesforce/schema/Account.Industry';
import ANUAL from '@salesforce/schema/Account.AnnualRevenue';
import { getFieldDisplayValue, getFieldValue, getRecord } from 'lightning/uiRecordApi';
import { getObjectInfo, getPicklistValues, getPicklistValuesByRecordType } from 'lightning/uiObjectInfoApi';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
export default class GetRecordDemo extends LightningElement {

    @api recordId;
    accName;
    accountName;
    @wire(getRecord,{recordId:'$recordId',fields:[ACCOUNT_NAME,ANUAL ]})
    accountInfo;
    // accountInfo({data,error}){
    //     if(data){
    //        console.log(data.fields.AnnualRevenue.value);
    //        console.log(data.fields.Name.value);
    //        this.accName=data.fields.Name.value;
    //        this.accountName=getFieldValue(data,ACCOUNT_NAME);
    //     }
    //     else if(error){
    //        console.log(error);
    //     }
    // }

    get revenue(){
        return getFieldValue(this.accountInfo.data,ANUAL);
    }

    @wire(getObjectInfo,{objectApiName:ACCOUNT_OBJECT})
    accountObjectInfo;

    @wire(getPicklistValues,{
        recordTypeId:"$accountObjectInfo.data.defaultRecordTypeId",
        fieldApiName:ACCOUNTINDUSTRY 
    })
    accPickList;

    @wire(getPicklistValuesByRecordType,{
        objectApiName:ACCOUNT_OBJECT,
        recordTypeId:'$accountObjectInfo.data.defaultRecordTypeId'
    })
    accountPickList;

}