import { LightningElement } from 'lwc';

export default class ChildComposition extends LightningElement {

    clickHandler(){
        const custEvent=new CustomEvent('fire',{
            bubbles:true,
            composed:true
        })
        this.dispatchEvent(custEvent);
    }
}