import { LightningElement, wire } from 'lwc';
import { subscribe,MessageContext,unsubscribe } from 'lightning/messageService';
import channelName from '@salesforce/messageChannel/sendmessage__c';
export default class SubscribeComponent extends LightningElement {

    subscription=null;
    fName='';
    lName='';

    @wire(MessageContext)
    messageContext;

    connectedCallback(){
        console.log('in con');
        this.subscription=subscribe(this.messageContext,channelName,(message)=> this.callData(message));
    }

    callData(message){
        console.log('-----'+message.firstName+'--------'+message.lastName);
      this.fName=message.firstName;
     this.lName=message.lastName;
    }

disconnectedCallback(){
    unsubscribe(this.subscription);
    this.subscription=null;
}

}