import { LightningElement, wire } from 'lwc';
import getAccountList from "@salesforce/apex/AccountHelper.getAccountList";

const columns = [
    { label: "Name", fieldName: "Name" },
    { label: "Industry", fieldName: "Industry" },
    { label: "Rating", fieldName: "Rating" },
]
export default class WireDecoratorproperty extends LightningElement {

    accountsData;
    error;
    columns = columns;
    // @wire(getAccountList)
    // accounts;

    @wire(getAccountList)
    accountsData1({ data, error }) {
        if(data) {
           // this.accountsData = data;
            //this.error = undefined;
           
           let updatedAccount=data.map((curritem)=>{
            let updatedObject={};
                if(!curritem.hasOwnProperty('Rating')){
                    updatedObject={...curritem,Rating:'Warm'};

                }
                else{
                    updatedObject={...curritem};
                }
                return updatedObject;
            })
            this.accountsData=[...updatedAccount];
            this.error=null;
        }
        else if (error) {
            this.error = error;
            this.accountsData = undefined;
        }
    }

}