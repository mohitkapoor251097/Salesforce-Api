import { LightningElement } from 'lwc';

export default class ParentComposition extends LightningElement {

    fireChildHandler(){
console.log('Event handle in parent component at child level');
    }

    fireChildDivHandler(){
        console.log('Event handle in parent component at div level');
    }
}