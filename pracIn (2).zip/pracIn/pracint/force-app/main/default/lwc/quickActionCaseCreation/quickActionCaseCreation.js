import { LightningElement, api } from 'lwc';
import CASE_OBJECT from '@salesforce/schema/Case';
import CASE_STATUS from '@salesforce/schema/Case.Status';
import CASE_ORIGIN from '@salesforce/schema/Case.Origin';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import {CloseActionScreenEvent} from 'lightning/actions';
export default class QuickActionCaseCreation extends LightningElement {
    @api recordId;
    objectApiName=CASE_OBJECT;

    fieldList={
        status:CASE_STATUS,
        origin:CASE_ORIGIN
    }
    handlePanelOpen() {
        // Add a CSS class to the body to blur the background
        document.querySelector('.slds-scope').classList.add('blur-background');
    }

    handlePanelClose() {
        // Remove the CSS class from the body to remove the blur effect
        document.querySelector('.slds-scope').classList.remove('blur-background');

    }

    closeModel(){
        this.dispatchEvent(new CloseActionScreenEvent());
       }
    errorHandler(event){
        this.showToast(event.detail.message,'error','error');
    }
    successHandler(){
       this.showToast('Case Created Successfully','success','success');
       this.dispatchEvent(new CloseActionScreenEvent());
    }
    submitHandler(event){
        event.preventDefault();
        const fields=event.detail.fields;
        if(!fields.AccountId){
            fields.AccountId=this.recordId;
        }
        this.template.querySelector('lightning-record-edit-form').submit(fields);
    }

    showToast(message,title,variant){
        const sevent=new ShowToastEvent({
           message:message,
           title:title,
           variant:variant
        })
        this.dispatchEvent(sevent);
    }

    resetHandler(){
        const inputFields=this.template.querySelectorAll('lightning-input-field');
        inputFields.forEach((currItem) => currItem.reset());
    }
}